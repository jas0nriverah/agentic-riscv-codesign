	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.countnegative_initSeed,"ax",@progbits
	.align	2
	.globl	countnegative_initSeed
	.type	countnegative_initSeed, @function
countnegative_initSeed:
	lui	a5,%hi(countnegative_seed)
	sw	zero,%lo(countnegative_seed)(a5)
	ret
	.size	countnegative_initSeed, .-countnegative_initSeed
	.section	.text.countnegative_randomInteger,"ax",@progbits
	.align	2
	.globl	countnegative_randomInteger
	.type	countnegative_randomInteger, @function
countnegative_randomInteger:
	addi	sp,sp,-16
	sw	s0,8(sp)
	lui	s0,%hi(countnegative_seed)
	lw	a5,%lo(countnegative_seed)(s0)
	li	a1,8192
	addi	a1,a1,-97
	slli	a0,a5,5
	add	a0,a0,a5
	slli	a0,a0,2
	add	a0,a0,a5
	addi	a0,a0,81
	sw	ra,12(sp)
	call	__modsi3
	sw	a0,%lo(countnegative_seed)(s0)
	lw	a0,%lo(countnegative_seed)(s0)
	lw	ra,12(sp)
	lw	s0,8(sp)
	addi	sp,sp,16
	jr	ra
	.size	countnegative_randomInteger, .-countnegative_randomInteger
	.section	.text.countnegative_initialize,"ax",@progbits
	.align	2
	.globl	countnegative_initialize
	.type	countnegative_initialize, @function
countnegative_initialize:
	addi	sp,sp,-16
	sw	s0,8(sp)
	sw	s2,0(sp)
	sw	ra,12(sp)
	sw	s1,4(sp)
	mv	s0,a0
	addi	s2,a0,1600
.L5:
	addi	s1,s0,80
.L6:
	call	countnegative_randomInteger
	sw	a0,0(s0)
	addi	s0,s0,4
	bne	s0,s1,.L6
	bne	s2,s0,.L5
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s1,4(sp)
	lw	s2,0(sp)
	addi	sp,sp,16
	jr	ra
	.size	countnegative_initialize, .-countnegative_initialize
	.section	.text.countnegative_init,"ax",@progbits
	.align	2
	.globl	countnegative_init
	.type	countnegative_init, @function
countnegative_init:
	lui	a0,%hi(countnegative_array)
	lui	a5,%hi(countnegative_seed)
	addi	a0,a0,%lo(countnegative_array)
	sw	zero,%lo(countnegative_seed)(a5)
	tail	countnegative_initialize
	.size	countnegative_init, .-countnegative_init
	.section	.text.countnegative_return,"ax",@progbits
	.align	2
	.globl	countnegative_return
	.type	countnegative_return, @function
countnegative_return:
	lui	a5,%hi(countnegative_postotal)
	lw	a0,%lo(countnegative_postotal)(a5)
	lui	a5,%hi(countnegative_poscnt)
	lw	a5,%lo(countnegative_poscnt)(a5)
	add	a0,a0,a5
	lui	a5,%hi(countnegative_negtotal)
	lw	a5,%lo(countnegative_negtotal)(a5)
	add	a0,a0,a5
	lui	a5,%hi(countnegative_negcnt)
	lw	a5,%lo(countnegative_negcnt)(a5)
	add	a0,a0,a5
	li	a5,-1540096
	addi	a5,a5,1826
	add	a0,a0,a5
	snez	a0,a0
	neg	a0,a0
	ret
	.size	countnegative_return, .-countnegative_return
	.section	.text.countnegative_sum,"ax",@progbits
	.align	2
	.globl	countnegative_sum
	.type	countnegative_sum, @function
countnegative_sum:
	addi	a4,a0,80
	li	a3,0
	addi	a0,a0,1680
	li	a1,0
	li	a2,0
	li	a6,0
.L13:
	addi	a5,a4,-80
.L16:
	lw	a7,0(a5)
	blt	a7,zero,.L14
	add	a6,a6,a7
	addi	a1,a1,1
.L15:
	addi	a5,a5,4
	bne	a5,a4,.L16
	addi	a4,a5,80
	bne	a4,a0,.L13
	lui	a5,%hi(countnegative_postotal)
	sw	a6,%lo(countnegative_postotal)(a5)
	lui	a5,%hi(countnegative_poscnt)
	sw	a1,%lo(countnegative_poscnt)(a5)
	lui	a5,%hi(countnegative_negtotal)
	sw	a2,%lo(countnegative_negtotal)(a5)
	lui	a5,%hi(countnegative_negcnt)
	sw	a3,%lo(countnegative_negcnt)(a5)
	ret
.L14:
	add	a2,a2,a7
	addi	a3,a3,1
	j	.L15
	.size	countnegative_sum, .-countnegative_sum
	.section	.text.countnegative_main,"ax",@progbits
	.align	2
	.globl	countnegative_main
	.type	countnegative_main, @function
countnegative_main:
	lui	a0,%hi(countnegative_array)
	addi	a0,a0,%lo(countnegative_array)
	tail	countnegative_sum
	.size	countnegative_main, .-countnegative_main
	.section	.text.isaforge_tacle_original_main,"ax",@progbits
	.align	2
	.globl	isaforge_tacle_original_main
	.type	isaforge_tacle_original_main, @function
isaforge_tacle_original_main:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	countnegative_init
	call	countnegative_main
	lw	ra,12(sp)
	addi	sp,sp,16
	tail	countnegative_return
	.size	isaforge_tacle_original_main, .-isaforge_tacle_original_main
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	tail	countnegative_init
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	countnegative_main
	lw	ra,12(sp)
	addi	sp,sp,16
	tail	countnegative_return
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	bne	a0,zero,.L28
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	countnegative_return
	lw	ra,12(sp)
	seqz	a0,a0
	addi	sp,sp,16
	jr	ra
.L28:
	li	a0,0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	countnegative_negcnt
	.section	.bss.countnegative_negcnt,"aw",@nobits
	.align	2
	.type	countnegative_negcnt, @object
	.size	countnegative_negcnt, 4
countnegative_negcnt:
	.zero	4
	.globl	countnegative_poscnt
	.section	.bss.countnegative_poscnt,"aw",@nobits
	.align	2
	.type	countnegative_poscnt, @object
	.size	countnegative_poscnt, 4
countnegative_poscnt:
	.zero	4
	.globl	countnegative_negtotal
	.section	.bss.countnegative_negtotal,"aw",@nobits
	.align	2
	.type	countnegative_negtotal, @object
	.size	countnegative_negtotal, 4
countnegative_negtotal:
	.zero	4
	.globl	countnegative_postotal
	.section	.bss.countnegative_postotal,"aw",@nobits
	.align	2
	.type	countnegative_postotal, @object
	.size	countnegative_postotal, 4
countnegative_postotal:
	.zero	4
	.globl	countnegative_array
	.section	.bss.countnegative_array,"aw",@nobits
	.align	2
	.type	countnegative_array, @object
	.size	countnegative_array, 1600
countnegative_array:
	.zero	1600
	.globl	countnegative_seed
	.section	.bss.countnegative_seed,"aw",@nobits
	.align	2
	.type	countnegative_seed, @object
	.size	countnegative_seed, 4
countnegative_seed:
	.zero	4
	.globl	__modsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
