"""Independent arithmetic replay of all fixed V7 OOF outputs; never fits models."""
from pathlib import Path
import argparse,hashlib,json,math,statistics,time
from datetime import datetime
import numpy as np

SEEDS=(2026101421,2026101422,2026101423)
VIEWS=('base','bit','affine','both','legacy_original','legacy_rewritten')
CAPS=(16,32,64,128,256)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,message):
    if not ok:raise AssertionError(message)
def compare(actual,expected,path=''):
    if isinstance(expected,dict):
        need(set(actual)==set(expected),'Exact metric keys '+path)
        for k,v in expected.items():compare(actual[k],v,path+'/'+str(k))
    elif isinstance(expected,list):
        need(len(actual)==len(expected),'Metric list length '+path)
        for i,(a,b) in enumerate(zip(actual,expected)):compare(a,b,path+'/'+str(i))
    elif isinstance(expected,float):need(math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-12),'Numeric metric differs '+path)
    else:need(actual==expected,'Metric differs '+path)

def cell(y,p):
    residual=[b-a for a,b in zip(y,p)];absolute=[abs(e) for e in residual];positive=[(a,e) for a,e in zip(y,absolute) if a>0];zero=[e for a,e in zip(y,absolute) if a==0]
    return {'count':len(y),'mae_lut4':statistics.fmean(absolute),'signed_bias_lut4':statistics.fmean(residual),
      'rmsle':math.sqrt(statistics.fmean([(math.log1p(b)-math.log1p(a))**2 for a,b in zip(y,p)])),
      'positive_target_count':len(positive),'positive_mape_percent':statistics.fmean([e/a for a,e in positive])*100 if positive else None,
      'zero_target_count':len(zero),'zero_mae_lut4':statistics.fmean(zero) if zero else None,
      'p95_absolute_error_lut4':float(np.quantile(absolute,.95)),'p99_absolute_error_lut4':float(np.quantile(absolute,.99)),
      'worst_absolute_error_lut4':max(absolute),'maximum_underprediction_lut4':max([max(-e,0) for e in residual]),
      'underprediction_count':sum(e<0 for e in residual),'overprediction_count':sum(e>0 for e in residual),'exact_prediction_count':sum(e==0 for e in residual),
      'caps':{str(cap):{'false_accept_count':sum(b<=cap<a for a,b in zip(y,p)),
          'false_reject_count':sum(a<=cap<b for a,b in zip(y,p)),'predicted_feasible_count':sum(b<=cap for b in p),
          'actually_feasible_count':sum(a<=cap for a in y),'count':len(y)} for cap in CAPS}}

def run(prepared,output,review_path,repo_root=None,preparation_audit=None):
    began=time.perf_counter();seal=read(prepared/'pre-score-freeze.json');plan=read(prepared/'plan.json');data=read(prepared/'fitting.json');summary=read(prepared/'fit/summary.json')
    runtime_paths=[Path(p) for p in plan['input_sha256'] if Path(p).as_posix().endswith('/isaforge/semantic_features_v7.py')]
    need(len(runtime_paths)==1,'Unique hash-bound original repository prefix')
    original_repo=runtime_paths[0].parents[1].resolve();repo_root=original_repo if repo_root is None else repo_root.resolve()
    def bound_repository_path(path):
        path=Path(path)
        need(path.is_absolute(),'Frozen repository reference is absolute')
        try:relative=path.relative_to(original_repo)
        except ValueError:raise AssertionError('Frozen source/input outside declared repository; explicit new policy required')
        target=(repo_root/relative).resolve()
        need(repo_root in target.parents,'Repository reference escapes rebase target')
        return target
    start=read(prepared/'fit/fit-start.json');review=read(review_path)
    need(sha(review_path)==start['review_sha256'],'Exact actual parent review')
    need(review['approved'] is True and review['pre_score_freeze_sha256']==sha(prepared/'pre-score-freeze.json'),'Parent approved exact preparation')
    need(datetime.fromisoformat(seal['created_at_utc'])<=datetime.fromisoformat(review['reviewed_at_utc'])<=datetime.fromisoformat(start['started_at_utc']),'Freeze-review-fit chronology')
    for entry in ('independent_preparation_audit','independent_proof_audit'):
        record=review[entry];path=Path(record['path'])
        if entry=='independent_preparation_audit' and preparation_audit is not None:path=preparation_audit.resolve()
        elif entry=='independent_proof_audit':path=bound_repository_path(path)
        else:
            need(repo_root==original_repo,'Relocation requires explicit outside preparation-audit override')
            if not path.is_absolute():path=review_path.parent/path
        need(sha(path)==record['sha256'] and read(path)['status']=='pass','Exact passing parent-reviewed audit '+entry)
    for name,value in seal['files_sha256'].items():need(sha(prepared/name)==value,'Prepared file still exact')
    for name,value in plan['input_sha256'].items():need(sha(bound_repository_path(name))==value,'All rebased inputs/sources/proofs remain exact')
    need(sha(repo_root/'isaforge/semantic_features_v7.py')==review['semantic_source_sha256'],'Exact reviewed semantic runtime after rebase')
    need(sha(prepared/'pre-score-freeze.json')==summary['pre_score_freeze_sha256'],'Exact prefit seal')
    rows=data['rows'];strata=sorted({r['stratum'] for r in rows});need(len(rows)==1665 and len(strata)==9,'Fixed1665row nine-stratum endpoint')
    y=[r['lut4_count'] for r in rows];zero=data['original_zero'];values={};scored={};fit_count=0;filehashes={}
    for view in VIEWS:
        for seed in SEEDS:
            path=prepared/'fit/predictions'/f'{view}-seed-{seed}.json';predictions=read(path);filehashes[str(path.relative_to(prepared))]=sha(path)
            need(len(predictions)==1665,'Full prediction coverage')
            for original,predicted,forcedzero in zip(rows,predictions,zero):
                need(all(predicted[k]==v for k,v in original.items()),'Prediction row/target identity')
                p=predicted['predicted_lut4'];need(type(p) in (int,float) and math.isfinite(p) and p>=0,'Finite nonnegative point')
                need(not forcedzero or p==0,'Unchanged original graph zero override')
                need(predicted['signed_error_lut4']==p-original['lut4_count'],'Signed error')
            p=[r['predicted_lut4'] for r in predictions];values[(view,seed)]=p
            if view=='base':need(p==data['base_oof_reference'][str(seed)],'Exact historical217base OOF replay')
            by_stratum={s:cell([a for a,r in zip(y,rows) if r['stratum']==s],[b for b,r in zip(p,rows) if r['stratum']==s]) for s in strata}
            all_rows=cell(y,p);expected={'mae_lut4':all_rows['mae_lut4'],'macro_stratum_mae_lut4':statistics.fmean([v['mae_lut4'] for v in by_stratum.values()]),
                'rmsle':all_rows['rmsle'],'by_stratum':by_stratum,'all_rows':all_rows}
            metric_path=prepared/'fit/metrics'/f'{view}-seed-{seed}.json';actual=read(metric_path);filehashes[str(metric_path.relative_to(prepared))]=sha(metric_path)
            observed={k:v for k,v in actual.items() if k not in ('parameters','fold_fit_predict_seconds','reused_view')};compare(observed,expected,view+'/'+str(seed))
            compare(summary['scores'][view][str(seed)],actual,'summaryscore/'+view+'/'+str(seed))
            for name,value in {**plan['configuration'],'random_state':seed}.items():need(actual['parameters'][name]==value,'Matched fixed estimatorparameter')
            need(all(math.isfinite(t) and t>=0 for t in actual['fold_fit_predict_seconds']),'Valid retained fit timings')
            fit_count+=len(actual['fold_fit_predict_seconds']);scored[(view,seed)]=expected
    expected_views={}
    for view in VIEWS:
        numbers=[scored[(view,seed)]['macro_stratum_mae_lut4'] for seed in SEEDS]
        expected_views[view]={'macro_mae_mean':statistics.fmean(numbers),'macro_mae_sample_sd':statistics.stdev(numbers),
          'by_stratum_mean_mae':{s:statistics.fmean([scored[(view,seed)]['by_stratum'][s]['mae_lut4'] for seed in SEEDS]) for s in strata}}
    compare(summary['by_view'],expected_views,'by_view')
    expected_comparisons={}
    for left,right in [('both','base'),('bit','base'),('affine','base'),('both','bit'),('both','affine'),('legacy_rewritten','legacy_original'),('both','legacy_rewritten')]:
        differences=[scored[(left,s)]['macro_stratum_mae_lut4']-scored[(right,s)]['macro_stratum_mae_lut4'] for s in SEEDS]
        expected_comparisons[left+'_minus_'+right]={'values_lut4':differences,'mean_lut4':statistics.fmean(differences),
          'per_stratum_mean_difference':{s:expected_views[left]['by_stratum_mean_mae'][s]-expected_views[right]['by_stratum_mean_mae'][s] for s in strata}}
    compare(summary['paired_comparisons'],expected_comparisons,'paired')
    need(summary['fits_completed']==fit_count<=90,'Fixed90fit maximum and retained fit timing count')
    matrices={v:read(prepared/'matrices'/f'{v}.json')['values'] for v in VIEWS}
    for view,previous in summary['exact_matrix_reuse'].items():need(matrices[view]==matrices[previous],'Any reused view has exact matrix equality')
    need(read(prepared/'fit/fit-start.json')['pre_score_freeze_sha256']==sha(prepared/'pre-score-freeze.json'),'Fitstart seal binding')
    report={'status':'pass','scope':'Independent fixedfitting OOF arithmetic replay only; no new fits/testlabels/hardware',
      'audit_source_sha256':sha(__file__),'prepared_freeze_sha256':sha(prepared/'pre-score-freeze.json'),
      'parent_review_sha256':sha(review_path),'freeze_review_fit_chronology_valid':True,
      'repository_references_rebased_and_hashchecked':True,'relocated_repository':repo_root!=original_repo,
      'summary_sha256':sha(prepared/'fit/summary.json'),'prediction_metric_sha256':filehashes,'views':6,'seeds':3,
      'rows_per_prediction_file':1665,'prediction_rows_recomputed':6*3*1665,'fits_completed':fit_count,
      'all_score_and_tail_cap_zero_stratum_metrics_match':True,'all_paired_differences_and_seed_sample_sd_match':True,
      'all3historical217base_OOF_controls_exact':True,'recomputed_by_view':expected_views,'recomputed_paired_comparisons':expected_comparisons,
      'elapsed_seconds':time.perf_counter()-began,'limits':['OOF results are consumed fitting-only development, not independent generalization.',
        'Three-seed sample SD is algorithm sensitivity, not a population interval.','New bit identities are absent in fitting inputs; descriptor gains cannot demonstrate learning those identities.']}
    output.mkdir(parents=True,exist_ok=True);(output/'metrics-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='prediction_metric_sha256'},indent=2));return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--review',type=Path,required=True)
    p.add_argument('--repo-root',type=Path);p.add_argument('--preparation-audit',type=Path)
    a=p.parse_args();run(a.prepared.resolve(),a.output.resolve(),a.review.resolve(),a.repo_root,a.preparation_audit)
