# Independent V7 preparation and saved-score audit

All checks passed. No fitting, hardware measurement or held-out target use was performed by these audit scripts. The exact reviewed preparation seal is `4d600556cb26eba443a897eb0691244c8fbbb99bbb5449b1fd08d430dc40e3ba`; the completed fit summary is `29892d28d1ff2c1ec5ff9bec3582c961f8f15b29089f7274d871a40caef40850`.

`preparation-audit.json` reconstructs all1,665 fitting rows, targets, inherited folds, the217-column base against the prior mapping study and frozen V6 input vectors, both8-column blocks against the independent proof audit, all119 original legacy features against frozen V5 vectors and every rewritten119 vector by recomputation. All identity/vector/prevalence/fold-training-variance diagnostics match. One newly proved equivalent pair joins two inherited four-variant grouping components across folds1/3; the resulting eight-row component does not mean all eight functions are identical.

`metrics-audit.json` independently reconstructs all29,970 saved predictions from six views and three seeds, including all stratum, tail, zero, cap, paired-difference and sample-SD fields. All90 fits are accounted for by retained fold records; all three base217 OOF predictions exactly match the prior mapping study. Freeze→parent-review→fit chronology and every bound source/input/proof byte match. No model was fitted by the audit.

| View | Mean nine-stratum macro MAE | Sample SD across3 algorithm seeds |
| --- | ---: | ---: |
| Base217 | 4.935113 | 0.045047 |
| Base+bit8 | 4.887689 | 0.043933 |
| Base+affine8 | 4.935478 | 0.026736 |
| Base+both16 (primary) | 4.860089 | 0.032558 |
| Base+legacy119 original | 4.799579 | 0.034813 |
| Base+legacy119 rewritten | 4.738407 | 0.048898 |

The prespecified primary difference is -0.075024 LUT4 macro MAE (about1.52% relative), with paired seed differences -0.123305,-0.016780,-0.084986. The rewritten legacy control scores lower than the new16-column primary. These are descriptive consumed fitting-fold results, not independent accuracy or population-confidence estimates. Neither new bit identity occurs in the fitting corpus, so improvement cannot demonstrate learning those identities.

`posthoc-sensitivity.json` is explicitly separate from the prespecified summary. The linked eight validation rows contribute only -0.000009894 to the original primary difference. Excluding their validation errors gives -0.074844, but **their influence in training folds remains**; this cannot repair independence. Multiplication contributes -0.092864 to the macro difference and shared-diamond -0.013268; variable shifts add +0.016850 and workload +0.012039, offsetting some gain.

Across seeds, the primary view's pooled p95/p99 absolute errors rise by0.6804/2.6420 LUT4, maximum underprediction rises5.6411, zero-target MAE rises0.00521 (252 zero targets), and positive-only MAPE rises0.10375 percentage points. Worst absolute error falls13.8911. At cap16, false rejects increase by5 per seed on average with unchanged false accepts; other cap changes are fully retained. Count averages across seeds are fractional algorithm summaries, not extra independent observations. These tradeoffs preclude describing the result as a uniform improvement or a demonstrated rewrite mechanism.

The replay scripts take explicit paths. `replay_metrics.py` supports `--repo-root` for hash-checked rebasing of recorded repository references and `--preparation-audit` for an explicit outside-repository audit override that must match the original parent-review SHA. It never rewrites frozen metadata or silently borrows original host files during relocated replay.
