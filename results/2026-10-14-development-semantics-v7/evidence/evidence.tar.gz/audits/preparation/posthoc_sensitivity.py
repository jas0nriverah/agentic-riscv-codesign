"""Explicit post-hoc saved-prediction sensitivity; no refits or independence repair."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,statistics,time

spec=importlib.util.spec_from_file_location('independent_metrics',Path(__file__).with_name('replay_metrics.py'))
metrics=importlib.util.module_from_spec(spec);spec.loader.exec_module(metrics)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,message):
    if not ok:raise AssertionError(message)

def run(prepared,audit_path,output):
    began=time.perf_counter();audit=read(audit_path);need(audit['status']=='pass','Primary arithmetic replay must pass first')
    need(audit['summary_sha256']==sha(prepared/'fit/summary.json'),'Exact independently audited summary')
    for path,value in audit['prediction_metric_sha256'].items():need(sha(prepared/path)==value,'Exact audited predictions and metrics')
    diagnostics=read(prepared/'input-diagnostics.json');data=read(prepared/'fitting.json');rows=data['rows'];fold_ids=data['fold_ids']
    baseline=diagnostics['original_equivalence']['row_components']
    newly_linked=[g for g in diagnostics['by_rewrite_mode']['combined']['crossfold_components'] if len({baseline[i] for i in g})>1]
    selected=sorted({i for g in newly_linked for i in g});need(len(newly_linked)==1 and len(selected)==8,'Declared new eight-row grouping component')
    strata=sorted({r['stratum'] for r in rows});n={s:sum(r['stratum']==s for r in rows) for s in strata}
    need(len(strata)==9,'Unchanged nine-stratum endpoint')
    kept=[i for i in range(len(rows)) if i not in set(selected)];need(all(any(rows[i]['stratum']==s for i in kept) for s in strata),'Sensitivity retains every stratum')
    seeds={};row_details=[]
    for seed in metrics.SEEDS:
        base=read(prepared/'fit/predictions'/f'base-seed-{seed}.json');both=read(prepared/'fit/predictions'/f'both-seed-{seed}.json')
        y=[r['lut4_count'] for r in rows];bp=[r['predicted_lut4'] for r in base];np=[r['predicted_lut4'] for r in both]
        deltas=[abs(p-a)-abs(b-a) for a,b,p in zip(y,bp,np)]
        contributions={s:statistics.fmean([d for d,r in zip(deltas,rows) if r['stratum']==s])/9 for s in strata}
        primary=sum(contributions.values())
        expected=audit['recomputed_paired_comparisons']['both_minus_base']['values_lut4'][list(metrics.SEEDS).index(seed)]
        need(abs(primary-expected)<1e-11,'Posthoc contributions preserve primary fixed weights')
        component_contribution=sum(deltas[i]/(9*n[rows[i]['stratum']]) for i in selected)
        excluded_by_stratum={s:statistics.fmean([deltas[i] for i in kept if rows[i]['stratum']==s]) for s in strata}
        excluded=statistics.fmean(excluded_by_stratum.values())
        def changes(indices):
            old=metrics.cell([y[i] for i in indices],[bp[i] for i in indices]);new=metrics.cell([y[i] for i in indices],[np[i] for i in indices])
            names=('mae_lut4','signed_bias_lut4','rmsle','positive_mape_percent','zero_mae_lut4',
                   'p95_absolute_error_lut4','p99_absolute_error_lut4','worst_absolute_error_lut4','maximum_underprediction_lut4',
                   'underprediction_count','overprediction_count','exact_prediction_count')
            return {'base':old,'both':new,'both_minus_base':{k:new[k]-old[k] if new[k] is not None and old[k] is not None else None for k in names},
                'cap_count_changes':{cap:{k:new['caps'][cap][k]-old['caps'][cap][k] for k in ('false_accept_count','false_reject_count','predicted_feasible_count')} for cap in old['caps']}}
        seeds[str(seed)]={'primary_both_minus_base_macro_mae_lut4':primary,'linked8_contribution_to_primary_difference_lut4':component_contribution,
          'other1657_contribution_using_original_primary_weights_lut4':primary-component_contribution,
          'excluding8_validation_rows_macro_mae_difference_lut4':excluded,
          'excluding8_validation_rows_by_stratum_mae_difference_lut4':excluded_by_stratum,
          'per_stratum_contribution_to_original_primary_difference_lut4':contributions,
          'all_rows_tail_zero_cap_changes':changes(list(range(len(rows)))),
          'excluding8_validation_rows_tail_zero_cap_changes':changes(kept),
          'per_stratum_tail_zero_cap_changes':{s:changes([i for i,r in enumerate(rows) if r['stratum']==s]) for s in strata},
          'row_comparison_counts':{'better':sum(d<0 for d in deltas),'worse':sum(d>0 for d in deltas),'equal':sum(d==0 for d in deltas)}}
        for i in selected:
            row_details.append({**rows[i],'seed':seed,'fold':fold_ids[i],'base_prediction':bp[i],'both_prediction':np[i],
                'absolute_error_difference_lut4':deltas[i],'contribution_to_original_macro_difference_lut4':deltas[i]/(9*n[rows[i]['stratum']])})
    keys=('primary_both_minus_base_macro_mae_lut4','linked8_contribution_to_primary_difference_lut4',
          'other1657_contribution_using_original_primary_weights_lut4','excluding8_validation_rows_macro_mae_difference_lut4')
    means={k:statistics.fmean(s[k] for s in seeds.values()) for k in keys}
    mean_tail_changes={k:statistics.fmean(s['all_rows_tail_zero_cap_changes']['both_minus_base'][k] for s in seeds.values())
        if all(s['all_rows_tail_zero_cap_changes']['both_minus_base'][k] is not None for s in seeds.values()) else None
        for k in next(iter(seeds.values()))['all_rows_tail_zero_cap_changes']['both_minus_base']}
    cap_template=next(iter(seeds.values()))['all_rows_tail_zero_cap_changes']['cap_count_changes']
    mean_cap_changes={cap:{k:statistics.fmean(s['all_rows_tail_zero_cap_changes']['cap_count_changes'][cap][k] for s in seeds.values())
        for k in cap_template[cap]} for cap in cap_template}
    report={'schema':'isaforge-v7-posthoc-sensitivity-v1','status':'pass','scope':'POST-HOC saved fitting-OOF prediction analysis only; separate from prespecified primary summary',
      'source_sha256':sha(__file__),'independent_metrics_source_sha256':sha(Path(__file__).with_name('replay_metrics.py')),
      'primary_audit_sha256':sha(audit_path),'summary_sha256':sha(prepared/'fit/summary.json'),
      'input_diagnostics_sha256':sha(prepared/'input-diagnostics.json'),'prepared_freeze_sha256':sha(prepared/'pre-score-freeze.json'),
      'newly_linked_components_prepared_positions':newly_linked,'linked_development_indices':[rows[i]['development_index'] for i in selected],
      'linked_row_count':8,'remaining_validation_row_count':1657,'means_over3seeds':means,
      'mean_all_rows_tail_zero_cap_changes_over3seeds':mean_tail_changes,'mean_cap_count_changes_over3seeds':mean_cap_changes,
      'mean_per_stratum_contribution_to_original_primary_difference_lut4':{s:statistics.fmean(r['per_stratum_contribution_to_original_primary_difference_lut4'][s] for r in seeds.values()) for s in strata},
      'all_seeds':seeds,'linked_rows_all_seed_predictions':row_details,'new_fits':0,'elapsed_seconds':time.perf_counter()-began,
      'limits':['These analyses were requested after fitting began and do not replace or amend the prespecified primary result.',
        'The eight rows form a connected grouping component joined by one proved equivalent pair; all eight are not identical functions.',
        'Excluding eight validation rows leaves their influence in training folds. It does not repair independence or estimate leakage-free generalization.',
        'Contribution arithmetic is descriptive and does not establish a causal normalization mechanism.',
        'Means of per-seed count changes are fractional summaries, not additional independent observations.',
        'Bit identities are absent in the fitting corpus; changes in generic known-bit descriptors cannot demonstrate learning those identities.',
        'No population interval, significance test, fresh-target evaluation or new model fitting is performed.']}
    output.mkdir(parents=True,exist_ok=True);(output/'posthoc-sensitivity.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'means_over3seeds':means,'per_stratum_contributions':report['mean_per_stratum_contribution_to_original_primary_difference_lut4']},indent=2));return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepared',type=Path,required=True);p.add_argument('--primary-audit',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();run(a.prepared.resolve(),a.primary_audit.resolve(),a.output.resolve())
