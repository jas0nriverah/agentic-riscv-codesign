"""Read-only independent V7 prepared matrices, identity diagnostics and proof bindings."""
from pathlib import Path
import argparse,hashlib,json,math,sys,time
from collections import defaultdict
import numpy as np

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def need(ok,message):
    if not ok:raise AssertionError(message)
def equal(a,b,message):need(a==b,message)

def components(originals,normalized,groups,fold_ids,key):
    parent=list(range(len(originals)))
    def find(i):
        while i!=parent[i]:parent[i]=parent[parent[i]];i=parent[i]
        return i
    seen={}
    for i,(original,new,group) in enumerate(zip(originals,normalized,groups)):
        for value in [('group',group),('text',original),('text',new),('equiv',key(original)),('equiv',key(new))]:
            if value in seen:
                left,right=find(i),find(seen[value]);parent[max(left,right)]=min(left,right)
            else:seen[value]=i
    buckets=defaultdict(list)
    ids=[find(i) for i in range(len(originals))]
    for i,c in enumerate(ids):buckets[c].append(i)
    cross=[rows for rows in buckets.values() if len({fold_ids[i] for i in rows})>1]
    return {'component_count':len(buckets),'component_sizes':sorted(map(len,buckets.values())),
      'crossfold_component_count':len(cross),'crossfold_rows':sum(map(len,cross)),
      'crossfold_components':cross,'row_components':ids}

def duplicates(values,fold_ids):
    buckets=defaultdict(list)
    for i,row in enumerate(values):buckets[tuple(row)].append(i)
    duplicated=[v for v in buckets.values() if len(v)>1]
    cross=[v for v in duplicated if len({fold_ids[i] for i in v})>1]
    return {'unique_count':len(buckets),'duplicate_class_count':len(duplicated),'duplicate_rows':sum(map(len,duplicated)),
      'crossfold_class_count':len(cross),'crossfold_rows':sum(map(len,cross)),'crossfold_classes':cross}

def run(root,prepared,output):
    sys.path.insert(0,str(root))
    from isaforge.area_model_v5 import columns,view_indices,original_zero
    from isaforge import structural_features_v5 as legacy
    from isaforge.v5_corpus import equivalence_key
    from isaforge.features import parse_formula
    began=time.perf_counter();seal=read(prepared/'pre-score-freeze.json');plan=read(prepared/'plan.json')
    need(not(prepared/'fit').exists(),'Pre-fit audit before fit begins')
    need(seal['stage']=='pre-score-freeze' and seal['fits_completed']==0 and seal['maximum_fits']==90,'Actual prefit seal')
    for name,value in seal['files_sha256'].items():equal(sha(prepared/name),value,'Every sealed preparation file')
    equal(sha(prepared/'plan.json'),seal['plan_sha256'],'Plan hash')
    for path,value in plan['input_sha256'].items():equal(sha(path),value,'Every bound input/source/proof file')
    old=root/'results/2026-10-14-v5';oldfreeze=read(old/'freeze.json');oldentries={e['path']:e['sha256'] for e in oldfreeze['files']}
    for name in ('development-data.json','development-features.json','split.json'):equal(sha(old/name),oldentries[name],'Frozen original development file')
    split=read(old/'split.json');fit=split['fit_indices'];data=read(old/'development-data.json');features=read(old/'development-features.json')
    need(len(fit)==len(set(fit))==1665 and not(set(fit)&set(split['calibration_indices'])),'Exact fit/calibration isolation')
    selected=[data[i] for i in fit];del data
    original=[r['formula'] for r in selected];strata=[r.get('stratum','workload') for r in selected];targets=[r['lut4_count'] for r in selected]
    x=np.array([features['records'][i]['values'] for i in fit]);equal(tuple(features['columns']),columns(),'Frozen313columns')
    mapping=root/'results/2026-10-14-development-mapping';block=read(mapping/'features.json');mapped=np.array([r['values'] for r in block['records']])
    equal([(r['development_index'],r['formula']) for r in block['records']],list(zip(fit,original)),'Historical mapping row alignment')
    base=np.column_stack((x[:,view_indices('dual_graph')],mapped));need(base.shape==(1665,217),'Exact217base')
    expected_base_names=[columns()[i] for i in view_indices('dual_graph')]+['mapping_'+n for n in block['columns']]
    v6=root/'results/2026-10-14-v6';point=read(v6/'point-freeze.json');consumed_path=v6/'corpus/consumed-features.json'
    equal(sha(consumed_path),next(e['sha256'] for e in point['files'] if e['path']=='corpus/consumed-features.json'),'Frozen V6 input provenance')
    consumed={r['formula']:r['values'] for r in read(consumed_path)['records']}
    for i,formula in enumerate(original):equal(consumed[formula],x[i].tolist()+mapped[i].tolist(),'Exact frozen V6 full336 fitting vector')
    audit=root/'results/2026-10-14-development-semantics-v7/audit';certificate=read(audit/'fitting-inputs/fitting-input-audit.json')
    proved=read(audit/'fitting-inputs/fitting-input-records.json');equal(sha(audit/'fitting-inputs/fitting-input-records.json'),certificate['records_sha256'],'Independent audited records')
    equal(certificate['fit_formula_sha256'],digest(original),'Exact independent proof formula cohort')
    equal(certificate['fit_indices_sha256'],digest(fit),'Exact independent proof indices')
    for name,value in certificate['source_sha256'].items():equal(sha(root/name),value,'Independent audit actual source')
    stored=read(prepared/'fitting.json');equal(stored['rows'],[{'formula':f,'development_index':i,'stratum':s,'lut4_count':t} for f,i,s,t in zip(original,fit,strata,targets)],'Prepared targets/formulas are1665fit only')
    equal(plan['targets_sha256'],digest(targets),'Target cohort binding')
    equal(plan['formula_sha256'],digest(original),'Formula cohort binding')
    fold_ids=[-1]*1665;positions={i:p for p,i in enumerate(fit)};group_by_formula=split['component_by_formula']
    for fold,valid in enumerate(split['fold_validation_indices']):
        for i in valid:
            need(i in positions and fold_ids[positions[i]]==-1,'Validation partition')
            fold_ids[positions[i]]=fold
        training=set(fit)-set(valid)
        need(not({group_by_formula[original[positions[i]]] for i in valid}&{group_by_formula[original[positions[i]]] for i in training}),'Original group-disjoint folds')
    equal(stored['fold_ids'],fold_ids,'Exact inherited folds');equal(stored['original_zero'],original_zero(x).tolist(),'Original graph zero override')
    matrices={v:read(prepared/'matrices'/f'{v}.json') for v in ('base','bit','affine','both','legacy_original','legacy_rewritten')}
    equal(matrices['base']['columns'],expected_base_names,'Exact217column order');equal(matrices['base']['values'],base.tolist(),'Exact217prior mapping vectors')
    ledger=read(prepared/'proof-ledger.json');equal(len(ledger),1665,'Complete proof ledger')
    for i,(actual,expected) in enumerate(zip(ledger,proved)):
        equal((actual['formula'],actual['development_index']),(original[i],fit[i]),'Prepared proof input alignment')
        for mode in ('bit','affine','combined'):
            for field in ('normalized_formula','features'):
                equal(actual['modes'][mode][field],expected['modes'][mode][field],'Prepared proof/feature exact independent audit')
    bit=[list(r['modes']['bit']['features'].values()) for r in proved];affine=[list(r['modes']['affine']['features'].values()) for r in proved]
    equal(matrices['bit']['values'],np.column_stack((base,bit)).tolist(),'Independent8bit suffix')
    equal(matrices['affine']['values'],np.column_stack((base,affine)).tolist(),'Independent8affine suffix')
    equal(matrices['both']['values'],np.column_stack((base,bit,affine)).tolist(),'Exact233primary nesting')
    equal(tuple(columns()[194:]),legacy.FEATURE_NAMES,'Frozen119semantic schema')
    equal(matrices['legacy_original']['values'],np.column_stack((base,x[:,194:])).tolist(),'All frozen original119semantic vectors exact')
    rewrites=[]
    for record in proved:
        value=legacy.feature_dict(record['modes']['combined']['normalized_formula']);rewrites.append([value[n] for n in legacy.FEATURE_NAMES])
    equal(matrices['legacy_rewritten']['values'],np.column_stack((base,rewrites)).tolist(),'All recomputed rewritten119semantic vectors exact')
    diagnostics=read(prepared/'input-diagnostics.json');groups=[group_by_formula[f] for f in original]
    baseline=components(original,original,groups,fold_ids,equivalence_key)
    equal(diagnostics['original_equivalence'],baseline,'Independent original identity components')
    new_cross={}
    for mode in ('bit','affine','combined'):
        normalized=[r['modes'][mode]['normalized_formula'] for r in proved];actual=components(original,normalized,groups,fold_ids,equivalence_key)
        observed=diagnostics['by_rewrite_mode'][mode]
        for k,v in actual.items():equal(observed[k],v,'Independent '+mode+' equivalence diagnostic '+k)
        new_cross[mode]=sum(len({baseline['row_components'][i] for i in group})>1 for group in actual['crossfold_components'])
    equal(seal['new_equivalence_crossfold_components'],new_cross,'Newly established crossfold components only')
    for view,record in matrices.items():
        equal(record['columns'],plan['columns'][view],'Column plan equality '+view)
        equal(diagnostics['exact_vector_duplicates'][view],duplicates(record['values'],fold_ids),'Independent exact-vector diagnostic '+view)
        matrix=np.array(record['values']);need(matrix.shape==(1665,len(record['columns'])) and np.isfinite(matrix).all() and (matrix>=0).all(),'Finite declaredmatrix '+view)
        for j,name in enumerate(record['columns']):
            p=diagnostics['prevalence'][view][name]
            equal(p['unique_values'],len(set(matrix[:,j])),'Input-only uniquevalues '+name)
            equal(p['nonzero_rows'],int(np.count_nonzero(matrix[:,j])),'Input-only prevalence '+name)
            for fold in range(5):
                training=matrix[np.array(fold_ids)!=fold,j]
                equal(p['training_unique_values_by_fold'][fold],len(set(training)),'Fold training uniquevalues '+name)
                need(math.isclose(p['training_variance_by_fold'][fold],float(np.var(training)),rel_tol=1e-12,abs_tol=1e-12),'Fold training variance '+name)
    for key in ('calibration_rows_used','test_rows_used','external_rows_used','new_hardware_measurements'):equal(plan[key],0,'No forbidden study inputs')
    for seed in (2026101421,2026101422,2026101423):
        historical=read(mapping/'predictions'/f'dual_graph_plus_mapping-seed-{seed}.json')
        equal(stored['base_oof_reference'][str(seed)],[r['predicted_lut4'] for r in historical],'Exact historical base OOF reference')
    equal(plan['seeds'],[2026101421,2026101422,2026101423],'Fixed seeds')
    equal(plan['configuration'],{'n_estimators':300,'min_samples_leaf':1,'max_features':1.,'n_jobs':1},'Matched tree budget')
    need(not(prepared/'fit').exists(),'No fitting started during independent prep review')
    result={'status':'pass','scope':'Read-only prefit preparation audit; no fitting or hardware',
      'prepared_freeze_sha256':sha(prepared/'pre-score-freeze.json'),'plan_sha256':sha(prepared/'plan.json'),
      'source_sha256':sha(__file__),'exact_fitting_rows':1665,'exact_base_columns':217,
      'view_column_counts':{v:len(r['columns']) for v,r in matrices.items()},'new_equivalence_crossfold_components':new_cross,
      'all_prepared_proof_features_and_normal_forms_match_independent_audit':True,
      'all_original_legacy119_match_frozen_vectors':True,'all_rewritten_legacy119_recomputed_exact':True,
      'all_identity_prevalence_and_training_variance_diagnostics_reconstructed':True,
      'no_calibration_test_or_external_rows_in_fits':True,'elapsed_seconds':time.perf_counter()-began,
      'limits':['Fixed inherited folds remain descriptive if newly proved equivalents cross folds.',
        'Bit identity occurrences are absent in fitting inputs; cannot establish learned benefit of those rules.']}
    output.mkdir(parents=True,exist_ok=True);(output/'preparation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--prepared',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();run(a.root.resolve(),a.prepared.resolve(),a.output.resolve())
