	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.bitcount_bit_shifter,"ax",@progbits
	.align	2
	.globl	bitcount_bit_shifter
	.type	bitcount_bit_shifter, @function
bitcount_bit_shifter:
	mv	a5,a0
	li	a4,0
	li	a0,0
.L2:
	addi	a3,a4,-32
	beq	a3,zero,.L1
	bne	a5,zero,.L3
.L1:
	ret
.L3:
	andi	a3,a5,1
	add	a0,a0,a3
	addi	a4,a4,1
	srai	a5,a5,1
	j	.L2
	.size	bitcount_bit_shifter, .-bitcount_bit_shifter
	.section	.text.bitcount_return,"ax",@progbits
	.align	2
	.globl	bitcount_return
	.type	bitcount_return, @function
bitcount_return:
	lui	a5,%hi(bitcount_n)
	lw	a0,%lo(bitcount_n)(a5)
	addi	a0,a0,-1095
	snez	a0,a0
	ret
	.size	bitcount_return, .-bitcount_return
	.section	.text.bitcount_random,"ax",@progbits
	.align	2
	.globl	bitcount_random
	.type	bitcount_random, @function
bitcount_random:
	addi	sp,sp,-16
	sw	s0,8(sp)
	lui	s0,%hi(bitcount_randseed)
	sw	s1,4(sp)
	lw	s1,%lo(bitcount_randseed)(s0)
	li	a1,126976
	addi	a1,a1,797
	mv	a0,s1
	sw	ra,12(sp)
	sw	s2,0(sp)
	call	__modsi3
	li	a1,16384
	addi	a1,a1,423
	call	__mulsi3
	li	a1,126976
	mv	s2,a0
	addi	a1,a1,797
	mv	a0,s1
	call	__divsi3
	li	a1,-4096
	addi	a1,a1,1260
	call	__mulsi3
	add	a0,s2,a0
	bgt	a0,zero,.L10
	li	a5,-2147483648
	addi	a5,a5,-1
	add	a0,a0,a5
.L10:
	lw	ra,12(sp)
	sw	a0,%lo(bitcount_randseed)(s0)
	lw	s0,8(sp)
	lw	s1,4(sp)
	lw	s2,0(sp)
	addi	sp,sp,16
	jr	ra
	.size	bitcount_random, .-bitcount_random
	.section	.text.bitcount_bit_count,"ax",@progbits
	.align	2
	.globl	bitcount_bit_count
	.type	bitcount_bit_count, @function
bitcount_bit_count:
	beq	a0,zero,.L13
	mv	a5,a0
	li	a0,0
.L14:
	addi	a4,a5,-1
	and	a5,a5,a4
	addi	a0,a0,1
	bne	a5,zero,.L14
.L13:
	ret
	.size	bitcount_bit_count, .-bitcount_bit_count
	.section	.text.bitcount_bitcount,"ax",@progbits
	.align	2
	.globl	bitcount_bitcount
	.type	bitcount_bitcount, @function
bitcount_bitcount:
	li	a5,1431654400
	addi	a5,a5,1365
	srli	a4,a0,1
	and	a4,a4,a5
	and	a0,a0,a5
	add	a4,a4,a0
	li	a3,858992640
	addi	a3,a3,819
	srli	a5,a4,2
	and	a5,a5,a3
	and	a4,a4,a3
	add	a5,a5,a4
	li	a3,252645376
	addi	a3,a3,-241
	srli	a4,a5,4
	and	a4,a4,a3
	and	a5,a5,a3
	add	a4,a4,a5
	li	a3,16711680
	addi	a3,a3,255
	srli	a5,a4,8
	and	a5,a5,a3
	and	a4,a4,a3
	add	a5,a5,a4
	srli	a0,a5,16
	slli	a5,a5,16
	srli	a5,a5,16
	add	a0,a0,a5
	ret
	.size	bitcount_bitcount, .-bitcount_bitcount
	.section	.text.bitcount_init3,"ax",@progbits
	.align	2
	.globl	bitcount_init3
	.type	bitcount_init3, @function
bitcount_init3:
	addi	sp,sp,-288
	lui	a1,%hi(.LANCHOR0)
	li	a2,256
	addi	a1,a1,%lo(.LANCHOR0)
	addi	a0,sp,16
	sw	ra,284(sp)
	sw	zero,12(sp)
	call	memcpy
	lui	a5,%hi(isaforge_bitcount_bits_3)
	sw	zero,12(sp)
	li	a2,255
	addi	a5,a5,%lo(isaforge_bitcount_bits_3)
.L21:
	lw	a4,12(sp)
	ble	a4,a2,.L22
	lw	ra,284(sp)
	addi	sp,sp,288
	jr	ra
.L22:
	lw	a3,12(sp)
	lw	a4,12(sp)
	addi	a3,a3,272
	add	a3,a3,sp
	lbu	a3,-256(a3)
	add	a4,a5,a4
	sb	a3,0(a4)
	lw	a4,12(sp)
	addi	a4,a4,1
	sw	a4,12(sp)
	j	.L21
	.size	bitcount_init3, .-bitcount_init3
	.section	.text.bitcount_ntbl_bitcount,"ax",@progbits
	.align	2
	.globl	bitcount_ntbl_bitcount
	.type	bitcount_ntbl_bitcount, @function
bitcount_ntbl_bitcount:
	srli	a5,a0,4
	lui	a4,%hi(isaforge_bitcount_bits_3)
	addi	a4,a4,%lo(isaforge_bitcount_bits_3)
	andi	a3,a0,15
	andi	a5,a5,15
	add	a5,a4,a5
	add	a3,a4,a3
	lbu	a3,0(a3)
	lbu	a5,0(a5)
	add	a5,a5,a3
	srli	a3,a0,8
	andi	a3,a3,15
	add	a3,a4,a3
	lbu	a3,0(a3)
	add	a5,a5,a3
	srli	a3,a0,12
	andi	a3,a3,15
	add	a3,a4,a3
	lbu	a3,0(a3)
	add	a5,a5,a3
	srli	a3,a0,16
	andi	a3,a3,15
	add	a3,a4,a3
	lbu	a3,0(a3)
	add	a5,a5,a3
	srli	a3,a0,20
	andi	a3,a3,15
	add	a3,a4,a3
	lbu	a3,0(a3)
	add	a5,a5,a3
	srli	a3,a0,24
	andi	a3,a3,15
	add	a3,a4,a3
	srli	a0,a0,28
	lbu	a3,0(a3)
	add	a4,a4,a0
	lbu	a0,0(a4)
	add	a5,a5,a3
	add	a0,a5,a0
	ret
	.size	bitcount_ntbl_bitcount, .-bitcount_ntbl_bitcount
	.section	.text.bitcount_BW_btbl_bitcount,"ax",@progbits
	.align	2
	.globl	bitcount_BW_btbl_bitcount
	.type	bitcount_BW_btbl_bitcount, @function
bitcount_BW_btbl_bitcount:
	lui	a5,%hi(isaforge_bitcount_bits_3)
	addi	a5,a5,%lo(isaforge_bitcount_bits_3)
	andi	a4,a0,255
	add	a4,a5,a4
	lbu	a3,0(a4)
	srli	a4,a0,8
	andi	a4,a4,0xff
	add	a4,a5,a4
	lbu	a4,0(a4)
	add	a3,a3,a4
	srli	a4,a0,24
	add	a4,a5,a4
	lbu	a4,0(a4)
	add	a3,a3,a4
	srli	a4,a0,16
	andi	a4,a4,0xff
	add	a5,a5,a4
	lbu	a0,0(a5)
	add	a0,a3,a0
	ret
	.size	bitcount_BW_btbl_bitcount, .-bitcount_BW_btbl_bitcount
	.section	.text.bitcount_AR_btbl_bitcount,"ax",@progbits
	.align	2
	.globl	bitcount_AR_btbl_bitcount
	.type	bitcount_AR_btbl_bitcount, @function
bitcount_AR_btbl_bitcount:
	lui	a5,%hi(isaforge_bitcount_bits_3)
	addi	a5,a5,%lo(isaforge_bitcount_bits_3)
	andi	a4,a0,255
	add	a4,a5,a4
	lbu	a2,0(a4)
	srli	a4,a0,8
	andi	a4,a4,0xff
	add	a4,a5,a4
	lbu	a3,0(a4)
	srli	a4,a0,16
	andi	a4,a4,0xff
	add	a4,a5,a4
	srli	a0,a0,24
	lbu	a4,0(a4)
	add	a5,a5,a0
	lbu	a0,0(a5)
	add	a3,a3,a2
	add	a4,a4,a3
	add	a0,a0,a4
	ret
	.size	bitcount_AR_btbl_bitcount, .-bitcount_AR_btbl_bitcount
	.section	.text.bitcount_init4,"ax",@progbits
	.align	2
	.globl	bitcount_init4
	.type	bitcount_init4, @function
bitcount_init4:
	addi	sp,sp,-288
	lui	a1,%hi(.LANCHOR0)
	li	a2,256
	addi	a1,a1,%lo(.LANCHOR0)
	addi	a0,sp,16
	sw	ra,284(sp)
	sw	zero,12(sp)
	call	memcpy
	lui	a5,%hi(isaforge_bitcount_bits_4)
	sw	zero,12(sp)
	li	a2,255
	addi	a5,a5,%lo(isaforge_bitcount_bits_4)
.L28:
	lw	a4,12(sp)
	ble	a4,a2,.L29
	lw	ra,284(sp)
	addi	sp,sp,288
	jr	ra
.L29:
	lw	a3,12(sp)
	lw	a4,12(sp)
	addi	a3,a3,272
	add	a3,a3,sp
	lbu	a3,-256(a3)
	add	a4,a5,a4
	sb	a3,0(a4)
	lw	a4,12(sp)
	addi	a4,a4,1
	sw	a4,12(sp)
	j	.L28
	.size	bitcount_init4, .-bitcount_init4
	.section	.text.bitcount_init,"ax",@progbits
	.align	2
	.globl	bitcount_init
	.type	bitcount_init, @function
bitcount_init:
	lui	a5,%hi(bitcount_randseed)
	li	a4,1
	addi	sp,sp,-16
	sw	a4,%lo(bitcount_randseed)(a5)
	lui	a5,%hi(bitcount_n)
	sw	zero,%lo(bitcount_n)(a5)
	li	a4,10
	lui	a5,%hi(bitcount_iterations)
	sw	ra,12(sp)
	sw	a4,%lo(bitcount_iterations)(a5)
	call	bitcount_init3
	lw	ra,12(sp)
	addi	sp,sp,16
	tail	bitcount_init4
	.size	bitcount_init, .-bitcount_init
	.section	.text.bitcount_ntbl_bitcnt,"ax",@progbits
	.align	2
	.globl	bitcount_ntbl_bitcnt
	.type	bitcount_ntbl_bitcnt, @function
bitcount_ntbl_bitcnt:
	lui	a3,%hi(isaforge_bitcount_bits_4)
	mv	a5,a0
	addi	a3,a3,%lo(isaforge_bitcount_bits_4)
	li	a0,0
.L34:
	andi	a4,a5,15
	add	a4,a3,a4
	lbu	a4,0(a4)
	srli	a5,a5,4
	add	a0,a0,a4
	bne	a5,zero,.L34
	ret
	.size	bitcount_ntbl_bitcnt, .-bitcount_ntbl_bitcnt
	.section	.text.bitcount_btbl_bitcnt,"ax",@progbits
	.align	2
	.globl	bitcount_btbl_bitcnt
	.type	bitcount_btbl_bitcnt, @function
bitcount_btbl_bitcnt:
	lui	a3,%hi(isaforge_bitcount_bits_4)
	mv	a5,a0
	addi	a3,a3,%lo(isaforge_bitcount_bits_4)
	li	a0,0
.L37:
	andi	a4,a5,255
	add	a4,a3,a4
	lbu	a4,0(a4)
	srli	a5,a5,8
	add	a0,a0,a4
	bne	a5,zero,.L37
	ret
	.size	bitcount_btbl_bitcnt, .-bitcount_btbl_bitcnt
	.section	.text.bitcount_main,"ax",@progbits
	.align	2
	.globl	bitcount_main
	.type	bitcount_main, @function
bitcount_main:
	addi	sp,sp,-48
	sw	s2,32(sp)
	lui	s2,%hi(.L43)
	sw	s1,36(sp)
	sw	s8,8(sp)
	sw	s9,4(sp)
	sw	ra,44(sp)
	sw	s0,40(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	s7,12(sp)
	sw	s10,0(sp)
	li	s1,0
	li	s8,6
	addi	s2,s2,%lo(.L43)
	lui	s9,%hi(bitcount_res)
.L52:
	call	bitcount_random
	lui	a5,%hi(bitcount_iterations)
	addi	s6,s1,-1
	lw	s10,%lo(bitcount_iterations)(a5)
	lui	s4,%hi(bitcount_seed)
	slli	s5,s6,2
	sw	a0,%lo(bitcount_seed)(s4)
	li	s3,0
	add	s5,s5,s2
	lui	s7,%hi(bitcount_n)
.L40:
	bne	s10,s3,.L51
	addi	s1,s1,1
	li	a5,8
	bne	s1,a5,.L52
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	lw	s7,12(sp)
	lw	s8,8(sp)
	lw	s9,4(sp)
	lw	s10,0(sp)
	addi	sp,sp,48
	jr	ra
.L51:
	lw	s0,%lo(bitcount_seed)(s4)
	bgtu	s6,s8,.L41
	lw	a5,0(s5)
	mv	a0,s0
	jr	a5
	.section	.rodata.bitcount_main,"a",@progbits
	.align	2
	.align	2
.L43:
	.word	.L49
	.word	.L48
	.word	.L47
	.word	.L46
	.word	.L45
	.word	.L44
	.word	.L42
	.section	.text.bitcount_main
.L41:
	mv	a0,s0
	call	bitcount_bit_count
.L50:
	lw	a5,%lo(bitcount_n)(s7)
	addi	s0,s0,13
	sw	a0,%lo(bitcount_res)(s9)
	add	a5,a5,a0
	sw	a5,%lo(bitcount_n)(s7)
	addi	s3,s3,1
	sw	s0,%lo(bitcount_seed)(s4)
	j	.L40
.L49:
	call	bitcount_bitcount
	j	.L50
.L48:
	call	bitcount_ntbl_bitcnt
	j	.L50
.L47:
	call	bitcount_btbl_bitcnt
	j	.L50
.L46:
	call	bitcount_ntbl_bitcount
	j	.L50
.L45:
	call	bitcount_BW_btbl_bitcount
	j	.L50
.L44:
	call	bitcount_AR_btbl_bitcount
	j	.L50
.L42:
	call	bitcount_bit_shifter
	j	.L50
	.size	bitcount_main, .-bitcount_main
	.section	.text.isaforge_tacle_original_main,"ax",@progbits
	.align	2
	.globl	isaforge_tacle_original_main
	.type	isaforge_tacle_original_main, @function
isaforge_tacle_original_main:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	bitcount_init
	call	bitcount_main
	lui	a5,%hi(bitcount_n)
	lw	a0,%lo(bitcount_n)(a5)
	lw	ra,12(sp)
	addi	a0,a0,-1095
	snez	a0,a0
	addi	sp,sp,16
	jr	ra
	.size	isaforge_tacle_original_main, .-isaforge_tacle_original_main
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	tail	bitcount_init
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	bitcount_main
	lui	a5,%hi(bitcount_n)
	lw	a0,%lo(bitcount_n)(a5)
	lw	ra,12(sp)
	addi	a0,a0,-1095
	snez	a0,a0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	bne	a0,zero,.L63
	lui	a5,%hi(bitcount_n)
	lw	a0,%lo(bitcount_n)(a5)
	addi	a0,a0,-1095
	seqz	a0,a0
	ret
.L63:
	li	a0,0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.bss.isaforge_bitcount_bits_4,"aw",@nobits
	.align	2
	.type	isaforge_bitcount_bits_4, @object
	.size	isaforge_bitcount_bits_4, 256
isaforge_bitcount_bits_4:
	.zero	256
	.section	.bss.isaforge_bitcount_bits_3,"aw",@nobits
	.align	2
	.type	isaforge_bitcount_bits_3, @object
	.size	isaforge_bitcount_bits_3, 256
isaforge_bitcount_bits_3:
	.zero	256
	.globl	bitcount_iterations
	.section	.bss.bitcount_iterations,"aw",@nobits
	.align	2
	.type	bitcount_iterations, @object
	.size	bitcount_iterations, 4
bitcount_iterations:
	.zero	4
	.globl	bitcount_n
	.section	.bss.bitcount_n,"aw",@nobits
	.align	2
	.type	bitcount_n, @object
	.size	bitcount_n, 4
bitcount_n:
	.zero	4
	.globl	bitcount_seed
	.section	.bss.bitcount_seed,"aw",@nobits
	.align	2
	.type	bitcount_seed, @object
	.size	bitcount_seed, 4
bitcount_seed:
	.zero	4
	.globl	bitcount_res
	.section	.bss.bitcount_res,"aw",@nobits
	.align	2
	.type	bitcount_res, @object
	.size	bitcount_res, 4
bitcount_res:
	.zero	4
	.globl	bitcount_randseed
	.section	.bss.bitcount_randseed,"aw",@nobits
	.align	2
	.type	bitcount_randseed, @object
	.size	bitcount_randseed, 4
bitcount_randseed:
	.zero	4
	.section	.rodata
	.align	2
	.set	.LANCHOR0,. + 0
.LC0:
	.base64	"AAEBAgECAgMBAgIDAgMDBAECAgMCAwMEAgMDBAMEBAUBAgIDAgMDBAIDAwQDBAQFAgMDBAMEBAUDBAQFBAUFBgECAgMCAwMEAgMDBAMEBAUCAwMEAwQEBQMEBAUEBQUGAgMDBAMEBAUDBAQFBAUFBgMEBAUEBQUGBAUFBgUGBgcBAgIDAgMDBAIDAwQDBAQFAgMDBAMEBAUDBAQFBAUFBgIDAwQDBAQFAwQEBQQFBQYDBAQFBAUFBgQFBQYFBgYHAgMDBAMEBAUDBAQFBAUFBgMEBAUEBQUGBAUFBgUGBgcDBAQFBAUFBgQFBQYFBgYHBAUFBgUGBgcFBgYHBgcH"
	.ascii	"\b"
	.globl	__divsi3
	.globl	__mulsi3
	.globl	__modsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
