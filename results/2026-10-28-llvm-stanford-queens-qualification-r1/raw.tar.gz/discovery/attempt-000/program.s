	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.isaforge_queens_reset_output,"ax",@progbits
	.align	2
	.globl	isaforge_queens_reset_output
	.type	isaforge_queens_reset_output, @function
isaforge_queens_reset_output:
	lui	a5,%hi(output_errors)
	sw	zero,%lo(output_errors)(a5)
	lui	a5,%hi(output_calls)
	sw	zero,%lo(output_calls)(a5)
	li	a4,1
	lui	a5,%hi(expected_next)
	sw	a4,%lo(expected_next)(a5)
	ret
	.size	isaforge_queens_reset_output, .-isaforge_queens_reset_output
	.section	.rodata.isaforge_queens_printf.str1.4,"aMS",@progbits,1
	.align	2
.LC0:
	.string	"%d\n"
	.section	.text.isaforge_queens_printf,"ax",@progbits
	.align	2
	.globl	isaforge_queens_printf
	.type	isaforge_queens_printf, @function
isaforge_queens_printf:
	addi	sp,sp,-48
	sw	a5,36(sp)
	lui	a5,%hi(.LC0)
	sw	a1,20(sp)
	sw	a2,24(sp)
	sw	a3,28(sp)
	sw	a4,32(sp)
	sw	a6,40(sp)
	sw	a7,44(sp)
	addi	a5,a5,%lo(.LC0)
.L3:
	lbu	a3,0(a0)
	lbu	a4,0(a5)
	beq	a3,zero,.L4
	beq	a3,a4,.L5
.L6:
	lui	a4,%hi(output_errors)
	lw	a5,%lo(output_errors)(a4)
	addi	a5,a5,1
	sw	a5,%lo(output_errors)(a4)
	j	.L9
.L5:
	addi	a0,a0,1
	addi	a5,a5,1
	j	.L3
.L4:
	bne	a4,zero,.L6
	lw	a4,20(sp)
	addi	a5,sp,20
	sw	a5,12(sp)
	addi	a2,a4,-1
	li	a3,99
	lui	a5,%hi(expected_next)
	bgtu	a2,a3,.L7
	lw	a3,%lo(expected_next)(a5)
	beq	a4,a3,.L8
.L7:
	lui	a3,%hi(output_errors)
	lw	a4,%lo(output_errors)(a3)
	addi	a4,a4,1
	sw	a4,%lo(output_errors)(a3)
.L8:
	lui	a3,%hi(output_calls)
	lw	a4,%lo(output_calls)(a3)
	addi	a4,a4,1
	sw	a4,%lo(output_calls)(a3)
	lw	a4,%lo(expected_next)(a5)
	addi	a4,a4,1
	sw	a4,%lo(expected_next)(a5)
.L9:
	li	a0,0
	addi	sp,sp,48
	jr	ra
	.size	isaforge_queens_printf, .-isaforge_queens_printf
	.section	.text.Initrand,"ax",@progbits
	.align	2
	.globl	Initrand
	.type	Initrand, @function
Initrand:
	li	a5,73728
	lui	a4,%hi(seed)
	addi	a5,a5,1027
	sw	a5,%lo(seed)(a4)
	ret
	.size	Initrand, .-Initrand
	.section	.text.Rand,"ax",@progbits
	.align	2
	.globl	Rand
	.type	Rand, @function
Rand:
	addi	sp,sp,-16
	sw	s0,8(sp)
	lui	s0,%hi(seed)
	lw	a0,%lo(seed)(s0)
	li	a1,1309
	sw	ra,12(sp)
	call	__mulsi3
	li	a5,12288
	addi	a5,a5,1561
	add	a0,a0,a5
	slli	a0,a0,16
	srli	a0,a0,16
	lw	ra,12(sp)
	sw	a0,%lo(seed)(s0)
	lw	s0,8(sp)
	addi	sp,sp,16
	jr	ra
	.size	Rand, .-Rand
	.section	.text.Try,"ax",@progbits
	.align	2
	.globl	Try
	.type	Try, @function
Try:
	addi	sp,sp,-64
	sw	s0,56(sp)
	sw	s1,52(sp)
	sw	s2,48(sp)
	sw	s3,44(sp)
	sw	s4,40(sp)
	sw	s5,36(sp)
	slli	s4,a0,2
	sw	ra,60(sp)
	mv	s5,a0
	sw	zero,0(a1)
	addi	s1,a3,4
	add	s0,a2,s4
	add	s2,a4,s4
	li	s3,0
.L15:
	lw	a0,0(a1)
	bne	a0,zero,.L14
	addi	a0,s3,-8
	bne	a0,zero,.L20
.L14:
	lw	ra,60(sp)
	lw	s0,56(sp)
	lw	s1,52(sp)
	lw	s2,48(sp)
	lw	s3,44(sp)
	lw	s4,40(sp)
	lw	s5,36(sp)
	addi	sp,sp,64
	jr	ra
.L20:
	lw	a0,0(s1)
	addi	s3,s3,1
	beq	a0,zero,.L17
	lw	a0,4(s0)
	beq	a0,zero,.L17
	lw	a0,24(s2)
	beq	a0,zero,.L17
	add	a0,a5,s4
	sw	s3,0(a0)
	sw	zero,0(s1)
	sw	zero,4(s0)
	sw	zero,24(s2)
	li	a0,7
	bgt	s5,a0,.L19
	addi	a0,s5,1
	sw	a5,28(sp)
	sw	a4,24(sp)
	sw	a3,20(sp)
	sw	a2,16(sp)
	sw	a1,12(sp)
	call	Try
	lw	a1,12(sp)
	lw	a2,16(sp)
	lw	a3,20(sp)
	lw	a0,0(a1)
	lw	a4,24(sp)
	lw	a5,28(sp)
	bne	a0,zero,.L17
	li	a0,1
	sw	a0,0(s1)
	sw	a0,4(s0)
	sw	a0,24(s2)
.L17:
	addi	s1,s1,4
	addi	s0,s0,4
	addi	s2,s2,-4
	j	.L15
.L19:
	li	a0,1
	sw	a0,0(a1)
	j	.L17
	.size	Try, .-Try
	.section	.rodata.Doit.str1.4,"aMS",@progbits,1
	.align	2
.LC1:
	.string	" Error in Queens.\n"
	.section	.text.Doit,"ax",@progbits
	.align	2
	.globl	Doit
	.type	Doit, @function
Doit:
	addi	sp,sp,-224
	sw	ra,220(sp)
	addi	a2,sp,140
	addi	a3,sp,80
	addi	a4,sp,8
	li	a5,-7
	li	a0,7
	li	a1,1
	li	a6,17
.L37:
	addi	a7,a5,-1
	bgtu	a7,a0,.L33
	sw	a1,-28(a4)
.L33:
	bgt	a5,a1,.L34
.L36:
	sw	a1,0(a3)
.L35:
	addi	a5,a5,1
	addi	a2,a2,4
	addi	a3,a3,4
	addi	a4,a4,4
	bne	a5,a6,.L37
	addi	a5,sp,44
	addi	a4,sp,80
	addi	a3,sp,8
	addi	a2,sp,140
	addi	a1,sp,4
	li	a0,1
	call	Try
	lw	a5,4(sp)
	bne	a5,zero,.L32
	lui	a0,%hi(.LC1)
	addi	a0,a0,%lo(.LC1)
	call	isaforge_queens_printf
.L32:
	lw	ra,220(sp)
	addi	sp,sp,224
	jr	ra
.L34:
	sw	a1,-28(a2)
	ble	a5,a0,.L36
	j	.L35
	.size	Doit, .-Doit
	.section	.text.Queens,"ax",@progbits
	.align	2
	.globl	Queens
	.type	Queens, @function
Queens:
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	ra,28(sp)
	li	s0,50
.L42:
	sw	a0,12(sp)
	addi	s0,s0,-1
	call	Doit
	lw	a0,12(sp)
	bne	s0,zero,.L42
	lw	s0,24(sp)
	lw	ra,28(sp)
	addi	a1,a0,1
	lui	a0,%hi(.LC0)
	addi	a0,a0,%lo(.LC0)
	addi	sp,sp,32
	tail	isaforge_queens_printf
	.size	Queens, .-Queens
	.section	.text.isaforge_queens_upstream_main,"ax",@progbits
	.align	2
	.globl	isaforge_queens_upstream_main
	.type	isaforge_queens_upstream_main, @function
isaforge_queens_upstream_main:
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	ra,28(sp)
	li	a0,0
	li	s0,100
.L46:
	sw	a0,12(sp)
	call	Queens
	lw	a0,12(sp)
	addi	a0,a0,1
	bne	a0,s0,.L46
	lw	ra,28(sp)
	lw	s0,24(sp)
	li	a0,0
	addi	sp,sp,32
	jr	ra
	.size	isaforge_queens_upstream_main, .-isaforge_queens_upstream_main
	.section	.text.isaforge_queens_output_calls,"ax",@progbits
	.align	2
	.globl	isaforge_queens_output_calls
	.type	isaforge_queens_output_calls, @function
isaforge_queens_output_calls:
	lui	a5,%hi(output_calls)
	lw	a0,%lo(output_calls)(a5)
	ret
	.size	isaforge_queens_output_calls, .-isaforge_queens_output_calls
	.section	.text.isaforge_queens_output_errors,"ax",@progbits
	.align	2
	.globl	isaforge_queens_output_errors
	.type	isaforge_queens_output_errors, @function
isaforge_queens_output_errors:
	lui	a5,%hi(output_errors)
	lw	a0,%lo(output_errors)(a5)
	ret
	.size	isaforge_queens_output_errors, .-isaforge_queens_output_errors
	.section	.text.isaforge_queens_output_valid,"ax",@progbits
	.align	2
	.globl	isaforge_queens_output_valid
	.type	isaforge_queens_output_valid, @function
isaforge_queens_output_valid:
	lui	a5,%hi(output_errors)
	lw	a5,%lo(output_errors)(a5)
	li	a0,0
	bne	a5,zero,.L51
	lui	a5,%hi(output_calls)
	lw	a4,%lo(output_calls)(a5)
	li	a5,100
	bne	a4,a5,.L51
	lui	a5,%hi(expected_next)
	lw	a0,%lo(expected_next)(a5)
	addi	a0,a0,-101
	seqz	a0,a0
.L51:
	ret
	.size	isaforge_queens_output_valid, .-isaforge_queens_output_valid
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	tail	isaforge_queens_reset_output
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	isaforge_queens_reset_output
	call	isaforge_queens_upstream_main
	call	isaforge_queens_output_valid
	lw	ra,12(sp)
	xori	a0,a0,1
	neg	a0,a0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	bne	a0,zero,.L60
	tail	isaforge_queens_output_valid
.L60:
	li	a0,0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	zi
	.section	.bss.zi,"aw",@nobits
	.align	2
	.type	zi, @object
	.size	zi, 4
zi:
	.zero	4
	.globl	zr
	.section	.bss.zr,"aw",@nobits
	.align	2
	.type	zr, @object
	.size	zr, 4
zr:
	.zero	4
	.globl	e
	.section	.bss.e,"aw",@nobits
	.align	2
	.type	e, @object
	.size	e, 1040
e:
	.zero	1040
	.globl	w
	.section	.bss.w,"aw",@nobits
	.align	2
	.type	w, @object
	.size	w, 2056
w:
	.zero	2056
	.globl	z
	.section	.bss.z,"aw",@nobits
	.align	2
	.type	z, @object
	.size	z, 2056
z:
	.zero	2056
	.globl	top
	.section	.bss.top,"aw",@nobits
	.align	2
	.type	top, @object
	.size	top, 4
top:
	.zero	4
	.globl	littlest
	.section	.bss.littlest,"aw",@nobits
	.align	2
	.type	littlest, @object
	.size	littlest, 4
littlest:
	.zero	4
	.globl	biggest
	.section	.bss.biggest,"aw",@nobits
	.align	2
	.type	biggest, @object
	.size	biggest, 4
biggest:
	.zero	4
	.globl	sortlist
	.section	.bss.sortlist,"aw",@nobits
	.align	2
	.type	sortlist, @object
	.size	sortlist, 20004
sortlist:
	.zero	20004
	.globl	kount
	.section	.bss.kount,"aw",@nobits
	.align	2
	.type	kount, @object
	.size	kount, 4
kount:
	.zero	4
	.globl	n
	.section	.bss.n,"aw",@nobits
	.align	2
	.type	n, @object
	.size	n, 4
n:
	.zero	4
	.globl	p
	.section	.bss.p,"aw",@nobits
	.align	2
	.type	p, @object
	.size	p, 26624
p:
	.zero	26624
	.globl	puzzl
	.section	.bss.puzzl,"aw",@nobits
	.align	2
	.type	puzzl, @object
	.size	puzzl, 2048
puzzl:
	.zero	2048
	.globl	piecemax
	.section	.bss.piecemax,"aw",@nobits
	.align	2
	.type	piecemax, @object
	.size	piecemax, 52
piecemax:
	.zero	52
	.globl	class
	.section	.bss.class,"aw",@nobits
	.align	2
	.type	class, @object
	.size	class, 52
class:
	.zero	52
	.globl	piececount
	.section	.bss.piececount,"aw",@nobits
	.align	2
	.type	piececount, @object
	.size	piececount, 16
piececount:
	.zero	16
	.globl	rmr
	.section	.bss.rmr,"aw",@nobits
	.align	2
	.type	rmr, @object
	.size	rmr, 6724
rmr:
	.zero	6724
	.globl	rmb
	.section	.bss.rmb,"aw",@nobits
	.align	2
	.type	rmb, @object
	.size	rmb, 6724
rmb:
	.zero	6724
	.globl	rma
	.section	.bss.rma,"aw",@nobits
	.align	2
	.type	rma, @object
	.size	rma, 6724
rma:
	.zero	6724
	.globl	imr
	.section	.bss.imr,"aw",@nobits
	.align	2
	.type	imr, @object
	.size	imr, 6724
imr:
	.zero	6724
	.globl	imb
	.section	.bss.imb,"aw",@nobits
	.align	2
	.type	imb, @object
	.size	imb, 6724
imb:
	.zero	6724
	.globl	ima
	.section	.bss.ima,"aw",@nobits
	.align	2
	.type	ima, @object
	.size	ima, 6724
ima:
	.zero	6724
	.globl	movesdone
	.section	.bss.movesdone,"aw",@nobits
	.align	2
	.type	movesdone, @object
	.size	movesdone, 4
movesdone:
	.zero	4
	.globl	freelist
	.section	.bss.freelist,"aw",@nobits
	.align	2
	.type	freelist, @object
	.size	freelist, 4
freelist:
	.zero	4
	.globl	cellspace
	.section	.bss.cellspace,"aw",@nobits
	.align	2
	.type	cellspace, @object
	.size	cellspace, 152
cellspace:
	.zero	152
	.globl	stack
	.section	.bss.stack,"aw",@nobits
	.align	2
	.type	stack, @object
	.size	stack, 16
stack:
	.zero	16
	.globl	tree
	.section	.bss.tree,"aw",@nobits
	.align	2
	.type	tree, @object
	.size	tree, 4
tree:
	.zero	4
	.globl	pctr
	.section	.bss.pctr,"aw",@nobits
	.align	2
	.type	pctr, @object
	.size	pctr, 4
pctr:
	.zero	4
	.globl	permarray
	.section	.bss.permarray,"aw",@nobits
	.align	2
	.type	permarray, @object
	.size	permarray, 44
permarray:
	.zero	44
	.globl	seed
	.section	.bss.seed,"aw",@nobits
	.align	2
	.type	seed, @object
	.size	seed, 4
seed:
	.zero	4
	.globl	floated
	.section	.bss.floated,"aw",@nobits
	.align	2
	.type	floated, @object
	.size	floated, 4
floated:
	.zero	4
	.globl	fixed
	.section	.bss.fixed,"aw",@nobits
	.align	2
	.type	fixed, @object
	.size	fixed, 4
fixed:
	.zero	4
	.globl	value
	.section	.bss.value,"aw",@nobits
	.align	2
	.type	value, @object
	.size	value, 4
value:
	.zero	4
	.section	.bss.expected_next,"aw",@nobits
	.align	2
	.type	expected_next, @object
	.size	expected_next, 4
expected_next:
	.zero	4
	.section	.bss.output_calls,"aw",@nobits
	.align	2
	.type	output_calls, @object
	.size	output_calls, 4
output_calls:
	.zero	4
	.section	.bss.output_errors,"aw",@nobits
	.align	2
	.type	output_errors, @object
	.size	output_errors, 4
output_errors:
	.zero	4
	.globl	__mulsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
