module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000011;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {value_n1[30:0], 1'b0} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {stage_n1_0[29:0], 2'b0} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {stage_n1_1[27:0], 4'b0} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {stage_n1_2[23:0], 8'b0} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {stage_n1_3[15:0], 16'b0} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] a_n2 = n1;
wire [31:0] b_n2 = in1;
wire signed [63:0] p_n2 = $signed({{32{a_n2[31]}}, a_n2}) * $signed({32'b0, b_n2});
wire [31:0] n2 = p_n2[63:32];
assign result = n2;
endmodule
