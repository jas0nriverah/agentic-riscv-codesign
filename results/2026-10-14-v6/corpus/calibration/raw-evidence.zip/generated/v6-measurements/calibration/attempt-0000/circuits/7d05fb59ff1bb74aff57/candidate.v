module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 ^ 32'hfffff801;
wire [31:0] n1 = in0 - in1;
wire [31:0] n2 = n1 & 32'h0f0f0f0f;
wire [31:0] n3 = n2 - in0;
wire [31:0] n4 = n0 * n3;
assign result = n4;
endmodule
