module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 - in0;
wire [31:0] n1 = n0 + in1;
wire [31:0] n2 = in1 + 32'h000001ff;
wire [31:0] n3 = n1 + n2;
wire [31:0] n4 = n3 - in1;
assign result = n4;
endmodule
