module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 - in0;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = n1 - in1;
wire [31:0] n3 = n2 + 32'hfffffaab;
assign result = n3;
endmodule
