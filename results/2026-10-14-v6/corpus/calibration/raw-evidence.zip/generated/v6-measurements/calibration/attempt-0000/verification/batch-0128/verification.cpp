#include "Vverification_top.h"
#include "verilated.h"
#include <fstream>
#include <iostream>
#include <cstdint>
int main(int argc, char **argv) { Verilated::commandArgs(argc, argv);
Vverification_top top; std::ifstream vectors(argv[1]); uint32_t a,b,want; unsigned count=0;
while(vectors >> std::hex >> a >> b) { top.in0=a; top.in1=b; top.eval();
if (!(vectors >> std::hex >> want) || top.out_0 != want) { std::cerr << "Mismatch formula 0 vector " << std::dec << count << " got " << std::hex << top.out_0 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_1 != want) { std::cerr << "Mismatch formula 1 vector " << std::dec << count << " got " << std::hex << top.out_1 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_2 != want) { std::cerr << "Mismatch formula 2 vector " << std::dec << count << " got " << std::hex << top.out_2 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_3 != want) { std::cerr << "Mismatch formula 3 vector " << std::dec << count << " got " << std::hex << top.out_3 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_4 != want) { std::cerr << "Mismatch formula 4 vector " << std::dec << count << " got " << std::hex << top.out_4 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_5 != want) { std::cerr << "Mismatch formula 5 vector " << std::dec << count << " got " << std::hex << top.out_5 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_6 != want) { std::cerr << "Mismatch formula 6 vector " << std::dec << count << " got " << std::hex << top.out_6 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_7 != want) { std::cerr << "Mismatch formula 7 vector " << std::dec << count << " got " << std::hex << top.out_7 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_8 != want) { std::cerr << "Mismatch formula 8 vector " << std::dec << count << " got " << std::hex << top.out_8 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_9 != want) { std::cerr << "Mismatch formula 9 vector " << std::dec << count << " got " << std::hex << top.out_9 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_10 != want) { std::cerr << "Mismatch formula 10 vector " << std::dec << count << " got " << std::hex << top.out_10 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_11 != want) { std::cerr << "Mismatch formula 11 vector " << std::dec << count << " got " << std::hex << top.out_11 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_12 != want) { std::cerr << "Mismatch formula 12 vector " << std::dec << count << " got " << std::hex << top.out_12 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_13 != want) { std::cerr << "Mismatch formula 13 vector " << std::dec << count << " got " << std::hex << top.out_13 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_14 != want) { std::cerr << "Mismatch formula 14 vector " << std::dec << count << " got " << std::hex << top.out_14 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_15 != want) { std::cerr << "Mismatch formula 15 vector " << std::dec << count << " got " << std::hex << top.out_15 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_16 != want) { std::cerr << "Mismatch formula 16 vector " << std::dec << count << " got " << std::hex << top.out_16 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_17 != want) { std::cerr << "Mismatch formula 17 vector " << std::dec << count << " got " << std::hex << top.out_17 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_18 != want) { std::cerr << "Mismatch formula 18 vector " << std::dec << count << " got " << std::hex << top.out_18 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_19 != want) { std::cerr << "Mismatch formula 19 vector " << std::dec << count << " got " << std::hex << top.out_19 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_20 != want) { std::cerr << "Mismatch formula 20 vector " << std::dec << count << " got " << std::hex << top.out_20 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_21 != want) { std::cerr << "Mismatch formula 21 vector " << std::dec << count << " got " << std::hex << top.out_21 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_22 != want) { std::cerr << "Mismatch formula 22 vector " << std::dec << count << " got " << std::hex << top.out_22 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_23 != want) { std::cerr << "Mismatch formula 23 vector " << std::dec << count << " got " << std::hex << top.out_23 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_24 != want) { std::cerr << "Mismatch formula 24 vector " << std::dec << count << " got " << std::hex << top.out_24 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_25 != want) { std::cerr << "Mismatch formula 25 vector " << std::dec << count << " got " << std::hex << top.out_25 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_26 != want) { std::cerr << "Mismatch formula 26 vector " << std::dec << count << " got " << std::hex << top.out_26 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_27 != want) { std::cerr << "Mismatch formula 27 vector " << std::dec << count << " got " << std::hex << top.out_27 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_28 != want) { std::cerr << "Mismatch formula 28 vector " << std::dec << count << " got " << std::hex << top.out_28 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_29 != want) { std::cerr << "Mismatch formula 29 vector " << std::dec << count << " got " << std::hex << top.out_29 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_30 != want) { std::cerr << "Mismatch formula 30 vector " << std::dec << count << " got " << std::hex << top.out_30 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_31 != want) { std::cerr << "Mismatch formula 31 vector " << std::dec << count << " got " << std::hex << top.out_31 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_32 != want) { std::cerr << "Mismatch formula 32 vector " << std::dec << count << " got " << std::hex << top.out_32 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_33 != want) { std::cerr << "Mismatch formula 33 vector " << std::dec << count << " got " << std::hex << top.out_33 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_34 != want) { std::cerr << "Mismatch formula 34 vector " << std::dec << count << " got " << std::hex << top.out_34 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_35 != want) { std::cerr << "Mismatch formula 35 vector " << std::dec << count << " got " << std::hex << top.out_35 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_36 != want) { std::cerr << "Mismatch formula 36 vector " << std::dec << count << " got " << std::hex << top.out_36 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_37 != want) { std::cerr << "Mismatch formula 37 vector " << std::dec << count << " got " << std::hex << top.out_37 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_38 != want) { std::cerr << "Mismatch formula 38 vector " << std::dec << count << " got " << std::hex << top.out_38 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_39 != want) { std::cerr << "Mismatch formula 39 vector " << std::dec << count << " got " << std::hex << top.out_39 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_40 != want) { std::cerr << "Mismatch formula 40 vector " << std::dec << count << " got " << std::hex << top.out_40 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_41 != want) { std::cerr << "Mismatch formula 41 vector " << std::dec << count << " got " << std::hex << top.out_41 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_42 != want) { std::cerr << "Mismatch formula 42 vector " << std::dec << count << " got " << std::hex << top.out_42 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_43 != want) { std::cerr << "Mismatch formula 43 vector " << std::dec << count << " got " << std::hex << top.out_43 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_44 != want) { std::cerr << "Mismatch formula 44 vector " << std::dec << count << " got " << std::hex << top.out_44 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_45 != want) { std::cerr << "Mismatch formula 45 vector " << std::dec << count << " got " << std::hex << top.out_45 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_46 != want) { std::cerr << "Mismatch formula 46 vector " << std::dec << count << " got " << std::hex << top.out_46 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_47 != want) { std::cerr << "Mismatch formula 47 vector " << std::dec << count << " got " << std::hex << top.out_47 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_48 != want) { std::cerr << "Mismatch formula 48 vector " << std::dec << count << " got " << std::hex << top.out_48 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_49 != want) { std::cerr << "Mismatch formula 49 vector " << std::dec << count << " got " << std::hex << top.out_49 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_50 != want) { std::cerr << "Mismatch formula 50 vector " << std::dec << count << " got " << std::hex << top.out_50 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_51 != want) { std::cerr << "Mismatch formula 51 vector " << std::dec << count << " got " << std::hex << top.out_51 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_52 != want) { std::cerr << "Mismatch formula 52 vector " << std::dec << count << " got " << std::hex << top.out_52 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_53 != want) { std::cerr << "Mismatch formula 53 vector " << std::dec << count << " got " << std::hex << top.out_53 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_54 != want) { std::cerr << "Mismatch formula 54 vector " << std::dec << count << " got " << std::hex << top.out_54 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_55 != want) { std::cerr << "Mismatch formula 55 vector " << std::dec << count << " got " << std::hex << top.out_55 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_56 != want) { std::cerr << "Mismatch formula 56 vector " << std::dec << count << " got " << std::hex << top.out_56 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_57 != want) { std::cerr << "Mismatch formula 57 vector " << std::dec << count << " got " << std::hex << top.out_57 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_58 != want) { std::cerr << "Mismatch formula 58 vector " << std::dec << count << " got " << std::hex << top.out_58 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_59 != want) { std::cerr << "Mismatch formula 59 vector " << std::dec << count << " got " << std::hex << top.out_59 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_60 != want) { std::cerr << "Mismatch formula 60 vector " << std::dec << count << " got " << std::hex << top.out_60 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_61 != want) { std::cerr << "Mismatch formula 61 vector " << std::dec << count << " got " << std::hex << top.out_61 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_62 != want) { std::cerr << "Mismatch formula 62 vector " << std::dec << count << " got " << std::hex << top.out_62 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_63 != want) { std::cerr << "Mismatch formula 63 vector " << std::dec << count << " got " << std::hex << top.out_63 << " expected " << want << "\n"; return 1; }
++count; }
std::cout << count << " vectors passed\n"; top.final(); return 0; }