module candidate(input wire [31:0] in0,in1,output wire [31:0] result); assign result=32'b0; endmodule
