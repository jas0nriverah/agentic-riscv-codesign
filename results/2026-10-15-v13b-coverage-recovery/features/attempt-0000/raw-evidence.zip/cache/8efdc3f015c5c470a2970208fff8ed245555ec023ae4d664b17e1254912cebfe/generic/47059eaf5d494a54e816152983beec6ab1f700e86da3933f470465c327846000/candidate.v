module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = in1 & 32'h00000155;
wire [31:0] n2 = n0 + n1;
wire [31:0] n3 = n2 - in0;
assign result = n3;
endmodule
