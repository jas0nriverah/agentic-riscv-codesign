	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.levenshtein_distance,"ax",@progbits
	.align	2
	.globl	levenshtein_distance
	.type	levenshtein_distance, @function
levenshtein_distance:
	addi	sp,sp,-80
	sw	ra,76(sp)
	sw	s0,72(sp)
	sw	s1,68(sp)
	addi	s0,sp,80
	sw	s2,64(sp)
	sw	s4,56(sp)
	sw	s5,52(sp)
	sw	s9,36(sp)
	sw	s11,28(sp)
	sw	s3,60(sp)
	sw	s6,48(sp)
	sw	s7,44(sp)
	sw	s8,40(sp)
	sw	s10,32(sp)
	mv	s11,a1
	sw	a0,-68(s0)
	call	strlen
	mv	s5,a0
	mv	a0,s11
	call	strlen
	addi	s2,a0,1
	mv	a1,s2
	mv	s4,a0
	addi	a0,s5,1
	call	__mulsi3
	slli	a0,a0,2
	addi	a0,a0,15
	andi	a0,a0,-16
	slli	s2,s2,2
	sub	sp,sp,a0
	srli	s9,s2,2
	mv	s1,sp
	li	s2,0
.L2:
	ble	s2,s5,.L3
	li	a5,0
.L4:
	ble	a5,s4,.L5
	li	s8,1
.L6:
	ble	s8,s4,.L12
	mv	a1,s9
	mv	a0,s5
	call	__mulsi3
	add	a0,a0,s4
	slli	a0,a0,2
	add	s1,s1,a0
	lw	a0,0(s1)
	addi	sp,s0,-80
	lw	ra,76(sp)
	lw	s0,72(sp)
	lw	s1,68(sp)
	lw	s2,64(sp)
	lw	s3,60(sp)
	lw	s4,56(sp)
	lw	s5,52(sp)
	lw	s6,48(sp)
	lw	s7,44(sp)
	lw	s8,40(sp)
	lw	s9,36(sp)
	lw	s10,32(sp)
	lw	s11,28(sp)
	addi	sp,sp,80
	jr	ra
.L3:
	mv	a0,s2
	mv	a1,s9
	call	__mulsi3
	slli	a0,a0,2
	add	a0,s1,a0
	sw	s2,0(a0)
	addi	s2,s2,1
	j	.L2
.L5:
	slli	a4,a5,2
	add	a4,s1,a4
	sw	a5,0(a4)
	addi	a5,a5,1
	j	.L4
.L10:
	mv	a1,s9
	addi	a0,s3,-1
	call	__mulsi3
	lw	a5,-68(s0)
	add	a0,a0,s6
	slli	a0,a0,2
	add	a5,a5,s3
	lbu	a4,-1(a5)
	lbu	a5,-1(s7)
	add	a0,s1,a0
	lw	s2,0(a0)
	beq	a4,a5,.L7
	mv	a1,s9
	addi	a0,s3,-1
	call	__mulsi3
	add	a0,a0,s8
	slli	a0,a0,2
	add	a0,s1,a0
	lw	a5,0(a0)
	addi	a4,s2,1
	addi	s2,a5,1
	ble	s2,a4,.L8
	mv	s2,a4
.L8:
	mv	a1,s9
	mv	a0,s3
	call	__mulsi3
	add	a0,a0,s6
	slli	a0,a0,2
	add	a0,s1,a0
	lw	a5,0(a0)
	addi	a5,a5,1
	ble	s2,a5,.L7
	mv	s2,a5
.L7:
	mv	a0,s3
	mv	a1,s9
	call	__mulsi3
	add	a0,a0,s8
	slli	a0,a0,2
	add	a0,s1,a0
	sw	s2,0(a0)
	addi	s3,s3,1
.L11:
	ble	s3,s5,.L10
	addi	s8,s8,1
	j	.L6
.L12:
	li	s3,1
	addi	s6,s8,-1
	add	s7,s11,s8
	j	.L11
	.size	levenshtein_distance, .-levenshtein_distance
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-48
	sw	s1,36(sp)
	lui	s1,%hi(strings)
	addi	s1,s1,%lo(strings)
	sw	s2,32(sp)
	sw	s3,28(sp)
	sw	ra,44(sp)
	sw	s0,40(sp)
	sw	zero,12(sp)
	addi	s3,s1,20
	mv	s2,s1
.L16:
	mv	s0,s1
.L17:
	lw	a1,0(s0)
	lw	a0,0(s2)
	addi	s0,s0,4
	call	levenshtein_distance
	lw	a5,12(sp)
	add	a0,a0,a5
	sw	a0,12(sp)
	bne	s0,s3,.L17
	addi	s2,s2,4
	bne	s2,s0,.L16
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	a0,12(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	addi	sp,sp,48
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-122
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	strings
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
.LC0:
	.string	"srrjngre"
	.align	2
.LC1:
	.string	"asfcjnsdkj"
	.align	2
.LC2:
	.string	"string"
	.align	2
.LC3:
	.string	"msd"
	.align	2
.LC4:
	.string	"strings"
	.section	.data.strings,"aw"
	.align	2
	.type	strings, @object
	.size	strings, 20
strings:
	.word	.LC0
	.word	.LC1
	.word	.LC2
	.word	.LC3
	.word	.LC4
	.globl	__mulsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
