module verification_top(input wire [31:0] in0, in1, output wire [31:0] out_0, output wire [31:0] out_1, output wire [31:0] out_2, output wire [31:0] out_3, output wire [31:0] out_4, output wire [31:0] out_5, output wire [31:0] out_6, output wire [31:0] out_7, output wire [31:0] out_8, output wire [31:0] out_9, output wire [31:0] out_10, output wire [31:0] out_11, output wire [31:0] out_12, output wire [31:0] out_13, output wire [31:0] out_14, output wire [31:0] out_15, output wire [31:0] out_16, output wire [31:0] out_17, output wire [31:0] out_18, output wire [31:0] out_19, output wire [31:0] out_20, output wire [31:0] out_21, output wire [31:0] out_22, output wire [31:0] out_23, output wire [31:0] out_24, output wire [31:0] out_25, output wire [31:0] out_26, output wire [31:0] out_27, output wire [31:0] out_28, output wire [31:0] out_29, output wire [31:0] out_30, output wire [31:0] out_31, output wire [31:0] out_32, output wire [31:0] out_33, output wire [31:0] out_34, output wire [31:0] out_35, output wire [31:0] out_36, output wire [31:0] out_37, output wire [31:0] out_38, output wire [31:0] out_39, output wire [31:0] out_40, output wire [31:0] out_41, output wire [31:0] out_42, output wire [31:0] out_43, output wire [31:0] out_44, output wire [31:0] out_45, output wire [31:0] out_46, output wire [31:0] out_47, output wire [31:0] out_48, output wire [31:0] out_49, output wire [31:0] out_50, output wire [31:0] out_51, output wire [31:0] out_52, output wire [31:0] out_53, output wire [31:0] out_54, output wire [31:0] out_55, output wire [31:0] out_56, output wire [31:0] out_57, output wire [31:0] out_58, output wire [31:0] out_59, output wire [31:0] out_60, output wire [31:0] out_61, output wire [31:0] out_62, output wire [31:0] out_63, output wire [31:0] out_64, output wire [31:0] out_65, output wire [31:0] out_66, output wire [31:0] out_67, output wire [31:0] out_68, output wire [31:0] out_69, output wire [31:0] out_70, output wire [31:0] out_71, output wire [31:0] out_72, output wire [31:0] out_73, output wire [31:0] out_74, output wire [31:0] out_75, output wire [31:0] out_76, output wire [31:0] out_77, output wire [31:0] out_78, output wire [31:0] out_79, output wire [31:0] out_80, output wire [31:0] out_81, output wire [31:0] out_82, output wire [31:0] out_83, output wire [31:0] out_84, output wire [31:0] out_85, output wire [31:0] out_86, output wire [31:0] out_87, output wire [31:0] out_88, output wire [31:0] out_89, output wire [31:0] out_90, output wire [31:0] out_91, output wire [31:0] out_92, output wire [31:0] out_93, output wire [31:0] out_94, output wire [31:0] out_95, output wire [31:0] out_96, output wire [31:0] out_97, output wire [31:0] out_98, output wire [31:0] out_99, output wire [31:0] out_100, output wire [31:0] out_101, output wire [31:0] out_102, output wire [31:0] out_103, output wire [31:0] out_104, output wire [31:0] out_105, output wire [31:0] out_106, output wire [31:0] out_107, output wire [31:0] out_108, output wire [31:0] out_109, output wire [31:0] out_110, output wire [31:0] out_111, output wire [31:0] out_112, output wire [31:0] out_113, output wire [31:0] out_114, output wire [31:0] out_115, output wire [31:0] out_116, output wire [31:0] out_117, output wire [31:0] out_118, output wire [31:0] out_119, output wire [31:0] out_120, output wire [31:0] out_121, output wire [31:0] out_122, output wire [31:0] out_123, output wire [31:0] out_124, output wire [31:0] out_125, output wire [31:0] out_126, output wire [31:0] out_127);
candidate_0 c0(.in0(in0), .in1(in1), .result(out_0));
candidate_1 c1(.in0(in0), .in1(in1), .result(out_1));
candidate_2 c2(.in0(in0), .in1(in1), .result(out_2));
candidate_3 c3(.in0(in0), .in1(in1), .result(out_3));
candidate_4 c4(.in0(in0), .in1(in1), .result(out_4));
candidate_5 c5(.in0(in0), .in1(in1), .result(out_5));
candidate_6 c6(.in0(in0), .in1(in1), .result(out_6));
candidate_7 c7(.in0(in0), .in1(in1), .result(out_7));
candidate_8 c8(.in0(in0), .in1(in1), .result(out_8));
candidate_9 c9(.in0(in0), .in1(in1), .result(out_9));
candidate_10 c10(.in0(in0), .in1(in1), .result(out_10));
candidate_11 c11(.in0(in0), .in1(in1), .result(out_11));
candidate_12 c12(.in0(in0), .in1(in1), .result(out_12));
candidate_13 c13(.in0(in0), .in1(in1), .result(out_13));
candidate_14 c14(.in0(in0), .in1(in1), .result(out_14));
candidate_15 c15(.in0(in0), .in1(in1), .result(out_15));
candidate_16 c16(.in0(in0), .in1(in1), .result(out_16));
candidate_17 c17(.in0(in0), .in1(in1), .result(out_17));
candidate_18 c18(.in0(in0), .in1(in1), .result(out_18));
candidate_19 c19(.in0(in0), .in1(in1), .result(out_19));
candidate_20 c20(.in0(in0), .in1(in1), .result(out_20));
candidate_21 c21(.in0(in0), .in1(in1), .result(out_21));
candidate_22 c22(.in0(in0), .in1(in1), .result(out_22));
candidate_23 c23(.in0(in0), .in1(in1), .result(out_23));
candidate_24 c24(.in0(in0), .in1(in1), .result(out_24));
candidate_25 c25(.in0(in0), .in1(in1), .result(out_25));
candidate_26 c26(.in0(in0), .in1(in1), .result(out_26));
candidate_27 c27(.in0(in0), .in1(in1), .result(out_27));
candidate_28 c28(.in0(in0), .in1(in1), .result(out_28));
candidate_29 c29(.in0(in0), .in1(in1), .result(out_29));
candidate_30 c30(.in0(in0), .in1(in1), .result(out_30));
candidate_31 c31(.in0(in0), .in1(in1), .result(out_31));
candidate_32 c32(.in0(in0), .in1(in1), .result(out_32));
candidate_33 c33(.in0(in0), .in1(in1), .result(out_33));
candidate_34 c34(.in0(in0), .in1(in1), .result(out_34));
candidate_35 c35(.in0(in0), .in1(in1), .result(out_35));
candidate_36 c36(.in0(in0), .in1(in1), .result(out_36));
candidate_37 c37(.in0(in0), .in1(in1), .result(out_37));
candidate_38 c38(.in0(in0), .in1(in1), .result(out_38));
candidate_39 c39(.in0(in0), .in1(in1), .result(out_39));
candidate_40 c40(.in0(in0), .in1(in1), .result(out_40));
candidate_41 c41(.in0(in0), .in1(in1), .result(out_41));
candidate_42 c42(.in0(in0), .in1(in1), .result(out_42));
candidate_43 c43(.in0(in0), .in1(in1), .result(out_43));
candidate_44 c44(.in0(in0), .in1(in1), .result(out_44));
candidate_45 c45(.in0(in0), .in1(in1), .result(out_45));
candidate_46 c46(.in0(in0), .in1(in1), .result(out_46));
candidate_47 c47(.in0(in0), .in1(in1), .result(out_47));
candidate_48 c48(.in0(in0), .in1(in1), .result(out_48));
candidate_49 c49(.in0(in0), .in1(in1), .result(out_49));
candidate_50 c50(.in0(in0), .in1(in1), .result(out_50));
candidate_51 c51(.in0(in0), .in1(in1), .result(out_51));
candidate_52 c52(.in0(in0), .in1(in1), .result(out_52));
candidate_53 c53(.in0(in0), .in1(in1), .result(out_53));
candidate_54 c54(.in0(in0), .in1(in1), .result(out_54));
candidate_55 c55(.in0(in0), .in1(in1), .result(out_55));
candidate_56 c56(.in0(in0), .in1(in1), .result(out_56));
candidate_57 c57(.in0(in0), .in1(in1), .result(out_57));
candidate_58 c58(.in0(in0), .in1(in1), .result(out_58));
candidate_59 c59(.in0(in0), .in1(in1), .result(out_59));
candidate_60 c60(.in0(in0), .in1(in1), .result(out_60));
candidate_61 c61(.in0(in0), .in1(in1), .result(out_61));
candidate_62 c62(.in0(in0), .in1(in1), .result(out_62));
candidate_63 c63(.in0(in0), .in1(in1), .result(out_63));
candidate_64 c64(.in0(in0), .in1(in1), .result(out_64));
candidate_65 c65(.in0(in0), .in1(in1), .result(out_65));
candidate_66 c66(.in0(in0), .in1(in1), .result(out_66));
candidate_67 c67(.in0(in0), .in1(in1), .result(out_67));
candidate_68 c68(.in0(in0), .in1(in1), .result(out_68));
candidate_69 c69(.in0(in0), .in1(in1), .result(out_69));
candidate_70 c70(.in0(in0), .in1(in1), .result(out_70));
candidate_71 c71(.in0(in0), .in1(in1), .result(out_71));
candidate_72 c72(.in0(in0), .in1(in1), .result(out_72));
candidate_73 c73(.in0(in0), .in1(in1), .result(out_73));
candidate_74 c74(.in0(in0), .in1(in1), .result(out_74));
candidate_75 c75(.in0(in0), .in1(in1), .result(out_75));
candidate_76 c76(.in0(in0), .in1(in1), .result(out_76));
candidate_77 c77(.in0(in0), .in1(in1), .result(out_77));
candidate_78 c78(.in0(in0), .in1(in1), .result(out_78));
candidate_79 c79(.in0(in0), .in1(in1), .result(out_79));
candidate_80 c80(.in0(in0), .in1(in1), .result(out_80));
candidate_81 c81(.in0(in0), .in1(in1), .result(out_81));
candidate_82 c82(.in0(in0), .in1(in1), .result(out_82));
candidate_83 c83(.in0(in0), .in1(in1), .result(out_83));
candidate_84 c84(.in0(in0), .in1(in1), .result(out_84));
candidate_85 c85(.in0(in0), .in1(in1), .result(out_85));
candidate_86 c86(.in0(in0), .in1(in1), .result(out_86));
candidate_87 c87(.in0(in0), .in1(in1), .result(out_87));
candidate_88 c88(.in0(in0), .in1(in1), .result(out_88));
candidate_89 c89(.in0(in0), .in1(in1), .result(out_89));
candidate_90 c90(.in0(in0), .in1(in1), .result(out_90));
candidate_91 c91(.in0(in0), .in1(in1), .result(out_91));
candidate_92 c92(.in0(in0), .in1(in1), .result(out_92));
candidate_93 c93(.in0(in0), .in1(in1), .result(out_93));
candidate_94 c94(.in0(in0), .in1(in1), .result(out_94));
candidate_95 c95(.in0(in0), .in1(in1), .result(out_95));
candidate_96 c96(.in0(in0), .in1(in1), .result(out_96));
candidate_97 c97(.in0(in0), .in1(in1), .result(out_97));
candidate_98 c98(.in0(in0), .in1(in1), .result(out_98));
candidate_99 c99(.in0(in0), .in1(in1), .result(out_99));
candidate_100 c100(.in0(in0), .in1(in1), .result(out_100));
candidate_101 c101(.in0(in0), .in1(in1), .result(out_101));
candidate_102 c102(.in0(in0), .in1(in1), .result(out_102));
candidate_103 c103(.in0(in0), .in1(in1), .result(out_103));
candidate_104 c104(.in0(in0), .in1(in1), .result(out_104));
candidate_105 c105(.in0(in0), .in1(in1), .result(out_105));
candidate_106 c106(.in0(in0), .in1(in1), .result(out_106));
candidate_107 c107(.in0(in0), .in1(in1), .result(out_107));
candidate_108 c108(.in0(in0), .in1(in1), .result(out_108));
candidate_109 c109(.in0(in0), .in1(in1), .result(out_109));
candidate_110 c110(.in0(in0), .in1(in1), .result(out_110));
candidate_111 c111(.in0(in0), .in1(in1), .result(out_111));
candidate_112 c112(.in0(in0), .in1(in1), .result(out_112));
candidate_113 c113(.in0(in0), .in1(in1), .result(out_113));
candidate_114 c114(.in0(in0), .in1(in1), .result(out_114));
candidate_115 c115(.in0(in0), .in1(in1), .result(out_115));
candidate_116 c116(.in0(in0), .in1(in1), .result(out_116));
candidate_117 c117(.in0(in0), .in1(in1), .result(out_117));
candidate_118 c118(.in0(in0), .in1(in1), .result(out_118));
candidate_119 c119(.in0(in0), .in1(in1), .result(out_119));
candidate_120 c120(.in0(in0), .in1(in1), .result(out_120));
candidate_121 c121(.in0(in0), .in1(in1), .result(out_121));
candidate_122 c122(.in0(in0), .in1(in1), .result(out_122));
candidate_123 c123(.in0(in0), .in1(in1), .result(out_123));
candidate_124 c124(.in0(in0), .in1(in1), .result(out_124));
candidate_125 c125(.in0(in0), .in1(in1), .result(out_125));
candidate_126 c126(.in0(in0), .in1(in1), .result(out_126));
candidate_127 c127(.in0(in0), .in1(in1), .result(out_127));
endmodule
module candidate_0(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] n1 = {31'b0, (n0 < in0)};
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_1(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hffffffff;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_2(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hfffffb0c;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_3(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hfffffff1;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_4(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hfffffe88;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_5(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hfffffe88;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {value_n1[30:0], 1'b0} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {stage_n1_0[29:0], 2'b0} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {stage_n1_1[27:0], 4'b0} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {stage_n1_2[23:0], 8'b0} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {stage_n1_3[15:0], 16'b0} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_6(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000000;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_7(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000000;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {value_n1[30:0], 1'b0} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {stage_n1_0[29:0], 2'b0} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {stage_n1_1[27:0], 4'b0} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {stage_n1_2[23:0], 8'b0} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {stage_n1_3[15:0], 16'b0} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_8(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000001;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_9(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h0000000f;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_10(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000006a0;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_11(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000001d8;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_12(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000001d8;
wire [31:0] n1 = 32'h00000000 + 32'h00000018;
wire [31:0] shift_n2 = n1;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {1'b0, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {2'b0, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {4'b0, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {8'b0, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {16'b0, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n0 + n2;
assign result = n3;
endmodule

module candidate_13(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000001f8;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_14(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000224;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_15(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000274;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_16(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000274;
wire [31:0] n1 = 32'h00000000 + 32'h00000018;
wire [31:0] shift_n2 = n1;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {1'b0, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {2'b0, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {4'b0, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {8'b0, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {16'b0, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n0 + n2;
assign result = n3;
endmodule

module candidate_17(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000294;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_18(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000298;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_19(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000298;
wire [31:0] n1 = 32'h00000000 + 32'h00000018;
wire [31:0] shift_n2 = n1;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {1'b0, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {2'b0, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {4'b0, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {8'b0, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {16'b0, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n0 + n2;
assign result = n3;
endmodule

module candidate_20(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000002b8;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_21(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000002c0;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_22(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000002e4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_23(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h00000000;
wire [31:0] n2 = n1 + in0;
assign result = n2;
endmodule

module candidate_24(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h00000000;
wire [31:0] shift_n2 = 32'h00000002;
wire [31:0] value_n2 = in0;
wire [31:0] stage_n2_0 = shift_n2[0] ? {value_n2[30:0], 1'b0} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {stage_n2_0[29:0], 2'b0} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {stage_n2_1[27:0], 4'b0} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {stage_n2_2[23:0], 8'b0} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {stage_n2_3[15:0], 16'b0} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 + n2;
assign result = n3;
endmodule

module candidate_25(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80005000;
wire [31:0] n1 = n0 + 32'hfffffe88;
wire [31:0] n2 = n1 + in0;
assign result = n2;
endmodule

module candidate_26(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80005000;
wire [31:0] n1 = n0 + 32'hfffffe88;
wire [31:0] shift_n2 = 32'h00000002;
wire [31:0] value_n2 = in0;
wire [31:0] stage_n2_0 = shift_n2[0] ? {value_n2[30:0], 1'b0} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {stage_n2_0[29:0], 2'b0} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {stage_n2_1[27:0], 4'b0} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {stage_n2_2[23:0], 8'b0} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {stage_n2_3[15:0], 16'b0} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 + n2;
assign result = n3;
endmodule

module candidate_27(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h00000004;
wire [31:0] n1 = n0 & 32'hfffffffc;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_28(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'hfffffffc;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_29(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'hfffffffc;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = in0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_30(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h00000007;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_31(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] a_n0 = in0;
wire [31:0] b_n0 = in1;
wire signed [63:0] p_n0 = $signed({32'b0, a_n0}) * $signed({32'b0, b_n0});
wire [31:0] n0 = p_n0[63:32];
wire [31:0] n1 = n0 & 32'hfffffffc;
wire [31:0] shift_n2 = 32'h00000002;
wire [31:0] value_n2 = n0;
wire [31:0] stage_n2_0 = shift_n2[0] ? {1'b0, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {2'b0, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {4'b0, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {8'b0, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {16'b0, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 + n2;
assign result = n3;
endmodule

module candidate_32(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 + 32'h0000015c;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_33(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 + 32'h00000354;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_34(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h00000354;
wire [31:0] n2 = in0 + n1;
assign result = n2;
endmodule

module candidate_35(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00003000;
wire [31:0] n1 = n0 + 32'h0000015c;
wire [31:0] n2 = in0 + n1;
assign result = n2;
endmodule

module candidate_36(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 & 32'hfffffffc;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_37(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 & 32'h00000003;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_38(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00001000;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_39(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in1 + 32'h000002e0;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {value_n1[30:0], 1'b0} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {stage_n1_0[29:0], 2'b0} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {stage_n1_1[27:0], 4'b0} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {stage_n1_2[23:0], 8'b0} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {stage_n1_3[15:0], 16'b0} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = in0 + n1;
assign result = n2;
endmodule

module candidate_40(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000002;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_41(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000008;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_42(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = {31'b0, (in0 < in1)};
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_43(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000003;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_44(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000018;
wire [31:0] shift_n1 = n0;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = in0 + n1;
assign result = n2;
endmodule

module candidate_45(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000001;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_46(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_47(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000018;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_48(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001c;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_49(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000003;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
assign result = n1;
endmodule

module candidate_50(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h00000010;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = in0 + n1;
assign result = n2;
endmodule

module candidate_51(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000002;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in0;
wire [31:0] shift_n2 = 32'h00000001;
wire [31:0] value_n2 = n1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {value_n2[30:0], 1'b0} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {stage_n2_0[29:0], 2'b0} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {stage_n2_1[27:0], 4'b0} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {stage_n2_2[23:0], 8'b0} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {stage_n2_3[15:0], 16'b0} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n2 + in1;
assign result = n3;
endmodule

module candidate_52(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000001;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_53(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_54(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h00000010;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_55(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h00000010;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {value_n1[30:0], 1'b0} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {stage_n1_0[29:0], 2'b0} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {stage_n1_1[27:0], 4'b0} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {stage_n1_2[23:0], 8'b0} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {stage_n1_3[15:0], 16'b0} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h00000010;
wire [31:0] value_n2 = n1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {1'b0, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {2'b0, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {4'b0, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {8'b0, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {16'b0, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n0 + n2;
assign result = n3;
endmodule

module candidate_56(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000002;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in0;
assign result = n1;
endmodule

module candidate_57(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000002;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_58(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000017;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_59(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000018;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_60(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001f;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_61(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001f;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h00000001;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_62(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000004;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_63(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000004;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h0000001c;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 + n1;
assign result = n2;
endmodule

module candidate_64(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000001;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_65(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_66(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000003;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_67(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001f;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in0;
assign result = n1;
endmodule

module candidate_68(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001f;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in1;
assign result = n1;
endmodule

module candidate_69(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] n1 = n0 + 32'h000002e0;
assign result = n1;
endmodule

module candidate_70(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000000;
wire [31:0] n1 = n0 + 32'h00000001;
assign result = n1;
endmodule

module candidate_71(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000007ff;
wire [31:0] n1 = n0 + 32'h000006a5;
assign result = n1;
endmodule

module candidate_72(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'h000007ff;
wire [31:0] n1 = n0 + 32'h00000385;
assign result = n1;
endmodule

module candidate_73(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hffffffff;
wire [31:0] n1 = n0 & 32'hffffff01;
wire [31:0] n2 = n1 + 32'h000000ff;
assign result = n2;
endmodule

module candidate_74(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'hffffff01;
wire [31:0] n1 = n0 + 32'h000000ff;
assign result = n1;
endmodule

module candidate_75(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h000000ff;
wire [31:0] n1 = n0 + 32'hffffff81;
assign result = n1;
endmodule

module candidate_76(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000017;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 & 32'h000000ff;
wire [31:0] n2 = n1 + 32'hffffff81;
assign result = n2;
endmodule

module candidate_77(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hc0000000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule

module candidate_78(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h8000d000;
wire [31:0] n1 = n0 + 32'hfffff818;
assign result = n1;
endmodule

module candidate_79(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h8000c000;
wire [31:0] n1 = n0 + 32'h00000204;
assign result = n1;
endmodule

module candidate_80(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000006c8;
assign result = n1;
endmodule

module candidate_81(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000258;
assign result = n1;
endmodule

module candidate_82(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000264;
assign result = n1;
endmodule

module candidate_83(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000270;
assign result = n1;
endmodule

module candidate_84(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000294;
assign result = n1;
endmodule

module candidate_85(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002a0;
assign result = n1;
endmodule

module candidate_86(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002b0;
assign result = n1;
endmodule

module candidate_87(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002bc;
assign result = n1;
endmodule

module candidate_88(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002c0;
assign result = n1;
endmodule

module candidate_89(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002c8;
assign result = n1;
endmodule

module candidate_90(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002d4;
assign result = n1;
endmodule

module candidate_91(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h000002dc;
assign result = n1;
endmodule

module candidate_92(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000300;
assign result = n1;
endmodule

module candidate_93(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h0000031c;
assign result = n1;
endmodule

module candidate_94(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000324;
assign result = n1;
endmodule

module candidate_95(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000358;
assign result = n1;
endmodule

module candidate_96(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80007000;
wire [31:0] n1 = n0 + 32'h00000364;
assign result = n1;
endmodule

module candidate_97(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h00000000;
assign result = n1;
endmodule

module candidate_98(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h0000066c;
assign result = n1;
endmodule

module candidate_99(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h00000294;
assign result = n1;
endmodule

module candidate_100(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h000002a0;
assign result = n1;
endmodule

module candidate_101(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80006000;
wire [31:0] n1 = n0 + 32'h00000354;
assign result = n1;
endmodule

module candidate_102(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80005000;
wire [31:0] n1 = n0 + 32'hfffffe88;
assign result = n1;
endmodule

module candidate_103(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80005000;
wire [31:0] n1 = n0 + 32'h00000148;
assign result = n1;
endmodule

module candidate_104(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80004000;
wire [31:0] n1 = n0 + 32'hfffffac8;
assign result = n1;
endmodule

module candidate_105(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80000000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule

module candidate_106(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80000000;
wire [31:0] n1 = n0 + 32'hfffffff0;
assign result = n1;
endmodule

module candidate_107(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80000000;
wire [31:0] n1 = n0 + 32'hfffffffe;
assign result = n1;
endmodule

module candidate_108(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80000000;
wire [31:0] n1 = n0 + 32'hffffff00;
assign result = n1;
endmodule

module candidate_109(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80000000;
wire [31:0] n1 = n0 + 32'h00000004;
assign result = n1;
endmodule

module candidate_110(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hfffff000;
wire [31:0] n1 = n0 + 32'h00000056;
assign result = n1;
endmodule

module candidate_111(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hfffff000;
wire [31:0] n1 = n0 + 32'h00000061;
assign result = n1;
endmodule

module candidate_112(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hfc000000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule

module candidate_113(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hffffe000;
wire [31:0] n1 = n0 + 32'hfffff930;
assign result = n1;
endmodule

module candidate_114(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hff800000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule

module candidate_115(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hccccd000;
wire [31:0] n1 = n0 + 32'hfffffccd;
assign result = n1;
endmodule

module candidate_116(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hccccd000;
wire [31:0] n1 = n0 + 32'hfffffccc;
assign result = n1;
endmodule

module candidate_117(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00100000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule

module candidate_118(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h3e99a000;
wire [31:0] n1 = n0 + 32'hfffff999;
assign result = n1;
endmodule

module candidate_119(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h3f491000;
wire [31:0] n1 = n0 + 32'hffffffd8;
assign result = n1;
endmodule

module candidate_120(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h3fc91000;
wire [31:0] n1 = n0 + 32'hffffffd0;
assign result = n1;
endmodule

module candidate_121(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h4016d000;
wire [31:0] n1 = n0 + 32'hfffffbe3;
assign result = n1;
endmodule

module candidate_122(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h43491000;
wire [31:0] n1 = n0 + 32'hffffff80;
assign result = n1;
endmodule

module candidate_123(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00003000;
wire [31:0] n1 = n0 + 32'hfffffe3c;
assign result = n1;
endmodule

module candidate_124(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00003000;
wire [31:0] n1 = n0 + 32'h0000015c;
assign result = n1;
endmodule

module candidate_125(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h66666000;
wire [31:0] n1 = n0 + 32'h00000667;
assign result = n1;
endmodule

module candidate_126(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h7e000000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule

module candidate_127(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h10000000;
wire [31:0] n1 = n0 + 32'hffffffff;
assign result = n1;
endmodule
