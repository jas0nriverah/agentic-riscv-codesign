module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80005000;
wire [31:0] n1 = n0 + 32'hfffffe88;
wire [31:0] n2 = n1 + in0;
assign result = n2;
endmodule
