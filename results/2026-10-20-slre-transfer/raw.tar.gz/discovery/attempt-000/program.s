	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.op_len,"ax",@progbits
	.align	2
	.type	op_len, @function
op_len:
	lbu	a4,0(a0)
	li	a5,92
	bne	a4,a5,.L3
	lbu	a4,1(a0)
	li	a5,120
	li	a0,2
	bne	a4,a5,.L1
	li	a0,4
	ret
.L3:
	li	a0,1
.L1:
	ret
	.size	op_len, .-op_len
	.section	.text.get_op_len,"ax",@progbits
	.align	2
	.type	get_op_len, @function
get_op_len:
	lbu	a4,0(a0)
	li	a5,91
	bne	a4,a5,.L6
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	s1,20(sp)
	sw	s2,16(sp)
	sw	s3,12(sp)
	sw	ra,28(sp)
	mv	s2,a0
	addi	s1,a1,-1
	li	s0,0
	li	s3,93
.L7:
	bgt	s1,s0,.L8
	bge	s1,s0,.L9
	li	s0,-1
.L10:
	lw	ra,28(sp)
	addi	a0,s0,1
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	addi	sp,sp,32
	jr	ra
.L11:
	call	op_len
	add	s0,s0,a0
	j	.L7
.L8:
	addi	a0,s0,1
	add	a0,s2,a0
	lbu	a5,0(a0)
	bne	a5,s3,.L11
.L9:
	addi	s0,s0,1
	j	.L10
.L6:
	tail	op_len
	.size	get_op_len, .-get_op_len
	.section	.text.match_op,"ax",@progbits
	.align	2
	.type	match_op, @function
match_op:
	lbu	a5,0(a0)
	li	a4,92
	beq	a5,a4,.L18
	bgtu	a5,a4,.L19
	li	a4,36
	li	a0,-1
	beq	a5,a4,.L17
	li	a4,46
	li	a0,1
.L50:
	beq	a5,a4,.L17
	addi	a2,a2,2047
	lw	a3,369(a2)
	lbu	a4,0(a1)
	andi	a3,a3,1
	beq	a3,zero,.L34
	lui	a3,%hi(_ctype_+1)
	addi	a3,a3,%lo(_ctype_+1)
	add	a2,a3,a5
	lbu	a2,0(a2)
	li	a1,1
	andi	a2,a2,3
	bne	a2,a1,.L35
	addi	a5,a5,32
.L35:
	add	a3,a3,a4
	lbu	a3,0(a3)
	li	a2,1
	andi	a3,a3,3
	bne	a3,a2,.L34
	addi	a4,a4,32
.L34:
	li	a0,-1
	beq	a5,a4,.L52
	ret
.L19:
	li	a4,124
	li	a0,-4
	j	.L50
.L18:
	lbu	a5,1(a0)
	li	a4,115
	lbu	a2,0(a1)
	beq	a5,a4,.L22
	bgtu	a5,a4,.L23
	li	a4,83
	beq	a5,a4,.L24
	li	a4,100
	beq	a5,a4,.L25
.L26:
	li	a0,-1
	beq	a5,a2,.L52
.L17:
	ret
.L23:
	li	a4,120
	bne	a5,a4,.L26
	lbu	a3,2(a0)
	lui	a5,%hi(_ctype_+1)
	addi	a5,a5,%lo(_ctype_+1)
	add	a4,a3,a5
	lbu	a4,0(a4)
	li	a1,1
	andi	a4,a4,3
	bne	a4,a1,.L28
	addi	a3,a3,32
.L28:
	add	a4,a5,a3
	lbu	a1,0(a4)
	addi	a4,a3,-87
	andi	a1,a1,4
	beq	a1,zero,.L30
	addi	a4,a3,-48
.L30:
	lbu	a3,3(a0)
	li	a0,1
	slli	a4,a4,4
	add	a1,a5,a3
	lbu	a1,0(a1)
	andi	a1,a1,3
	bne	a1,a0,.L31
	addi	a3,a3,32
.L31:
	add	a5,a5,a3
	lbu	a5,0(a5)
	addi	a1,a3,-87
	andi	a5,a5,4
	beq	a5,zero,.L33
	addi	a1,a3,-48
.L33:
	or	a4,a4,a1
	li	a0,-1
	bne	a2,a4,.L17
.L52:
	li	a0,1
	ret
.L24:
	lui	a5,%hi(_ctype_+1)
	addi	a5,a5,%lo(_ctype_+1)
	add	a5,a2,a5
	lbu	a0,0(a5)
	slli	a5,a0,28
	srai	a0,a5,31
.L51:
	ori	a0,a0,1
	ret
.L22:
	lui	a5,%hi(_ctype_+1)
	addi	a5,a5,%lo(_ctype_+1)
	add	a5,a2,a5
	lbu	a0,0(a5)
	andi	a0,a0,8
.L53:
	seqz	a0,a0
	neg	a0,a0
	j	.L51
.L25:
	lui	a5,%hi(_ctype_+1)
	addi	a5,a5,%lo(_ctype_+1)
	add	a5,a2,a5
	lbu	a0,0(a5)
	andi	a0,a0,4
	j	.L53
	.size	match_op, .-match_op
	.section	.text.bar,"ax",@progbits
	.align	2
	.type	bar, @function
bar:
	addi	sp,sp,-96
	sw	s0,88(sp)
	sw	s1,84(sp)
	sw	s2,80(sp)
	sw	s3,76(sp)
	sw	s4,72(sp)
	sw	s7,60(sp)
	sw	s8,56(sp)
	sw	ra,92(sp)
	sw	s5,68(sp)
	sw	s6,64(sp)
	sw	s9,52(sp)
	sw	s10,48(sp)
	sw	s11,44(sp)
	mv	s3,a0
	mv	s1,a1
	mv	s4,a2
	mv	s2,a3
	sw	a4,0(sp)
	mv	s0,a5
	li	s8,0
	li	s7,0
.L56:
	bge	s7,s1,.L113
	ble	s8,s2,.L100
.L113:
	mv	s5,s8
	j	.L55
.L100:
	add	a5,s3,s7
	lbu	s9,0(a5)
	sw	a5,8(sp)
	li	a5,40
	bne	s9,a5,.L57
	lw	a4,0(sp)
	addi	a5,s0,1
	slli	a5,a5,4
	add	a5,a4,a5
	lw	a5,4(a5)
	addi	a5,a5,2
	sw	a5,4(sp)
.L58:
	lw	a5,4(sp)
	ble	a5,zero,.L104
	add	a5,s7,a5
	bge	a5,s1,.L60
	add	s6,s3,a5
	lbu	a4,0(s6)
	addi	a3,a4,-42
	sltiu	a3,a3,2
	bne	a3,zero,.L110
	addi	a3,a4,-63
	bne	a3,zero,.L60
.L110:
	add	a3,s4,s8
	sw	a3,12(sp)
	sub	a3,s2,s8
	sw	a3,16(sp)
	li	a3,63
	bne	a4,a3,.L62
	lw	a4,0(sp)
	lw	a1,4(sp)
	mv	a5,s0
	sub	a3,s2,s8
	add	a2,s4,s8
	add	a0,s3,s7
	call	bar
	not	a5,a0
	srai	a5,a5,31
	and	a0,a0,a5
	add	s8,s8,a0
	addi	s7,s7,1
.L64:
	lw	a5,4(sp)
	add	s7,s7,a5
	j	.L56
.L57:
	sub	a1,s1,s7
	add	a0,s3,s7
	call	get_op_len
	addi	a5,s9,-42
	sw	a0,4(sp)
	andi	a5,a5,0xff
	li	a4,1
	bleu	a5,a4,.L103
	li	a5,63
	bne	s9,a5,.L58
.L103:
	li	s5,-2
	j	.L55
.L62:
	addi	s10,a5,1
	li	s7,0
	ble	s1,s10,.L65
	add	a4,s3,s10
	lbu	a4,0(a4)
	li	a3,63
	bne	a4,a3,.L65
	addi	s10,a5,2
	li	s7,1
.L65:
	sub	a5,s1,s10
	sw	a5,20(sp)
	add	a5,s3,s10
	mv	s5,s8
	mv	s11,s8
	li	s9,-1
	sw	a5,24(sp)
.L72:
	lw	a4,0(sp)
	lw	a1,4(sp)
	lw	a0,8(sp)
	mv	a5,s0
	sub	a3,s2,s11
	add	a2,s4,s11
	call	bar
	mv	t1,a0
	ble	a0,zero,.L66
	add	s11,s11,a0
.L66:
	lbu	a5,0(s6)
	addi	a5,a5,-43
	bne	a5,zero,.L111
	blt	t1,zero,.L67
.L111:
	ble	s1,s10,.L107
	lw	a4,0(sp)
	lw	a1,20(sp)
	lw	a0,24(sp)
	mv	a5,s0
	sub	a3,s2,s11
	add	a2,s4,s11
	sw	t1,28(sp)
	call	bar
	lw	t1,28(sp)
	mv	s9,a0
	blt	a0,zero,.L69
	add	s5,s11,a0
.L69:
	bge	s8,s5,.L112
	bne	s7,zero,.L70
.L112:
	bgt	t1,zero,.L72
.L70:
	bge	t1,zero,.L67
	lbu	a4,0(s6)
	li	a5,42
	bne	a4,a5,.L67
	lw	a4,0(sp)
	lw	a3,16(sp)
	lw	a2,12(sp)
	mv	a5,s0
	sub	a1,s1,s10
	add	a0,s3,s10
	call	bar
	mv	s9,a0
	ble	a0,zero,.L67
	add	s5,s8,a0
.L67:
	lbu	a4,0(s6)
	li	a5,43
	bne	a4,a5,.L73
	bne	s8,s5,.L55
.L74:
	li	s5,-1
	j	.L55
.L107:
	mv	s5,s11
	j	.L69
.L73:
	sub	a6,s8,s5
	srli	s9,s9,31
	seqz	a6,a6
	and	a6,a6,s9
	beq	a6,zero,.L55
	bgt	s1,s10,.L74
.L55:
	lw	ra,92(sp)
	lw	s0,88(sp)
	lw	s1,84(sp)
	lw	s2,80(sp)
	lw	s3,76(sp)
	lw	s4,72(sp)
	lw	s6,64(sp)
	lw	s7,60(sp)
	lw	s8,56(sp)
	lw	s9,52(sp)
	lw	s10,48(sp)
	lw	s11,44(sp)
	mv	a0,s5
	lw	s5,68(sp)
	addi	sp,sp,96
	jr	ra
.L60:
	li	a4,91
	bne	s9,a4,.L75
	addi	s6,s7,1
	add	s6,s3,s6
	lbu	s11,0(s6)
	addi	s10,s7,2
	li	a5,94
	sub	s10,s1,s10
	add	a1,s4,s8
	bne	s11,a5,.L76
	addi	s6,s6,1
	addi	s10,s10,-1
.L76:
	li	s5,-1
	li	s9,0
	j	.L145
.L86:
	beq	a3,t1,.L77
	lbu	a4,1(a5)
	bne	a4,t1,.L77
	lbu	a4,2(a5)
	addi	a2,a4,-93
	beq	a2,zero,.L77
	beq	a4,zero,.L77
	lw	a5,0(sp)
	addi	a5,a5,2047
	lw	s5,369(a5)
	lbu	a5,0(a1)
	beq	s5,zero,.L78
	sltu	a4,a4,a5
	sgtu	a5,a3,a5
	seqz	a4,a4
	seqz	a5,a5
	and	s5,a4,a5
.L79:
	addi	s9,s9,3
.L84:
	bgt	s9,s10,.L85
	add	a5,s6,s9
	lbu	a3,0(a5)
	beq	a3,t3,.L85
	bne	s5,a7,.L86
	li	a5,94
	bne	s11,a5,.L89
	j	.L74
.L78:
	lui	a2,%hi(_ctype_+1)
	addi	a2,a2,%lo(_ctype_+1)
	add	a0,a2,a5
	lbu	a0,0(a0)
	andi	a0,a0,3
	bne	a0,a7,.L80
	addi	a5,a5,32
.L80:
	add	a0,a2,a3
	lbu	a0,0(a0)
	li	t4,1
	andi	a0,a0,3
	bne	a0,t4,.L81
	addi	a3,a3,32
.L81:
	blt	a5,a3,.L79
	add	a2,a2,a4
	lbu	a3,0(a2)
	li	a2,1
	andi	a3,a3,3
	bne	a3,a2,.L82
	addi	a4,a4,32
.L82:
	sgt	a5,a5,a4
	seqz	s5,a5
	j	.L79
.L77:
	lw	a2,0(sp)
	mv	a0,a5
	sw	a1,12(sp)
	sw	a5,8(sp)
	call	match_op
	mv	s5,a0
	lw	a0,8(sp)
	call	op_len
	lw	a1,12(sp)
	add	s9,s9,a0
.L145:
	li	t3,93
	li	a7,1
	li	t1,45
	j	.L84
.L85:
	li	a4,94
	li	a5,1
	beq	s11,a4,.L88
	bne	s5,a5,.L74
.L89:
	addi	s8,s8,1
	j	.L64
.L88:
	bne	s5,a5,.L89
	j	.L74
.L75:
	li	a4,40
	bne	s9,a4,.L91
	lw	a4,0(sp)
	addi	s6,s0,1
	lw	a4,1600(a4)
	ble	a4,s6,.L108
	add	a4,s4,s8
	sub	s11,s1,a5
	sw	a4,8(sp)
	sub	s10,s2,s8
	bgt	s11,zero,.L109
	lw	a2,0(sp)
	mv	a3,s6
	mv	a1,s10
	mv	a0,a4
	call	doh
	mv	s5,a0
.L93:
	bge	s5,zero,.L95
	j	.L55
.L109:
	add	a5,s3,a5
	li	s9,0
	sw	a5,12(sp)
.L92:
	lw	a2,0(sp)
	lw	a0,8(sp)
	mv	a3,s6
	sub	a1,s10,s9
	call	doh
	mv	s5,a0
	bge	a0,zero,.L94
.L96:
	addi	s9,s9,1
	ble	s9,s10,.L92
	j	.L93
.L94:
	add	a2,s8,a0
	lw	a4,0(sp)
	lw	a0,12(sp)
	sub	a3,s2,a2
	mv	a5,s6
	add	a2,s4,a2
	mv	a1,s11
	call	bar
	blt	a0,zero,.L96
.L95:
	lw	a5,0(sp)
	addi	a5,a5,2047
	lw	a5,361(a5)
	beq	a5,zero,.L97
	slli	s0,s0,3
	add	s0,a5,s0
	lw	a5,8(sp)
	sw	s5,4(s0)
	sw	a5,0(s0)
.L97:
	add	s8,s8,s5
	mv	s0,s6
	j	.L64
.L91:
	li	a5,94
	bne	s9,a5,.L98
	beq	s8,zero,.L64
	j	.L74
.L98:
	li	a5,36
	bne	s9,a5,.L99
	beq	s8,s2,.L64
	j	.L74
.L99:
	beq	s8,s2,.L74
	lw	a2,0(sp)
	add	a1,s4,s8
	add	a0,s3,s7
	call	match_op
	li	a5,1
	mv	s5,a0
	bne	a0,a5,.L55
	add	s8,s8,a5
	j	.L64
.L104:
	li	s5,-5
	j	.L55
.L108:
	li	s5,-4
	j	.L55
	.size	bar, .-bar
	.section	.text.doh,"ax",@progbits
	.align	2
	.type	doh, @function
doh:
	addi	sp,sp,-48
	sw	s0,40(sp)
	slli	s0,a3,4
	add	s0,a2,s0
	sw	s2,32(sp)
	mv	s2,a0
	lw	a0,0(s0)
	sw	s1,36(sp)
	sw	s3,28(sp)
	sw	ra,44(sp)
	mv	s3,a1
	mv	a4,a2
	mv	a5,a3
	li	s1,0
.L151:
	lw	a3,12(s0)
	bne	a3,zero,.L147
	lw	a1,4(s0)
.L148:
	mv	a3,s3
	mv	a2,s2
	sw	a5,12(sp)
	sw	a4,8(sp)
	call	bar
	bgt	a0,zero,.L146
	lw	a3,12(s0)
	ble	a3,s1,.L146
	lw	a3,8(s0)
	addi	s1,s1,1
	lw	a4,8(sp)
	add	a3,s1,a3
	addi	a3,a3,199
	slli	a3,a3,3
	add	a3,a4,a3
	lw	a0,8(a3)
	lw	a5,12(sp)
	addi	a0,a0,1
	j	.L151
.L147:
	bne	a3,s1,.L149
	lw	a1,0(s0)
	lw	a3,4(s0)
	add	a1,a1,a3
.L153:
	sub	a1,a1,a0
	j	.L148
.L149:
	lw	a3,8(s0)
	add	a3,s1,a3
	addi	a3,a3,200
	slli	a3,a3,3
	add	a3,a4,a3
	lw	a1,8(a3)
	j	.L153
.L146:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	addi	sp,sp,48
	jr	ra
	.size	doh, .-doh
	.section	.rodata.slre_match.str1.4,"aMS",@progbits,1
	.align	2
.LC0:
	.string	"(?i)"
	.align	2
.LC1:
	.string	"^$().[]*+?|\\Ssd"
	.section	.text.slre_match,"ax",@progbits
	.align	2
	.globl	slre_match
	.type	slre_match, @function
slre_match:
	addi	sp,sp,-2032
	sw	s2,2016(sp)
	sw	s4,2008(sp)
	sw	ra,2028(sp)
	sw	s0,2024(sp)
	sw	s1,2020(sp)
	sw	s3,2012(sp)
	sw	s5,2004(sp)
	sw	s6,2000(sp)
	sw	s7,1996(sp)
	sw	s8,1992(sp)
	sw	s9,1988(sp)
	sw	s10,1984(sp)
	sw	s11,1980(sp)
	addi	sp,sp,-480
	addi	a5,sp,2047
	addi	a5,a5,385
	sw	zero,0(a5)
	addi	a5,sp,2047
	addi	a5,a5,397
	sw	zero,0(a5)
	addi	a5,sp,2047
	addi	a5,a5,393
	sw	a4,0(a5)
	sw	a1,8(sp)
	addi	a5,sp,2047
	lui	a1,%hi(.LC0)
	mv	s4,a2
	addi	a5,a5,389
	li	a2,4
	addi	a1,a1,%lo(.LC0)
	mv	s2,a0
	sw	zero,1628(sp)
	sw	a3,0(a5)
	call	memcmp
	bne	a0,zero,.L155
	addi	a5,sp,2047
	addi	a5,a5,397
	lw	a5,0(a5)
	addi	a4,sp,2047
	addi	a4,a4,397
	ori	a5,a5,1
	sw	a5,0(a4)
	addi	s2,s2,4
.L155:
	mv	a0,s2
	call	strlen
	li	a5,1
	sw	a5,1628(sp)
	lui	s3,%hi(_ctype_+1)
	lui	a5,%hi(.LC1)
	addi	s1,sp,-1648
	mv	s10,a0
	li	s0,0
	li	s8,0
	li	s6,124
	li	s7,92
	li	s5,40
	addi	s11,a5,%lo(.LC1)
	addi	s3,s3,%lo(_ctype_+1)
	sw	s2,1676(s1)
	sw	a0,1680(s1)
.L156:
	bgt	s10,s8,.L170
	bne	s0,zero,.L171
	addi	a5,sp,28
	mv	a4,a5
	li	a1,0
	mv	s2,a5
.L172:
	addi	a3,sp,2047
	lw	a2,385(a3)
	addi	a3,a3,385
	blt	a1,a2,.L176
	lw	a0,1628(sp)
	li	a4,0
	li	a3,0
.L177:
	blt	a3,a0,.L182
	lw	a5,1676(s1)
	li	a0,-1
	li	s3,94
	lbu	s1,0(a5)
.L183:
	blt	s4,s0,.L154
	lw	a5,8(sp)
	li	a3,0
	mv	a2,s2
	sub	a1,s4,s0
	add	a0,a5,s0
	call	doh
	blt	a0,zero,.L184
	add	a0,a0,s0
	j	.L154
.L170:
	add	s9,s2,s8
	sub	a1,s10,s8
	mv	a0,s9
	call	get_op_len
	lbu	a5,0(s9)
	sw	a0,12(sp)
	bne	a5,s6,.L157
	addi	a5,sp,2047
	lw	a4,385(a5)
	addi	a5,a5,385
	li	a5,99
	bgt	a4,a5,.L186
	lw	a3,1628(sp)
	addi	a3,a3,-1
	slli	a5,a3,4
	add	a5,s1,a5
	lw	a2,1680(a5)
	li	a5,-1
	beq	a2,a5,.L159
	mv	a3,s0
.L159:
	addi	a5,a4,200
	slli	a5,a5,3
	add	a5,s1,a5
	sw	a3,1680(a5)
	sw	s9,1684(a5)
	addi	a5,sp,2047
	addi	a4,a4,1
	addi	a5,a5,385
	sw	a4,0(a5)
.L165:
	lw	a5,12(sp)
	add	s8,s8,a5
	j	.L156
.L157:
	bne	a5,s7,.L161
	addi	a5,s10,-1
	blt	s8,a5,.L162
.L164:
	li	a0,-6
.L154:
	addi	sp,sp,480
	lw	ra,2028(sp)
	lw	s0,2024(sp)
	lw	s1,2020(sp)
	lw	s2,2016(sp)
	lw	s3,2012(sp)
	lw	s4,2008(sp)
	lw	s5,2004(sp)
	lw	s6,2000(sp)
	lw	s7,1996(sp)
	lw	s8,1992(sp)
	lw	s9,1988(sp)
	lw	s10,1984(sp)
	lw	s11,1980(sp)
	addi	sp,sp,2032
	jr	ra
.L162:
	lbu	a1,1(s9)
	li	a5,120
	bne	a1,a5,.L163
	addi	a5,s10,-3
	bge	s8,a5,.L164
	lbu	a5,2(s9)
	add	a5,a5,s3
	lbu	a5,0(a5)
	andi	a5,a5,68
	beq	a5,zero,.L164
	lbu	a5,3(s9)
	add	a5,a5,s3
	lbu	a5,0(a5)
	andi	a5,a5,68
	bne	a5,zero,.L165
	j	.L164
.L163:
	mv	a0,s11
	call	strchr
	bne	a0,zero,.L165
	j	.L164
.L161:
	bne	a5,s5,.L166
	lw	a5,1628(sp)
	li	a4,99
	bgt	a5,a4,.L187
	slli	a4,a5,4
	addi	a3,s8,1
	add	a4,s1,a4
	add	a3,s2,a3
	sw	a3,1676(a4)
	li	a3,-1
	sw	a3,1680(a4)
	addi	a4,a5,1
	sw	a4,1628(sp)
	addi	a4,sp,2047
	addi	a4,a4,393
	lw	a4,0(a4)
	ble	a4,zero,.L190
	bgt	a5,a4,.L188
.L190:
	addi	s0,s0,1
	j	.L165
.L166:
	li	a4,41
	bne	a5,a4,.L165
	lw	a5,1628(sp)
	addi	a5,a5,-1
	slli	a4,a5,4
	add	a4,s1,a4
	lw	a3,1680(a4)
	li	a4,-1
	beq	a3,a4,.L168
	mv	a5,s0
.L168:
	slli	a5,a5,4
	add	a5,s1,a5
	lw	a4,1676(a5)
	addi	s0,s0,-1
	sub	a4,s9,a4
	sw	a4,1680(a5)
	bge	s0,zero,.L169
.L171:
	li	a0,-3
	j	.L154
.L169:
	ble	s8,zero,.L165
	lbu	a5,-1(s9)
	bne	a5,s5,.L165
	li	a0,-1
	j	.L154
.L176:
	addi	a1,a1,1
	mv	a3,a4
	mv	a0,a1
.L173:
	addi	a2,sp,2047
	addi	a2,a2,385
	lw	a2,0(a2)
	blt	a0,a2,.L175
	addi	a4,a4,8
	j	.L172
.L175:
	lw	a2,1604(a4)
	lw	a6,1612(a3)
	ble	a2,a6,.L174
	sw	a6,1604(a4)
	lw	a6,1616(a3)
	lw	a7,1608(a4)
	sw	a6,1608(a4)
	sw	a2,1612(a3)
	sw	a7,1616(a3)
.L174:
	addi	a0,a0,1
	addi	a3,a3,8
	j	.L173
.L182:
	sw	zero,12(a5)
	sw	a4,8(a5)
.L178:
	bgt	a2,a4,.L179
.L181:
	addi	a3,a3,1
	addi	a5,a5,16
	j	.L177
.L179:
	slli	a1,a4,3
	add	a1,s2,a1
	lw	a1,1604(a1)
	bne	a3,a1,.L181
	lw	a1,12(a5)
	addi	a4,a4,1
	addi	a1,a1,1
	sw	a1,12(a5)
	j	.L178
.L184:
	beq	s1,s3,.L154
	addi	s0,s0,1
	j	.L183
.L186:
	li	a0,-8
	j	.L154
.L187:
	li	a0,-9
	j	.L154
.L188:
	li	a0,-7
	j	.L154
	.size	slre_match, .-slre_match
	.section	.text.benchmark_body,"ax",@progbits
	.align	2
	.type	benchmark_body, @function
benchmark_body:
	addi	sp,sp,-48
	lui	a5,%hi(text)
	sw	s1,36(sp)
	sw	s2,32(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	ra,44(sp)
	sw	s0,40(sp)
	sw	s3,28(sp)
	sw	s6,16(sp)
	mv	s5,a0
	li	s1,0
	addi	s4,a5,%lo(text)
	lui	s2,%hi(regexes)
.L205:
	blt	s1,s5,.L207
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	a0,4(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	addi	sp,sp,48
	jr	ra
.L207:
	mv	a0,s4
	call	strlen
	addi	s0,s2,%lo(regexes)
	mv	s6,a0
	sw	zero,4(sp)
	addi	s3,s0,16
.L206:
	lw	a0,0(s0)
	li	a4,1
	addi	a3,sp,8
	mv	a2,s6
	mv	a1,s4
	call	slre_match
	lw	a5,4(sp)
	addi	s0,s0,4
	add	a5,a5,a0
	sw	a5,4(sp)
	bne	s0,s3,.L206
	addi	s1,s1,1
	j	.L205
	.size	benchmark_body, .-benchmark_body
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	tail	benchmark_body
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	li	a0,110
	tail	benchmark_body
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-102
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	regexes
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
.LC2:
	.string	"(ab)+"
	.align	2
.LC3:
	.string	"(b.+)+"
	.align	2
.LC4:
	.string	"a[ab]*"
	.align	2
.LC5:
	.string	"([ab^c][ab^c])+"
	.section	.data.regexes,"aw"
	.align	2
	.type	regexes, @object
	.size	regexes, 16
regexes:
	.word	.LC2
	.word	.LC3
	.word	.LC4
	.word	.LC5
	.globl	text
	.section	.data.text,"aw"
	.align	2
	.type	text, @object
	.size	text, 46
text:
	.string	"abbbababaabccababcacbcbcbabbabcbabcabcbbcbbac"
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
