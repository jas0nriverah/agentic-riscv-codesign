// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vverification_top.h for the primary calling header

#ifndef VERILATED_VVERIFICATION_TOP___024ROOT_H_
#define VERILATED_VVERIFICATION_TOP___024ROOT_H_  // guard

#include "verilated.h"


class Vverification_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vverification_top___024root final {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __VstlPhaseResult;
    CData/*0:0*/ __VicoDidInit;
    CData/*0:0*/ __VicoPhaseResult;
    VL_IN(in0,31,0);
    VL_IN(in1,31,0);
    VL_OUT(out_0,31,0);
    VL_OUT(out_1,31,0);
    VL_OUT(out_2,31,0);
    VL_OUT(out_3,31,0);
    VL_OUT(out_4,31,0);
    VL_OUT(out_5,31,0);
    VL_OUT(out_6,31,0);
    VL_OUT(out_7,31,0);
    VL_OUT(out_8,31,0);
    VL_OUT(out_9,31,0);
    VL_OUT(out_10,31,0);
    VL_OUT(out_11,31,0);
    VL_OUT(out_12,31,0);
    VL_OUT(out_13,31,0);
    VL_OUT(out_14,31,0);
    VL_OUT(out_15,31,0);
    VL_OUT(out_16,31,0);
    VL_OUT(out_17,31,0);
    VL_OUT(out_18,31,0);
    VL_OUT(out_19,31,0);
    VL_OUT(out_20,31,0);
    VL_OUT(out_21,31,0);
    VL_OUT(out_22,31,0);
    VL_OUT(out_23,31,0);
    VL_OUT(out_24,31,0);
    VL_OUT(out_25,31,0);
    VL_OUT(out_26,31,0);
    VL_OUT(out_27,31,0);
    VL_OUT(out_28,31,0);
    VL_OUT(out_29,31,0);
    VL_OUT(out_30,31,0);
    VL_OUT(out_31,31,0);
    IData/*31:0*/ verification_top__DOT__c20__DOT__n4;
    IData/*31:0*/ __Vtrigprevexpr___TOP__in0__0;
    IData/*31:0*/ __Vtrigprevexpr___TOP__in1__0;
    VlUnpacked<QData/*63:0*/, 1> __VstlTriggered;
    VlUnpacked<QData/*63:0*/, 2> __VicoTriggered;

    // INTERNAL VARIABLES
    Vverification_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vverification_top___024root(Vverification_top__Syms* symsp, const char* namep);
    ~Vverification_top___024root();
    VL_UNCOPYABLE(Vverification_top___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
