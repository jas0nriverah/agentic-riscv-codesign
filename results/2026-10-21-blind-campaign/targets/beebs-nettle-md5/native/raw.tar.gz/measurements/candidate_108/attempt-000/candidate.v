module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h4787c000;
wire [31:0] n1 = n0 + 32'h0000062a;
wire [31:0] n2 = in0 + n1;
wire [31:0] n3 = n2 + in1;
assign result = n3;
endmodule
