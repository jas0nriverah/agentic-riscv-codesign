	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.compress1,"ax",@progbits
	.align	2
	.globl	compress1
	.type	compress1, @function
compress1:
	mv	a5,a0
	li	a4,1
	li	a0,0
.L2:
	bne	a1,zero,.L4
	ret
.L4:
	andi	a3,a1,1
	beq	a3,zero,.L3
	slli	a2,a5,31
	srai	a3,a2,31
	and	a3,a3,a4
	or	a0,a0,a3
	slli	a4,a4,1
.L3:
	srli	a1,a1,1
	srli	a5,a5,1
	j	.L2
	.size	compress1, .-compress1
	.section	.text.compress2,"ax",@progbits
	.align	2
	.globl	compress2
	.type	compress2, @function
compress2:
	mv	a5,a0
	li	a4,0
	li	a0,0
.L9:
	andi	a2,a1,1
	and	a3,a5,a2
	sll	a3,a3,a4
	srli	a1,a1,1
	or	a0,a0,a3
	add	a4,a4,a2
	srli	a5,a5,1
	bne	a1,zero,.L9
	ret
	.size	compress2, .-compress2
	.section	.text.compress3,"ax",@progbits
	.align	2
	.globl	compress3
	.type	compress3, @function
compress3:
	addi	sp,sp,-32
	not	a6,a1
	addi	a7,sp,12
	mv	a3,a1
	li	a2,0
	li	t3,1
	li	t1,5
.L12:
	slli	a4,a6,1
	xor	a4,a4,a6
	slli	a5,a4,2
	xor	a5,a5,a4
	slli	a4,a5,4
	xor	a4,a4,a5
	slli	a5,a4,8
	xor	a5,a5,a4
	slli	a4,a5,16
	xor	a4,a4,a5
	slli	a5,a4,1
	not	a4,a4
	and	a5,a5,a3
	and	a6,a6,a4
	sll	a4,t3,a2
	sw	a5,0(a7)
	xor	a3,a5,a3
	addi	a2,a2,1
	srl	a5,a5,a4
	xor	a3,a5,a3
	addi	a7,a7,4
	bne	a2,t1,.L12
	lw	a4,12(sp)
	and	a1,a1,a0
	lw	a5,16(sp)
	and	a4,a1,a4
	xor	a1,a1,a4
	srli	a4,a4,1
	xor	a4,a4,a1
	and	a5,a4,a5
	xor	a4,a4,a5
	srli	a5,a5,2
	xor	a5,a5,a4
	lw	a4,20(sp)
	lw	a0,28(sp)
	and	a4,a5,a4
	xor	a5,a5,a4
	srli	a4,a4,4
	xor	a4,a4,a5
	lw	a5,24(sp)
	addi	sp,sp,32
	and	a5,a4,a5
	xor	a4,a4,a5
	srli	a5,a5,8
	xor	a5,a5,a4
	and	a0,a5,a0
	xor	a5,a5,a0
	srli	a0,a0,16
	xor	a0,a0,a5
	jr	ra
	.size	compress3, .-compress3
	.section	.text.compress4,"ax",@progbits
	.align	2
	.globl	compress4
	.type	compress4, @function
compress4:
	not	a4,a1
	and	a0,a0,a1
	slli	a4,a4,1
	li	a2,0
	li	t3,1
	li	a7,5
.L16:
	slli	a3,a4,1
	xor	a3,a3,a4
	slli	a5,a3,2
	xor	a5,a5,a3
	slli	a3,a5,4
	xor	a3,a3,a5
	slli	a5,a3,8
	xor	a5,a5,a3
	slli	a3,a5,16
	xor	a3,a3,a5
	and	a5,a3,a1
	sll	a6,t3,a2
	xor	a1,a5,a1
	srl	t1,a5,a6
	and	a5,a5,a0
	xor	a0,a5,a0
	not	a3,a3
	srl	a5,a5,a6
	addi	a2,a2,1
	or	a1,t1,a1
	or	a0,a5,a0
	and	a4,a4,a3
	bne	a2,a7,.L16
	ret
	.size	compress4, .-compress4
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-32
	sw	s0,24(sp)
	lui	s0,%hi(test)
	addi	s0,s0,%lo(test)
	sw	s1,20(sp)
	sw	s2,16(sp)
	sw	s3,12(sp)
	sw	ra,28(sp)
	addi	s3,s0,216
	mv	s2,s0
	li	s1,0
.L20:
	lw	a1,4(s2)
	lw	a0,0(s2)
	addi	s2,s2,12
	call	compress1
	lw	a5,-4(s2)
	sub	a5,a5,a0
	snez	a5,a5
	or	s1,s1,a5
	bne	s3,s2,.L20
	mv	s2,s0
.L21:
	lw	a1,4(s2)
	lw	a0,0(s2)
	addi	s2,s2,12
	call	compress2
	lw	a5,-4(s2)
	sub	a5,a5,a0
	snez	a5,a5
	or	s1,s1,a5
	bne	s3,s2,.L21
	mv	s2,s0
.L22:
	lw	a1,4(s2)
	lw	a0,0(s2)
	addi	s2,s2,12
	call	compress3
	lw	a5,-4(s2)
	sub	a5,a5,a0
	snez	a5,a5
	or	s1,s1,a5
	bne	s3,s2,.L22
.L23:
	lw	a1,4(s0)
	lw	a0,0(s0)
	addi	s0,s0,12
	call	compress4
	lw	a5,-4(s0)
	sub	a5,a5,a0
	snez	a5,a5
	or	s1,s1,a5
	bne	s3,s0,.L23
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	mv	a0,s1
	lw	s1,20(sp)
	addi	sp,sp,32
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	test
	.section	.rodata.test,"a"
	.align	2
	.type	test, @object
	.size	test, 216
test:
	.word	-1
	.word	-2147483648
	.word	1
	.word	-1
	.word	1050698
	.word	31
	.word	-1
	.word	1431655765
	.word	65535
	.word	-1
	.word	-1998581931
	.word	8191
	.word	19088743
	.word	65535
	.word	17767
	.word	19088743
	.word	-65536
	.word	291
	.word	-1
	.word	-1
	.word	-1
	.word	0
	.word	0
	.word	0
	.word	0
	.word	-1
	.word	0
	.word	-1
	.word	0
	.word	0
	.word	-2147483648
	.word	-2147483648
	.word	1
	.word	1431655765
	.word	1431655765
	.word	65535
	.word	1431655765
	.word	-1431655766
	.word	0
	.word	2023406814
	.word	252645135
	.word	35534
	.word	2023406814
	.word	-252645136
	.word	31165
	.word	-1842063752
	.word	-2147483648
	.word	1
	.word	305419896
	.word	-268217003
	.word	1260
	.word	-2147483648
	.word	-268217003
	.word	8192
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
