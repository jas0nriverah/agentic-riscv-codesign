	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.g723_enc_abs,"ax",@progbits
	.align	2
	.globl	g723_enc_abs
	.type	g723_enc_abs, @function
g723_enc_abs:
	srai	a5,a0,31
	xor	a0,a5,a0
	sub	a0,a0,a5
	ret
	.size	g723_enc_abs, .-g723_enc_abs
	.section	.text.g723_enc_quan,"ax",@progbits
	.align	2
	.globl	g723_enc_quan
	.type	g723_enc_quan, @function
g723_enc_quan:
	li	a6,1
	li	a3,0
	li	a5,0
.L3:
	blt	a5,a2,.L5
	mv	a0,a3
	ret
.L5:
	mv	a4,a1
	beq	a6,zero,.L4
	addi	a4,a1,2
	lh	a1,0(a1)
	ble	a1,a0,.L4
	mv	a3,a5
	li	a6,0
.L4:
	addi	a5,a5,1
	mv	a1,a4
	j	.L3
	.size	g723_enc_quan, .-g723_enc_quan
	.section	.text.g723_enc_fmult,"ax",@progbits
	.align	2
	.globl	g723_enc_fmult
	.type	g723_enc_fmult, @function
g723_enc_fmult:
	addi	sp,sp,-32
	sw	s1,20(sp)
	sw	s2,16(sp)
	sw	ra,28(sp)
	sw	s0,24(sp)
	sw	s3,12(sp)
	mv	s2,a0
	mv	s1,a1
	bgt	a0,zero,.L10
	neg	s0,a0
	slli	s0,s0,19
	srli	s0,s0,19
.L11:
	lui	a1,%hi(g723_enc_power2)
	addi	a1,a1,%lo(g723_enc_power2)
	li	a2,3
	mv	a0,s0
	call	g723_enc_quan
	addi	a0,a0,-6
	slli	a0,a0,16
	srli	a0,a0,16
	li	a1,32
	beq	s0,zero,.L12
	slli	a5,a0,16
	srai	a5,a5,16
	sra	a1,s0,a0
	bge	a5,zero,.L12
	neg	a5,a5
	sll	s0,s0,a5
	slli	a1,s0,16
	srai	a1,a1,16
.L12:
	srai	a5,s1,6
	andi	a5,a5,15
	addi	a5,a5,-13
	add	s0,a0,a5
	andi	a0,s1,63
	call	__mulsi3
	addi	a0,a0,48
	slli	s3,s0,16
	slli	a5,a0,12
	srai	s3,s3,16
	srai	a0,a5,16
	blt	s3,zero,.L14
	sll	a0,a0,s0
	slli	a0,a0,17
	srli	a0,a0,17
.L15:
	xor	s2,s2,s1
	bge	s2,zero,.L9
	neg	a0,a0
.L9:
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	addi	sp,sp,32
	jr	ra
.L10:
	slli	s0,a0,16
	srai	s0,s0,16
	j	.L11
.L14:
	neg	s3,s3
	sra	a0,a0,s3
	slli	a0,a0,16
	srai	a0,a0,16
	j	.L15
	.size	g723_enc_fmult, .-g723_enc_fmult
	.section	.text.g723_enc_predictor_zero,"ax",@progbits
	.align	2
	.globl	g723_enc_predictor_zero
	.type	g723_enc_predictor_zero, @function
g723_enc_predictor_zero:
	addi	sp,sp,-16
	sw	s0,8(sp)
	mv	s0,a0
	lh	a0,16(a0)
	lh	a1,32(s0)
	sw	s1,4(sp)
	srai	a0,a0,2
	sw	s2,0(sp)
	sw	ra,12(sp)
	call	g723_enc_fmult
	addi	s2,s0,18
	mv	s1,a0
	addi	s0,s0,28
.L21:
	lh	a0,0(s2)
	lh	a1,16(s2)
	addi	s2,s2,2
	srai	a0,a0,2
	call	g723_enc_fmult
	add	s1,s1,a0
	bne	s0,s2,.L21
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s2,0(sp)
	mv	a0,s1
	lw	s1,4(sp)
	addi	sp,sp,16
	jr	ra
	.size	g723_enc_predictor_zero, .-g723_enc_predictor_zero
	.section	.text.g723_enc_predictor_pole,"ax",@progbits
	.align	2
	.globl	g723_enc_predictor_pole
	.type	g723_enc_predictor_pole, @function
g723_enc_predictor_pole:
	addi	sp,sp,-16
	sw	s0,8(sp)
	mv	s0,a0
	lh	a0,14(a0)
	lh	a1,46(s0)
	sw	ra,12(sp)
	srai	a0,a0,2
	sw	s1,4(sp)
	call	g723_enc_fmult
	mv	s1,a0
	lh	a0,12(s0)
	lh	a1,44(s0)
	srai	a0,a0,2
	call	g723_enc_fmult
	lw	ra,12(sp)
	lw	s0,8(sp)
	add	a0,s1,a0
	lw	s1,4(sp)
	addi	sp,sp,16
	jr	ra
	.size	g723_enc_predictor_pole, .-g723_enc_predictor_pole
	.section	.text.g723_enc_step_size,"ax",@progbits
	.align	2
	.globl	g723_enc_step_size
	.type	g723_enc_step_size, @function
g723_enc_step_size:
	lh	a1,10(a0)
	addi	sp,sp,-16
	sw	s0,8(sp)
	sw	ra,12(sp)
	sw	s1,4(sp)
	li	a5,255
	lh	s0,4(a0)
	bgt	a1,a5,.L26
	lw	s1,0(a0)
	srai	a1,a1,2
	srai	s1,s1,6
	sub	a0,s0,s1
	ble	a0,zero,.L28
	call	__mulsi3
	srai	s0,a0,6
	add	s0,s0,s1
.L26:
	lw	ra,12(sp)
	mv	a0,s0
	lw	s0,8(sp)
	lw	s1,4(sp)
	addi	sp,sp,16
	jr	ra
.L28:
	mv	s0,s1
	beq	a0,zero,.L26
	call	__mulsi3
	addi	a0,a0,63
	srai	a0,a0,6
	add	s0,a0,s1
	j	.L26
	.size	g723_enc_step_size, .-g723_enc_step_size
	.section	.text.g723_enc_quantize,"ax",@progbits
	.align	2
	.globl	g723_enc_quantize
	.type	g723_enc_quantize, @function
g723_enc_quantize:
	addi	sp,sp,-32
	srai	a5,a0,31
	sw	s0,24(sp)
	xor	s0,a5,a0
	sub	s0,s0,a5
	slli	s0,s0,16
	sw	s3,12(sp)
	srai	s0,s0,16
	mv	s3,a1
	lui	a1,%hi(g723_enc_power2)
	sw	s2,16(sp)
	sw	s4,8(sp)
	mv	s2,a0
	mv	s4,a2
	addi	a1,a1,%lo(g723_enc_power2)
	li	a2,15
	srai	a0,s0,1
	sw	s1,20(sp)
	sw	ra,28(sp)
	mv	s1,a3
	slli	s0,s0,7
	call	g723_enc_quan
	sra	s0,s0,a0
	srai	a5,s3,2
	slli	a0,a0,7
	andi	s0,s0,127
	sub	a0,a0,a5
	add	a0,s0,a0
	slli	a0,a0,16
	mv	a2,s1
	mv	a1,s4
	srai	a0,a0,16
	call	g723_enc_quan
	bge	s2,zero,.L33
	slli	s1,s1,1
	addi	s1,s1,1
	sub	a0,s1,a0
.L32:
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	lw	s4,8(sp)
	addi	sp,sp,32
	jr	ra
.L33:
	bne	a0,zero,.L32
	slli	s1,s1,1
	addi	a0,s1,1
	j	.L32
	.size	g723_enc_quantize, .-g723_enc_quantize
	.section	.text.g723_enc_reconstruct,"ax",@progbits
	.align	2
	.globl	g723_enc_reconstruct
	.type	g723_enc_reconstruct, @function
g723_enc_reconstruct:
	srai	a2,a2,2
	add	a1,a2,a1
	slli	a5,a1,16
	srai	a5,a5,16
	mv	a3,a0
	bge	a5,zero,.L37
	li	a0,0
	beq	a3,zero,.L36
	li	a0,-32768
	ret
.L37:
	andi	a1,a1,127
	srai	a5,a5,7
	addi	a1,a1,128
	andi	a5,a5,15
	li	a4,14
	slli	a1,a1,7
	sub	a5,a4,a5
	sra	a0,a1,a5
	beq	a3,zero,.L36
	li	a5,-32768
	add	a0,a0,a5
.L36:
	ret
	.size	g723_enc_reconstruct, .-g723_enc_reconstruct
	.section	.text.g723_enc_update,"ax",@progbits
	.align	2
	.globl	g723_enc_update
	.type	g723_enc_update, @function
g723_enc_update:
	addi	sp,sp,-64
	sw	s2,48(sp)
	mv	s2,a3
	lw	a3,0(a7)
	sw	s6,32(sp)
	mv	s6,a5
	slli	a5,a3,1
	sw	s0,56(sp)
	sw	s3,44(sp)
	sw	s4,40(sp)
	sw	s5,36(sp)
	sw	s7,28(sp)
	mv	s4,a1
	mv	s0,a7
	slli	s5,a4,17
	sw	ra,60(sp)
	sw	s1,52(sp)
	srai	a1,a5,16
	li	a7,9
	li	s7,0
	srli	s3,a6,31
	srli	s5,s5,17
	bgt	a1,a7,.L96
	srai	a5,a3,10
	andi	a5,a5,31
	addi	a5,a5,32
	sll	a5,a5,a1
	slli	a5,a5,16
	srai	a5,a5,16
.L45:
	srai	s1,a5,1
	add	s1,s1,a5
	lbu	a5,48(s0)
	srai	s1,s1,1
	sub	a2,a2,s4
	sgt	s1,s5,s1
	srai	a2,a2,5
	seqz	a5,a5
	add	a2,a2,s4
	seqz	s1,s1
	or	s1,s1,a5
	li	a1,4096
	mv	a5,a2
	slli	a2,a2,16
	srai	a2,a2,16
	addi	a1,a1,1024
	xori	s1,s1,1
	ble	a2,a1,.L46
	mv	a5,a1
.L46:
	slli	a1,a5,16
	srai	a1,a1,16
	li	a2,544
	bge	a1,a2,.L47
	mv	a5,a2
.L47:
	sh	a5,4(s0)
	neg	a2,a3
	slli	a5,a5,16
	srai	a2,a2,6
	srai	a5,a5,16
	add	a5,a2,a5
	add	a5,a5,a3
	sw	a5,0(s0)
	beq	s1,zero,.L48
	sw	zero,12(s0)
	sw	zero,16(s0)
	sw	zero,20(s0)
	sw	zero,24(s0)
.L49:
	lhu	a5,40(s0)
	sh	a5,42(s0)
	lhu	a5,38(s0)
	sh	a5,40(s0)
	lhu	a5,36(s0)
	sh	a5,38(s0)
	lhu	a5,34(s0)
	sh	a5,36(s0)
	lhu	a5,32(s0)
	sh	a5,34(s0)
	bne	s5,zero,.L68
	srai	a4,a4,31
	andi	a4,a4,-1024
	addi	a4,a4,32
.L70:
	lhu	a5,44(s0)
	sh	a4,32(s0)
	sh	a5,46(s0)
	li	a5,32
	beq	s6,zero,.L73
	ble	s6,zero,.L74
	lui	a1,%hi(g723_enc_power2)
	li	a2,15
	addi	a1,a1,%lo(g723_enc_power2)
	mv	a0,s6
	call	g723_enc_quan
	slli	a5,s6,6
	sra	a5,a5,a0
	slli	a0,a0,6
	add	a5,a5,a0
.L73:
	sh	a5,44(s0)
	li	a2,0
	lh	a5,28(s0)
	bne	s1,zero,.L75
	li	a2,-12288
	addi	a2,a2,512
	slt	a2,s7,a2
.L75:
	lh	a4,6(s0)
	lh	a3,8(s0)
	sh	a5,30(s0)
	sub	a5,s2,a4
	srai	a5,a5,5
	add	a5,a5,a4
	slli	a4,s2,2
	sub	a4,a4,a3
	srai	a4,a4,7
	add	a4,a4,a3
	slli	a5,a5,16
	slli	a4,a4,16
	srai	a5,a5,16
	srai	a4,a4,16
	sh	s3,28(s0)
	sb	a2,48(s0)
	sh	a5,6(s0)
	sh	a4,8(s0)
	li	a3,256
	bne	s1,zero,.L76
	li	a1,1535
	lh	a3,10(s0)
	ble	s4,a1,.L105
	beq	a2,zero,.L78
.L105:
	li	a5,512
	sub	a5,a5,a3
.L104:
	srai	a5,a5,4
	add	a3,a3,a5
.L76:
	lw	ra,60(sp)
	sh	a3,10(s0)
	lw	s0,56(sp)
	lw	s1,52(sp)
	lw	s2,48(sp)
	lw	s3,44(sp)
	lw	s4,40(sp)
	lw	s5,36(sp)
	lw	s6,32(sp)
	lw	s7,28(sp)
	addi	sp,sp,64
	jr	ra
.L96:
	li	a5,32768
	addi	a5,a5,-1024
	j	.L45
.L48:
	lh	a2,14(s0)
	lh	a1,12(s0)
	lh	a7,28(s0)
	srai	a5,a2,7
	slli	a3,a1,16
	sub	a2,a2,a5
	srli	a3,a3,16
	bne	a6,zero,.L50
.L99:
	slli	s7,a2,16
	srai	s7,s7,16
.L51:
	srai	a1,a1,8
	sub	a3,a3,a1
	bne	a6,zero,.L57
.L100:
	li	a5,16384
	addi	a5,a5,-1024
	sub	a2,a5,s7
	slli	a2,a2,16
	slli	a3,a3,16
	srai	a2,a2,16
	srai	a3,a3,16
	sh	s7,14(s0)
	neg	a1,a2
	bge	a3,a1,.L60
	sub	a5,s7,a5
	sh	a5,12(s0)
.L61:
	slli	a2,a4,17
	addi	a3,s0,16
	addi	a7,s0,28
	li	a6,5
	srli	a2,a2,17
.L67:
	lh	a5,0(a3)
	srai	a1,a5,9
	beq	a0,a6,.L101
	srai	a1,a5,8
.L101:
	sub	a5,a5,a1
	sh	a5,0(a3)
	beq	a2,zero,.L65
	lh	a1,16(a3)
	xor	a1,a1,a4
	blt	a1,zero,.L66
	addi	a5,a5,128
.L102:
	sh	a5,0(a3)
.L65:
	addi	a3,a3,2
	bne	a7,a3,.L67
	j	.L49
.L50:
	mv	a5,a1
	bne	a7,s3,.L52
	neg	a5,a3
	slli	a5,a5,16
	srai	a5,a5,16
.L52:
	li	t1,-8192
	bgt	a5,t1,.L53
	addi	a2,a2,-256
.L98:
	lh	a5,30(s0)
	slli	a2,a2,16
	srai	a2,a2,16
	beq	a5,s3,.L56
	li	a5,-12288
	addi	a5,a5,129
	li	s7,-12288
	blt	a2,a5,.L51
	li	a5,12288
	addi	a5,a5,127
	li	s7,12288
	bgt	a2,a5,.L51
	addi	a2,a2,-128
	j	.L99
.L53:
	li	t1,8192
	blt	a5,t1,.L55
	addi	a2,a2,255
	j	.L98
.L55:
	srai	a5,a5,5
	add	a2,a2,a5
	j	.L98
.L56:
	li	a5,-12288
	addi	a5,a5,-127
	li	s7,-12288
	blt	a2,a5,.L51
	li	a5,12288
	addi	a5,a5,-129
	li	s7,12288
	bgt	a2,a5,.L51
	addi	a2,a2,128
	j	.L99
.L57:
	bne	a7,s3,.L59
	addi	a3,a3,192
	j	.L100
.L59:
	addi	a3,a3,-192
	j	.L100
.L60:
	bge	a2,a3,.L62
	sh	a2,12(s0)
	j	.L61
.L66:
	addi	a5,a5,-128
	j	.L102
.L62:
	sh	a3,12(s0)
	j	.L61
.L68:
	lui	a1,%hi(g723_enc_power2)
	mv	a0,s5
	li	a2,15
	addi	a1,a1,%lo(g723_enc_power2)
	sw	a4,12(sp)
	call	g723_enc_quan
	lw	a4,12(sp)
	slli	s5,s5,6
	sra	s5,s5,a0
	slli	a0,a0,6
	blt	a4,zero,.L71
.L103:
	add	a4,s5,a0
	j	.L70
.L71:
	addi	a0,a0,-1024
	j	.L103
.L74:
	li	a4,-32768
	li	a5,-992
	ble	s6,a4,.L73
	neg	s6,s6
	slli	s6,s6,16
	srli	s6,s6,16
	lui	a1,%hi(g723_enc_power2)
	mv	a0,s6
	li	a2,15
	addi	a1,a1,%lo(g723_enc_power2)
	call	g723_enc_quan
	slli	a5,a0,6
	slli	s6,s6,6
	addi	a5,a5,-1024
	sra	s6,s6,a0
	add	a5,a5,s6
	j	.L73
.L78:
	slli	a5,a5,2
	sub	a5,a5,a4
	srai	a2,a4,3
	srai	a4,a5,31
	xor	a5,a4,a5
	sub	a5,a5,a4
	ble	a2,a5,.L105
	neg	a5,a3
	j	.L104
	.size	g723_enc_update, .-g723_enc_update
	.section	.text.g723_enc_alaw2linear,"ax",@progbits
	.align	2
	.globl	g723_enc_alaw2linear
	.type	g723_enc_alaw2linear, @function
g723_enc_alaw2linear:
	xori	a5,a0,85
	slli	a3,a5,4
	srli	a4,a5,4
	andi	a3,a3,255
	andi	a4,a4,7
	addi	a0,a3,8
	beq	a4,zero,.L110
	li	a2,1
	addi	a0,a3,264
	beq	a4,a2,.L110
	addi	a4,a4,-1
	sll	a0,a0,a4
.L110:
	slli	a5,a5,24
	srai	a5,a5,24
	blt	a5,zero,.L106
	neg	a0,a0
.L106:
	ret
	.size	g723_enc_alaw2linear, .-g723_enc_alaw2linear
	.section	.text.g723_enc_ulaw2linear,"ax",@progbits
	.align	2
	.globl	g723_enc_ulaw2linear
	.type	g723_enc_ulaw2linear, @function
g723_enc_ulaw2linear:
	xori	a5,a0,255
	slli	a0,a5,3
	srli	a4,a5,4
	andi	a0,a0,120
	slli	a5,a5,24
	addi	a0,a0,132
	andi	a4,a4,7
	srai	a5,a5,24
	sll	a0,a0,a4
	bge	a5,zero,.L113
	li	a5,132
	sub	a0,a5,a0
	ret
.L113:
	addi	a0,a0,-132
	ret
	.size	g723_enc_ulaw2linear, .-g723_enc_ulaw2linear
	.section	.text.g723_enc_g723_24_encoder,"ax",@progbits
	.align	2
	.globl	g723_enc_g723_24_encoder
	.type	g723_enc_g723_24_encoder, @function
g723_enc_g723_24_encoder:
	addi	sp,sp,-32
	sw	s4,8(sp)
	sw	ra,28(sp)
	sw	s0,24(sp)
	sw	s1,20(sp)
	sw	s2,16(sp)
	sw	s3,12(sp)
	sw	s5,4(sp)
	li	a5,2
	mv	s4,a2
	beq	a1,a5,.L116
	li	a5,3
	beq	a1,a5,.L117
	li	a5,1
	li	s0,-1
	bne	a1,a5,.L115
	andi	a0,a0,0xff
	call	g723_enc_ulaw2linear
	j	.L117
.L116:
	andi	a0,a0,0xff
	call	g723_enc_alaw2linear
.L117:
	srai	s0,a0,2
	mv	a0,s4
	call	g723_enc_predictor_zero
	slli	a5,a0,16
	mv	s1,a0
	mv	a0,s4
	srai	s2,a5,17
	call	g723_enc_predictor_pole
	add	s1,a0,s1
	slli	a5,s1,16
	mv	a0,s4
	srai	s1,a5,17
	call	g723_enc_step_size
	slli	s5,a0,16
	sub	a0,s0,s1
	srai	s5,s5,16
	lui	a2,%hi(g723_enc_qtab_723_24)
	slli	a0,a0,16
	li	a3,3
	addi	a2,a2,%lo(g723_enc_qtab_723_24)
	mv	a1,s5
	srai	a0,a0,16
	call	g723_enc_quantize
	slli	s0,a0,16
	srai	s0,s0,16
	lui	a5,%hi(g723_enc_dqlntab)
	slli	s3,s0,1
	addi	a5,a5,%lo(g723_enc_dqlntab)
	add	a5,a5,s3
	lh	a1,0(a5)
	mv	a2,s5
	andi	a0,a0,4
	call	g723_enc_reconstruct
	mv	a4,a0
	add	a5,s1,a0
	bge	a0,zero,.L122
	slli	a5,a0,18
	srli	a5,a5,18
	sub	a5,s1,a5
.L122:
	lui	a3,%hi(g723_enc_fitab)
	lui	a2,%hi(g723_enc_witab)
	addi	a3,a3,%lo(g723_enc_fitab)
	addi	a2,a2,%lo(g723_enc_witab)
	sub	a6,s2,s1
	add	a3,a3,s3
	add	a2,a2,s3
	add	a6,a5,a6
	lh	a3,0(a3)
	lh	a2,0(a2)
	slli	a6,a6,16
	slli	a5,a5,16
	mv	a7,s4
	srai	a6,a6,16
	srai	a5,a5,16
	mv	a1,s5
	li	a0,3
	call	g723_enc_update
.L115:
	lw	ra,28(sp)
	mv	a0,s0
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	lw	s4,8(sp)
	lw	s5,4(sp)
	addi	sp,sp,32
	jr	ra
	.size	g723_enc_g723_24_encoder, .-g723_enc_g723_24_encoder
	.section	.text.g723_enc_pack_output,"ax",@progbits
	.align	2
	.globl	g723_enc_pack_output
	.type	g723_enc_pack_output, @function
g723_enc_pack_output:
	lui	a2,%hi(out_bits.2)
	lw	a5,%lo(out_bits.2)(a2)
	lui	a3,%hi(out_buffer.1)
	lw	a4,%lo(out_buffer.1)(a3)
	sll	a0,a0,a5
	or	a4,a0,a4
	sw	a4,%lo(out_buffer.1)(a3)
	add	a0,a5,a1
	li	a5,7
	bgt	a0,a5,.L125
	sw	a0,%lo(out_bits.2)(a2)
.L126:
	sgt	a0,a0,zero
	ret
.L125:
	addi	a0,a0,-8
	srli	a5,a4,8
	sw	a0,%lo(out_bits.2)(a2)
	lui	a2,%hi(i.0)
	sw	a5,%lo(out_buffer.1)(a3)
	lw	a3,%lo(i.0)(a2)
	lui	a5,%hi(g723_enc_OUTPUT)
	addi	a5,a5,%lo(g723_enc_OUTPUT)
	slli	a1,a3,2
	add	a5,a5,a1
	andi	a4,a4,255
	addi	a3,a3,1
	sw	a4,0(a5)
	sw	a3,%lo(i.0)(a2)
	j	.L126
	.size	g723_enc_pack_output, .-g723_enc_pack_output
	.section	.text.g723_enc_init_state,"ax",@progbits
	.align	2
	.globl	g723_enc_init_state
	.type	g723_enc_init_state, @function
g723_enc_init_state:
	li	a5,36864
	addi	a5,a5,-2048
	sw	a5,0(a0)
	li	a5,544
	sw	a5,4(a0)
	li	a5,2097152
	addi	a5,a5,32
	sw	a5,44(a0)
	sw	zero,8(a0)
	sw	zero,12(a0)
	sw	zero,28(a0)
	addi	a5,a0,16
	addi	a4,a0,28
	li	a3,32
.L128:
	sh	zero,0(a5)
	sh	a3,16(a5)
	addi	a5,a5,2
	bne	a4,a5,.L128
	sb	zero,48(a0)
	ret
	.size	g723_enc_init_state, .-g723_enc_init_state
	.section	.text.g723_enc_init,"ax",@progbits
	.align	2
	.globl	g723_enc_init
	.type	g723_enc_init, @function
g723_enc_init:
	lui	a0,%hi(g723_enc_state)
	addi	sp,sp,-32
	addi	a0,a0,%lo(g723_enc_state)
	sw	ra,28(sp)
	sw	zero,12(sp)
	call	g723_enc_init_state
	lui	a5,%hi(g723_enc_INPUT)
	addi	a5,a5,%lo(g723_enc_INPUT)
	addi	a3,a5,1024
.L131:
	lw	a4,0(a5)
	lw	a2,12(sp)
	addi	a5,a5,4
	add	a4,a4,a2
	sw	a4,-4(a5)
	bne	a5,a3,.L131
	lw	ra,28(sp)
	addi	sp,sp,32
	jr	ra
	.size	g723_enc_init, .-g723_enc_init
	.section	.text.g723_enc_return,"ax",@progbits
	.align	2
	.globl	g723_enc_return
	.type	g723_enc_return, @function
g723_enc_return:
	lui	a5,%hi(g723_enc_OUTPUT)
	addi	a5,a5,%lo(g723_enc_OUTPUT)
	addi	a4,a5,1024
	li	a0,0
.L135:
	lw	a3,0(a5)
	addi	a5,a5,4
	add	a0,a0,a3
	bne	a5,a4,.L135
	li	a5,-24576
	addi	a5,a5,292
	add	a0,a0,a5
	snez	a0,a0
	ret
	.size	g723_enc_return, .-g723_enc_return
	.section	.text.g723_enc_main,"ax",@progbits
	.align	2
	.globl	g723_enc_main
	.type	g723_enc_main, @function
g723_enc_main:
	addi	sp,sp,-16
	sw	s0,8(sp)
	lui	s0,%hi(g723_enc_INPUT)
	addi	s0,s0,%lo(g723_enc_INPUT)
	lui	a2,%hi(g723_enc_state)
	sw	s1,4(sp)
	sw	ra,12(sp)
	addi	s1,s0,1024
	addi	a2,a2,%lo(g723_enc_state)
.L138:
	lh	a0,0(s0)
	li	a1,2
	addi	s0,s0,4
	call	g723_enc_g723_24_encoder
	li	a1,3
	andi	a0,a0,0xff
	call	g723_enc_pack_output
	lui	a5,%hi(g723_enc_state)
	addi	a2,a5,%lo(g723_enc_state)
	bne	s0,s1,.L138
.L139:
	bne	a0,zero,.L140
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s1,4(sp)
	addi	sp,sp,16
	jr	ra
.L140:
	li	a1,3
	li	a0,0
	call	g723_enc_pack_output
	j	.L139
	.size	g723_enc_main, .-g723_enc_main
	.section	.text.isaforge_tacle_original_main,"ax",@progbits
	.align	2
	.globl	isaforge_tacle_original_main
	.type	isaforge_tacle_original_main, @function
isaforge_tacle_original_main:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	g723_enc_init
	call	g723_enc_main
	lw	ra,12(sp)
	addi	sp,sp,16
	tail	g723_enc_return
	.size	isaforge_tacle_original_main, .-isaforge_tacle_original_main
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	tail	g723_enc_init
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	g723_enc_main
	lw	ra,12(sp)
	addi	sp,sp,16
	tail	g723_enc_return
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	bne	a0,zero,.L151
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	g723_enc_return
	lw	ra,12(sp)
	xori	a0,a0,1
	addi	sp,sp,16
	jr	ra
.L151:
	li	a0,0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.bss.i.0,"aw",@nobits
	.align	2
	.type	i.0, @object
	.size	i.0, 4
i.0:
	.zero	4
	.section	.bss.out_buffer.1,"aw",@nobits
	.align	2
	.type	out_buffer.1, @object
	.size	out_buffer.1, 4
out_buffer.1:
	.zero	4
	.section	.bss.out_bits.2,"aw",@nobits
	.align	2
	.type	out_bits.2, @object
	.size	out_bits.2, 4
out_bits.2:
	.zero	4
	.globl	g723_enc_fitab
	.section	.data.g723_enc_fitab,"aw"
	.align	2
	.type	g723_enc_fitab, @object
	.size	g723_enc_fitab, 32
g723_enc_fitab:
	.half	0
	.half	0
	.half	0
	.half	512
	.half	512
	.half	512
	.half	1536
	.half	3584
	.half	3584
	.half	1536
	.half	512
	.half	512
	.half	512
	.half	0
	.half	0
	.half	0
	.globl	g723_enc_witab
	.section	.data.g723_enc_witab,"aw"
	.align	2
	.type	g723_enc_witab, @object
	.size	g723_enc_witab, 32
g723_enc_witab:
	.half	-12
	.half	18
	.half	41
	.half	64
	.half	112
	.half	198
	.half	355
	.half	1122
	.half	1122
	.half	355
	.half	198
	.half	112
	.half	64
	.half	41
	.half	18
	.half	-12
	.globl	g723_enc_dqlntab
	.section	.data.g723_enc_dqlntab,"aw"
	.align	2
	.type	g723_enc_dqlntab, @object
	.size	g723_enc_dqlntab, 32
g723_enc_dqlntab:
	.half	-2048
	.half	4
	.half	135
	.half	213
	.half	273
	.half	323
	.half	373
	.half	425
	.half	425
	.half	373
	.half	323
	.half	273
	.half	213
	.half	135
	.half	4
	.half	-2048
	.globl	g723_enc_qtab_723_24
	.section	.data.g723_enc_qtab_723_24,"aw"
	.align	2
	.type	g723_enc_qtab_723_24, @object
	.size	g723_enc_qtab_723_24, 6
g723_enc_qtab_723_24:
	.half	8
	.half	218
	.half	331
	.globl	g723_enc_power2
	.section	.data.g723_enc_power2,"aw"
	.align	2
	.type	g723_enc_power2, @object
	.size	g723_enc_power2, 30
g723_enc_power2:
	.half	1
	.half	2
	.half	4
	.half	8
	.half	16
	.half	32
	.half	64
	.half	128
	.half	256
	.half	512
	.half	1024
	.half	2048
	.half	4096
	.half	8192
	.half	16384
	.globl	g723_enc_OUTPUT
	.section	.bss.g723_enc_OUTPUT,"aw",@nobits
	.align	2
	.type	g723_enc_OUTPUT, @object
	.size	g723_enc_OUTPUT, 1024
g723_enc_OUTPUT:
	.zero	1024
	.globl	g723_enc_INPUT
	.section	.data.g723_enc_INPUT,"aw"
	.align	2
	.type	g723_enc_INPUT, @object
	.size	g723_enc_INPUT, 1024
g723_enc_INPUT:
	.word	51
	.word	17
	.word	31
	.word	53
	.word	95
	.word	17
	.word	70
	.word	22
	.word	49
	.word	12
	.word	8
	.word	39
	.word	28
	.word	37
	.word	99
	.word	54
	.word	77
	.word	65
	.word	77
	.word	78
	.word	83
	.word	15
	.word	63
	.word	31
	.word	35
	.word	92
	.word	52
	.word	40
	.word	61
	.word	79
	.word	94
	.word	87
	.word	87
	.word	68
	.word	76
	.word	58
	.word	39
	.word	35
	.word	20
	.word	83
	.word	42
	.word	46
	.word	98
	.word	12
	.word	21
	.word	96
	.word	74
	.word	41
	.word	78
	.word	76
	.word	96
	.word	2
	.word	32
	.word	76
	.word	24
	.word	59
	.word	4
	.word	96
	.word	32
	.word	5
	.word	44
	.word	92
	.word	57
	.word	12
	.word	57
	.word	25
	.word	50
	.word	23
	.word	48
	.word	41
	.word	88
	.word	43
	.word	36
	.word	38
	.word	4
	.word	16
	.word	52
	.word	70
	.word	9
	.word	40
	.word	78
	.word	24
	.word	34
	.word	23
	.word	30
	.word	30
	.word	89
	.word	3
	.word	65
	.word	40
	.word	68
	.word	73
	.word	94
	.word	23
	.word	84
	.word	97
	.word	78
	.word	43
	.word	68
	.word	81
	.word	16
	.word	28
	.word	13
	.word	87
	.word	75
	.word	21
	.word	14
	.word	29
	.word	81
	.word	22
	.word	56
	.word	72
	.word	19
	.word	99
	.word	25
	.word	43
	.word	76
	.word	86
	.word	90
	.word	98
	.word	39
	.word	43
	.word	12
	.word	46
	.word	24
	.word	99
	.word	65
	.word	61
	.word	24
	.word	45
	.word	79
	.word	7
	.word	48
	.word	15
	.word	24
	.word	95
	.word	62
	.word	99
	.word	48
	.word	80
	.word	75
	.word	38
	.word	48
	.word	53
	.word	9
	.word	60
	.word	35
	.word	14
	.word	78
	.word	71
	.word	45
	.word	71
	.word	9
	.word	97
	.word	55
	.word	74
	.word	58
	.word	64
	.word	78
	.word	18
	.word	30
	.word	28
	.word	69
	.word	29
	.word	57
	.word	42
	.word	30
	.word	44
	.word	57
	.word	49
	.word	61
	.word	42
	.word	13
	.word	25
	.word	3
	.word	98
	.word	11
	.word	38
	.word	65
	.word	35
	.word	55
	.word	36
	.word	57
	.word	48
	.word	16
	.word	62
	.word	17
	.word	56
	.word	29
	.word	88
	.word	84
	.word	85
	.word	90
	.word	60
	.word	54
	.word	16
	.word	66
	.word	69
	.word	26
	.word	10
	.word	82
	.word	19
	.word	42
	.word	35
	.word	84
	.word	13
	.word	26
	.word	17
	.word	48
	.word	38
	.word	50
	.word	50
	.word	35
	.word	53
	.word	12
	.word	52
	.word	61
	.word	74
	.word	56
	.word	34
	.word	80
	.word	59
	.word	26
	.word	67
	.word	55
	.word	79
	.word	89
	.word	89
	.word	6
	.word	80
	.word	91
	.word	65
	.word	16
	.word	30
	.word	16
	.word	28
	.word	85
	.word	54
	.word	3
	.word	20
	.word	2
	.word	36
	.word	62
	.word	52
	.word	55
	.word	15
	.word	83
	.word	3
	.word	2
	.word	38
	.word	62
	.word	2
	.word	63
	.word	92
	.word	37
	.word	73
	.globl	g723_enc_state
	.section	.bss.g723_enc_state,"aw",@nobits
	.align	2
	.type	g723_enc_state, @object
	.size	g723_enc_state, 52
g723_enc_state:
	.zero	52
	.globl	__mulsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
