// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vverification_top.h for the primary calling header

#include "Vverification_top__pch.h"

VL_ATTR_COLD void Vverification_top___024root___eval_static(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_static\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP__in0__0 = vlSelfRef.in0;
    vlSelfRef.__Vtrigprevexpr___TOP__in1__0 = vlSelfRef.in1;
}

VL_ATTR_COLD void Vverification_top___024root___eval_initial(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_initial\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vverification_top___024root___eval_final(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_final\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vverification_top___024root___eval_phase__stl(Vverification_top___024root* vlSelf);

VL_ATTR_COLD void Vverification_top___024root___eval_settle(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_settle\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VstlIterCount;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vverification_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-11/can-this-run-offline/work/agentic-riscv-codesign/results/boundary-abstention-validation/raw/verification/verification.v", 1, "", "DIDNOTCONVERGE: Settle region did not converge after '--converge-limit' of 10000 tries");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        vlSelfRef.__VstlPhaseResult = Vverification_top___024root___eval_phase__stl(vlSelf);
        vlSelfRef.__VstlFirstIteration = 0U;
    } while (vlSelfRef.__VstlPhaseResult);
}

VL_ATTR_COLD bool Vverification_top___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(Vverification_top___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vverification_top___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vverification_top___024root___stl_sequent__TOP__0(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___stl_sequent__TOP__0\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ verification_top__DOT__c41__DOT__stage_n4_0;
    verification_top__DOT__c41__DOT__stage_n4_0 = 0;
    IData/*31:0*/ verification_top__DOT__c39__DOT__stage_n7_0;
    verification_top__DOT__c39__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c37__DOT__stage_n5_0;
    verification_top__DOT__c37__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c35__DOT__stage_n5_0;
    verification_top__DOT__c35__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c33__DOT__stage_n5_0;
    verification_top__DOT__c33__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c29__DOT__stage_n5_0;
    verification_top__DOT__c29__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c27__DOT__stage_n6_0;
    verification_top__DOT__c27__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c26__DOT__n7;
    verification_top__DOT__c26__DOT__n7 = 0;
    IData/*31:0*/ verification_top__DOT__c25__DOT__stage_n5_0;
    verification_top__DOT__c25__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c24__DOT__n2;
    verification_top__DOT__c24__DOT__n2 = 0;
    IData/*31:0*/ verification_top__DOT__c23__DOT__stage_n4_2;
    verification_top__DOT__c23__DOT__stage_n4_2 = 0;
    IData/*31:0*/ verification_top__DOT__c23__DOT__stage_n4_3;
    verification_top__DOT__c23__DOT__stage_n4_3 = 0;
    IData/*31:0*/ verification_top__DOT__c22__DOT__stage_n4_1;
    verification_top__DOT__c22__DOT__stage_n4_1 = 0;
    IData/*31:0*/ verification_top__DOT__c21__DOT__stage_n4_0;
    verification_top__DOT__c21__DOT__stage_n4_0 = 0;
    IData/*31:0*/ verification_top__DOT__c19__DOT__stage_n5_2;
    verification_top__DOT__c19__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c19__DOT__stage_n5_3;
    verification_top__DOT__c19__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c18__DOT__stage_n5_1;
    verification_top__DOT__c18__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c17__DOT__stage_n5_0;
    verification_top__DOT__c17__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_0;
    verification_top__DOT__c15__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_1;
    verification_top__DOT__c15__DOT__stage_n7_1 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_2;
    verification_top__DOT__c15__DOT__stage_n7_2 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_3;
    verification_top__DOT__c15__DOT__stage_n7_3 = 0;
    IData/*31:0*/ verification_top__DOT__c13__DOT__stage_n7_0;
    verification_top__DOT__c13__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c13__DOT__stage_n7_1;
    verification_top__DOT__c13__DOT__stage_n7_1 = 0;
    IData/*31:0*/ verification_top__DOT__c13__DOT__stage_n7_2;
    verification_top__DOT__c13__DOT__stage_n7_2 = 0;
    IData/*31:0*/ verification_top__DOT__c13__DOT__stage_n7_3;
    verification_top__DOT__c13__DOT__stage_n7_3 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n6_0;
    verification_top__DOT__c11__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n6_1;
    verification_top__DOT__c11__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n6_2;
    verification_top__DOT__c11__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n6_3;
    verification_top__DOT__c11__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n6_0;
    verification_top__DOT__c9__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n6_1;
    verification_top__DOT__c9__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n6_2;
    verification_top__DOT__c9__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n6_3;
    verification_top__DOT__c9__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n5_0;
    verification_top__DOT__c7__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n5_1;
    verification_top__DOT__c7__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n5_2;
    verification_top__DOT__c7__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n5_3;
    verification_top__DOT__c7__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n5_0;
    verification_top__DOT__c5__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n5_1;
    verification_top__DOT__c5__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n5_2;
    verification_top__DOT__c5__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n5_3;
    verification_top__DOT__c5__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c4__DOT__n7;
    verification_top__DOT__c4__DOT__n7 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n4_0;
    verification_top__DOT__c3__DOT__stage_n4_0 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n4_1;
    verification_top__DOT__c3__DOT__stage_n4_1 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n4_2;
    verification_top__DOT__c3__DOT__stage_n4_2 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n4_3;
    verification_top__DOT__c3__DOT__stage_n4_3 = 0;
    IData/*31:0*/ verification_top__DOT__c2__DOT__n6;
    verification_top__DOT__c2__DOT__n6 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n4_0;
    verification_top__DOT__c1__DOT__stage_n4_0 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n4_1;
    verification_top__DOT__c1__DOT__stage_n4_1 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n4_2;
    verification_top__DOT__c1__DOT__stage_n4_2 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n4_3;
    verification_top__DOT__c1__DOT__stage_n4_3 = 0;
    // Body
    verification_top__DOT__c41__DOT__stage_n4_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000083U) 
                                                       + vlSelfRef.in0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         (0x00000014U 
                                                          ^ 
                                                          (((IData)(0x00000083U) 
                                                            + vlSelfRef.in0) 
                                                           >> 1U))
                                                          : 
                                                         (0x00000029U 
                                                          ^ 
                                                          ((IData)(0x00000083U) 
                                                           + vlSelfRef.in0)))));
    vlSelfRef.verification_top__DOT__c30__DOT__stage_n4_0 
        = ((0x80000000U & (((IData)(0x00000065U) + 
                            (0x0000000dU ^ vlSelfRef.in0)) 
                           << 0x00000018U)) | (0x7f800000U 
                                               & (((IData)(0x00000065U) 
                                                   + 
                                                   (0x0000000dU 
                                                    ^ vlSelfRef.in0)) 
                                                  << 0x00000017U)));
    verification_top__DOT__c26__DOT__n7 = (vlSelfRef.in0 
                                           + vlSelfRef.in1);
    verification_top__DOT__c11__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000065U) 
                                                       + 
                                                       (0xff000000U 
                                                        & (0x0d000000U 
                                                           ^ 
                                                           (vlSelfRef.in1 
                                                            << 0x00000018U))))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in0)
                                                          ? 
                                                         ((IData)(0x00000065U) 
                                                          + 
                                                          (0x7f000000U 
                                                           & (0x0d000000U 
                                                              ^ 
                                                              (vlSelfRef.in1 
                                                               << 0x00000018U))))
                                                          : 
                                                         (((IData)(0x00000065U) 
                                                           + 
                                                           (0xff000000U 
                                                            & (0x0d000000U 
                                                               ^ 
                                                               (vlSelfRef.in1 
                                                                << 0x00000018U)))) 
                                                          >> 1U))));
    verification_top__DOT__c9__DOT__stage_n6_0 = ((0x80000000U 
                                                   & (((IData)(0x00000065U) 
                                                       + vlSelfRef.in0) 
                                                      << 0x00000018U)) 
                                                  | ((1U 
                                                      & ((IData)(1U) 
                                                         + vlSelfRef.in1))
                                                      ? 
                                                     (0x7f800000U 
                                                      & (0x06800000U 
                                                         ^ 
                                                         (0x7f800000U 
                                                          & (((IData)(0x00000065U) 
                                                              + vlSelfRef.in0) 
                                                             << 0x00000017U))))
                                                      : 
                                                     (0x7f000000U 
                                                      & (0x0d000000U 
                                                         ^ 
                                                         (((IData)(0x65U) 
                                                           + vlSelfRef.in0) 
                                                          << 0x00000018U)))));
    verification_top__DOT__c3__DOT__stage_n4_0 = ((0x80000000U 
                                                   & ((IData)(0x00000065U) 
                                                      + vlSelfRef.in1)) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & ((IData)(1U) 
                                                            + vlSelfRef.in0))
                                                         ? 
                                                        (6U 
                                                         ^ 
                                                         (((IData)(0x00000065U) 
                                                           + vlSelfRef.in1) 
                                                          >> 1U))
                                                         : 
                                                        (0x0000000dU 
                                                         ^ 
                                                         ((IData)(0x00000065U) 
                                                          + vlSelfRef.in1)))));
    verification_top__DOT__c1__DOT__stage_n4_0 = ((0x80000000U 
                                                   & ((IData)(0x00000065U) 
                                                      + 
                                                      (0x0000000dU 
                                                       ^ vlSelfRef.in0))) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in1)
                                                         ? 
                                                        ((IData)(0x00000065U) 
                                                         + 
                                                         (0x0000000dU 
                                                          ^ vlSelfRef.in0))
                                                         : 
                                                        (((IData)(0x00000065U) 
                                                          + 
                                                          (0x0000000dU 
                                                           ^ vlSelfRef.in0)) 
                                                         >> 1U))));
    verification_top__DOT__c24__DOT__n2 = (vlSelfRef.in1 
                                           ^ ((IData)(0x00000065U) 
                                              + (0x0000000dU 
                                                 ^ vlSelfRef.in0)));
    verification_top__DOT__c4__DOT__n7 = (vlSelfRef.in0 
                                          ^ vlSelfRef.in1);
    vlSelfRef.verification_top__DOT__c0__DOT__n6 = 
        (vlSelfRef.in0 | vlSelfRef.in1);
    verification_top__DOT__c2__DOT__n6 = (vlSelfRef.in0 
                                          & vlSelfRef.in1);
    verification_top__DOT__c9__DOT__stage_n6_1 = ((2U 
                                                   & ((IData)(5U) 
                                                      + vlSelfRef.in1))
                                                   ? 
                                                  (((- (IData)(
                                                               (1U 
                                                                & (((IData)(0x00000065U) 
                                                                    + vlSelfRef.in0) 
                                                                   >> 7U)))) 
                                                    << 0x0000001eU) 
                                                   | (verification_top__DOT__c9__DOT__stage_n6_0 
                                                      >> 2U))
                                                   : verification_top__DOT__c9__DOT__stage_n6_0);
    verification_top__DOT__c3__DOT__stage_n4_1 = ((2U 
                                                   & ((IData)(5U) 
                                                      + vlSelfRef.in0))
                                                   ? 
                                                  (((- (IData)(
                                                               (((IData)(0x00000065U) 
                                                                 + vlSelfRef.in1) 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001eU) 
                                                   | (verification_top__DOT__c3__DOT__stage_n4_0 
                                                      >> 2U))
                                                   : verification_top__DOT__c3__DOT__stage_n4_0);
    verification_top__DOT__c25__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & verification_top__DOT__c24__DOT__n2) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in1)
                                                          ? verification_top__DOT__c24__DOT__n2
                                                          : 
                                                         (verification_top__DOT__c24__DOT__n2 
                                                          >> 1U))));
    vlSelfRef.out_16 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x80000000U 
                                             & ((IData)(0x00000065U) 
                                                + (0x0000000dU 
                                                   ^ verification_top__DOT__c4__DOT__n7))) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & vlSelfRef.in1)
                                                   ? 
                                                  ((IData)(0x00000065U) 
                                                   + 
                                                   (0x0000000dU 
                                                    ^ verification_top__DOT__c4__DOT__n7))
                                                   : 
                                                  (((IData)(0x00000065U) 
                                                    + 
                                                    (0x0000000dU 
                                                     ^ verification_top__DOT__c4__DOT__n7)) 
                                                   >> 1U))))));
    vlSelfRef.out_24 = (verification_top__DOT__c4__DOT__n7 
                        + ((0x80000000U & verification_top__DOT__c24__DOT__n2) 
                           | (0x7fffffffU & ((1U & vlSelfRef.in1)
                                              ? verification_top__DOT__c24__DOT__n2
                                              : (verification_top__DOT__c24__DOT__n2 
                                                 >> 1U)))));
    verification_top__DOT__c39__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000083U) 
                                                       + 
                                                       (0xff000000U 
                                                        & (0x29000000U 
                                                           ^ 
                                                           (verification_top__DOT__c4__DOT__n7 
                                                            << 0x00000018U))))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in1)
                                                          ? 
                                                         ((IData)(0x00000083U) 
                                                          + 
                                                          (0x7f000000U 
                                                           & (0x29000000U 
                                                              ^ 
                                                              (verification_top__DOT__c4__DOT__n7 
                                                               << 0x00000018U))))
                                                          : 
                                                         (((IData)(0x00000083U) 
                                                           + 
                                                           (0xff000000U 
                                                            & (0x29000000U 
                                                               ^ 
                                                               (verification_top__DOT__c4__DOT__n7 
                                                                << 0x00000018U)))) 
                                                          >> 1U))));
    verification_top__DOT__c33__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000083U) 
                                                       + 
                                                       (0x00000029U 
                                                        ^ verification_top__DOT__c4__DOT__n7))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in0)
                                                          ? 
                                                         ((IData)(0x00000083U) 
                                                          + 
                                                          (0x00000029U 
                                                           ^ verification_top__DOT__c4__DOT__n7))
                                                          : 
                                                         (((IData)(0x00000083U) 
                                                           + 
                                                           (0x00000029U 
                                                            ^ verification_top__DOT__c4__DOT__n7)) 
                                                          >> 1U))));
    verification_top__DOT__c17__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000065U) 
                                                       + 
                                                       (0x0000000dU 
                                                        ^ verification_top__DOT__c4__DOT__n7))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in1)
                                                          ? 
                                                         ((IData)(0x00000065U) 
                                                          + 
                                                          (0x0000000dU 
                                                           ^ verification_top__DOT__c4__DOT__n7))
                                                          : 
                                                         (((IData)(0x00000065U) 
                                                           + 
                                                           (0x0000000dU 
                                                            ^ verification_top__DOT__c4__DOT__n7)) 
                                                          >> 1U))));
    vlSelfRef.out_0 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                       ^ (vlSelfRef.in1 + ((0x80000000U 
                                            & ((IData)(0x00000065U) 
                                               + (0x0000000dU 
                                                  ^ vlSelfRef.in0))) 
                                           | (0x7fffffffU 
                                              & ((1U 
                                                  & vlSelfRef.in1)
                                                  ? 
                                                 ((IData)(0x00000065U) 
                                                  + 
                                                  (0x0000000dU 
                                                   ^ vlSelfRef.in0))
                                                  : 
                                                 (((IData)(0x00000065U) 
                                                   + 
                                                   (0x0000000dU 
                                                    ^ vlSelfRef.in0)) 
                                                  >> 1U))))));
    vlSelfRef.out_8 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                       ^ (vlSelfRef.in1 + ((0x80000000U 
                                            & (((IData)(0x00000065U) 
                                                + vlSelfRef.in0) 
                                               << 0x00000018U)) 
                                           | ((1U & 
                                               ((IData)(1U) 
                                                + vlSelfRef.in1))
                                               ? (0x7f800000U 
                                                  & (0x06800000U 
                                                     ^ 
                                                     (0x7f800000U 
                                                      & (((IData)(0x00000065U) 
                                                          + vlSelfRef.in0) 
                                                         << 0x00000017U))))
                                               : (0x7f000000U 
                                                  & (0x0d000000U 
                                                     ^ 
                                                     (((IData)(0x65U) 
                                                       + vlSelfRef.in0) 
                                                      << 0x00000018U)))))));
    vlSelfRef.out_26 = (verification_top__DOT__c26__DOT__n7 
                        ^ ((0x80000000U & ((IData)(0x00000065U) 
                                           + (0x0000000dU 
                                              ^ (0x0000ffffU 
                                                 & vlSelfRef.verification_top__DOT__c0__DOT__n6)))) 
                           | (0x7fffffffU & ((1U & vlSelfRef.in0)
                                              ? ((IData)(0x00000065U) 
                                                 + 
                                                 (0x0000000dU 
                                                  ^ 
                                                  (0x0000ffffU 
                                                   & vlSelfRef.verification_top__DOT__c0__DOT__n6)))
                                              : (((IData)(0x00000065U) 
                                                  + 
                                                  (0x0000000dU 
                                                   ^ 
                                                   (0x0000ffffU 
                                                    & vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                                 >> 1U)))));
    vlSelfRef.out_30 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (vlSelfRef.in1 + vlSelfRef.verification_top__DOT__c30__DOT__stage_n4_0));
    vlSelfRef.out_32 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (verification_top__DOT__c4__DOT__n7 
                           + ((0x80000000U & ((IData)(0x0000001dU) 
                                              + (5U 
                                                 ^ verification_top__DOT__c4__DOT__n7))) 
                              | (0x7fffffffU & ((1U 
                                                 & vlSelfRef.in0)
                                                 ? 
                                                ((IData)(0x0000001dU) 
                                                 + 
                                                 (5U 
                                                  ^ verification_top__DOT__c4__DOT__n7))
                                                 : 
                                                (((IData)(0x0000001dU) 
                                                  + 
                                                  (5U 
                                                   ^ verification_top__DOT__c4__DOT__n7)) 
                                                 >> 1U))))));
    vlSelfRef.out_38 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (verification_top__DOT__c4__DOT__n7 
                           + ((0x80000000U & ((IData)(0x0000001dU) 
                                              + (0xff000000U 
                                                 & (0x05000000U 
                                                    ^ 
                                                    (verification_top__DOT__c4__DOT__n7 
                                                     << 0x00000018U))))) 
                              | (0x7fffffffU & ((1U 
                                                 & vlSelfRef.in1)
                                                 ? 
                                                ((IData)(0x0000001dU) 
                                                 + 
                                                 (0x7f000000U 
                                                  & (0x05000000U 
                                                     ^ 
                                                     (verification_top__DOT__c4__DOT__n7 
                                                      << 0x00000018U))))
                                                 : 
                                                (((IData)(0x0000001dU) 
                                                  + 
                                                  (0xff000000U 
                                                   & (0x05000000U 
                                                      ^ 
                                                      (verification_top__DOT__c4__DOT__n7 
                                                       << 0x00000018U)))) 
                                                 >> 1U))))));
    vlSelfRef.out_31 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (vlSelfRef.in1 + (((- (IData)(
                                                        (1U 
                                                         & (((IData)(0x00000065U) 
                                                             + 
                                                             (0x0000000dU 
                                                              ^ vlSelfRef.in0)) 
                                                            >> 7U)))) 
                                             << 0x0000001eU) 
                                            | (vlSelfRef.verification_top__DOT__c30__DOT__stage_n4_0 
                                               >> 2U))));
    vlSelfRef.out_40 = ((vlSelfRef.in0 + ((0x80000000U 
                                           & ((IData)(0x0000001dU) 
                                              + (5U 
                                                 ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                          | (0x7fffffffU 
                                             & ((1U 
                                                 & vlSelfRef.in1)
                                                 ? 
                                                ((IData)(0x0000001dU) 
                                                 + 
                                                 (5U 
                                                  ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                 : 
                                                (((IData)(0x0000001dU) 
                                                  + 
                                                  (5U 
                                                   ^ vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                                 >> 1U))))) 
                        ^ verification_top__DOT__c4__DOT__n7);
    vlSelfRef.out_41 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (vlSelfRef.in1 + ((2U & ((IData)(5U) 
                                                   + vlSelfRef.in1))
                                             ? (((- (IData)(
                                                            (((IData)(0x00000083U) 
                                                              + vlSelfRef.in0) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c41__DOT__stage_n4_0 
                                                   >> 2U))
                                             : verification_top__DOT__c41__DOT__stage_n4_0)));
    vlSelfRef.out_43 = ((vlSelfRef.in0 + ((0x80000000U 
                                           & ((IData)(0x00000047U) 
                                              + (0x0000000bU 
                                                 ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                          | (0x7fffffffU 
                                             & ((1U 
                                                 & vlSelfRef.in1)
                                                 ? 
                                                ((IData)(0x00000047U) 
                                                 + 
                                                 (0x0000000bU 
                                                  ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                 : 
                                                (((IData)(0x00000047U) 
                                                  + 
                                                  (0x0000000bU 
                                                   ^ vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                                 >> 1U))))) 
                        ^ verification_top__DOT__c4__DOT__n7);
    vlSelfRef.out_45 = ((vlSelfRef.in0 + ((0x80000000U 
                                           & ((IData)(0x00000083U) 
                                              + (0x00000029U 
                                                 ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                          | (0x7fffffffU 
                                             & ((1U 
                                                 & vlSelfRef.in1)
                                                 ? 
                                                ((IData)(0x00000083U) 
                                                 + 
                                                 (0x00000029U 
                                                  ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                 : 
                                                (((IData)(0x00000083U) 
                                                  + 
                                                  (0x00000029U 
                                                   ^ vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                                 >> 1U))))) 
                        ^ verification_top__DOT__c4__DOT__n7);
    verification_top__DOT__c37__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000083U) 
                                                       + 
                                                       (0x00000029U 
                                                        ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in0)
                                                          ? 
                                                         ((IData)(0x00000083U) 
                                                          + 
                                                          (0x00000029U 
                                                           ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                          : 
                                                         (((IData)(0x00000083U) 
                                                           + 
                                                           (0x00000029U 
                                                            ^ vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                                          >> 1U))));
    verification_top__DOT__c29__DOT__stage_n5_0 = (
                                                   (1U 
                                                    & vlSelfRef.in1)
                                                    ? 
                                                   (0x0000000dU 
                                                    ^ 
                                                    ((IData)(0x00000065U) 
                                                     + vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                    : 
                                                   (6U 
                                                    ^ 
                                                    (((IData)(0x00000065U) 
                                                      + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                     >> 1U)));
    verification_top__DOT__c27__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000065U) 
                                                       + 
                                                       (0x0000000dU 
                                                        ^ 
                                                        (0x0000ffffU 
                                                         & vlSelfRef.verification_top__DOT__c0__DOT__n6)))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in0)
                                                          ? 
                                                         ((IData)(0x00000065U) 
                                                          + 
                                                          (0x0000000dU 
                                                           ^ 
                                                           (0x0000ffffU 
                                                            & vlSelfRef.verification_top__DOT__c0__DOT__n6)))
                                                          : 
                                                         (((IData)(0x00000065U) 
                                                           + 
                                                           (0x0000000dU 
                                                            ^ 
                                                            (0x0000ffffU 
                                                             & vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                                          >> 1U))));
    verification_top__DOT__c15__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x00000065U) 
                                                        + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                       << 0x00000010U)) 
                                                   | ((1U 
                                                       & vlSelfRef.in0)
                                                       ? 
                                                      (0x0000000dU 
                                                       ^ 
                                                       (0x7fff0000U 
                                                        & (((IData)(0x00000065U) 
                                                            + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                           << 0x00000010U)))
                                                       : 
                                                      (6U 
                                                       ^ 
                                                       (0x7fff8000U 
                                                        & (((IData)(0x00000065U) 
                                                            + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                           << 0x0000000fU)))));
    verification_top__DOT__c7__DOT__stage_n5_0 = ((0x80000000U 
                                                   & ((IData)(0x00000065U) 
                                                      + vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in0)
                                                         ? 
                                                        (0x0000000dU 
                                                         ^ 
                                                         ((IData)(0x00000065U) 
                                                          + vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                         : 
                                                        (6U 
                                                         ^ 
                                                         (((IData)(0x00000065U) 
                                                           + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                          >> 1U)))));
    if ((2U & vlSelfRef.in0)) {
        verification_top__DOT__c11__DOT__stage_n6_1 
            = verification_top__DOT__c11__DOT__stage_n6_0;
        verification_top__DOT__c15__DOT__stage_n7_1 
            = verification_top__DOT__c15__DOT__stage_n7_0;
        verification_top__DOT__c7__DOT__stage_n5_1 
            = verification_top__DOT__c7__DOT__stage_n5_0;
    } else {
        verification_top__DOT__c11__DOT__stage_n6_1 
            = (((- (IData)((((IData)(0x00000065U) + 
                             (0xff000000U & (0x0d000000U 
                                             ^ (vlSelfRef.in1 
                                                << 0x00000018U)))) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c11__DOT__stage_n6_0 
                  >> 2U));
        verification_top__DOT__c15__DOT__stage_n7_1 
            = (((- (IData)((1U & (((IData)(0x00000065U) 
                                   + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                  >> 0x0000000fU)))) 
                << 0x0000001eU) | (verification_top__DOT__c15__DOT__stage_n7_0 
                                   >> 2U));
        verification_top__DOT__c7__DOT__stage_n5_1 
            = (((- (IData)((((IData)(0x00000065U) + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c7__DOT__stage_n5_0 
                  >> 2U));
    }
    vlSelfRef.out_2 = (verification_top__DOT__c2__DOT__n6 
                       ^ (vlSelfRef.in0 + ((0x80000000U 
                                            & ((IData)(0x00000065U) 
                                               + vlSelfRef.in1)) 
                                           | (0x7fffffffU 
                                              & ((1U 
                                                  & ((IData)(1U) 
                                                     + vlSelfRef.in0))
                                                  ? 
                                                 (6U 
                                                  ^ 
                                                  (((IData)(0x00000065U) 
                                                    + vlSelfRef.in1) 
                                                   >> 1U))
                                                  : 
                                                 (0x0000000dU 
                                                  ^ 
                                                  ((IData)(0x00000065U) 
                                                   + vlSelfRef.in1)))))));
    vlSelfRef.out_10 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in0 + ((0x80000000U 
                                             & ((IData)(0x00000065U) 
                                                + (0xff000000U 
                                                   & (0x0d000000U 
                                                      ^ 
                                                      (vlSelfRef.in1 
                                                       << 0x00000018U))))) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & vlSelfRef.in0)
                                                   ? 
                                                  ((IData)(0x00000065U) 
                                                   + 
                                                   (0x7f000000U 
                                                    & (0x0d000000U 
                                                       ^ 
                                                       (vlSelfRef.in1 
                                                        << 0x00000018U))))
                                                   : 
                                                  (((IData)(0x00000065U) 
                                                    + 
                                                    (0xff000000U 
                                                     & (0x0d000000U 
                                                        ^ 
                                                        (vlSelfRef.in1 
                                                         << 0x00000018U)))) 
                                                   >> 1U))))));
    vlSelfRef.out_12 = ((verification_top__DOT__c2__DOT__n6 
                         + ((0x80000000U & (((IData)(0x00000065U) 
                                             + verification_top__DOT__c2__DOT__n6) 
                                            << 0x00000010U)) 
                            | ((1U & vlSelfRef.in1)
                                ? (0x7fff0000U & (0x000d0000U 
                                                  ^ 
                                                  (((IData)(0x0065U) 
                                                    + verification_top__DOT__c2__DOT__n6) 
                                                   << 0x00000010U)))
                                : (0x7fff8000U & (0x00068000U 
                                                  ^ 
                                                  (0x7fff8000U 
                                                   & (((IData)(0x00000065U) 
                                                       + verification_top__DOT__c2__DOT__n6) 
                                                      << 0x0000000fU))))))) 
                        ^ verification_top__DOT__c4__DOT__n7);
    vlSelfRef.out_20 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((0x80000000U 
                                             & ((IData)(0x00000065U) 
                                                + vlSelfRef.in0)) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & verification_top__DOT__c2__DOT__n6)
                                                   ? 
                                                  (6U 
                                                   ^ 
                                                   (((IData)(0x00000065U) 
                                                     + vlSelfRef.in0) 
                                                    >> 1U))
                                                   : 
                                                  (0x0000000dU 
                                                   ^ 
                                                   ((IData)(0x00000065U) 
                                                    + vlSelfRef.in0)))))));
    vlSelfRef.out_34 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (verification_top__DOT__c2__DOT__n6 
                           + ((0x80000000U & ((IData)(0x0000001dU) 
                                              + verification_top__DOT__c2__DOT__n6)) 
                              | (0x7fffffffU & ((1U 
                                                 & vlSelfRef.in1)
                                                 ? 
                                                (5U 
                                                 ^ 
                                                 ((IData)(0x0000001dU) 
                                                  + verification_top__DOT__c2__DOT__n6))
                                                 : 
                                                (2U 
                                                 ^ 
                                                 (((IData)(0x0000001dU) 
                                                   + verification_top__DOT__c2__DOT__n6) 
                                                  >> 1U)))))));
    vlSelfRef.out_36 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                           + ((0x80000000U & ((IData)(0x0000001dU) 
                                              + (5U 
                                                 ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                              | (0x7fffffffU & ((1U 
                                                 & vlSelfRef.in0)
                                                 ? 
                                                ((IData)(0x0000001dU) 
                                                 + 
                                                 (5U 
                                                  ^ vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                 : 
                                                (((IData)(0x0000001dU) 
                                                  + 
                                                  (5U 
                                                   ^ vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                                 >> 1U))))));
    vlSelfRef.out_4 = ((vlSelfRef.in0 + ((0x80000000U 
                                          & ((IData)(0x00000065U) 
                                             + (0x0000000dU 
                                                ^ verification_top__DOT__c2__DOT__n6))) 
                                         | (0x7fffffffU 
                                            & ((1U 
                                                & vlSelfRef.in1)
                                                ? ((IData)(0x00000065U) 
                                                   + 
                                                   (0x0000000dU 
                                                    ^ verification_top__DOT__c2__DOT__n6))
                                                : (
                                                   ((IData)(0x00000065U) 
                                                    + 
                                                    (0x0000000dU 
                                                     ^ verification_top__DOT__c2__DOT__n6)) 
                                                   >> 1U))))) 
                       ^ verification_top__DOT__c4__DOT__n7);
    vlSelfRef.out_6 = (verification_top__DOT__c2__DOT__n6 
                       ^ (vlSelfRef.in1 + ((0x80000000U 
                                            & ((IData)(0x00000065U) 
                                               + vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                           | (0x7fffffffU 
                                              & ((1U 
                                                  & vlSelfRef.in0)
                                                  ? 
                                                 (0x0000000dU 
                                                  ^ 
                                                  ((IData)(0x00000065U) 
                                                   + vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                                  : 
                                                 (6U 
                                                  ^ 
                                                  (((IData)(0x00000065U) 
                                                    + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                   >> 1U)))))));
    vlSelfRef.out_14 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in1 + ((0x80000000U 
                                             & (((IData)(0x00000065U) 
                                                 + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                << 0x00000010U)) 
                                            | ((1U 
                                                & vlSelfRef.in0)
                                                ? (0x0000000dU 
                                                   ^ 
                                                   (0x7fff0000U 
                                                    & (((IData)(0x00000065U) 
                                                        + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                       << 0x00000010U)))
                                                : (6U 
                                                   ^ 
                                                   (0x7fff8000U 
                                                    & (((IData)(0x00000065U) 
                                                        + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                       << 0x0000000fU)))))));
    vlSelfRef.out_28 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in0 + ((1U & vlSelfRef.in1)
                                             ? (0x0000000dU 
                                                ^ ((IData)(0x00000065U) 
                                                   + vlSelfRef.verification_top__DOT__c0__DOT__n6))
                                             : (6U 
                                                ^ (
                                                   ((IData)(0x00000065U) 
                                                    + vlSelfRef.verification_top__DOT__c0__DOT__n6) 
                                                   >> 1U)))));
    vlSelfRef.out_42 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in1 + ((0x80000000U 
                                             & ((IData)(0x0000001dU) 
                                                + verification_top__DOT__c4__DOT__n7)) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & vlSelfRef.in0)
                                                   ? 
                                                  (5U 
                                                   ^ 
                                                   ((IData)(0x0000001dU) 
                                                    + verification_top__DOT__c4__DOT__n7))
                                                   : 
                                                  (2U 
                                                   ^ 
                                                   (((IData)(0x0000001dU) 
                                                     + verification_top__DOT__c4__DOT__n7) 
                                                    >> 1U)))))));
    vlSelfRef.out_44 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in1 + ((0x80000000U 
                                             & ((IData)(0x00000083U) 
                                                + verification_top__DOT__c4__DOT__n7)) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & vlSelfRef.in0)
                                                   ? 
                                                  (0x00000029U 
                                                   ^ 
                                                   ((IData)(0x00000083U) 
                                                    + verification_top__DOT__c4__DOT__n7))
                                                   : 
                                                  (0x00000014U 
                                                   ^ 
                                                   (((IData)(0x00000083U) 
                                                     + verification_top__DOT__c4__DOT__n7) 
                                                    >> 1U)))))));
    verification_top__DOT__c35__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000083U) 
                                                       + verification_top__DOT__c2__DOT__n6)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in1)
                                                          ? 
                                                         (0x00000029U 
                                                          ^ 
                                                          ((IData)(0x00000083U) 
                                                           + verification_top__DOT__c2__DOT__n6))
                                                          : 
                                                         (0x00000014U 
                                                          ^ 
                                                          (((IData)(0x00000083U) 
                                                            + verification_top__DOT__c2__DOT__n6) 
                                                           >> 1U)))));
    verification_top__DOT__c13__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x00000065U) 
                                                        + verification_top__DOT__c2__DOT__n6) 
                                                       << 0x00000010U)) 
                                                   | ((1U 
                                                       & vlSelfRef.in1)
                                                       ? 
                                                      (0x7fff0000U 
                                                       & (0x000d0000U 
                                                          ^ 
                                                          (((IData)(0x0065U) 
                                                            + verification_top__DOT__c2__DOT__n6) 
                                                           << 0x00000010U)))
                                                       : 
                                                      (0x7fff8000U 
                                                       & (0x00068000U 
                                                          ^ 
                                                          (0x7fff8000U 
                                                           & (((IData)(0x00000065U) 
                                                               + verification_top__DOT__c2__DOT__n6) 
                                                              << 0x0000000fU))))));
    verification_top__DOT__c5__DOT__stage_n5_0 = ((0x80000000U 
                                                   & ((IData)(0x00000065U) 
                                                      + 
                                                      (0x0000000dU 
                                                       ^ verification_top__DOT__c2__DOT__n6))) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in1)
                                                         ? 
                                                        ((IData)(0x00000065U) 
                                                         + 
                                                         (0x0000000dU 
                                                          ^ verification_top__DOT__c2__DOT__n6))
                                                         : 
                                                        (((IData)(0x00000065U) 
                                                          + 
                                                          (0x0000000dU 
                                                           ^ verification_top__DOT__c2__DOT__n6)) 
                                                         >> 1U))));
    if ((2U & vlSelfRef.in1)) {
        verification_top__DOT__c1__DOT__stage_n4_1 
            = verification_top__DOT__c1__DOT__stage_n4_0;
        verification_top__DOT__c18__DOT__stage_n5_1 
            = verification_top__DOT__c17__DOT__stage_n5_0;
        verification_top__DOT__c13__DOT__stage_n7_1 
            = verification_top__DOT__c13__DOT__stage_n7_0;
        verification_top__DOT__c5__DOT__stage_n5_1 
            = verification_top__DOT__c5__DOT__stage_n5_0;
    } else {
        verification_top__DOT__c1__DOT__stage_n4_1 
            = (((- (IData)((((IData)(0x00000065U) + 
                             (0x0000000dU ^ vlSelfRef.in0)) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c1__DOT__stage_n4_0 
                  >> 2U));
        verification_top__DOT__c18__DOT__stage_n5_1 
            = (((- (IData)((((IData)(0x00000065U) + 
                             (0x0000000dU ^ verification_top__DOT__c4__DOT__n7)) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c17__DOT__stage_n5_0 
                  >> 2U));
        verification_top__DOT__c13__DOT__stage_n7_1 
            = (((- (IData)((1U & (((IData)(0x00000065U) 
                                   + verification_top__DOT__c2__DOT__n6) 
                                  >> 0x0000000fU)))) 
                << 0x0000001eU) | (verification_top__DOT__c13__DOT__stage_n7_0 
                                   >> 2U));
        verification_top__DOT__c5__DOT__stage_n5_1 
            = (((- (IData)((((IData)(0x00000065U) + 
                             (0x0000000dU ^ verification_top__DOT__c2__DOT__n6)) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c5__DOT__stage_n5_0 
                  >> 2U));
    }
    verification_top__DOT__c21__DOT__stage_n4_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000065U) 
                                                       + vlSelfRef.in0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c2__DOT__n6)
                                                          ? 
                                                         (6U 
                                                          ^ 
                                                          (((IData)(0x00000065U) 
                                                            + vlSelfRef.in0) 
                                                           >> 1U))
                                                          : 
                                                         (0x0000000dU 
                                                          ^ 
                                                          ((IData)(0x00000065U) 
                                                           + vlSelfRef.in0)))));
    if ((4U & vlSelfRef.in0)) {
        verification_top__DOT__c11__DOT__stage_n6_2 
            = verification_top__DOT__c11__DOT__stage_n6_1;
        verification_top__DOT__c15__DOT__stage_n7_2 
            = verification_top__DOT__c15__DOT__stage_n7_1;
        verification_top__DOT__c7__DOT__stage_n5_2 
            = verification_top__DOT__c7__DOT__stage_n5_1;
    } else {
        verification_top__DOT__c11__DOT__stage_n6_2 
            = (((- (IData)((verification_top__DOT__c11__DOT__stage_n6_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c11__DOT__stage_n6_1 
                  >> 4U));
        verification_top__DOT__c15__DOT__stage_n7_2 
            = (((- (IData)((verification_top__DOT__c15__DOT__stage_n7_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c15__DOT__stage_n7_1 
                  >> 4U));
        verification_top__DOT__c7__DOT__stage_n5_2 
            = (((- (IData)((verification_top__DOT__c7__DOT__stage_n5_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c7__DOT__stage_n5_1 
                  >> 4U));
    }
    verification_top__DOT__c9__DOT__stage_n6_2 = ((4U 
                                                   & ((IData)(5U) 
                                                      + vlSelfRef.in1))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c9__DOT__stage_n6_1 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c9__DOT__stage_n6_1 
                                                      >> 4U))
                                                   : verification_top__DOT__c9__DOT__stage_n6_1);
    verification_top__DOT__c3__DOT__stage_n4_2 = ((4U 
                                                   & ((IData)(5U) 
                                                      + vlSelfRef.in0))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c3__DOT__stage_n4_1 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c3__DOT__stage_n4_1 
                                                      >> 4U))
                                                   : verification_top__DOT__c3__DOT__stage_n4_1);
    if ((4U & vlSelfRef.in1)) {
        verification_top__DOT__c1__DOT__stage_n4_2 
            = verification_top__DOT__c1__DOT__stage_n4_1;
        verification_top__DOT__c19__DOT__stage_n5_2 
            = verification_top__DOT__c18__DOT__stage_n5_1;
        verification_top__DOT__c13__DOT__stage_n7_2 
            = verification_top__DOT__c13__DOT__stage_n7_1;
        verification_top__DOT__c5__DOT__stage_n5_2 
            = verification_top__DOT__c5__DOT__stage_n5_1;
    } else {
        verification_top__DOT__c1__DOT__stage_n4_2 
            = (((- (IData)((verification_top__DOT__c1__DOT__stage_n4_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c1__DOT__stage_n4_1 
                  >> 4U));
        verification_top__DOT__c19__DOT__stage_n5_2 
            = (((- (IData)((verification_top__DOT__c18__DOT__stage_n5_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c18__DOT__stage_n5_1 
                  >> 4U));
        verification_top__DOT__c13__DOT__stage_n7_2 
            = (((- (IData)((verification_top__DOT__c13__DOT__stage_n7_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c13__DOT__stage_n7_1 
                  >> 4U));
        verification_top__DOT__c5__DOT__stage_n5_2 
            = (((- (IData)((verification_top__DOT__c5__DOT__stage_n5_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c5__DOT__stage_n5_1 
                  >> 4U));
    }
    vlSelfRef.out_25 = (verification_top__DOT__c4__DOT__n7 
                        + ((2U & vlSelfRef.in1) ? verification_top__DOT__c25__DOT__stage_n5_0
                            : (((- (IData)((verification_top__DOT__c24__DOT__n2 
                                            >> 0x0000001fU))) 
                                << 0x0000001eU) | (verification_top__DOT__c25__DOT__stage_n5_0 
                                                   >> 2U))));
    vlSelfRef.out_39 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (verification_top__DOT__c4__DOT__n7 
                           + ((2U & vlSelfRef.in1) ? verification_top__DOT__c39__DOT__stage_n7_0
                               : (((- (IData)((((IData)(0x00000083U) 
                                                + (0xff000000U 
                                                   & (0x29000000U 
                                                      ^ 
                                                      (verification_top__DOT__c4__DOT__n7 
                                                       << 0x00000018U)))) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c39__DOT__stage_n7_0 
                                     >> 2U)))));
    vlSelfRef.out_33 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (verification_top__DOT__c4__DOT__n7 
                           + ((2U & vlSelfRef.in0) ? verification_top__DOT__c33__DOT__stage_n5_0
                               : (((- (IData)((((IData)(0x00000083U) 
                                                + (0x00000029U 
                                                   ^ verification_top__DOT__c4__DOT__n7)) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c33__DOT__stage_n5_0 
                                     >> 2U)))));
    vlSelfRef.out_17 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & vlSelfRef.in1)
                                             ? verification_top__DOT__c17__DOT__stage_n5_0
                                             : (((- (IData)(
                                                            (((IData)(0x00000065U) 
                                                              + 
                                                              (0x0000000dU 
                                                               ^ verification_top__DOT__c4__DOT__n7)) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c17__DOT__stage_n5_0 
                                                   >> 2U)))));
    vlSelfRef.out_37 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                           + ((2U & vlSelfRef.in0) ? verification_top__DOT__c37__DOT__stage_n5_0
                               : (((- (IData)((((IData)(0x00000083U) 
                                                + (0x00000029U 
                                                   ^ vlSelfRef.verification_top__DOT__c0__DOT__n6)) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c37__DOT__stage_n5_0 
                                     >> 2U)))));
    vlSelfRef.out_29 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in0 + ((2U & vlSelfRef.in1)
                                             ? verification_top__DOT__c29__DOT__stage_n5_0
                                             : (verification_top__DOT__c29__DOT__stage_n5_0 
                                                >> 2U))));
    vlSelfRef.out_27 = (((2U & vlSelfRef.in0) ? verification_top__DOT__c27__DOT__stage_n6_0
                          : (((- (IData)((((IData)(0x00000065U) 
                                           + (0x0000000dU 
                                              ^ (0x0000ffffU 
                                                 & vlSelfRef.verification_top__DOT__c0__DOT__n6))) 
                                          >> 0x0000001fU))) 
                              << 0x0000001eU) | (verification_top__DOT__c27__DOT__stage_n6_0 
                                                 >> 2U))) 
                        ^ verification_top__DOT__c26__DOT__n7);
    vlSelfRef.out_35 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                        ^ (verification_top__DOT__c2__DOT__n6 
                           + ((2U & vlSelfRef.in1) ? verification_top__DOT__c35__DOT__stage_n5_0
                               : (((- (IData)((((IData)(0x00000083U) 
                                                + verification_top__DOT__c2__DOT__n6) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c35__DOT__stage_n5_0 
                                     >> 2U)))));
    vlSelfRef.out_21 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((2U & verification_top__DOT__c2__DOT__n6)
                                             ? (((- (IData)(
                                                            (((IData)(0x00000065U) 
                                                              + vlSelfRef.in0) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c21__DOT__stage_n4_0 
                                                   >> 2U))
                                             : verification_top__DOT__c21__DOT__stage_n4_0)));
    verification_top__DOT__c22__DOT__stage_n4_1 = (
                                                   (2U 
                                                    & verification_top__DOT__c2__DOT__n6)
                                                    ? 
                                                   (((- (IData)(
                                                                (((IData)(0x00000065U) 
                                                                  + vlSelfRef.in0) 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c21__DOT__stage_n4_0 
                                                       >> 2U))
                                                    : verification_top__DOT__c21__DOT__stage_n4_0);
    if ((8U & vlSelfRef.in0)) {
        verification_top__DOT__c11__DOT__stage_n6_3 
            = (((- (IData)((verification_top__DOT__c11__DOT__stage_n6_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c11__DOT__stage_n6_2 
                  >> 8U));
        verification_top__DOT__c15__DOT__stage_n7_3 
            = (((- (IData)((verification_top__DOT__c15__DOT__stage_n7_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c15__DOT__stage_n7_2 
                  >> 8U));
        verification_top__DOT__c7__DOT__stage_n5_3 
            = (((- (IData)((verification_top__DOT__c7__DOT__stage_n5_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c7__DOT__stage_n5_2 
                  >> 8U));
    } else {
        verification_top__DOT__c11__DOT__stage_n6_3 
            = verification_top__DOT__c11__DOT__stage_n6_2;
        verification_top__DOT__c15__DOT__stage_n7_3 
            = verification_top__DOT__c15__DOT__stage_n7_2;
        verification_top__DOT__c7__DOT__stage_n5_3 
            = verification_top__DOT__c7__DOT__stage_n5_2;
    }
    verification_top__DOT__c9__DOT__stage_n6_3 = ((8U 
                                                   & ((IData)(5U) 
                                                      + vlSelfRef.in1))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c9__DOT__stage_n6_2 
                                                                >> 0x0000001fU))) 
                                                    << 0x00000018U) 
                                                   | (verification_top__DOT__c9__DOT__stage_n6_2 
                                                      >> 8U))
                                                   : verification_top__DOT__c9__DOT__stage_n6_2);
    verification_top__DOT__c3__DOT__stage_n4_3 = ((8U 
                                                   & ((IData)(5U) 
                                                      + vlSelfRef.in0))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c3__DOT__stage_n4_2 
                                                                >> 0x0000001fU))) 
                                                    << 0x00000018U) 
                                                   | (verification_top__DOT__c3__DOT__stage_n4_2 
                                                      >> 8U))
                                                   : verification_top__DOT__c3__DOT__stage_n4_2);
    if ((8U & vlSelfRef.in1)) {
        verification_top__DOT__c1__DOT__stage_n4_3 
            = (((- (IData)((verification_top__DOT__c1__DOT__stage_n4_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c1__DOT__stage_n4_2 
                  >> 8U));
        verification_top__DOT__c19__DOT__stage_n5_3 
            = (((- (IData)((verification_top__DOT__c19__DOT__stage_n5_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c19__DOT__stage_n5_2 
                  >> 8U));
        verification_top__DOT__c13__DOT__stage_n7_3 
            = (((- (IData)((verification_top__DOT__c13__DOT__stage_n7_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c13__DOT__stage_n7_2 
                  >> 8U));
        verification_top__DOT__c5__DOT__stage_n5_3 
            = (((- (IData)((verification_top__DOT__c5__DOT__stage_n5_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c5__DOT__stage_n5_2 
                  >> 8U));
    } else {
        verification_top__DOT__c1__DOT__stage_n4_3 
            = verification_top__DOT__c1__DOT__stage_n4_2;
        verification_top__DOT__c19__DOT__stage_n5_3 
            = verification_top__DOT__c19__DOT__stage_n5_2;
        verification_top__DOT__c13__DOT__stage_n7_3 
            = verification_top__DOT__c13__DOT__stage_n7_2;
        verification_top__DOT__c5__DOT__stage_n5_3 
            = verification_top__DOT__c5__DOT__stage_n5_2;
    }
    vlSelfRef.out_18 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((4U & vlSelfRef.in1)
                                             ? verification_top__DOT__c18__DOT__stage_n5_1
                                             : (((- (IData)(
                                                            (verification_top__DOT__c18__DOT__stage_n5_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c18__DOT__stage_n5_1 
                                                   >> 4U)))));
    vlSelfRef.out_22 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((4U & verification_top__DOT__c2__DOT__n6)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c22__DOT__stage_n4_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c22__DOT__stage_n4_1 
                                                   >> 4U))
                                             : verification_top__DOT__c22__DOT__stage_n4_1)));
    verification_top__DOT__c23__DOT__stage_n4_2 = (
                                                   (4U 
                                                    & verification_top__DOT__c2__DOT__n6)
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c22__DOT__stage_n4_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c22__DOT__stage_n4_1 
                                                       >> 4U))
                                                    : verification_top__DOT__c22__DOT__stage_n4_1);
    vlSelfRef.out_11 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in0 + ((0x00000010U 
                                             & vlSelfRef.in0)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c11__DOT__stage_n6_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c11__DOT__stage_n6_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c11__DOT__stage_n6_3)));
    vlSelfRef.out_9 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                       ^ (vlSelfRef.in1 + ((0x00000010U 
                                            & ((IData)(5U) 
                                               + vlSelfRef.in1))
                                            ? (((- (IData)(
                                                           (verification_top__DOT__c9__DOT__stage_n6_3 
                                                            >> 0x0000001fU))) 
                                                << 0x00000010U) 
                                               | (verification_top__DOT__c9__DOT__stage_n6_3 
                                                  >> 0x00000010U))
                                            : verification_top__DOT__c9__DOT__stage_n6_3)));
    vlSelfRef.out_3 = (verification_top__DOT__c2__DOT__n6 
                       ^ (vlSelfRef.in0 + ((0x00000010U 
                                            & ((IData)(5U) 
                                               + vlSelfRef.in0))
                                            ? (((- (IData)(
                                                           (verification_top__DOT__c3__DOT__stage_n4_3 
                                                            >> 0x0000001fU))) 
                                                << 0x00000010U) 
                                               | (verification_top__DOT__c3__DOT__stage_n4_3 
                                                  >> 0x00000010U))
                                            : verification_top__DOT__c3__DOT__stage_n4_3)));
    vlSelfRef.out_1 = (vlSelfRef.verification_top__DOT__c0__DOT__n6 
                       ^ (vlSelfRef.in1 + ((0x00000010U 
                                            & vlSelfRef.in1)
                                            ? (((- (IData)(
                                                           (verification_top__DOT__c1__DOT__stage_n4_3 
                                                            >> 0x0000001fU))) 
                                                << 0x00000010U) 
                                               | (verification_top__DOT__c1__DOT__stage_n4_3 
                                                  >> 0x00000010U))
                                            : verification_top__DOT__c1__DOT__stage_n4_3)));
    verification_top__DOT__c23__DOT__stage_n4_3 = (
                                                   (8U 
                                                    & verification_top__DOT__c2__DOT__n6)
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c23__DOT__stage_n4_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c23__DOT__stage_n4_2 
                                                       >> 8U))
                                                    : verification_top__DOT__c23__DOT__stage_n4_2);
    vlSelfRef.out_19 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x00000010U 
                                             & vlSelfRef.in1)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c19__DOT__stage_n5_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c19__DOT__stage_n5_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c19__DOT__stage_n5_3)));
    vlSelfRef.out_15 = (verification_top__DOT__c2__DOT__n6 
                        ^ (vlSelfRef.in1 + ((0x00000010U 
                                             & vlSelfRef.in0)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c15__DOT__stage_n7_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c15__DOT__stage_n7_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c15__DOT__stage_n7_3)));
    vlSelfRef.out_7 = (verification_top__DOT__c2__DOT__n6 
                       ^ (vlSelfRef.in1 + ((0x00000010U 
                                            & vlSelfRef.in0)
                                            ? (((- (IData)(
                                                           (verification_top__DOT__c7__DOT__stage_n5_3 
                                                            >> 0x0000001fU))) 
                                                << 0x00000010U) 
                                               | (verification_top__DOT__c7__DOT__stage_n5_3 
                                                  >> 0x00000010U))
                                            : verification_top__DOT__c7__DOT__stage_n5_3)));
    vlSelfRef.out_13 = ((verification_top__DOT__c2__DOT__n6 
                         + ((0x00000010U & vlSelfRef.in1)
                             ? (((- (IData)((verification_top__DOT__c13__DOT__stage_n7_3 
                                             >> 0x0000001fU))) 
                                 << 0x00000010U) | 
                                (verification_top__DOT__c13__DOT__stage_n7_3 
                                 >> 0x00000010U)) : verification_top__DOT__c13__DOT__stage_n7_3)) 
                        ^ verification_top__DOT__c4__DOT__n7);
    vlSelfRef.out_5 = ((vlSelfRef.in0 + ((0x00000010U 
                                          & vlSelfRef.in1)
                                          ? (((- (IData)(
                                                         (verification_top__DOT__c5__DOT__stage_n5_3 
                                                          >> 0x0000001fU))) 
                                              << 0x00000010U) 
                                             | (verification_top__DOT__c5__DOT__stage_n5_3 
                                                >> 0x00000010U))
                                          : verification_top__DOT__c5__DOT__stage_n5_3)) 
                       ^ verification_top__DOT__c4__DOT__n7);
    vlSelfRef.out_23 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((0x00000010U 
                                             & verification_top__DOT__c2__DOT__n6)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c23__DOT__stage_n4_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c23__DOT__stage_n4_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c23__DOT__stage_n4_3)));
}

VL_ATTR_COLD bool Vverification_top___024root___eval_phase__stl(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_phase__stl\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__stl
        vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                          & vlSelfRef.__VstlTriggered[0U]) 
                                         | (IData)((IData)(vlSelfRef.__VstlFirstIteration)));
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vverification_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vverification_top___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        {
            // Inlined CFunc: _eval_stl
            if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
                Vverification_top___024root___stl_sequent__TOP__0(vlSelf);
            }
        }
    }
    return (__VstlExecute);
}

bool Vverification_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (IData)(Vverification_top___024root___trigger_anySet__ico(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @( in0)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @( in1)\n");
    }
    if ((1U & (IData)(triggers[1U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 64 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vverification_top___024root___ctor_var_reset(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___ctor_var_reset\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->in0 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8091406170039428016ull);
    vlSelf->in1 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 15347402500067000120ull);
    vlSelf->out_0 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14999931525626829940ull);
    vlSelf->out_1 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 6957433418084696944ull);
    vlSelf->out_2 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 13158147396567980737ull);
    vlSelf->out_3 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17180532109900062040ull);
    vlSelf->out_4 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 15499468930870535485ull);
    vlSelf->out_5 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 13818405751840746258ull);
    vlSelf->out_6 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 3527040698140005751ull);
    vlSelf->out_7 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12410944435306891879ull);
    vlSelf->out_8 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 16433329148638991287ull);
    vlSelf->out_9 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2343069887417590846ull);
    vlSelf->out_10 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8960550563927050236ull);
    vlSelf->out_11 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10473700271020040127ull);
    vlSelf->out_12 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8926979852380361379ull);
    vlSelf->out_13 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17021235091846797638ull);
    vlSelf->out_14 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 18160135463446649663ull);
    vlSelf->out_15 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 5966456628850290546ull);
    vlSelf->out_16 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 1877621813541768183ull);
    vlSelf->out_17 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12304534007977534593ull);
    vlSelf->out_18 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17192217230413903243ull);
    vlSelf->out_19 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10972722702847355481ull);
    vlSelf->out_20 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 13933286199600656541ull);
    vlSelf->out_21 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2083920626321911616ull);
    vlSelf->out_22 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 4022420640369697151ull);
    vlSelf->out_23 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 7963255248836315059ull);
    vlSelf->out_24 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 11340809404433472656ull);
    vlSelf->out_25 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10939192264523977307ull);
    vlSelf->out_26 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 7939522081791136923ull);
    vlSelf->out_27 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 5623138094878909939ull);
    vlSelf->out_28 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9000692250476215376ull);
    vlSelf->out_29 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 1914742859836965189ull);
    vlSelf->out_30 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17618602537938313907ull);
    vlSelf->out_31 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 6942226766700291228ull);
    vlSelf->out_32 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14277639734141593598ull);
    vlSelf->out_33 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12515026450246560973ull);
    vlSelf->out_34 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17402709672682720308ull);
    vlSelf->out_35 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 15713673235437148532ull);
    vlSelf->out_36 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 5253190329454588828ull);
    vlSelf->out_37 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 718578882868244647ull);
    vlSelf->out_38 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 18389456481175282021ull);
    vlSelf->out_39 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8036967646932051395ull);
    vlSelf->out_40 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12568065000251404862ull);
    vlSelf->out_41 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 5061151175348882355ull);
    vlSelf->out_42 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 668855747368591769ull);
    vlSelf->out_43 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 11054915293158507517ull);
    vlSelf->out_44 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8060821358081729395ull);
    vlSelf->out_45 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 15945619155848642591ull);
    vlSelf->verification_top__DOT__c30__DOT__stage_n4_0 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 7020257697677756068ull);
    vlSelf->verification_top__DOT__c0__DOT__n6 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10399070365182063841ull);
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__VicoTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__in0__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__in1__0 = 0;
    vlSelf->__VicoDidInit = 0;
}
