// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcandidate.h for the primary calling header

#include "Vcandidate__pch.h"

bool Vcandidate___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcandidate___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((2U > n));
    return (0U);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vcandidate___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vcandidate___024root___eval_phase__ico(Vcandidate___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcandidate___024root___eval_phase__ico\n"); );
    Vcandidate__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__ico
        vlSelfRef.__VicoTriggered[0U] = (QData)((IData)(
                                                        (((vlSelfRef.in1 
                                                           != vlSelfRef.__Vtrigprevexpr___TOP__in1__0) 
                                                          << 1U) 
                                                         | (vlSelfRef.in0 
                                                            != vlSelfRef.__Vtrigprevexpr___TOP__in0__0))));
        vlSelfRef.__Vtrigprevexpr___TOP__in0__0 = vlSelfRef.in0;
        vlSelfRef.__Vtrigprevexpr___TOP__in1__0 = vlSelfRef.in1;
        if (VL_UNLIKELY(((1U & (~ (IData)(vlSelfRef.__VicoDidInit)))))) {
            vlSelfRef.__VicoDidInit = 1U;
            vlSelfRef.__VicoTriggered[0U] = (1ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (2ULL | vlSelfRef.__VicoTriggered[0U]);
        }
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vcandidate___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vcandidate___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_ico
            if ((3ULL & vlSelfRef.__VicoTriggered[0U])) {
                {
                    // Inlined CFunc: _ico_comb__TOP__0
                    vlSelfRef.result = ((vlSelfRef.in1 
                                         >> 1U) + (vlSelfRef.in0 
                                                   << 0x0000001fU));
                }
            }
        }
    }
    return (__VicoExecute);
}

void Vcandidate___024root___eval(Vcandidate___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcandidate___024root___eval\n"); );
    Vcandidate__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    // Body
    __VicoIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vcandidate___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-19/clo/agentic-riscv-codesign/generated/ascon-native-selector-2026-10-27-v5/measurements/candidate_04/attempt-000/candidate.v", 1, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 10000 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = Vcandidate___024root___eval_phase__ico(vlSelf);
    } while (vlSelfRef.__VicoPhaseResult);
}

#ifdef VL_DEBUG
void Vcandidate___024root___eval_debug_assertions(Vcandidate___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcandidate___024root___eval_debug_assertions\n"); );
    Vcandidate__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
