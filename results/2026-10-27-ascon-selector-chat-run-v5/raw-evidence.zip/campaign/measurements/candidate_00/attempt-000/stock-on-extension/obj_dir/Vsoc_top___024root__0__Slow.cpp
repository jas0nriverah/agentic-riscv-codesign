// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsoc_top.h for the primary calling header

#include "Vsoc_top__pch.h"

VL_ATTR_COLD void Vsoc_top___024root___eval_static(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___eval_static\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP__clk__0 = vlSelfRef.clk;
    vlSelfRef.__Vtrigprevexpr___TOP__resetn__0 = vlSelfRef.resetn;
    vlSelfRef.__Vtrigprevexpr___TOP__clk__1 = vlSelfRef.clk;
}

VL_ATTR_COLD void Vsoc_top___024root___eval_initial(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___eval_initial\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    {
        // Inlined CFunc: _eval_initial__TOP
        VL_READMEM_N(true, 32, 2048, 0, "/Users/jasonrivera/Documents/Codex/2026-10-19/clo/agentic-riscv-codesign/generated/ascon-native-selector-2026-10-27-v5/discovery/attempt-000/marked/firmware.hex"s
                     ,  &(vlSelfRef.soc_top__DOT__memory)
                     , 0, ~0ULL);
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[0U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[1U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[2U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[3U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[4U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[5U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[6U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[7U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[8U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[9U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[10U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[11U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[12U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[13U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[14U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[15U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[16U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[17U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[18U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[19U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[20U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[21U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[22U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[23U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[24U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[25U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[26U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[27U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[28U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[29U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[30U] = 0U;
        vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[31U] = 0U;
    }
}

VL_ATTR_COLD void Vsoc_top___024root___eval_final(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___eval_final\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsoc_top___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vsoc_top___024root___eval_phase__stl(Vsoc_top___024root* vlSelf);

VL_ATTR_COLD void Vsoc_top___024root___eval_settle(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___eval_settle\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VstlIterCount;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vsoc_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-19/clo/agentic-riscv-codesign/generated/ascon-native-selector-2026-10-27-v5/measurements/candidate_00/attempt-000/stock-on-extension/observer_top.v", 3, "", "DIDNOTCONVERGE: Settle region did not converge after '--converge-limit' of 10000 tries");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        vlSelfRef.__VstlPhaseResult = Vsoc_top___024root___eval_phase__stl(vlSelf);
        vlSelfRef.__VstlFirstIteration = 0U;
    } while (vlSelfRef.__VstlPhaseResult);
}

VL_ATTR_COLD bool Vsoc_top___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsoc_top___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(Vsoc_top___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vsoc_top___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vsoc_top___024root___stl_sequent__TOP__0(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___stl_sequent__TOP__0\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ soc_top__DOT__cpu__DOT__alu_eq;
    soc_top__DOT__cpu__DOT__alu_eq = 0;
    CData/*0:0*/ soc_top__DOT__cpu__DOT__alu_ltu;
    soc_top__DOT__cpu__DOT__alu_ltu = 0;
    CData/*0:0*/ soc_top__DOT__cpu__DOT__alu_lts;
    soc_top__DOT__cpu__DOT__alu_lts = 0;
    CData/*0:0*/ __VdfgRegularize_hebeb780c_0_1;
    __VdfgRegularize_hebeb780c_0_1 = 0;
    // Body
    vlSelfRef.report_strobe = (0U != (IData)(vlSelfRef.soc_top__DOT__report_remaining));
    vlSelfRef.report_bit = (1U & vlSelfRef.soc_top__DOT__report_shift);
    vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_rs1 = 
        (vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[vlSelfRef.soc_top__DOT__cpu__DOT__decoded_rs1] 
         & (- (IData)((0U != (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__decoded_rs1)))));
    vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_rs2 = 
        (vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs[vlSelfRef.soc_top__DOT__cpu__DOT__decoded_rs2] 
         & (- (IData)((0U != (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__decoded_rs2)))));
    vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_write = 0U;
    vlSelfRef.soc_top__DOT__request = ((IData)(vlSelfRef.resetn) 
                                       & ((~ (IData)(vlSelfRef.soc_top__DOT__mem_ready)) 
                                          & (IData)(vlSelfRef.soc_top__DOT__mem_valid)));
    vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_wrdata = 0U;
    if ((0x40U == (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__cpu_state))) {
        if (vlSelfRef.soc_top__DOT__cpu__DOT__latched_branch) {
            vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_write = 1U;
            vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_wrdata 
                = (vlSelfRef.soc_top__DOT__cpu__DOT__reg_pc 
                   + ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__latched_compr)
                       ? 2U : 4U));
        } else if (((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__latched_store) 
                    & (~ (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__latched_branch)))) {
            vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_write = 1U;
            vlSelfRef.soc_top__DOT__cpu__DOT__cpuregs_wrdata 
                = ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__latched_stalu)
                    ? vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_q
                    : vlSelfRef.soc_top__DOT__cpu__DOT__reg_out);
        }
    }
    __VdfgRegularize_hebeb780c_0_1 = ((~ (0U != (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_state))) 
                                      & (IData)(vlSelfRef.resetn));
    vlSelfRef.soc_top__DOT__mem_rdata = (vlSelfRef.soc_top__DOT__ram_rdata 
                                         & (- (IData)(
                                                      (0x00002000U 
                                                       > vlSelfRef.soc_top__DOT__mem_addr))));
    if ((0U == (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_wordsize))) {
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wstrb = 0x0fU;
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wdata 
            = vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2;
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_rdata_word 
            = vlSelfRef.soc_top__DOT__mem_rdata;
    } else if ((1U == (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_wordsize))) {
        if ((2U & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1)) {
            vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wstrb = 0x0cU;
            vlSelfRef.soc_top__DOT__cpu__DOT__mem_rdata_word 
                = (vlSelfRef.soc_top__DOT__mem_rdata 
                   >> 0x10U);
        } else {
            vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wstrb = 3U;
            vlSelfRef.soc_top__DOT__cpu__DOT__mem_rdata_word 
                = (0x0000ffffU & vlSelfRef.soc_top__DOT__mem_rdata);
        }
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wdata 
            = ((vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2 
                << 0x00000010U) | (0x0000ffffU & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2));
    } else if ((2U == (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_wordsize))) {
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wstrb 
            = (0x0000000fU & ((IData)(1U) << (3U & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1)));
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_wdata 
            = ((vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2 
                << 0x00000018U) | ((0x00ff0000U & (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2 
                                                   << 0x00000010U)) 
                                   | ((0x0000ff00U 
                                       & (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2 
                                          << 8U)) | 
                                      (0x000000ffU 
                                       & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2))));
        vlSelfRef.soc_top__DOT__cpu__DOT__mem_rdata_word 
            = ((2U & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1)
                ? ((1U & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1)
                    ? (vlSelfRef.soc_top__DOT__mem_rdata 
                       >> 0x18U) : (0x000000ffU & (vlSelfRef.soc_top__DOT__mem_rdata 
                                                   >> 0x10U)))
                : ((1U & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1)
                    ? (0x000000ffU & (vlSelfRef.soc_top__DOT__mem_rdata 
                                      >> 8U)) : (0x000000ffU 
                                                 & vlSelfRef.soc_top__DOT__mem_rdata)));
    }
    vlSelfRef.soc_top__DOT__cpu__DOT__mem_xfer = ((IData)(vlSelfRef.soc_top__DOT__mem_valid) 
                                                  & (IData)(vlSelfRef.soc_top__DOT__mem_ready));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_0 = ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_do_rinst) 
                                                | (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_do_rdata));
    vlSelfRef.soc_top__DOT__genblk1__DOT__extension__DOT__recognized 
        = ((IData)(vlSelfRef.soc_top__DOT__pcpi_valid) 
           & (0x0200000bU == (0xfe00707fU & vlSelfRef.soc_top__DOT__pcpi_insn)));
    soc_top__DOT__cpu__DOT__alu_eq = (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
                                      == vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2);
    soc_top__DOT__cpu__DOT__alu_lts = VL_LTS_III(32, vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1, vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2);
    soc_top__DOT__cpu__DOT__alu_ltu = (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
                                       < vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2);
    vlSelfRef.soc_top__DOT__cpu__DOT__is_rdcycle_rdcycleh_rdinstr_rdinstrh 
        = ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_rdcycle) 
           | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_rdcycleh) 
              | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_rdinstr) 
                 | (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_rdinstrh))));
    vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_write 
        = ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_do_wdata) 
           & (IData)(__VdfgRegularize_hebeb780c_0_1));
    vlSelfRef.soc_top__DOT__cpu__DOT__mem_rdata_latched_noshuffle 
        = ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_xfer)
            ? vlSelfRef.soc_top__DOT__mem_rdata : vlSelfRef.soc_top__DOT__cpu__DOT__mem_rdata_q);
    vlSelfRef.soc_top__DOT__cpu__DOT__mem_la_read = 
        (((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_do_prefetch) 
          | (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_0)) 
         & (IData)(__VdfgRegularize_hebeb780c_0_1));
    vlSelfRef.soc_top__DOT__cpu__DOT__mem_done = ((IData)(vlSelfRef.resetn) 
                                                  & (((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_do_rinst) 
                                                      & (3U 
                                                         == (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_state))) 
                                                     | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_xfer) 
                                                        & ((0U 
                                                            != (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_state)) 
                                                           & ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__mem_do_wdata) 
                                                              | (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_0))))));
    vlSelfRef.soc_top__DOT__pcpi_ready = ((IData)(vlSelfRef.soc_top__DOT__genblk1__DOT__extension__DOT__active) 
                                          & (IData)(vlSelfRef.soc_top__DOT__genblk1__DOT__extension__DOT__recognized));
    vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 = 0U;
    if (vlSelfRef.soc_top__DOT__cpu__DOT__instr_beq) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 
            = soc_top__DOT__cpu__DOT__alu_eq;
    } else if (vlSelfRef.soc_top__DOT__cpu__DOT__instr_bne) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 
            = (1U & (~ (IData)(soc_top__DOT__cpu__DOT__alu_eq)));
    } else if (vlSelfRef.soc_top__DOT__cpu__DOT__instr_bge) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 
            = (1U & (~ (IData)(soc_top__DOT__cpu__DOT__alu_lts)));
    } else if (vlSelfRef.soc_top__DOT__cpu__DOT__instr_bgeu) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 
            = (1U & (~ (IData)(soc_top__DOT__cpu__DOT__alu_ltu)));
    } else if (vlSelfRef.soc_top__DOT__cpu__DOT__is_slti_blt_slt) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 
            = soc_top__DOT__cpu__DOT__alu_lts;
    } else if (vlSelfRef.soc_top__DOT__cpu__DOT__is_sltiu_bltu_sltu) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0 
            = soc_top__DOT__cpu__DOT__alu_ltu;
    }
    vlSelfRef.soc_top__DOT__cpu__DOT__alu_out = 0U;
    if (vlSelfRef.soc_top__DOT__cpu__DOT__is_lui_auipc_jal_jalr_addi_add_sub) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out = 
            ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sub)
              ? (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
                 - vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2)
              : (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
                 + vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2));
    } else if (vlSelfRef.soc_top__DOT__cpu__DOT__is_compare) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out = vlSelfRef.soc_top__DOT__cpu__DOT__alu_out_0;
    } else if (((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_xori) 
                | (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_xor))) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out = 
            (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
             ^ vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2);
    } else if (((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_ori) 
                | (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_or))) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out = 
            (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
             | vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2);
    } else if (((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_andi) 
                | (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_and))) {
        vlSelfRef.soc_top__DOT__cpu__DOT__alu_out = 
            (vlSelfRef.soc_top__DOT__cpu__DOT__reg_op1 
             & vlSelfRef.soc_top__DOT__cpu__DOT__reg_op2);
    }
    vlSelfRef.soc_top__DOT__cpu__DOT__instr_trap = 
        (1U & (~ ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_lui) 
                  | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_auipc) 
                     | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_jal) 
                        | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_jalr) 
                           | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_beq) 
                              | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_bne) 
                                 | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_blt) 
                                    | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_bge) 
                                       | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_bltu) 
                                          | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_bgeu) 
                                             | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_lb) 
                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_lh) 
                                                   | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_lw) 
                                                      | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_lbu) 
                                                         | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_lhu) 
                                                            | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sb) 
                                                               | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sh) 
                                                                  | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sw) 
                                                                     | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_addi) 
                                                                        | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_slti) 
                                                                           | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sltiu) 
                                                                              | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_xori) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_ori) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_andi) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_slli) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_srli) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_srai) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_add) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sub) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sll) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_slt) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sltu) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_xor) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_srl) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_sra) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_or) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_and) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__is_rdcycle_rdcycleh_rdinstr_rdinstrh) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_fence) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_getq) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_setq) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_retirq) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_maskirq) 
                                                                                | ((IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_waitirq) 
                                                                                | (IData)(vlSelfRef.soc_top__DOT__cpu__DOT__instr_timer)))))))))))))))))))))))))))))))))))))))))))))));
    vlSelfRef.soc_top__DOT__pcpi_wait = ((~ (IData)(vlSelfRef.soc_top__DOT__pcpi_ready)) 
                                         & (IData)(vlSelfRef.soc_top__DOT__genblk1__DOT__extension__DOT__recognized));
    vlSelfRef.soc_top__DOT__cpu__DOT__pcpi_int_rd = 
        (vlSelfRef.soc_top__DOT__genblk1__DOT__extension__DOT__result 
         & (- (IData)((IData)(vlSelfRef.soc_top__DOT__pcpi_ready))));
}

VL_ATTR_COLD bool Vsoc_top___024root___eval_phase__stl(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___eval_phase__stl\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__stl
        vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                          & vlSelfRef.__VstlTriggered[0U]) 
                                         | (IData)((IData)(vlSelfRef.__VstlFirstIteration)));
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vsoc_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vsoc_top___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        {
            // Inlined CFunc: _eval_stl
            if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
                Vsoc_top___024root___stl_sequent__TOP__0(vlSelf);
            }
        }
    }
    return (__VstlExecute);
}

bool Vsoc_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsoc_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (IData)(Vsoc_top___024root___trigger_anySet__ico(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @( clk)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @( resetn)\n");
    }
    if ((1U & (IData)(triggers[1U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 64 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

bool Vsoc_top___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsoc_top___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(Vsoc_top___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge clk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vsoc_top___024root___ctor_var_reset(Vsoc_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsoc_top___024root___ctor_var_reset\n"); );
    Vsoc_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->clk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16707436170211756652ull);
    vlSelf->resetn = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8624841754543469506ull);
    vlSelf->trap = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18214934560881419504ull);
    vlSelf->done = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10296494685231209730ull);
    vlSelf->passed = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6876347940184475809ull);
    vlSelf->fault = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1992564187912778249ull);
    vlSelf->report_strobe = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11573775961505424404ull);
    vlSelf->report_bit = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3461448353085712315ull);
    vlSelf->soc_top__DOT__mem_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1914363070178644839ull);
    vlSelf->soc_top__DOT__mem_addr = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 402160349241106559ull);
    vlSelf->soc_top__DOT__mem_wdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9052019043540986556ull);
    vlSelf->soc_top__DOT__mem_wstrb = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 14323812297734284693ull);
    vlSelf->soc_top__DOT__mem_ready = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3584662510316712269ull);
    vlSelf->soc_top__DOT__mem_rdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8037683253241137959ull);
    vlSelf->soc_top__DOT__pcpi_valid = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16098038599675082897ull);
    vlSelf->soc_top__DOT__pcpi_ready = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15057797004047005417ull);
    vlSelf->soc_top__DOT__pcpi_wait = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16967254927072271504ull);
    vlSelf->soc_top__DOT__pcpi_insn = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12568430159996528674ull);
    for (int __Vi0 = 0; __Vi0 < 2048; ++__Vi0) {
        vlSelf->soc_top__DOT__memory[__Vi0] = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14503010094547972069ull);
    }
    vlSelf->soc_top__DOT__ram_rdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17225098428525558701ull);
    vlSelf->soc_top__DOT__request = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11192977294714395737ull);
    vlSelf->soc_top__DOT__report_shift = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14743011058201611615ull);
    vlSelf->soc_top__DOT__report_remaining = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 5911268034837438054ull);
    vlSelf->soc_top__DOT__genblk1__DOT__extension__DOT__recognized = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9441647235011707480ull);
    vlSelf->soc_top__DOT__genblk1__DOT__extension__DOT__active = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16454250882225636106ull);
    vlSelf->soc_top__DOT__genblk1__DOT__extension__DOT__result = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 4039549480810056952ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_la_read = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15515703913440157284ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_la_write = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2150282339782268592ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_la_wdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 1077519497307168601ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_la_wstrb = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 3383524088313565720ull);
    vlSelf->soc_top__DOT__cpu__DOT__count_cycle = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 6339120327472451108ull);
    vlSelf->soc_top__DOT__cpu__DOT__count_instr = VL_SCOPED_RAND_RESET_Q(64, __VscopeHash, 5356222810119662905ull);
    vlSelf->soc_top__DOT__cpu__DOT__reg_pc = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14245529096271108516ull);
    vlSelf->soc_top__DOT__cpu__DOT__reg_next_pc = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12031433105162702531ull);
    vlSelf->soc_top__DOT__cpu__DOT__reg_op1 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12695907250281018796ull);
    vlSelf->soc_top__DOT__cpu__DOT__reg_op2 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 6784521860568016359ull);
    vlSelf->soc_top__DOT__cpu__DOT__reg_out = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10018986010857807034ull);
    vlSelf->soc_top__DOT__cpu__DOT__reg_sh = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 245433577523180215ull);
    vlSelf->soc_top__DOT__cpu__DOT__timer = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14776134144262670423ull);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->soc_top__DOT__cpu__DOT__cpuregs[__Vi0] = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9426389682786911367ull);
    }
    vlSelf->soc_top__DOT__cpu__DOT__pcpi_int_rd = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 641668691585993004ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_state = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 13644001615326198262ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_wordsize = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 15956756032242152226ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_rdata_word = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8728779392755633256ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_rdata_q = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 11453526240727236261ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_do_prefetch = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13962858137249479896ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_do_rinst = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6954966044890255330ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_do_rdata = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1491792652511521712ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_do_wdata = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11949583626186840187ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_xfer = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18020375289757882809ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_rdata_latched_noshuffle = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 6948074287119110926ull);
    vlSelf->soc_top__DOT__cpu__DOT__mem_done = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5932345592668112155ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_lui = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11347969212342468722ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_auipc = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15567058619215204095ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_jal = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4456485101477330692ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_jalr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9991191226309878563ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_beq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12884522860298631206ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_bne = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14329777573057794180ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_blt = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13046019363497714619ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_bge = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10143760089886908463ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_bltu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13846386257356125466ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_bgeu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13490092235372879882ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_lb = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11399076057855566506ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_lh = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16771891535863236691ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_lw = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2299829371132442304ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_lbu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 406102706101889727ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_lhu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14115506733618182685ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sb = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10566732127928408592ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sh = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 736725889530562439ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sw = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17229555618312075154ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_addi = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15508046708729248434ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_slti = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 709403342113089075ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sltiu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17941055015120183268ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_xori = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13363833557690178536ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_ori = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1263342011146756250ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_andi = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10003211110484887281ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_slli = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3974430504565309599ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_srli = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13273823853822290160ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_srai = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11692970498372887931ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_add = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13416291301462318124ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sub = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5030316969430453075ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sll = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5467114161012725165ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_slt = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1795062754003224870ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sltu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14353487105635273767ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_xor = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17505455059292413324ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_srl = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17756129838723311279ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_sra = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16372243285059692169ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_or = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1259024595232788246ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_and = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1274860312908272472ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_rdcycle = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12933191315449732637ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_rdcycleh = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6779070663607075825ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_rdinstr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6841776901382085376ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_rdinstrh = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11558052404427874043ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_ecall_ebreak = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13360981826220102427ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_fence = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18035549205869489606ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_getq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9999199982193795254ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_setq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5982204139436059398ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_retirq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16053480312972307084ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_maskirq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4882266102609604408ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_waitirq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5711024595686515743ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_timer = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6844209240683477012ull);
    vlSelf->soc_top__DOT__cpu__DOT__instr_trap = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12891091700482610621ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoded_rd = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 9354947443000909946ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoded_rs1 = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 14838700569559952169ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoded_rs2 = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 4150447207648550422ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoded_imm = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2412882265023948879ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoded_imm_j = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2588376606978104736ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoder_trigger = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6040830618959215290ull);
    vlSelf->soc_top__DOT__cpu__DOT__decoder_pseudo_trigger = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16048097431189479187ull);
    vlSelf->soc_top__DOT__cpu__DOT__compressed_instr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12109306536474491470ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_lui_auipc_jal = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14488855509057206811ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_lb_lh_lw_lbu_lhu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16934783834390609897ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_slli_srli_srai = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 59886016128657005ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_jalr_addi_slti_sltiu_xori_ori_andi = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16214619792058010404ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_sb_sh_sw = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14524642100092919625ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_sll_srl_sra = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5563861440104314822ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_lui_auipc_jal_jalr_addi_add_sub = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7362782962504223283ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_slti_blt_slt = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2700761788616358837ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_sltiu_bltu_sltu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1744393102819195815ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_beq_bne_blt_bge_bltu_bgeu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13787010310708617214ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_lbu_lhu_lw = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7663562337897753938ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_alu_reg_imm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18311423022990147248ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_alu_reg_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6927763564196218625ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_compare = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7091173380409985667ull);
    vlSelf->soc_top__DOT__cpu__DOT__is_rdcycle_rdcycleh_rdinstr_rdinstrh = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6520831620234706726ull);
    vlSelf->soc_top__DOT__cpu__DOT__cpu_state = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 5806784081866965735ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_store = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 536029399115501787ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_stalu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3847573979846554242ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_branch = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16566011762675443728ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_compr = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5761794460015064075ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_is_lu = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9717019114937552758ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_is_lh = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4553124630833615924ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_is_lb = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9525031409274831129ull);
    vlSelf->soc_top__DOT__cpu__DOT__latched_rd = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 4813483197162996603ull);
    vlSelf->soc_top__DOT__cpu__DOT__current_pc = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 4415090203141969669ull);
    vlSelf->soc_top__DOT__cpu__DOT__pcpi_timeout_counter = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 5266093288669576258ull);
    vlSelf->soc_top__DOT__cpu__DOT__pcpi_timeout = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3038399311191958037ull);
    vlSelf->soc_top__DOT__cpu__DOT__do_waitirq = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8934975815388156200ull);
    vlSelf->soc_top__DOT__cpu__DOT__alu_out = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17788248579756354022ull);
    vlSelf->soc_top__DOT__cpu__DOT__alu_out_q = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17742544385434060071ull);
    vlSelf->soc_top__DOT__cpu__DOT__alu_out_0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14523643482187354567ull);
    vlSelf->soc_top__DOT__cpu__DOT__cpuregs_write = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13639996400823888473ull);
    vlSelf->soc_top__DOT__cpu__DOT__cpuregs_wrdata = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2676248074843980580ull);
    vlSelf->soc_top__DOT__cpu__DOT__cpuregs_rs1 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10448860471842390534ull);
    vlSelf->soc_top__DOT__cpu__DOT__cpuregs_rs2 = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 1374678678462199068ull);
    vlSelf->__VdfgRegularize_hebeb780c_0_0 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__VicoTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__resetn__0 = 0;
    vlSelf->__VicoDidInit = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__clk__1 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
}
