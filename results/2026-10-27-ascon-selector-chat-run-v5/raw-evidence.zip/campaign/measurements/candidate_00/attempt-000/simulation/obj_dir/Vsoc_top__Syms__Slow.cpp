// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vsoc_top__pch.h"

Vsoc_top__Syms::Vsoc_top__Syms(VerilatedContext* contextp, const char* namep, Vsoc_top* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    // Setup top module instance
    , TOP{this, namep}
{
    // Check resources
    Verilated::stackCheck(438);
    // Setup sub module instances
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-9);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
    // Setup scopes
    __Vscopep_soc_top = new VerilatedScope{this, "soc_top", "soc_top", "<null>", 0, VerilatedScope::SCOPE_OTHER};
    __Vscopep_soc_top__cpu = new VerilatedScope{this, "soc_top.cpu", "cpu", "<null>", 0, VerilatedScope::SCOPE_OTHER};
    // Setup export functions - final: 0
    // Setup export functions - final: 1
    // Setup public variables
    __Vscopep_soc_top->varInsert("mem_addr", &(TOP.soc_top__DOT__mem_addr), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RD|VLVF_NET, 0, 1 ,31,0);
    __Vscopep_soc_top->varInsert("mem_ready", &(TOP.soc_top__DOT__mem_ready), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RD, 0, 0);
    __Vscopep_soc_top->varInsert("mem_valid", &(TOP.soc_top__DOT__mem_valid), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RD|VLVF_NET, 0, 0);
    __Vscopep_soc_top->varInsert("mem_wstrb", &(TOP.soc_top__DOT__mem_wstrb), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RD|VLVF_NET, 0, 1 ,3,0);
    __Vscopep_soc_top->varInsert("pcpi_ready", &(TOP.soc_top__DOT__pcpi_ready), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RD|VLVF_CONTINUOUSLY|VLVF_NET, 0, 0);
    __Vscopep_soc_top->varInsert("pcpi_valid", &(TOP.soc_top__DOT__pcpi_valid), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RD|VLVF_NET, 0, 0);
    __Vscopep_soc_top->varInsert("pcpi_wait", &(TOP.soc_top__DOT__pcpi_wait), false, VLVT_UINT8, VLVD_NODIR|VLVF_PUB_RD|VLVF_CONTINUOUSLY|VLVF_NET, 0, 0);
    __Vscopep_soc_top__cpu->varInsert("count_instr", &(TOP.soc_top__DOT__cpu__DOT__count_instr), false, VLVT_UINT64, VLVD_NODIR|VLVF_PUB_RD, 0, 1 ,63,0);
    __Vscopep_soc_top__cpu->varInsert("cpuregs", &(TOP.soc_top__DOT__cpu__DOT__cpuregs), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RD, 1, 1 ,0,31 ,31,0);
    __Vscopep_soc_top__cpu->varInsert("reg_pc", &(TOP.soc_top__DOT__cpu__DOT__reg_pc), false, VLVT_UINT32, VLVD_NODIR|VLVF_PUB_RD, 0, 1 ,31,0);
}

Vsoc_top__Syms::~Vsoc_top__Syms() {
    // Tear down scopes
    VL_DO_CLEAR(delete __Vscopep_soc_top, __Vscopep_soc_top = nullptr);
    VL_DO_CLEAR(delete __Vscopep_soc_top__cpu, __Vscopep_soc_top__cpu = nullptr);
    // Tear down sub module instances
}
