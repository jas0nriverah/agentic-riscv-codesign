// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vsoc_top.h for the primary calling header

#ifndef VERILATED_VSOC_TOP___024ROOT_H_
#define VERILATED_VSOC_TOP___024ROOT_H_  // guard

#include "verilated.h"


class Vsoc_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vsoc_top___024root final {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(resetn,0,0);
        VL_OUT8(trap,0,0);
        VL_OUT8(done,0,0);
        VL_OUT8(passed,0,0);
        VL_OUT8(fault,0,0);
        VL_OUT8(report_strobe,0,0);
        VL_OUT8(report_bit,0,0);
        CData/*0:0*/ soc_top__DOT__mem_valid;
        CData/*3:0*/ soc_top__DOT__mem_wstrb;
        CData/*0:0*/ soc_top__DOT__mem_ready;
        CData/*0:0*/ soc_top__DOT__pcpi_valid;
        CData/*0:0*/ soc_top__DOT__pcpi_ready;
        CData/*0:0*/ soc_top__DOT__pcpi_wait;
        CData/*0:0*/ soc_top__DOT__request;
        CData/*5:0*/ soc_top__DOT__report_remaining;
        CData/*0:0*/ soc_top__DOT__genblk1__DOT__extension__DOT__recognized;
        CData/*0:0*/ soc_top__DOT__genblk1__DOT__extension__DOT__active;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_la_read;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_la_write;
        CData/*3:0*/ soc_top__DOT__cpu__DOT__mem_la_wstrb;
        CData/*4:0*/ soc_top__DOT__cpu__DOT__reg_sh;
        CData/*1:0*/ soc_top__DOT__cpu__DOT__mem_state;
        CData/*1:0*/ soc_top__DOT__cpu__DOT__mem_wordsize;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_do_prefetch;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_do_rinst;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_do_rdata;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_do_wdata;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_xfer;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__mem_done;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_lui;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_auipc;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_jal;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_jalr;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_beq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_bne;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_blt;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_bge;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_bltu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_bgeu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_lb;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_lh;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_lw;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_lbu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_lhu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sb;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sh;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sw;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_addi;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_slti;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sltiu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_xori;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_ori;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_andi;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_slli;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_srli;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_srai;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_add;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sub;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sll;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_slt;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sltu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_xor;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_srl;
    };
    struct {
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_sra;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_or;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_and;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_rdcycle;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_rdcycleh;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_rdinstr;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_rdinstrh;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_ecall_ebreak;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_fence;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_getq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_setq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_retirq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_maskirq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_waitirq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_timer;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__instr_trap;
        CData/*4:0*/ soc_top__DOT__cpu__DOT__decoded_rd;
        CData/*4:0*/ soc_top__DOT__cpu__DOT__decoded_rs1;
        CData/*4:0*/ soc_top__DOT__cpu__DOT__decoded_rs2;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__decoder_trigger;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__decoder_pseudo_trigger;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__compressed_instr;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_lui_auipc_jal;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_lb_lh_lw_lbu_lhu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_slli_srli_srai;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_jalr_addi_slti_sltiu_xori_ori_andi;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_sb_sh_sw;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_sll_srl_sra;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_lui_auipc_jal_jalr_addi_add_sub;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_slti_blt_slt;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_sltiu_bltu_sltu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_beq_bne_blt_bge_bltu_bgeu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_lbu_lhu_lw;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_alu_reg_imm;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_alu_reg_reg;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_compare;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__is_rdcycle_rdcycleh_rdinstr_rdinstrh;
        CData/*7:0*/ soc_top__DOT__cpu__DOT__cpu_state;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_store;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_stalu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_branch;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_compr;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_is_lu;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_is_lh;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__latched_is_lb;
        CData/*4:0*/ soc_top__DOT__cpu__DOT__latched_rd;
        CData/*3:0*/ soc_top__DOT__cpu__DOT__pcpi_timeout_counter;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__pcpi_timeout;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__do_waitirq;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__alu_out_0;
        CData/*0:0*/ soc_top__DOT__cpu__DOT__cpuregs_write;
        CData/*0:0*/ __VdfgRegularize_hebeb780c_0_0;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VstlPhaseResult;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clk__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__resetn__0;
        CData/*0:0*/ __VicoDidInit;
        CData/*0:0*/ __VicoPhaseResult;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clk__1;
        CData/*0:0*/ __VactPhaseResult;
        CData/*0:0*/ __VnbaPhaseResult;
        IData/*31:0*/ soc_top__DOT__mem_addr;
        IData/*31:0*/ soc_top__DOT__mem_wdata;
        IData/*31:0*/ soc_top__DOT__mem_rdata;
    };
    struct {
        IData/*31:0*/ soc_top__DOT__pcpi_insn;
        IData/*31:0*/ soc_top__DOT__ram_rdata;
        IData/*31:0*/ soc_top__DOT__report_shift;
        IData/*31:0*/ soc_top__DOT__genblk1__DOT__extension__DOT__result;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__mem_la_wdata;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__reg_pc;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__reg_next_pc;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__reg_op1;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__reg_op2;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__reg_out;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__timer;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__pcpi_int_rd;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__mem_rdata_word;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__mem_rdata_q;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__mem_rdata_latched_noshuffle;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__decoded_imm;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__decoded_imm_j;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__current_pc;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__alu_out;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__alu_out_q;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__cpuregs_wrdata;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__cpuregs_rs1;
        IData/*31:0*/ soc_top__DOT__cpu__DOT__cpuregs_rs2;
        IData/*31:0*/ __VactIterCount;
        QData/*63:0*/ soc_top__DOT__cpu__DOT__count_cycle;
        QData/*63:0*/ soc_top__DOT__cpu__DOT__count_instr;
        VlUnpacked<IData/*31:0*/, 2048> soc_top__DOT__memory;
        VlUnpacked<IData/*31:0*/, 32> soc_top__DOT__cpu__DOT__cpuregs;
        VlUnpacked<QData/*63:0*/, 1> __VstlTriggered;
        VlUnpacked<QData/*63:0*/, 2> __VicoTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VactTriggered;
        VlUnpacked<QData/*63:0*/, 1> __VnbaTriggered;
    };

    // INTERNAL VARIABLES
    Vsoc_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vsoc_top___024root(Vsoc_top__Syms* symsp, const char* namep);
    ~Vsoc_top___024root();
    VL_UNCOPYABLE(Vsoc_top___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
