checked_sim.o: \
  /Users/jasonrivera/Documents/Codex/2026-10-19/clo/agentic-riscv-codesign/generated/ascon-native-selector-2026-10-27-v5/inputs/checked_sim.cpp \
  Vsoc_top.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_config.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilatedos.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_types.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_funcs.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/vltstd/svdpi.h \
  Vsoc_top___024root.h \
  /Users/jasonrivera/Documents/Codex/2026-10-19/clo/agentic-riscv-codesign/generated/ascon-native-selector-2026-10-27-v5/inputs/stack_monitor.hpp
