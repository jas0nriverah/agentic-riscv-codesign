Vsoc_top__ALL.o: Vsoc_top__ALL.cpp Vsoc_top.cpp Vsoc_top__pch.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_config.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilatedos.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_types.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_funcs.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_dpi.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_sym_props.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/vltstd/svdpi.h \
  Vsoc_top__Syms.h Vsoc_top.h Vsoc_top___024root.h \
  Vsoc_top___024root__0.cpp Vsoc_top__Dpi.cpp Vsoc_top__Dpi.h \
  Vsoc_top___024root__Slow.cpp Vsoc_top___024root__0__Slow.cpp \
  Vsoc_top__Syms__Slow.cpp
