// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vcandidate__pch.h"

//============================================================
// Constructors

Vcandidate::Vcandidate(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vcandidate__Syms(contextp(), _vcname__, this)}
    , in0{vlSymsp->TOP.in0}
    , in1{vlSymsp->TOP.in1}
    , result{vlSymsp->TOP.result}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vcandidate::Vcandidate(const char* _vcname__)
    : Vcandidate(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vcandidate::~Vcandidate() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vcandidate___024root___eval_debug_assertions(Vcandidate___024root* vlSelf);
#endif  // VL_DEBUG
void Vcandidate___024root___eval_static(Vcandidate___024root* vlSelf);
void Vcandidate___024root___eval_initial(Vcandidate___024root* vlSelf);
void Vcandidate___024root___eval_settle(Vcandidate___024root* vlSelf);
void Vcandidate___024root___eval(Vcandidate___024root* vlSelf);

void Vcandidate::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vcandidate::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vcandidate___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vcandidate___024root___eval_static(&(vlSymsp->TOP));
        Vcandidate___024root___eval_initial(&(vlSymsp->TOP));
        Vcandidate___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vcandidate___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vcandidate::eventsPending() { return false; }

uint64_t Vcandidate::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vcandidate::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vcandidate___024root___eval_final(Vcandidate___024root* vlSelf);

VL_ATTR_COLD void Vcandidate::final() {
    contextp()->executingFinal(true);
    Vcandidate___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vcandidate::hierName() const { return vlSymsp->name(); }
const char* Vcandidate::modelName() const { return "Vcandidate"; }
unsigned Vcandidate::threads() const { return 1; }
void Vcandidate::prepareClone() const { contextp()->prepareClone(); }
void Vcandidate::atClone() const {
    contextp()->threadPoolpOnClone();
}
