// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcandidate.h for the primary calling header

#include "Vcandidate__pch.h"

void Vcandidate___024root___ctor_var_reset(Vcandidate___024root* vlSelf);

Vcandidate___024root::Vcandidate___024root(Vcandidate__Syms* symsp, const char* namep)
 {
    vlSymsp = symsp;
    vlNamep = strdup(namep);
    // Reset structure values
    Vcandidate___024root___ctor_var_reset(this);
}

void Vcandidate___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

Vcandidate___024root::~Vcandidate___024root() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}
