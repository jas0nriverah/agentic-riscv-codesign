// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VCANDIDATE__SYMS_H_
#define VERILATED_VCANDIDATE__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vcandidate.h"

// INCLUDE MODULE CLASSES
#include "Vcandidate___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) Vcandidate__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vcandidate* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vcandidate___024root           TOP;

    // CONSTRUCTORS
    Vcandidate__Syms(VerilatedContext* contextp, const char* namep, Vcandidate* modelp);
    ~Vcandidate__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard
