// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vcandidate.h for the primary calling header

#ifndef VERILATED_VCANDIDATE___024ROOT_H_
#define VERILATED_VCANDIDATE___024ROOT_H_  // guard

#include "verilated.h"


class Vcandidate__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vcandidate___024root final {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __VstlPhaseResult;
    CData/*0:0*/ __VicoDidInit;
    CData/*0:0*/ __VicoPhaseResult;
    VL_IN(in0,31,0);
    VL_IN(in1,31,0);
    VL_OUT(result,31,0);
    IData/*31:0*/ __Vtrigprevexpr___TOP__in0__0;
    IData/*31:0*/ __Vtrigprevexpr___TOP__in1__0;
    VlUnpacked<QData/*63:0*/, 1> __VstlTriggered;
    VlUnpacked<QData/*63:0*/, 2> __VicoTriggered;

    // INTERNAL VARIABLES
    Vcandidate__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vcandidate___024root(Vcandidate__Syms* symsp, const char* namep);
    ~Vcandidate___024root();
    VL_UNCOPYABLE(Vcandidate___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
