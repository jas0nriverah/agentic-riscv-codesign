	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.ToH,"ax",@progbits
	.align	2
	.globl	ToH
	.type	ToH, @function
ToH:
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	s1,20(sp)
	sw	ra,28(sp)
	mv	s1,a2
	mv	s0,a0
	mv	a2,a3
.L3:
	bne	s0,zero,.L2
	lbu	a5,0(a1)
	sb	a5,0(s1)
	sb	zero,0(a1)
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	addi	sp,sp,32
	jr	ra
.L2:
	addi	a0,s0,-1
	mv	a3,s1
	sw	a2,12(sp)
	sw	a1,8(sp)
	sw	a0,4(sp)
	call	ToH
	lw	a1,8(sp)
	add	a5,a1,s0
	lbu	a4,0(a5)
	add	s0,s1,s0
	sb	a4,0(s0)
	sb	zero,0(a5)
	mv	a5,a1
	lw	s0,4(sp)
	lw	a1,12(sp)
	mv	a2,a5
	j	.L3
	.size	ToH, .-ToH
	.section	.text.computeGold,"ax",@progbits
	.align	2
	.globl	computeGold
	.type	computeGold, @function
computeGold:
	addi	a0,a0,-1
	tail	ToH
	.size	computeGold, .-computeGold
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	lui	a1,%hi(A)
	lui	a2,%hi(B)
	lui	a3,%hi(C)
	sw	ra,12(sp)
	li	a5,0
	addi	a1,a1,%lo(A)
	addi	a2,a2,%lo(B)
	addi	a3,a3,%lo(C)
	li	a4,12
.L10:
	add	a0,a5,a1
	sb	a5,0(a0)
	add	a0,a5,a2
	sb	zero,0(a0)
	add	a0,a5,a3
	sb	zero,0(a0)
	addi	a5,a5,1
	bne	a5,a4,.L10
	li	a0,11
	call	ToH
	lw	ra,12(sp)
	li	a0,1
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	li	a5,1
	bne	a0,a5,.L17
	lui	a4,%hi(B)
	li	a5,0
	addi	a4,a4,%lo(B)
	li	a3,12
.L15:
	add	a2,a5,a4
	lbu	a2,0(a2)
	bne	a2,a5,.L17
	addi	a5,a5,1
	bne	a5,a3,.L15
	ret
.L17:
	li	a0,0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.bss.C,"aw",@nobits
	.align	2
	.type	C, @object
	.size	C, 12
C:
	.zero	12
	.section	.bss.B,"aw",@nobits
	.align	2
	.type	B, @object
	.size	B, 12
B:
	.zero	12
	.section	.bss.A,"aw",@nobits
	.align	2
	.type	A, @object
	.size	A, 12
A:
	.zero	12
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
