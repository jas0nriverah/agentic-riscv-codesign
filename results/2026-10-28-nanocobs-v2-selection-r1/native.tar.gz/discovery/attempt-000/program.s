	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.cobs_word_load,"ax",@progbits
	.align	2
	.type	cobs_word_load, @function
cobs_word_load:
	addi	sp,sp,-32
	mv	a1,a0
	li	a2,4
	addi	a0,sp,12
	sw	ra,28(sp)
	call	memcpy
	lw	ra,28(sp)
	lw	a0,12(sp)
	addi	sp,sp,32
	jr	ra
	.size	cobs_word_load, .-cobs_word_load
	.section	.text.flush_block,"ax",@progbits
	.align	2
	.type	flush_block, @function
flush_block:
	addi	sp,sp,-64
	sw	s0,56(sp)
	sw	s3,44(sp)
	sw	s4,40(sp)
	sw	s6,32(sp)
	sw	s7,28(sp)
	sw	ra,60(sp)
	sw	s1,52(sp)
	sw	s2,48(sp)
	sw	s5,36(sp)
	sw	s8,24(sp)
	sw	s9,20(sp)
	lbu	s1,10(a0)
	lbu	s5,9(a0)
	lw	s6,4(a0)
	mv	s3,a0
	sub	s0,s5,s1
	mv	s7,a1
	mv	s4,a2
	bleu	s0,a2,.L4
	mv	s0,a2
.L4:
	li	s8,3
	li	a0,0
	bleu	s0,s8,.L6
	li	s2,0
	add	s9,s6,s1
.L5:
	add	a0,s9,s2
	call	cobs_word_load
	sw	a0,12(sp)
	li	a2,4
	add	a0,s7,s2
	addi	a1,sp,12
	call	memcpy
	addi	s2,s2,4
	sub	a5,s0,s2
	bgtu	a5,s8,.L5
	addi	a0,s0,-4
	andi	a0,a0,-4
	addi	s1,s1,4
	add	s1,a0,s1
	addi	a0,a0,4
.L6:
	bleu	s5,s1,.L11
	bgtu	s4,a0,.L8
.L11:
	sb	s1,10(s3)
	lw	ra,60(sp)
	lw	s0,56(sp)
	lw	s1,52(sp)
	lw	s2,48(sp)
	lw	s3,44(sp)
	lw	s4,40(sp)
	lw	s5,36(sp)
	lw	s6,32(sp)
	lw	s7,28(sp)
	lw	s8,24(sp)
	lw	s9,20(sp)
	addi	sp,sp,64
	jr	ra
.L8:
	add	a5,s6,s1
	lbu	a4,0(a5)
	add	a5,s7,a0
	addi	s1,s1,1
	sb	a4,0(a5)
	addi	a0,a0,1
	j	.L6
	.size	flush_block, .-flush_block
	.section	.text.cobs_encode_tinyframe,"ax",@progbits
	.align	2
	.globl	cobs_encode_tinyframe
	.type	cobs_encode_tinyframe, @function
cobs_encode_tinyframe:
	beq	a0,zero,.L31
	sltiu	a5,a1,2
	bne	a5,zero,.L31
	lbu	a5,0(a0)
	li	a4,90
	beq	a5,a4,.L19
	li	a0,2
	ret
.L20:
	li	a0,2
.L17:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	lw	s7,12(sp)
	addi	sp,sp,48
	jr	ra
.L19:
	addi	sp,sp,-48
	sw	s3,28(sp)
	addi	s3,a1,-1
	sw	ra,44(sp)
	sw	s0,40(sp)
	sw	s1,36(sp)
	sw	s2,32(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	s7,12(sp)
	add	a4,a0,s3
	lbu	a4,0(a4)
	bne	a4,a5,.L20
	li	s5,-16842752
	li	s6,-2139062272
	mv	s1,a0
	li	s0,1
	li	s2,0
	addi	s5,s5,-257
	addi	s6,s6,128
	li	s7,255
.L29:
	bleu	s3,s0,.L32
	sub	s4,s3,s0
	andi	s4,s4,-4
	add	s4,s4,s0
.L22:
	bne	s0,s4,.L25
.L24:
	bgtu	s3,s0,.L28
.L32:
	sub	a5,s0,s2
	li	a4,255
	bgtu	a5,a4,.L20
	add	s2,s1,s2
	sb	a5,0(s2)
	add	s1,s1,s0
	sb	zero,0(s1)
	li	a0,0
	j	.L17
.L25:
	add	a0,s1,s0
	call	cobs_word_load
	add	a5,a0,s5
	not	a0,a0
	and	a5,a5,a0
	and	a5,a5,s6
	bne	a5,zero,.L24
	addi	s0,s0,4
	j	.L22
.L28:
	add	a5,s1,s0
	lbu	a5,0(a5)
	bne	a5,zero,.L27
	sub	a5,s0,s2
	bgtu	a5,s7,.L20
	add	s2,s1,s2
	sb	a5,0(s2)
	mv	s2,s0
	addi	s0,s0,1
	j	.L29
.L27:
	addi	s0,s0,1
	j	.L24
.L31:
	li	a0,1
	ret
	.size	cobs_encode_tinyframe, .-cobs_encode_tinyframe
	.section	.text.cobs_decode_tinyframe,"ax",@progbits
	.align	2
	.globl	cobs_decode_tinyframe
	.type	cobs_decode_tinyframe, @function
cobs_decode_tinyframe:
	beq	a0,zero,.L47
	sltiu	a5,a1,2
	bne	a5,zero,.L47
	addi	sp,sp,-48
	sw	s6,16(sp)
	sw	s7,12(sp)
	li	s6,-16842752
	li	s7,-2139062272
	sw	s0,40(sp)
	sw	s1,36(sp)
	sw	s2,32(sp)
	sw	s8,8(sp)
	sw	ra,44(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	mv	s2,a1
	mv	s1,a0
	li	s0,0
	li	s8,3
	addi	s6,s6,-257
	addi	s7,s7,128
.L39:
	add	s5,s1,s0
	lbu	s4,0(s5)
	beq	s4,zero,.L45
	sb	zero,0(s5)
	add	s0,s4,s0
	bleu	s0,s2,.L48
.L41:
	li	a0,2
.L37:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	lw	s7,12(sp)
	lw	s8,8(sp)
	addi	sp,sp,48
	jr	ra
.L42:
	add	a0,s5,s3
	call	cobs_word_load
	add	a5,a0,s6
	not	a0,a0
	and	a5,a5,a0
	and	a5,a5,s7
	bne	a5,zero,.L41
	addi	s3,s3,4
.L40:
	sub	a5,s4,s3
	bgtu	a5,s8,.L42
.L43:
	bltu	s3,s4,.L44
	bltu	s0,s2,.L39
.L45:
	addi	s2,s2,-1
	bne	s2,s0,.L41
	li	a5,90
	sb	a5,0(s1)
	add	s1,s1,s0
	sb	a5,0(s1)
	li	a0,0
	j	.L37
.L48:
	li	s3,1
	j	.L40
.L44:
	add	a5,s5,s3
	lbu	a5,0(a5)
	beq	a5,zero,.L41
	addi	s3,s3,1
	j	.L43
.L47:
	li	a0,1
	ret
	.size	cobs_decode_tinyframe, .-cobs_decode_tinyframe
	.section	.text.cobs_encode,"ax",@progbits
	.align	2
	.globl	cobs_encode
	.type	cobs_encode, @function
cobs_encode:
	sltiu	a5,a3,2
	seqz	a6,a4
	or	a6,a6,a5
	seqz	a5,a2
	or	a5,a5,a6
	bne	a5,zero,.L76
	beq	a0,zero,.L76
	addi	sp,sp,-96
	sw	s8,56(sp)
	li	s8,1
	sw	s0,88(sp)
	sw	s2,80(sp)
	sw	s3,76(sp)
	sw	s4,72(sp)
	sw	s9,52(sp)
	sw	s10,48(sp)
	mv	s4,a2
	sw	ra,92(sp)
	sw	s1,84(sp)
	sw	s5,68(sp)
	sw	s6,64(sp)
	sw	s7,60(sp)
	sw	s11,44(sp)
	sw	a4,12(sp)
	mv	s2,a3
	mv	s10,a1
	mv	s3,a0
	li	s9,0
	mv	s0,s8
	li	a2,0
.L58:
	bltu	a2,s10,.L74
.L66:
	bgeu	s0,s2,.L75
	lw	a5,12(sp)
	add	a3,s4,s9
	sb	s8,0(a3)
	add	a4,s4,s0
	sb	zero,0(a4)
	addi	s0,s0,1
	sw	s0,0(a5)
	li	a0,0
	j	.L56
.L74:
	bgeu	s0,s2,.L75
	li	a5,254
	sub	a1,s2,s0
	sub	s1,a5,s8
	bleu	s1,a1,.L60
	mv	s1,a1
.L60:
	sub	a1,s10,a2
	bleu	s1,a1,.L61
	mv	s1,a1
.L61:
	li	a5,3
	bleu	s1,a5,.L73
	li	s5,-16842752
	li	s6,-2139062272
	li	s7,16842752
	mv	s11,a2
	addi	s5,s5,-257
	addi	s6,s6,128
	addi	s7,s7,257
	add	s1,a2,s1
.L65:
	add	a0,s3,s11
	call	cobs_word_load
	add	a2,a0,s5
	not	a1,a0
	and	a2,a2,a1
	and	a2,a2,s6
	bne	a2,zero,.L62
	sw	a0,28(sp)
	li	a2,4
	addi	a1,sp,28
	add	a0,s4,s0
	call	memcpy
	addi	s8,s8,4
.L63:
	addi	s11,s11,4
	sub	a2,s1,s11
	li	a5,3
	addi	s0,s0,4
	bgtu	a2,a5,.L65
.L77:
	mv	a2,s11
	bgeu	s11,s10,.L66
.L73:
	bltu	s0,s2,.L67
.L75:
	li	a0,3
.L56:
	lw	ra,92(sp)
	lw	s0,88(sp)
	lw	s1,84(sp)
	lw	s2,80(sp)
	lw	s3,76(sp)
	lw	s4,72(sp)
	lw	s5,68(sp)
	lw	s6,64(sp)
	lw	s7,60(sp)
	lw	s8,56(sp)
	lw	s9,52(sp)
	lw	s10,48(sp)
	lw	s11,44(sp)
	addi	sp,sp,96
	jr	ra
.L62:
	addi	a2,s8,-1
	bne	a2,zero,.L77
	bne	a0,zero,.L77
	add	a0,s4,s9
	li	a2,4
	addi	a1,sp,28
	sw	s7,28(sp)
	addi	s9,s9,4
	call	memcpy
	li	s8,1
	j	.L63
.L67:
	add	a1,s3,a2
	lbu	a1,0(a1)
	addi	a2,a2,1
	beq	a1,zero,.L68
	add	a0,s4,s0
	sb	a1,0(a0)
	addi	s8,s8,1
	li	a5,255
	addi	s0,s0,1
	bne	s8,a5,.L69
.L68:
	add	a3,s4,s9
	sb	s8,0(a3)
	beq	a1,zero,.L70
	mv	a5,s0
	bleu	s10,a2,.L71
.L70:
	addi	a5,s0,1
.L71:
	mv	s9,s0
	li	s8,1
	mv	s0,a5
	j	.L58
.L69:
	bgtu	s10,a2,.L73
	j	.L58
.L76:
	li	a0,1
	ret
	.size	cobs_encode, .-cobs_encode
	.section	.text.cobs_encode_inc_begin,"ax",@progbits
	.align	2
	.globl	cobs_encode_inc_begin
	.type	cobs_encode_inc_begin, @function
cobs_encode_inc_begin:
	seqz	a5,a1
	sltiu	a2,a2,255
	or	a5,a5,a2
	bne	a5,zero,.L99
	beq	a0,zero,.L99
	li	a5,257
	sw	zero,0(a0)
	sw	a1,4(a0)
	sw	a5,8(a0)
	li	a0,0
	ret
.L99:
	li	a0,1
	ret
	.size	cobs_encode_inc_begin, .-cobs_encode_inc_begin
	.section	.text.cobs_encode_inc,"ax",@progbits
	.align	2
	.globl	cobs_encode_inc
	.type	cobs_encode_inc, @function
cobs_encode_inc:
	seqz	a5,a3
	seqz	a4,a2
	or	a4,a4,a5
	seqz	a5,a1
	or	a5,a5,a4
	bne	a5,zero,.L111
	beq	a0,zero,.L111
	addi	sp,sp,-96
	sw	s5,68(sp)
	lw	s5,0(a1)
	li	a4,1
	sw	ra,92(sp)
	sw	s0,88(sp)
	sw	s1,84(sp)
	sw	s2,80(sp)
	sw	s3,76(sp)
	sw	s4,72(sp)
	sw	s6,64(sp)
	sw	s7,60(sp)
	sw	s8,56(sp)
	sw	s9,52(sp)
	sw	s10,48(sp)
	sw	s11,44(sp)
	mv	a5,a4
	beq	s5,zero,.L100
	lw	s7,4(a1)
	beq	s7,zero,.L100
	lw	t1,0(a0)
	bgtu	t1,a4,.L100
	lw	a5,12(a1)
	sw	a3,12(sp)
	sw	a2,8(sp)
	sw	a5,0(sp)
	lw	s8,8(a1)
	lw	s4,4(a0)
	lbu	s9,8(a0)
	lbu	s3,9(a0)
	mv	s0,a0
	li	s1,0
	li	s2,0
	bne	t1,a4,.L102
.L110:
	lw	a5,0(sp)
	add	a1,s7,s2
	sb	s3,9(s0)
	sub	a2,a5,s2
	mv	a0,s0
	call	flush_block
	lbu	a4,10(s0)
	add	s2,s2,a0
	li	a5,1
	bltu	a4,s3,.L103
	sb	zero,10(s0)
	mv	s3,a5
	mv	s9,a5
.L102:
	li	a4,254
	li	a5,255
	sub	a4,a4,s9
	sub	a5,a5,s3
	bleu	a5,a4,.L104
	mv	a5,a4
.L104:
	sub	a4,s8,s1
	bleu	a5,a4,.L105
	mv	a5,a4
.L105:
	li	s10,3
	bleu	a5,s10,.L106
	li	s6,-16842752
	li	s11,-2139062272
	add	a5,a5,s1
	addi	s6,s6,-257
	addi	s11,s11,128
	sw	a5,4(sp)
.L107:
	add	a0,s5,s1
	call	cobs_word_load
	add	a5,a0,s6
	not	a2,a0
	and	a5,a5,a2
	and	a5,a5,s11
	bne	a5,zero,.L106
	sw	a0,28(sp)
	li	a2,4
	add	a0,s4,s3
	addi	a1,sp,28
	call	memcpy
	lw	a5,4(sp)
	addi	s1,s1,4
	addi	s3,s3,4
	sub	a5,a5,s1
	addi	s9,s9,4
	bgtu	a5,s10,.L107
.L106:
	li	a4,255
.L109:
	bgeu	s1,s8,.L118
	addi	s1,s1,1
	add	a5,s5,s1
	lbu	a5,-1(a5)
	beq	a5,zero,.L108
	addi	s3,s3,1
	add	a2,s4,s3
	sb	a5,-1(a2)
	addi	s9,s9,1
	bne	s9,a4,.L109
.L108:
	addi	a5,s9,-255
	seqz	a5,a5
	sb	a5,11(s0)
	sb	s9,0(s4)
	sb	zero,10(s0)
	j	.L110
.L118:
	li	a5,0
.L103:
	sw	a5,0(s0)
	lw	a5,8(sp)
	sb	s9,8(s0)
	sb	s3,9(s0)
	sw	s1,0(a5)
	lw	a5,12(sp)
	sw	s2,0(a5)
	li	a5,0
.L100:
	lw	ra,92(sp)
	lw	s0,88(sp)
	lw	s1,84(sp)
	lw	s2,80(sp)
	lw	s3,76(sp)
	lw	s4,72(sp)
	lw	s5,68(sp)
	lw	s6,64(sp)
	lw	s7,60(sp)
	lw	s8,56(sp)
	lw	s9,52(sp)
	lw	s10,48(sp)
	lw	s11,44(sp)
	mv	a0,a5
	addi	sp,sp,96
	jr	ra
.L111:
	li	a5,1
	mv	a0,a5
	ret
	.size	cobs_encode_inc, .-cobs_encode_inc
	.section	.text.cobs_encode_inc_end,"ax",@progbits
	.align	2
	.globl	cobs_encode_inc_end
	.type	cobs_encode_inc_end, @function
cobs_encode_inc_end:
	seqz	a5,a4
	seqz	a6,a3
	or	a6,a6,a5
	seqz	a5,a1
	or	a5,a5,a6
	bne	a5,zero,.L140
	beq	a0,zero,.L140
	addi	sp,sp,-48
	sw	s1,36(sp)
	lw	s1,0(a0)
	sw	s7,12(sp)
	lui	s7,%hi(.L133)
	sw	s0,40(sp)
	sw	s2,32(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	s8,8(sp)
	sw	ra,44(sp)
	mv	s4,a4
	mv	s5,a3
	mv	s6,a2
	mv	s3,a1
	mv	s0,a0
	li	s2,0
	li	s8,4
	addi	s7,s7,%lo(.L133)
.L130:
	bgtu	s1,s8,.L131
.L146:
	slli	a5,s1,2
	add	a5,a5,s7
	lw	a5,0(a5)
	jr	a5
	.section	.rodata.cobs_encode_inc_end,"a",@progbits
	.align	2
	.align	2
.L133:
	.word	.L137
	.word	.L136
	.word	.L135
	.word	.L134
	.word	.L132
	.section	.text.cobs_encode_inc_end
.L131:
	j	.L131
.L136:
	sub	a2,s6,s2
	add	a1,s3,s2
	mv	a0,s0
	call	flush_block
	lbu	a4,10(s0)
	lbu	a5,9(s0)
	add	s2,s2,a0
	bltu	a4,a5,.L132
	li	a5,257
	sh	a5,8(s0)
	sb	zero,10(s0)
	li	s1,0
	j	.L146
.L137:
	lbu	a4,11(s0)
	lbu	a5,8(s0)
	beq	a4,zero,.L139
	li	a4,1
	bne	a5,a4,.L139
	lbu	a4,9(s0)
	li	s1,3
	beq	a4,a5,.L130
.L139:
	lw	a4,4(s0)
	li	s1,2
	sb	a5,0(a4)
	sb	zero,10(s0)
	j	.L130
.L135:
	sub	a2,s6,s2
	add	a1,s3,s2
	mv	a0,s0
	call	flush_block
	lbu	a4,10(s0)
	lbu	a5,9(s0)
	add	s2,s2,a0
	bltu	a4,a5,.L132
	li	s1,3
	j	.L130
.L134:
	bleu	s6,s2,.L132
	add	a1,s3,s2
	sb	zero,0(a1)
	addi	s2,s2,1
	li	s1,4
.L132:
	sw	s1,0(s0)
	lw	ra,44(sp)
	lw	s0,40(sp)
	addi	s1,s1,-4
	sw	s2,0(s5)
	seqz	s1,s1
	sb	s1,0(s4)
	lw	s2,32(sp)
	lw	s1,36(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	lw	s7,12(sp)
	lw	s8,8(sp)
	li	a0,0
	addi	sp,sp,48
	jr	ra
.L140:
	li	a0,1
	ret
	.size	cobs_encode_inc_end, .-cobs_encode_inc_end
	.section	.text.cobs_decode_inc_begin,"ax",@progbits
	.align	2
	.globl	cobs_decode_inc_begin
	.type	cobs_decode_inc_begin, @function
cobs_decode_inc_begin:
	beq	a0,zero,.L153
	sw	zero,0(a0)
	li	a0,0
	ret
.L153:
	li	a0,1
	ret
	.size	cobs_decode_inc_begin, .-cobs_decode_inc_begin
	.section	.text.cobs_decode_inc,"ax",@progbits
	.align	2
	.globl	cobs_decode_inc
	.type	cobs_decode_inc, @function
cobs_decode_inc:
	seqz	a6,a4
	seqz	a5,a3
	or	a5,a5,a6
	seqz	a6,a2
	addi	sp,sp,-112
	or	a6,a6,a5
	seqz	a5,a1
	or	a5,a5,a6
	sw	s2,96(sp)
	seqz	s2,a0
	or	s2,s2,a5
	sw	ra,108(sp)
	sw	s0,104(sp)
	sw	s1,100(sp)
	sw	s3,92(sp)
	sw	s4,88(sp)
	sw	s5,84(sp)
	sw	s6,80(sp)
	sw	s7,76(sp)
	sw	s8,72(sp)
	sw	s9,68(sp)
	sw	s10,64(sp)
	sw	s11,60(sp)
	li	a5,1
	bne	s2,zero,.L154
	lw	s3,4(a1)
	li	a5,1
	beq	s3,zero,.L154
	lw	s1,0(a1)
	beq	s1,zero,.L154
	lw	s11,0(a0)
	li	a6,2
	bgtu	s11,a6,.L154
	lw	s4,8(a1)
	lw	s5,12(a1)
	lbu	s9,4(a0)
	lbu	s10,5(a0)
	sw	a4,24(sp)
	sw	a3,20(sp)
	sw	a2,16(sp)
	mv	s0,a0
	li	s8,0
	li	a5,0
.L156:
	bgtu	s4,a5,.L173
.L166:
	lw	a4,20(sp)
	sw	s11,0(s0)
	sb	s10,5(s0)
	sb	s9,4(s0)
	sw	s8,0(a4)
	lw	a4,16(sp)
	sw	a5,0(a4)
	lw	a5,24(sp)
	sb	s2,0(a5)
	li	a5,0
.L154:
	lw	ra,108(sp)
	lw	s0,104(sp)
	lw	s1,100(sp)
	lw	s2,96(sp)
	lw	s3,92(sp)
	lw	s4,88(sp)
	lw	s5,84(sp)
	lw	s6,80(sp)
	lw	s7,76(sp)
	lw	s8,72(sp)
	lw	s9,68(sp)
	lw	s10,64(sp)
	lw	s11,60(sp)
	mv	a0,a5
	addi	sp,sp,112
	jr	ra
.L173:
	li	a4,1
	beq	s11,a4,.L157
	li	a4,2
	beq	s11,a4,.L158
	add	a4,s1,a5
	lbu	s9,0(a4)
	addi	a5,a5,1
	li	s11,1
	mv	s10,s9
	j	.L156
.L158:
	li	a4,255
	beq	s10,a4,.L160
	addi	s6,s4,-1
	sub	a4,s5,s8
	sub	s6,s6,a5
	bleu	s6,a4,.L161
	mv	s6,a4
.L161:
	andi	s6,s6,-4
	li	s7,16842752
	add	s6,s6,s8
	addi	s7,s7,257
.L162:
	bne	s8,s6,.L164
.L160:
	add	a4,s1,a5
	lbu	a4,0(a4)
	beq	a4,zero,.L178
	li	a4,255
	beq	s10,a4,.L179
	bgeu	s8,s5,.L166
	add	a4,s3,s8
	sb	zero,0(a4)
	addi	s8,s8,1
.L179:
	li	s11,0
	j	.L156
.L164:
	add	a0,s1,a5
	sw	a5,12(sp)
	call	cobs_word_load
	lw	a5,12(sp)
	bne	a0,s7,.L160
	add	a0,s3,s8
	li	a2,4
	addi	a1,sp,44
	sw	zero,44(sp)
	call	memcpy
	lw	a5,12(sp)
	li	s10,1
	addi	s8,s8,4
	addi	a5,a5,4
	mv	s9,s10
	j	.L162
.L157:
	li	a4,4
	bleu	s9,a4,.L171
	sub	a2,s4,a5
	sub	a4,s5,s8
	bleu	a4,a2,.L168
	mv	a4,a2
.L168:
	addi	a2,s9,-1
	bleu	a4,a2,.L169
	mv	a4,a2
.L169:
	li	a3,3
	bleu	a4,a3,.L171
	li	s6,-16842752
	li	s7,-2139062272
	add	a4,a5,a4
	addi	s6,s6,-257
	addi	s7,s7,128
	sw	a4,12(sp)
.L170:
	add	a0,s1,a5
	sw	a5,28(sp)
	call	cobs_word_load
	add	a4,a0,s6
	not	a2,a0
	and	a4,a4,a2
	and	a4,a4,s7
	lw	a5,28(sp)
	bne	a4,zero,.L171
	sw	a0,44(sp)
	li	a2,4
	add	a0,s3,s8
	addi	a1,sp,44
	call	memcpy
	lw	a5,28(sp)
	lw	a4,12(sp)
	li	a3,3
	addi	a5,a5,4
	sub	a4,a4,a5
	addi	s8,s8,4
	addi	s9,s9,-4
	bgtu	a4,a3,.L170
.L171:
	li	a4,1
	bne	s9,a4,.L172
	li	s11,2
	j	.L156
.L172:
	bleu	s5,s8,.L166
	bgeu	a5,s4,.L166
	add	a4,s1,a5
	lbu	a4,0(a4)
	beq	a4,zero,.L181
	add	a2,s3,s8
	addi	s9,s9,-1
	addi	a5,a5,1
	sb	a4,0(a2)
	addi	s8,s8,1
	j	.L171
.L178:
	li	s2,1
	j	.L166
.L181:
	li	a5,2
	j	.L154
	.size	cobs_decode_inc, .-cobs_decode_inc
	.section	.text.cobs_decode,"ax",@progbits
	.align	2
	.globl	cobs_decode
	.type	cobs_decode, @function
cobs_decode:
	sltiu	a6,a1,2
	seqz	a7,a4
	or	a7,a7,a6
	seqz	a6,a2
	or	a6,a6,a7
	bne	a6,zero,.L189
	beq	a0,zero,.L189
	addi	sp,sp,-64
	sw	a0,32(sp)
	sw	a2,36(sp)
	sw	a1,40(sp)
	sw	a3,44(sp)
	addi	a2,sp,20
	mv	a3,a4
	addi	a1,sp,32
	addi	a4,sp,19
	addi	a0,sp,24
	sw	ra,60(sp)
	sw	a5,12(sp)
	sw	zero,24(sp)
	call	cobs_decode_inc
	bne	a0,zero,.L184
	lbu	a4,19(sp)
	beq	a4,zero,.L190
	lw	a5,12(sp)
	beq	a5,zero,.L184
	lw	a4,20(sp)
	addi	a4,a4,1
	sw	a4,0(a5)
.L184:
	lw	ra,60(sp)
	addi	sp,sp,64
	jr	ra
.L189:
	li	a0,1
	ret
.L190:
	li	a0,3
	j	.L184
	.size	cobs_decode, .-cobs_decode
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
