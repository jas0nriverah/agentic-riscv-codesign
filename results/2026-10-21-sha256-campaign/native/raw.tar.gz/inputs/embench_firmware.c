// Workload-independent Embench harness on the existing serial-report SoC.
#include <stdint.h>
extern void initialise_benchmark(void), warm_caches(int);
extern int benchmark(void), verify_benchmark(int);
static inline uint32_t cycles(void) {
    uint32_t v; __asm__ volatile("rdcycle %0" : "=r"(v) :: "memory"); return v;
}
static inline uint32_t instructions(void) {
    uint32_t v; __asm__ volatile("rdinstret %0" : "=r"(v) :: "memory"); return v;
}
int main(void) {
    initialise_benchmark();
    warm_caches(1);
    uint32_t i0=instructions(), c0=cycles();
    int result=benchmark();
    uint32_t c1=cycles(), i1=instructions();
    int correct=verify_benchmark(result);
    // FIPS SHA-256 fixed-message digest, checked in full outside the timed window.
    // Upstream verify_benchmark checks only its first eight bytes.
    extern unsigned char buffer[32];
    static const unsigned char expected_sha256[32] = {
        0x24,0x8d,0x6a,0x61,0xd2,0x06,0x38,0xb8,
        0xe5,0xc0,0x26,0x93,0x0c,0x3e,0x60,0x39,
        0xa3,0x3c,0xe4,0x59,0x64,0xff,0x21,0x67,
        0xf6,0xec,0xed,0xd4,0x19,0xdb,0x06,0xc1
    };
    for (unsigned int byte=0; byte<sizeof(expected_sha256); ++byte)
        if (buffer[byte] != expected_sha256[byte]) correct=0;

    volatile uint32_t *out=(volatile uint32_t *)0x10000000;
    *out=0x49534146; *out=(uint32_t)result; *out=c1-c0; *out=i1-i0; *out=correct;
    *(volatile uint32_t *)0x10000004=correct ? 0x600d600d : 0xdead0003;
    return 0;
}
