	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a3,%hi(a)
	li	a4,2
	addi	a3,a3,%lo(a)
	li	a0,11
.L2:
	slli	a5,a4,2
	add	a5,a5,a3
	j	.L5
.L3:
	sw	a2,4(a5)
	sw	a1,0(a5)
.L5:
	lw	a1,0(a5)
	addi	a5,a5,-4
	lw	a2,0(a5)
	bltu	a1,a2,.L3
	addi	a4,a4,1
	bne	a4,a0,.L2
	li	a0,0
	ret
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(a)
	addi	a5,a5,%lo(a)
	li	a4,11
	sw	a4,4(a5)
	li	a4,10
	sw	a4,8(a5)
	li	a4,9
	sw	a4,12(a5)
	li	a4,8
	sw	a4,16(a5)
	li	a4,7
	sw	a4,20(a5)
	li	a4,6
	sw	a4,24(a5)
	li	a4,5
	sw	a4,28(a5)
	li	a4,4
	sw	a4,32(a5)
	li	a4,3
	sw	a4,36(a5)
	li	a4,2
	sw	zero,0(a5)
	sw	a4,40(a5)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	sp,sp,-64
	lui	a1,%hi(.LANCHOR0)
	addi	a1,a1,%lo(.LANCHOR0)
	li	a2,44
	addi	a0,sp,4
	sw	ra,60(sp)
	call	memcpy
	lui	a4,%hi(a)
	mv	a6,a0
	li	a5,0
	addi	a4,a4,%lo(a)
	li	a1,44
.L9:
	add	a2,a5,a4
	add	a3,a6,a5
	lw	a2,0(a2)
	lw	a3,0(a3)
	bne	a2,a3,.L10
	addi	a5,a5,4
	bne	a5,a1,.L9
	li	a0,1
.L7:
	lw	ra,60(sp)
	addi	sp,sp,64
	jr	ra
.L10:
	li	a0,0
	j	.L7
	.size	verify_benchmark, .-verify_benchmark
	.globl	a
	.section	.bss.a,"aw",@nobits
	.align	2
	.type	a, @object
	.size	a, 44
a:
	.zero	44
	.section	.rodata
	.align	2
	.set	.LANCHOR0,. + 0
.LC0:
	.word	0
	.word	2
	.word	3
	.word	4
	.word	5
	.word	6
	.word	7
	.word	8
	.word	9
	.word	10
	.word	11
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
