	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.swi120,"ax",@progbits
	.align	2
	.globl	swi120
	.type	swi120, @function
swi120:
	addi	a0,a0,120
	ret
	.size	swi120, .-swi120
	.section	.text.swi50,"ax",@progbits
	.align	2
	.globl	swi50
	.type	swi50, @function
swi50:
	addi	a0,a0,50
	ret
	.size	swi50, .-swi50
	.section	.text.swi10,"ax",@progbits
	.align	2
	.globl	swi10
	.type	swi10, @function
swi10:
	addi	a0,a0,10
	ret
	.size	swi10, .-swi10
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-32
	sw	zero,12(sp)
	lw	a0,12(sp)
	sw	ra,28(sp)
	call	swi10
	sw	a0,12(sp)
	lw	a0,12(sp)
	call	swi50
	sw	a0,12(sp)
	lw	a0,12(sp)
	call	swi120
	lw	ra,28(sp)
	sw	a0,12(sp)
	lw	a0,12(sp)
	addi	sp,sp,32
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-180
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
