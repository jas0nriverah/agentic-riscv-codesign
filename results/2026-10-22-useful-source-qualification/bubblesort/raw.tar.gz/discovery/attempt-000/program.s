	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(factor)
	li	a4,-1
	sw	a4,%lo(factor)(a5)
	lui	a5,%hi(Array)
	addi	a5,a5,%lo(Array)
	li	a4,0
	li	a3,-100
.L2:
	sw	a4,0(a5)
	addi	a4,a4,-1
	addi	a5,a5,4
	bne	a4,a3,.L2
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.BubbleSort,"ax",@progbits
	.align	2
	.globl	BubbleSort
	.type	BubbleSort, @function
BubbleSort:
	li	a4,100
	mv	a7,a4
.L5:
	mv	a5,a0
	li	a3,0
	li	a2,1
.L6:
	lw	a1,0(a5)
	lw	a6,4(a5)
	ble	a1,a6,.L9
	sw	a6,0(a5)
	sw	a1,4(a5)
	li	a2,0
.L9:
	addi	a3,a3,1
	beq	a3,a7,.L11
	addi	a5,a5,4
	bne	a3,a4,.L6
.L11:
	beq	a2,zero,.L16
	ret
.L16:
	addi	a4,a4,-1
	bne	a4,zero,.L5
	ret
	.size	BubbleSort, .-BubbleSort
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a0,%hi(Array)
	addi	sp,sp,-16
	addi	a0,a0,%lo(Array)
	sw	ra,12(sp)
	call	BubbleSort
	lw	ra,12(sp)
	li	a0,0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	sp,sp,-416
	lui	a1,%hi(.LANCHOR0)
	addi	a1,a1,%lo(.LANCHOR0)
	li	a2,400
	mv	a0,sp
	sw	ra,412(sp)
	call	memcpy
	lui	a4,%hi(Array)
	mv	a6,a0
	li	a5,0
	addi	a4,a4,%lo(Array)
	li	a1,400
.L21:
	add	a2,a5,a4
	add	a3,a6,a5
	lw	a2,0(a2)
	lw	a3,0(a3)
	bne	a2,a3,.L22
	addi	a5,a5,4
	bne	a5,a1,.L21
	li	a0,1
.L19:
	lw	ra,412(sp)
	addi	sp,sp,416
	jr	ra
.L22:
	li	a0,0
	j	.L19
	.size	verify_benchmark, .-verify_benchmark
	.globl	factor
	.section	.bss.factor,"aw",@nobits
	.align	2
	.type	factor, @object
	.size	factor, 4
factor:
	.zero	4
	.globl	Seed
	.section	.bss.Seed,"aw",@nobits
	.align	2
	.type	Seed, @object
	.size	Seed, 4
Seed:
	.zero	4
	.globl	Array
	.section	.bss.Array,"aw",@nobits
	.align	2
	.type	Array, @object
	.size	Array, 404
Array:
	.zero	404
	.section	.rodata
	.align	2
	.set	.LANCHOR0,. + 0
.LC0:
	.word	-99
	.word	-98
	.word	-97
	.word	-96
	.word	-95
	.word	-94
	.word	-93
	.word	-92
	.word	-91
	.word	-90
	.word	-89
	.word	-88
	.word	-87
	.word	-86
	.word	-85
	.word	-84
	.word	-83
	.word	-82
	.word	-81
	.word	-80
	.word	-79
	.word	-78
	.word	-77
	.word	-76
	.word	-75
	.word	-74
	.word	-73
	.word	-72
	.word	-71
	.word	-70
	.word	-69
	.word	-68
	.word	-67
	.word	-66
	.word	-65
	.word	-64
	.word	-63
	.word	-62
	.word	-61
	.word	-60
	.word	-59
	.word	-58
	.word	-57
	.word	-56
	.word	-55
	.word	-54
	.word	-53
	.word	-52
	.word	-51
	.word	-50
	.word	-49
	.word	-48
	.word	-47
	.word	-46
	.word	-45
	.word	-44
	.word	-43
	.word	-42
	.word	-41
	.word	-40
	.word	-39
	.word	-38
	.word	-37
	.word	-36
	.word	-35
	.word	-34
	.word	-33
	.word	-32
	.word	-31
	.word	-30
	.word	-29
	.word	-28
	.word	-27
	.word	-26
	.word	-25
	.word	-24
	.word	-23
	.word	-22
	.word	-21
	.word	-20
	.word	-19
	.word	-18
	.word	-17
	.word	-16
	.word	-15
	.word	-14
	.word	-13
	.word	-12
	.word	-11
	.word	-10
	.word	-9
	.word	-8
	.word	-7
	.word	-6
	.word	-5
	.word	-4
	.word	-3
	.word	-2
	.word	-1
	.word	0
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
