	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.fib,"ax",@progbits
	.align	2
	.globl	fib
	.type	fib, @function
fib:
	addi	sp,sp,-16
	sw	s0,8(sp)
	sw	s1,4(sp)
	sw	s2,0(sp)
	sw	ra,12(sp)
	mv	s0,a0
	li	s1,0
	li	s2,1
.L3:
	bleu	s0,s2,.L2
	addi	a0,s0,-1
	call	fib
	addi	s0,s0,-2
	add	s1,s1,a0
	j	.L3
.L2:
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s2,0(sp)
	addi	a0,s1,1
	lw	s1,4(sp)
	addi	sp,sp,16
	jr	ra
	.size	fib, .-fib
	.section	.text.anka,"ax",@progbits
	.align	2
	.globl	anka
	.type	anka, @function
anka:
	ble	a0,zero,.L6
	addi	a0,a0,-1
	tail	kalle
.L6:
	li	a0,1
	ret
	.size	anka, .-anka
	.section	.text.kalle,"ax",@progbits
	.align	2
	.globl	kalle
	.type	kalle, @function
kalle:
	ble	a0,zero,.L8
	addi	a0,a0,-1
	tail	anka
.L8:
	li	a0,0
	ret
	.size	kalle, .-kalle
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a5,%hi(n)
	lw	a0,%lo(n)(a5)
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	fib
	lw	ra,12(sp)
	lui	a5,%hi(In)
	sw	a0,%lo(In)(a5)
	lw	a0,%lo(In)(a5)
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(n)
	li	a4,10
	sw	a4,%lo(n)(a5)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-89
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.bss.n,"aw",@nobits
	.align	2
	.type	n, @object
	.size	n, 4
n:
	.zero	4
	.globl	In
	.section	.bss.In,"aw",@nobits
	.align	2
	.type	In, @object
	.size	In, 4
In:
	.zero	4
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
