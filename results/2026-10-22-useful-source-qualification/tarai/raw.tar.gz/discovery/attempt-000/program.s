	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.tarai,"ax",@progbits
	.align	2
	.globl	tarai
	.type	tarai, @function
tarai:
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	s1,20(sp)
	sw	s2,16(sp)
	sw	ra,28(sp)
	sw	s3,12(sp)
	sw	s4,8(sp)
	mv	s2,a0
	mv	s0,a1
	mv	s1,a2
.L2:
	bgt	s2,s0,.L4
	mv	s3,s0
.L1:
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s4,8(sp)
	mv	a0,s3
	lw	s3,12(sp)
	addi	sp,sp,32
	jr	ra
.L4:
	mv	a2,s1
	mv	a1,s0
	addi	a0,s2,-1
	call	tarai
	mv	s4,a0
	mv	a2,s2
	mv	a1,s1
	addi	a0,s0,-1
	call	tarai
	mv	s3,a0
	ble	s4,a0,.L1
	mv	a2,s0
	mv	a1,s2
	addi	a0,s1,-1
	call	tarai
	mv	s1,a0
	mv	s0,s3
	mv	s2,s4
	j	.L2
	.size	tarai, .-tarai
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a5,%hi(z)
	lw	a2,%lo(z)(a5)
	lui	a5,%hi(y)
	lw	a1,%lo(y)(a5)
	lui	a5,%hi(x)
	lw	a0,%lo(x)(a5)
	addi	sp,sp,-32
	sw	ra,28(sp)
	sw	zero,12(sp)
	call	tarai
	lw	ra,28(sp)
	sw	a0,12(sp)
	lw	a0,12(sp)
	addi	sp,sp,32
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(x)
	li	a4,9
	sw	a4,%lo(x)(a5)
	lui	a5,%hi(y)
	li	a4,6
	sw	a4,%lo(y)(a5)
	lui	a5,%hi(z)
	li	a4,3
	sw	a4,%lo(z)(a5)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-9
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	z
	.section	.bss.z,"aw",@nobits
	.align	2
	.type	z, @object
	.size	z, 4
z:
	.zero	4
	.globl	y
	.section	.bss.y,"aw",@nobits
	.align	2
	.type	y, @object
	.size	y, 4
y:
	.zero	4
	.globl	x
	.section	.bss.x,"aw",@nobits
	.align	2
	.type	x, @object
	.size	x, 4
x:
	.zero	4
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
