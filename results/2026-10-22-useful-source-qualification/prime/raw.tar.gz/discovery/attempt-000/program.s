	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.divides,"ax",@progbits
	.align	2
	.globl	divides
	.type	divides, @function
divides:
	mv	a5,a1
	addi	sp,sp,-16
	mv	a1,a0
	mv	a0,a5
	sw	ra,12(sp)
	call	__umodsi3
	lw	ra,12(sp)
	seqz	a0,a0
	addi	sp,sp,16
	jr	ra
	.size	divides, .-divides
	.section	.text.even,"ax",@progbits
	.align	2
	.globl	even
	.type	even, @function
even:
	not	a0,a0
	andi	a0,a0,1
	ret
	.size	even, .-even
	.section	.text.prime,"ax",@progbits
	.align	2
	.globl	prime
	.type	prime, @function
prime:
	addi	sp,sp,-16
	slli	a4,a0,31
	sw	s0,8(sp)
	sw	s1,4(sp)
	sw	ra,12(sp)
	srli	a5,a4,31
	mv	s0,a0
	li	s1,3
	bne	a5,zero,.L5
	addi	s0,a0,-2
	seqz	a0,s0
.L6:
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s1,4(sp)
	addi	sp,sp,16
	jr	ra
.L7:
	mv	a1,s1
	mv	a0,s0
	call	__umodsi3
	beq	a0,zero,.L6
	addi	s1,s1,2
.L5:
	mv	a1,s1
	mv	a0,s1
	call	__mulsi3
	bgeu	s0,a0,.L7
	addi	s0,s0,-1
	snez	a0,s0
	j	.L6
	.size	prime, .-prime
	.section	.text.swap,"ax",@progbits
	.align	2
	.globl	swap
	.type	swap, @function
swap:
	lw	a4,0(a1)
	lw	a5,0(a0)
	sw	a4,0(a0)
	sw	a5,0(a1)
	ret
	.size	swap, .-swap
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	lui	a5,%hi(y)
	lui	a4,%hi(x)
	lw	a0,%lo(y)(a5)
	sw	s0,8(sp)
	lw	s0,%lo(x)(a4)
	sw	ra,12(sp)
	sw	a0,%lo(x)(a4)
	sw	s0,%lo(y)(a5)
	call	prime
	li	a5,1
	beq	a0,zero,.L16
	mv	a0,s0
	call	prime
	xori	a5,a0,1
	andi	a5,a5,0xff
.L16:
	lw	ra,12(sp)
	lw	s0,8(sp)
	lui	a4,%hi(result)
	sw	a5,%lo(result)(a4)
	li	a0,0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	li	a5,20480
	lui	a4,%hi(x)
	addi	a5,a5,1169
	sw	a5,%lo(x)(a4)
	li	a5,512000
	lui	a4,%hi(y)
	addi	a5,a5,1239
	sw	a5,%lo(y)(a4)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	lui	a5,%hi(result)
	lw	a0,%lo(result)(a5)
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	y
	.section	.bss.y,"aw",@nobits
	.align	2
	.type	y, @object
	.size	y, 4
y:
	.zero	4
	.globl	x
	.section	.bss.x,"aw",@nobits
	.align	2
	.type	x, @object
	.size	x, 4
x:
	.zero	4
	.globl	result
	.section	.bss.result,"aw",@nobits
	.align	2
	.type	result, @object
	.size	result, 4
result:
	.zero	4
	.globl	__mulsi3
	.globl	__umodsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
