	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.InitSeed,"ax",@progbits
	.align	2
	.globl	InitSeed
	.type	InitSeed, @function
InitSeed:
	lui	a5,%hi(Seed)
	sw	zero,%lo(Seed)(a5)
	li	a0,0
	ret
	.size	InitSeed, .-InitSeed
	.section	.text.Sum,"ax",@progbits
	.align	2
	.globl	Sum
	.type	Sum, @function
Sum:
	addi	a4,a0,40
	addi	a3,a0,440
	li	a2,0
	li	a1,0
	li	a0,0
	li	a6,0
.L3:
	addi	a5,a4,-40
.L6:
	lw	a7,0(a5)
	bge	a7,zero,.L4
	add	a6,a6,a7
	addi	a1,a1,1
.L5:
	addi	a5,a5,4
	bne	a5,a4,.L6
	addi	a4,a5,40
	bne	a4,a3,.L3
	lui	a5,%hi(Postotal)
	sw	a6,%lo(Postotal)(a5)
	lui	a5,%hi(Poscnt)
	sw	a1,%lo(Poscnt)(a5)
	lui	a5,%hi(Negtotal)
	sw	a0,%lo(Negtotal)(a5)
	lui	a5,%hi(Negcnt)
	sw	a2,%lo(Negcnt)(a5)
	ret
.L4:
	add	a0,a0,a7
	addi	a2,a2,1
	j	.L5
	.size	Sum, .-Sum
	.section	.text.Test,"ax",@progbits
	.align	2
	.globl	Test
	.type	Test, @function
Test:
	tail	Sum
	.size	Test, .-Test
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a0,%hi(Array)
	addi	a0,a0,%lo(Array)
	tail	Sum
	.size	benchmark, .-benchmark
	.section	.text.RandomInteger,"ax",@progbits
	.align	2
	.globl	RandomInteger
	.type	RandomInteger, @function
RandomInteger:
	addi	sp,sp,-16
	sw	s0,8(sp)
	lui	s0,%hi(Seed)
	lw	a5,%lo(Seed)(s0)
	li	a1,8192
	addi	a1,a1,-97
	slli	a0,a5,5
	add	a0,a0,a5
	slli	a0,a0,2
	add	a0,a0,a5
	addi	a0,a0,81
	sw	ra,12(sp)
	call	__modsi3
	lw	ra,12(sp)
	sw	a0,%lo(Seed)(s0)
	lw	s0,8(sp)
	addi	sp,sp,16
	jr	ra
	.size	RandomInteger, .-RandomInteger
	.section	.text.Initialize,"ax",@progbits
	.align	2
	.globl	Initialize
	.type	Initialize, @function
Initialize:
	addi	sp,sp,-16
	sw	s0,8(sp)
	sw	s2,0(sp)
	sw	ra,12(sp)
	sw	s1,4(sp)
	mv	s0,a0
	addi	s2,a0,400
.L14:
	addi	s1,s0,40
.L15:
	call	RandomInteger
	sw	a0,0(s0)
	addi	s0,s0,4
	bne	s0,s1,.L15
	bne	s2,s0,.L14
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s1,4(sp)
	lw	s2,0(sp)
	li	a0,0
	addi	sp,sp,16
	jr	ra
	.size	Initialize, .-Initialize
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a0,%hi(Array)
	lui	a5,%hi(Seed)
	addi	a0,a0,%lo(Array)
	sw	zero,%lo(Seed)(a5)
	tail	Initialize
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	li	a5,-397312
	addi	a5,a5,637
	add	a0,a0,a5
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	Negcnt
	.section	.bss.Negcnt,"aw",@nobits
	.align	2
	.type	Negcnt, @object
	.size	Negcnt, 4
Negcnt:
	.zero	4
	.globl	Poscnt
	.section	.bss.Poscnt,"aw",@nobits
	.align	2
	.type	Poscnt, @object
	.size	Poscnt, 4
Poscnt:
	.zero	4
	.globl	Negtotal
	.section	.bss.Negtotal,"aw",@nobits
	.align	2
	.type	Negtotal, @object
	.size	Negtotal, 4
Negtotal:
	.zero	4
	.globl	Postotal
	.section	.bss.Postotal,"aw",@nobits
	.align	2
	.type	Postotal, @object
	.size	Postotal, 4
Postotal:
	.zero	4
	.globl	Array
	.section	.bss.Array,"aw",@nobits
	.align	2
	.type	Array, @object
	.size	Array, 400
Array:
	.zero	400
	.globl	Seed
	.section	.bss.Seed,"aw",@nobits
	.align	2
	.type	Seed, @object
	.size	Seed, 4
Seed:
	.zero	4
	.globl	__modsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
