// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vverification_top.h for the primary calling header

#include "Vverification_top__pch.h"

bool Vverification_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((2U > n));
    return (0U);
}

void Vverification_top___024root___ico_comb__TOP__0(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___ico_comb__TOP__0\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ verification_top__DOT__c32__DOT__n2;
    verification_top__DOT__c32__DOT__n2 = 0;
    IData/*31:0*/ verification_top__DOT__c20__DOT__n2;
    verification_top__DOT__c20__DOT__n2 = 0;
    IData/*31:0*/ verification_top__DOT__c14__DOT__stage_n1_0;
    verification_top__DOT__c14__DOT__stage_n1_0 = 0;
    IData/*31:0*/ verification_top__DOT__c14__DOT__stage_n1_1;
    verification_top__DOT__c14__DOT__stage_n1_1 = 0;
    IData/*31:0*/ verification_top__DOT__c14__DOT__stage_n1_2;
    verification_top__DOT__c14__DOT__stage_n1_2 = 0;
    IData/*31:0*/ verification_top__DOT__c14__DOT__stage_n1_3;
    verification_top__DOT__c14__DOT__stage_n1_3 = 0;
    IData/*31:0*/ verification_top__DOT__c10__DOT__stage_n2_1;
    verification_top__DOT__c10__DOT__stage_n2_1 = 0;
    IData/*31:0*/ verification_top__DOT__c10__DOT__stage_n2_2;
    verification_top__DOT__c10__DOT__stage_n2_2 = 0;
    IData/*31:0*/ verification_top__DOT__c10__DOT__stage_n2_3;
    verification_top__DOT__c10__DOT__stage_n2_3 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n2_3;
    verification_top__DOT__c9__DOT__stage_n2_3 = 0;
    IData/*31:0*/ verification_top__DOT__c8__DOT__n0;
    verification_top__DOT__c8__DOT__n0 = 0;
    IData/*31:0*/ verification_top__DOT__c8__DOT__stage_n2_0;
    verification_top__DOT__c8__DOT__stage_n2_0 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n2_2;
    verification_top__DOT__c7__DOT__stage_n2_2 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n2_3;
    verification_top__DOT__c7__DOT__stage_n2_3 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n2_0;
    verification_top__DOT__c5__DOT__stage_n2_0 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n2_1;
    verification_top__DOT__c5__DOT__stage_n2_1 = 0;
    IData/*31:0*/ verification_top__DOT__c4__DOT__n0;
    verification_top__DOT__c4__DOT__n0 = 0;
    IData/*31:0*/ verification_top__DOT__c2__DOT__stage_n2_2;
    verification_top__DOT__c2__DOT__stage_n2_2 = 0;
    IData/*31:0*/ verification_top__DOT__c2__DOT__stage_n2_3;
    verification_top__DOT__c2__DOT__stage_n2_3 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n2_1;
    verification_top__DOT__c1__DOT__stage_n2_1 = 0;
    IData/*31:0*/ verification_top__DOT__c0__DOT__n0;
    verification_top__DOT__c0__DOT__n0 = 0;
    IData/*31:0*/ verification_top__DOT__c0__DOT__stage_n2_0;
    verification_top__DOT__c0__DOT__stage_n2_0 = 0;
    // Body
    vlSelfRef.out_16 = ((vlSelfRef.in1 + (vlSelfRef.in0 
                                          << 2U)) - 
                        (vlSelfRef.in0 >> 7U));
    vlSelfRef.out_17 = ((vlSelfRef.in1 + (vlSelfRef.in0 
                                          << 5U)) - 
                        (vlSelfRef.in0 >> 7U));
    vlSelfRef.out_18 = ((vlSelfRef.in1 + (vlSelfRef.in0 
                                          << 0x0000000dU)) 
                        - (vlSelfRef.in0 >> 7U));
    vlSelfRef.out_19 = ((vlSelfRef.in1 + (vlSelfRef.in0 
                                          << 0x00000019U)) 
                        - (vlSelfRef.in0 >> 7U));
    vlSelfRef.out_28 = (VL_LTS_III(32, vlSelfRef.in0, 
                                   ((IData)(0x0000000bU) 
                                    + vlSelfRef.in1)) 
                        ^ (vlSelfRef.in1 >> 9U));
    vlSelfRef.out_29 = (VL_LTS_III(32, vlSelfRef.in0, 
                                   ((IData)(0x0000002fU) 
                                    + vlSelfRef.in1)) 
                        ^ (vlSelfRef.in1 >> 9U));
    vlSelfRef.out_30 = (VL_LTS_III(32, vlSelfRef.in0, 
                                   ((IData)(0x000000bfU) 
                                    + vlSelfRef.in1)) 
                        ^ (vlSelfRef.in1 >> 9U));
    vlSelfRef.out_31 = ((vlSelfRef.in1 >> 9U) ^ VL_LTS_III(32, vlSelfRef.in0, 
                                                           ((IData)(0x000002ffU) 
                                                            + vlSelfRef.in1)));
    vlSelfRef.out_36 = ((vlSelfRef.in0 ^ (vlSelfRef.in1 
                                          << 2U)) & 
                        (vlSelfRef.in0 >> 3U));
    vlSelfRef.out_37 = ((vlSelfRef.in0 ^ (vlSelfRef.in1 
                                          << 7U)) & 
                        (vlSelfRef.in0 >> 3U));
    vlSelfRef.out_38 = ((vlSelfRef.in0 ^ (vlSelfRef.in1 
                                          << 0x00000012U)) 
                        & (vlSelfRef.in0 >> 3U));
    vlSelfRef.out_39 = ((vlSelfRef.in0 ^ (vlSelfRef.in1 
                                          << 0x0000001cU)) 
                        & (vlSelfRef.in0 >> 3U));
    verification_top__DOT__c32__DOT__n2 = (vlSelfRef.in0 
                                           & vlSelfRef.in1);
    verification_top__DOT__c20__DOT__n2 = (vlSelfRef.in1 
                                           - vlSelfRef.in0);
    verification_top__DOT__c14__DOT__stage_n1_0 = (
                                                   (1U 
                                                    & vlSelfRef.in0)
                                                    ? 
                                                   (vlSelfRef.in1 
                                                    << 1U)
                                                    : vlSelfRef.in1);
    verification_top__DOT__c0__DOT__n0 = (vlSelfRef.in0 
                                          + vlSelfRef.in1);
    verification_top__DOT__c4__DOT__n0 = (vlSelfRef.in0 
                                          ^ vlSelfRef.in1);
    verification_top__DOT__c8__DOT__n0 = (vlSelfRef.in0 
                                          - vlSelfRef.in1);
    vlSelfRef.out_32 = (verification_top__DOT__c32__DOT__n2 
                        ^ ((IData)(0x00000017U) * vlSelfRef.in0));
    vlSelfRef.out_33 = (verification_top__DOT__c32__DOT__n2 
                        ^ ((IData)(0x0000002fU) * vlSelfRef.in0));
    vlSelfRef.out_34 = (verification_top__DOT__c32__DOT__n2 
                        ^ ((IData)(0x0000005fU) * vlSelfRef.in0));
    vlSelfRef.out_35 = (((IData)(0x000000bfU) * vlSelfRef.in0) 
                        ^ verification_top__DOT__c32__DOT__n2);
    vlSelfRef.out_20 = (verification_top__DOT__c20__DOT__n2 
                        + (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                            >> 2U)));
    vlSelfRef.out_21 = (verification_top__DOT__c20__DOT__n2 
                        + (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                            >> 6U)));
    vlSelfRef.out_22 = (verification_top__DOT__c20__DOT__n2 
                        + (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                            >> 0x00000010U)));
    vlSelfRef.out_23 = (verification_top__DOT__c20__DOT__n2 
                        + (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                            >> 0x0000001bU)));
    verification_top__DOT__c14__DOT__stage_n1_1 = (
                                                   (2U 
                                                    & vlSelfRef.in0)
                                                    ? 
                                                   (verification_top__DOT__c14__DOT__stage_n1_0 
                                                    << 2U)
                                                    : verification_top__DOT__c14__DOT__stage_n1_0);
    if ((1U & vlSelfRef.in1)) {
        verification_top__DOT__c0__DOT__stage_n2_0 
            = (verification_top__DOT__c0__DOT__n0 << 1U);
        verification_top__DOT__c5__DOT__stage_n2_0 
            = (verification_top__DOT__c4__DOT__n0 >> 1U);
    } else {
        verification_top__DOT__c0__DOT__stage_n2_0 
            = verification_top__DOT__c0__DOT__n0;
        verification_top__DOT__c5__DOT__stage_n2_0 
            = verification_top__DOT__c4__DOT__n0;
    }
    vlSelfRef.out_4 = (((1U & vlSelfRef.in1) ? (verification_top__DOT__c4__DOT__n0 
                                                >> 1U)
                         : verification_top__DOT__c4__DOT__n0) 
                       - vlSelfRef.in0);
    vlSelfRef.out_24 = (verification_top__DOT__c4__DOT__n0 
                        | (vlSelfRef.in0 & (vlSelfRef.in1 
                                            >> 3U)));
    vlSelfRef.out_25 = (verification_top__DOT__c4__DOT__n0 
                        | (vlSelfRef.in0 & (vlSelfRef.in1 
                                            >> 8U)));
    vlSelfRef.out_26 = (verification_top__DOT__c4__DOT__n0 
                        | (vlSelfRef.in0 & (vlSelfRef.in1 
                                            >> 0x00000013U)));
    vlSelfRef.out_27 = ((vlSelfRef.in0 & (vlSelfRef.in1 
                                          >> 0x0000001aU)) 
                        | verification_top__DOT__c4__DOT__n0);
    vlSelfRef.out_12 = (verification_top__DOT__c8__DOT__n0 
                        ^ (vlSelfRef.in0 + ((1U & vlSelfRef.in0)
                                             ? (vlSelfRef.in1 
                                                << 1U)
                                             : vlSelfRef.in1)));
    vlSelfRef.out_13 = (verification_top__DOT__c8__DOT__n0 
                        ^ (vlSelfRef.in0 + ((4U & vlSelfRef.in0)
                                             ? (((1U 
                                                  & vlSelfRef.in0)
                                                  ? 
                                                 (vlSelfRef.in1 
                                                  << 1U)
                                                  : vlSelfRef.in1) 
                                                << 4U)
                                             : ((1U 
                                                 & vlSelfRef.in0)
                                                 ? 
                                                (vlSelfRef.in1 
                                                 << 1U)
                                                 : vlSelfRef.in1))));
    verification_top__DOT__c8__DOT__stage_n2_0 = ((0x80000000U 
                                                   & verification_top__DOT__c8__DOT__n0) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in1)
                                                         ? 
                                                        (verification_top__DOT__c8__DOT__n0 
                                                         >> 1U)
                                                         : verification_top__DOT__c8__DOT__n0)));
    verification_top__DOT__c14__DOT__stage_n1_2 = (
                                                   (4U 
                                                    & vlSelfRef.in0)
                                                    ? 
                                                   (verification_top__DOT__c14__DOT__stage_n1_1 
                                                    << 4U)
                                                    : verification_top__DOT__c14__DOT__stage_n1_1);
    vlSelfRef.out_0 = (vlSelfRef.in0 ^ ((2U & vlSelfRef.in1)
                                         ? (verification_top__DOT__c0__DOT__stage_n2_0 
                                            << 2U) : verification_top__DOT__c0__DOT__stage_n2_0));
    if ((2U & vlSelfRef.in1)) {
        verification_top__DOT__c1__DOT__stage_n2_1 
            = (verification_top__DOT__c0__DOT__stage_n2_0 
               << 2U);
        verification_top__DOT__c5__DOT__stage_n2_1 
            = (verification_top__DOT__c5__DOT__stage_n2_0 
               >> 2U);
        verification_top__DOT__c10__DOT__stage_n2_1 
            = (((- (IData)((verification_top__DOT__c8__DOT__n0 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c8__DOT__stage_n2_0 
                  >> 2U));
    } else {
        verification_top__DOT__c1__DOT__stage_n2_1 
            = verification_top__DOT__c0__DOT__stage_n2_0;
        verification_top__DOT__c5__DOT__stage_n2_1 
            = verification_top__DOT__c5__DOT__stage_n2_0;
        verification_top__DOT__c10__DOT__stage_n2_1 
            = verification_top__DOT__c8__DOT__stage_n2_0;
    }
    vlSelfRef.out_8 = (vlSelfRef.in1 + ((2U & vlSelfRef.in1)
                                         ? (((- (IData)(
                                                        (verification_top__DOT__c8__DOT__n0 
                                                         >> 0x0000001fU))) 
                                             << 0x0000001eU) 
                                            | (verification_top__DOT__c8__DOT__stage_n2_0 
                                               >> 2U))
                                         : verification_top__DOT__c8__DOT__stage_n2_0));
    verification_top__DOT__c14__DOT__stage_n1_3 = (
                                                   (8U 
                                                    & vlSelfRef.in0)
                                                    ? 
                                                   (verification_top__DOT__c14__DOT__stage_n1_2 
                                                    << 8U)
                                                    : verification_top__DOT__c14__DOT__stage_n1_2);
    vlSelfRef.out_1 = (vlSelfRef.in0 ^ ((4U & vlSelfRef.in1)
                                         ? (verification_top__DOT__c1__DOT__stage_n2_1 
                                            << 4U) : verification_top__DOT__c1__DOT__stage_n2_1));
    if ((4U & vlSelfRef.in1)) {
        verification_top__DOT__c2__DOT__stage_n2_2 
            = (verification_top__DOT__c1__DOT__stage_n2_1 
               << 4U);
        verification_top__DOT__c7__DOT__stage_n2_2 
            = (verification_top__DOT__c5__DOT__stage_n2_1 
               >> 4U);
        verification_top__DOT__c10__DOT__stage_n2_2 
            = (((- (IData)((verification_top__DOT__c10__DOT__stage_n2_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c10__DOT__stage_n2_1 
                  >> 4U));
    } else {
        verification_top__DOT__c2__DOT__stage_n2_2 
            = verification_top__DOT__c1__DOT__stage_n2_1;
        verification_top__DOT__c7__DOT__stage_n2_2 
            = verification_top__DOT__c5__DOT__stage_n2_1;
        verification_top__DOT__c10__DOT__stage_n2_2 
            = verification_top__DOT__c10__DOT__stage_n2_1;
    }
    if ((8U & vlSelfRef.in1)) {
        verification_top__DOT__c9__DOT__stage_n2_3 
            = (((- (IData)((((2U & vlSelfRef.in1) ? 
                             (((- (IData)((verification_top__DOT__c8__DOT__n0 
                                           >> 0x0000001fU))) 
                               << 0x0000001eU) | (verification_top__DOT__c8__DOT__stage_n2_0 
                                                  >> 2U))
                              : verification_top__DOT__c8__DOT__stage_n2_0) 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (((2U & vlSelfRef.in1) ? (((- (IData)(
                                                       (verification_top__DOT__c8__DOT__n0 
                                                        >> 0x0000001fU))) 
                                            << 0x0000001eU) 
                                           | (verification_top__DOT__c8__DOT__stage_n2_0 
                                              >> 2U))
                    : verification_top__DOT__c8__DOT__stage_n2_0) 
                  >> 8U));
        verification_top__DOT__c2__DOT__stage_n2_3 
            = (verification_top__DOT__c2__DOT__stage_n2_2 
               << 8U);
        verification_top__DOT__c7__DOT__stage_n2_3 
            = (verification_top__DOT__c7__DOT__stage_n2_2 
               >> 8U);
        verification_top__DOT__c10__DOT__stage_n2_3 
            = (((- (IData)((verification_top__DOT__c10__DOT__stage_n2_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c10__DOT__stage_n2_2 
                  >> 8U));
    } else {
        verification_top__DOT__c9__DOT__stage_n2_3 
            = ((2U & vlSelfRef.in1) ? (((- (IData)(
                                                   (verification_top__DOT__c8__DOT__n0 
                                                    >> 0x0000001fU))) 
                                        << 0x0000001eU) 
                                       | (verification_top__DOT__c8__DOT__stage_n2_0 
                                          >> 2U)) : verification_top__DOT__c8__DOT__stage_n2_0);
        verification_top__DOT__c2__DOT__stage_n2_3 
            = verification_top__DOT__c2__DOT__stage_n2_2;
        verification_top__DOT__c7__DOT__stage_n2_3 
            = verification_top__DOT__c7__DOT__stage_n2_2;
        verification_top__DOT__c10__DOT__stage_n2_3 
            = verification_top__DOT__c10__DOT__stage_n2_2;
    }
    vlSelfRef.out_5 = (((4U & vlSelfRef.in1) ? (verification_top__DOT__c5__DOT__stage_n2_1 
                                                >> 4U)
                         : verification_top__DOT__c5__DOT__stage_n2_1) 
                       - vlSelfRef.in0);
    vlSelfRef.out_6 = (((0x00000010U & vlSelfRef.in1)
                         ? (((4U & vlSelfRef.in1) ? 
                             (verification_top__DOT__c5__DOT__stage_n2_1 
                              >> 4U) : verification_top__DOT__c5__DOT__stage_n2_1) 
                            >> 0x00000010U) : ((4U 
                                                & vlSelfRef.in1)
                                                ? (verification_top__DOT__c5__DOT__stage_n2_1 
                                                   >> 4U)
                                                : verification_top__DOT__c5__DOT__stage_n2_1)) 
                       - vlSelfRef.in0);
    vlSelfRef.out_9 = (vlSelfRef.in1 + verification_top__DOT__c9__DOT__stage_n2_3);
    vlSelfRef.out_14 = (verification_top__DOT__c8__DOT__n0 
                        ^ (vlSelfRef.in0 + verification_top__DOT__c14__DOT__stage_n1_3));
    vlSelfRef.out_15 = ((vlSelfRef.in0 + ((0x00000010U 
                                           & vlSelfRef.in0)
                                           ? (verification_top__DOT__c14__DOT__stage_n1_3 
                                              << 0x00000010U)
                                           : verification_top__DOT__c14__DOT__stage_n1_3)) 
                        ^ verification_top__DOT__c8__DOT__n0);
    vlSelfRef.out_2 = (vlSelfRef.in0 ^ verification_top__DOT__c2__DOT__stage_n2_3);
    vlSelfRef.out_3 = (vlSelfRef.in0 ^ ((0x00000010U 
                                         & vlSelfRef.in1)
                                         ? (verification_top__DOT__c2__DOT__stage_n2_3 
                                            << 0x00000010U)
                                         : verification_top__DOT__c2__DOT__stage_n2_3));
    vlSelfRef.out_7 = (((0x00000010U & vlSelfRef.in1)
                         ? (verification_top__DOT__c7__DOT__stage_n2_3 
                            >> 0x00000010U) : verification_top__DOT__c7__DOT__stage_n2_3) 
                       - vlSelfRef.in0);
    vlSelfRef.out_10 = (vlSelfRef.in1 + verification_top__DOT__c10__DOT__stage_n2_3);
    vlSelfRef.out_11 = (vlSelfRef.in1 + ((0x00000010U 
                                          & vlSelfRef.in1)
                                          ? (((- (IData)(
                                                         (verification_top__DOT__c10__DOT__stage_n2_3 
                                                          >> 0x0000001fU))) 
                                              << 0x00000010U) 
                                             | (verification_top__DOT__c10__DOT__stage_n2_3 
                                                >> 0x00000010U))
                                          : verification_top__DOT__c10__DOT__stage_n2_3));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vverification_top___024root___eval_phase__ico(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_phase__ico\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__ico
        vlSelfRef.__VicoTriggered[0U] = (QData)((IData)(
                                                        (((vlSelfRef.in1 
                                                           != vlSelfRef.__Vtrigprevexpr___TOP__in1__0) 
                                                          << 1U) 
                                                         | (vlSelfRef.in0 
                                                            != vlSelfRef.__Vtrigprevexpr___TOP__in0__0))));
        vlSelfRef.__Vtrigprevexpr___TOP__in0__0 = vlSelfRef.in0;
        vlSelfRef.__Vtrigprevexpr___TOP__in1__0 = vlSelfRef.in1;
        if (VL_UNLIKELY(((1U & (~ (IData)(vlSelfRef.__VicoDidInit)))))) {
            vlSelfRef.__VicoDidInit = 1U;
            vlSelfRef.__VicoTriggered[0U] = (1ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (2ULL | vlSelfRef.__VicoTriggered[0U]);
        }
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vverification_top___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_ico
            if ((3ULL & vlSelfRef.__VicoTriggered[0U])) {
                Vverification_top___024root___ico_comb__TOP__0(vlSelf);
            }
        }
    }
    return (__VicoExecute);
}

void Vverification_top___024root___eval(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    // Body
    __VicoIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-11/can-this-run-offline/work/agentic-riscv-codesign/results/targeted-coverage-validation/raw/verification/verification.v", 1, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 10000 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = Vverification_top___024root___eval_phase__ico(vlSelf);
    } while (vlSelfRef.__VicoPhaseResult);
}

#ifdef VL_DEBUG
void Vverification_top___024root___eval_debug_assertions(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_debug_assertions\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
