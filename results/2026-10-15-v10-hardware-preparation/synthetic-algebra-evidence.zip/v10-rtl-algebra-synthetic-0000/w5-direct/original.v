module candidate(input wire [4:0] in0, in1, output wire [4:0] result);
wire [4:0] operand=in0;
wire [4:0] coefficient=5'd0 + 5'd13;
wire [4:0] product=operand * coefficient;
assign result=product;
endmodule
