module candidate(input wire [4:0] in0, in1, output wire [4:0] result);
wire [4:0] operand=(in0 & 5'd21) - in1;
wire [4:0] stage0=1'b0 ? {operand[3:0],1'b0} : operand;
wire [4:0] stage1=1'b0 ? {stage0[2:0],2'b0} : stage0;
wire [4:0] high=1'b1 ? {stage1[0:0],4'b0} : stage1;
wire [4:0] low={operand[3:0],1'b0};
wire [4:0] product=high-low-operand;
assign result=product + in1;
endmodule
