module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] operand=(in0 & 32'd21) - in1;
wire [31:0] coefficient=32'd0 + 32'd13;
wire [31:0] product=operand * coefficient;
assign result=product + in1;
endmodule
