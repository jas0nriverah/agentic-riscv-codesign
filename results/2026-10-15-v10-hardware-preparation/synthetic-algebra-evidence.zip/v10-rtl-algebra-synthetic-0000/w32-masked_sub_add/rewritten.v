module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] operand=(in0 & 32'd21) - in1;
wire [31:0] stage0=1'b0 ? {operand[30:0],1'b0} : operand;
wire [31:0] stage1=1'b0 ? {stage0[29:0],2'b0} : stage0;
wire [31:0] high=1'b1 ? {stage1[27:0],4'b0} : stage1;
wire [31:0] low={operand[30:0],1'b0};
wire [31:0] product=high-low-operand;
assign result=product + in1;
endmodule
