from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
root=Path.cwd();out=root/'generated/v10-rtl-algebra-synthetic-0000'
spec=importlib.util.spec_from_file_location('alg',root/'scripts/prove_v10_rtl_algebra.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
tools=json.loads((root/'results/2026-10-15-v10c-csd-hardware/tools.json').read_text());yosys=tools['executables']['yosys']['path'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(yosys)==tools['executables']['yosys']['sha256']
manifest={'scope':'Synthetic frontend validation only; no32study circuits, area mapping, routes or model jobs.','yosys':tools['executables']['yosys'],'checker_sha256':sha(root/'scripts/prove_v10_rtl_algebra.py'),'cases':[]}
for width in (5,32):
 for context in ('direct','masked_sub_add'):
  folder=out/f'w{width}-{context}';folder.mkdir()
  operand='in0' if context=='direct' else f"(in0 & {width}'d21) - in1"
  tail='' if context=='direct' else ' + in1'
  common=f'module candidate(input wire [{width-1}:0] in0, in1, output wire [{width-1}:0] result);\nwire [{width-1}:0] operand={operand};\n'
  orig=common+f"wire [{width-1}:0] coefficient={width}'d0 + {width}'d13;\nwire [{width-1}:0] product=operand * coefficient;\nassign result=product{tail};\nendmodule\n"
  rewrite=common+f"wire [{width-1}:0] stage0=1'b0 ? {{operand[{width-2}:0],1'b0}} : operand;\nwire [{width-1}:0] stage1=1'b0 ? {{stage0[{width-3}:0],2'b0}} : stage0;\nwire [{width-1}:0] high=1'b1 ? {{stage1[{width-5}:0],4'b0}} : stage1;\nwire [{width-1}:0] low={{operand[{width-2}:0],1'b0}};\nwire [{width-1}:0] product=high-low-operand;\nassign result=product{tail};\nendmodule\n"
  sources={'original':orig,'rewritten':rewrite,'wrong_coefficient':orig.replace(f"{width}'d13",f"{width}'d12")}
  objects={};lineage={}
  for arm,source in sources.items():
   rtl=folder/f'{arm}.v';rtl.write_text(source);net=folder/f'{arm}.json';script=folder/f'{arm}.ys'
   script.write_text(f'read_verilog "{rtl}"\nhierarchy -check -top candidate\nproc\nopt_clean\nwrite_json "{net}"\n')
   with (folder/f'{arm}.log').open('w') as f:
    completed=subprocess.run([yosys,'-s',str(script)],stdout=f,stderr=subprocess.STDOUT,timeout=30,env={'PATH':str(Path(yosys).parent)+':/usr/bin:/bin','LC_ALL':'C'})
   assert completed.returncode==0
   objects[arm]=m.load(net);lineage[arm]={p.name:sha(p) for p in (rtl,net,script,folder/f'{arm}.log')}
  proved=m.prove_pair(objects['original'],objects['rewritten'],width=width);wrong=m.prove_pair(objects['wrong_coefficient'],objects['rewritten'],width=width)
  assert proved['proved'] and not wrong['proved']
  with (folder/'proofs.json').open('x') as f:json.dump({'equivalent':proved,'wrong_coefficient':wrong},f,indent=2)
  c=m.Circuit(objects['rewritten'],width=width);n=0
  samples=((a,b) for a in range(1<<width) for b in range(1<<width)) if width==5 else ((a,b) for a in (0,1,31,63,0x7fffffff,0x80000000,0xffffffff) for b in (0,1,31,63,0x7fffffff,0x80000000,0xffffffff))
  for a,b in samples:
   expected=13*a if context=='direct' else 13*((a&21)-b)+b
   assert c.evaluate_polynomial(c.result,a,b)==expected&((1<<width)-1);n+=1
  manifest['cases'].append({'width':width,'context':context,'equivalent_proved':True,'mutant_not_proved':True,'oracle_checks':n,'lineage':lineage})
assert sha(yosys)==tools['executables']['yosys']['sha256'];assert sha(root/'scripts/prove_v10_rtl_algebra.py')==manifest['checker_sha256']
manifest['native_frontend_jobs']=12;manifest['script_sha256']=sha(__file__)
with (out/'review.json').open('x') as f:json.dump(manifest,f,indent=2)
print(json.dumps({'status':'pass','native_frontend_jobs':12,'equivalent_pairs':4,'mutants_not_proved':4,'oracle_checks':sum(x['oracle_checks'] for x in manifest['cases'])}))
