module candidate(input wire [31:0] in0,in1,output wire [31:0] result); assign result=in0 ^ in1; endmodule
