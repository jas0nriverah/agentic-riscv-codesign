module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 - in0;
wire [31:0] n1 = n0 & 32'h000003e6;
wire [31:0] n2 = n1 + 32'h00000002;
assign result = n2;
endmodule
