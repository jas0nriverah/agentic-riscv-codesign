	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.foo,"ax",@progbits
	.align	2
	.globl	foo
	.type	foo, @function
foo:
	addi	sp,sp,-32
	mv	a1,a0
	sw	ra,28(sp)
	sw	a0,12(sp)
	call	__mulsi3
	lw	a1,12(sp)
	lw	ra,28(sp)
	slli	a5,a1,3
	add	a0,a0,a5
	li	a5,4
	sub	a5,a5,a1
	sll	a0,a0,a5
	addi	sp,sp,32
	jr	ra
	.size	foo, .-foo
	.section	.text.expint,"ax",@progbits
	.align	2
	.globl	expint
	.type	expint, @function
expint:
	addi	sp,sp,-48
	sw	s1,36(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	ra,44(sp)
	sw	s0,40(sp)
	sw	s2,32(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	s7,12(sp)
	sw	s8,8(sp)
	sw	s9,4(sp)
	sw	s10,0(sp)
	li	s1,1
	mv	s3,a1
	addi	s4,a0,-1
	ble	a1,s1,.L4
	li	s0,29999104
	addi	s0,s0,896
	li	s2,1998848
	li	s8,8192
	add	s6,a0,a1
	li	s5,-1
	mv	s1,s0
	addi	s2,s2,1152
	addi	s8,s8,1807
	li	s9,-101
.L7:
	mv	a1,s5
	sub	a0,s4,s5
	call	__mulsi3
	mv	a1,s1
	slli	s7,s5,1
	sub	s7,s6,s7
	mv	s10,a0
	call	__mulsi3
	add	a0,a0,s7
	slli	s1,a0,2
	mv	a1,s2
	add	s1,s1,a0
	mv	a0,s10
	call	__divsi3
	add	s2,a0,s7
	slli	s1,s1,1
	mv	a1,s2
	mv	a0,s1
	call	__mulsi3
	mv	a1,a0
	mv	s7,a0
	mv	a0,s0
	call	__mulsi3
	mv	s0,a0
	bgt	s7,s8,.L5
	mv	a1,a0
	neg	a0,s3
	call	__mulsi3
	mv	s0,a0
.L3:
	lw	ra,44(sp)
	mv	a0,s0
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	lw	s7,12(sp)
	lw	s8,8(sp)
	lw	s9,4(sp)
	lw	s10,0(sp)
	addi	sp,sp,48
	jr	ra
.L5:
	addi	s5,s5,-1
	bne	s5,s9,.L7
	li	s0,0
	j	.L3
.L4:
	seqz	s0,s4
	neg	s0,s0
	andi	s0,s0,998
	addi	s0,s0,2
	mv	s2,s1
	sub	s5,s1,a0
	li	s7,101
.L11:
	mv	a1,s2
	neg	a0,s3
	call	__divsi3
	mv	a1,a0
	mv	a0,s1
	call	__mulsi3
	mv	s1,a0
	beq	s4,s2,.L13
	add	a1,s5,s2
	neg	a0,a0
	call	__divsi3
.L10:
	addi	s2,s2,1
	add	s0,s0,a0
	bne	s2,s7,.L11
	j	.L3
.L13:
	li	s8,255
	li	a5,1
.L9:
	add	a4,a5,s2
	addi	a5,a5,1
	add	s8,s8,a4
	ble	a5,s2,.L9
	mv	a0,s3
	call	foo
	mv	a1,s1
	call	__mulsi3
	add	a0,a0,s8
	j	.L10
	.size	expint, .-expint
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a5,%hi(x)
	lw	a1,%lo(x)(a5)
	lui	a5,%hi(n)
	lw	a0,%lo(n)(a5)
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	expint
	lw	ra,12(sp)
	lui	a5,%hi(benchmark_result)
	sw	a0,%lo(benchmark_result)(a5)
	lw	a0,%lo(benchmark_result)(a5)
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(n)
	li	a4,50
	sw	a4,%lo(n)(a5)
	lui	a5,%hi(x)
	li	a4,1
	sw	a4,%lo(x)(a5)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-2048
	addi	a0,a0,-1835
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.bss.x,"aw",@nobits
	.align	2
	.type	x, @object
	.size	x, 4
x:
	.zero	4
	.section	.bss.n,"aw",@nobits
	.align	2
	.type	n, @object
	.size	n, 4
n:
	.zero	4
	.globl	benchmark_result
	.section	.bss.benchmark_result,"aw",@nobits
	.align	2
	.type	benchmark_result, @object
	.size	benchmark_result, 4
benchmark_result:
	.zero	4
	.globl	__divsi3
	.globl	__mulsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
