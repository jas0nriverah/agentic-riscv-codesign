// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vverification_top.h for the primary calling header

#include "Vverification_top__pch.h"

bool Vverification_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((2U > n));
    return (0U);
}

void Vverification_top___024root___ico_comb__TOP__0(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___ico_comb__TOP__0\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ verification_top__DOT__c31__DOT__stage_n5_1;
    verification_top__DOT__c31__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c31__DOT__stage_n5_2;
    verification_top__DOT__c31__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c31__DOT__stage_n5_3;
    verification_top__DOT__c31__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c30__DOT__stage_n5_0;
    verification_top__DOT__c30__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c29__DOT__stage_n5_0;
    verification_top__DOT__c29__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c29__DOT__stage_n5_1;
    verification_top__DOT__c29__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c29__DOT__stage_n5_2;
    verification_top__DOT__c29__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c29__DOT__stage_n5_3;
    verification_top__DOT__c29__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c27__DOT__stage_n7_2;
    verification_top__DOT__c27__DOT__stage_n7_2 = 0;
    IData/*31:0*/ verification_top__DOT__c27__DOT__stage_n7_3;
    verification_top__DOT__c27__DOT__stage_n7_3 = 0;
    IData/*31:0*/ verification_top__DOT__c26__DOT__stage_n7_1;
    verification_top__DOT__c26__DOT__stage_n7_1 = 0;
    IData/*31:0*/ verification_top__DOT__c25__DOT__stage_n7_0;
    verification_top__DOT__c25__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c23__DOT__stage_n6_2;
    verification_top__DOT__c23__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c23__DOT__stage_n6_3;
    verification_top__DOT__c23__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c22__DOT__stage_n6_1;
    verification_top__DOT__c22__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c21__DOT__stage_n6_0;
    verification_top__DOT__c21__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c19__DOT__stage_n6_2;
    verification_top__DOT__c19__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c19__DOT__stage_n6_3;
    verification_top__DOT__c19__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c18__DOT__stage_n6_1;
    verification_top__DOT__c18__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c17__DOT__stage_n6_0;
    verification_top__DOT__c17__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_2;
    verification_top__DOT__c15__DOT__stage_n7_2 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_3;
    verification_top__DOT__c15__DOT__stage_n7_3 = 0;
    IData/*31:0*/ verification_top__DOT__c14__DOT__stage_n7_1;
    verification_top__DOT__c14__DOT__stage_n7_1 = 0;
    IData/*31:0*/ verification_top__DOT__c13__DOT__stage_n7_0;
    verification_top__DOT__c13__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n5_2;
    verification_top__DOT__c11__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n5_3;
    verification_top__DOT__c11__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c10__DOT__stage_n5_1;
    verification_top__DOT__c10__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n5_0;
    verification_top__DOT__c9__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n6_2;
    verification_top__DOT__c7__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n6_3;
    verification_top__DOT__c7__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c6__DOT__stage_n6_1;
    verification_top__DOT__c6__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n6_0;
    verification_top__DOT__c5__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c4__DOT__n0;
    verification_top__DOT__c4__DOT__n0 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n5_2;
    verification_top__DOT__c3__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n5_3;
    verification_top__DOT__c3__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c2__DOT__stage_n5_1;
    verification_top__DOT__c2__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n5_0;
    verification_top__DOT__c1__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c0__DOT__n0;
    verification_top__DOT__c0__DOT__n0 = 0;
    IData/*31:0*/ verification_top__DOT__c0__DOT__n7;
    verification_top__DOT__c0__DOT__n7 = 0;
    // Body
    vlSelfRef.out_16 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((0x80000000U 
                                             & ((IData)(0x0000004fU) 
                                                + (0xff000000U 
                                                   & (0x11000000U 
                                                      ^ 
                                                      (vlSelfRef.in0 
                                                       << 0x00000018U))))) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & vlSelfRef.in1)
                                                   ? 
                                                  ((IData)(0x0000004fU) 
                                                   + 
                                                   (0x7f000000U 
                                                    & (0x11000000U 
                                                       ^ 
                                                       (vlSelfRef.in0 
                                                        << 0x00000018U))))
                                                   : 
                                                  (((IData)(0x0000004fU) 
                                                    + 
                                                    (0xff000000U 
                                                     & (0x11000000U 
                                                        ^ 
                                                        (vlSelfRef.in0 
                                                         << 0x00000018U)))) 
                                                   >> 1U))))));
    verification_top__DOT__c29__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000004fU) 
                                                       + 
                                                       (0x00000011U 
                                                        ^ vlSelfRef.in0))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         ((IData)(0x0000004fU) 
                                                          + 
                                                          (0x00000011U 
                                                           ^ vlSelfRef.in0))
                                                          : 
                                                         (((IData)(0x0000004fU) 
                                                           + 
                                                           (0x00000011U 
                                                            ^ vlSelfRef.in0)) 
                                                          >> 1U))));
    verification_top__DOT__c17__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000004fU) 
                                                       + 
                                                       (0xff000000U 
                                                        & (0x11000000U 
                                                           ^ 
                                                           (vlSelfRef.in0 
                                                            << 0x00000018U))))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in1)
                                                          ? 
                                                         ((IData)(0x0000004fU) 
                                                          + 
                                                          (0x7f000000U 
                                                           & (0x11000000U 
                                                              ^ 
                                                              (vlSelfRef.in0 
                                                               << 0x00000018U))))
                                                          : 
                                                         (((IData)(0x0000004fU) 
                                                           + 
                                                           (0xff000000U 
                                                            & (0x11000000U 
                                                               ^ 
                                                               (vlSelfRef.in0 
                                                                << 0x00000018U)))) 
                                                          >> 1U))));
    verification_top__DOT__c21__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x0000004fU) 
                                                        + vlSelfRef.in1) 
                                                       << 0x00000018U)) 
                                                   | ((1U 
                                                       & vlSelfRef.in0)
                                                       ? 
                                                      (0x7f000000U 
                                                       & (0x11000000U 
                                                          ^ 
                                                          (((IData)(0x4fU) 
                                                            + vlSelfRef.in1) 
                                                           << 0x00000018U)))
                                                       : 
                                                      (0x7f800000U 
                                                       & (0x08800000U 
                                                          ^ 
                                                          (0x7f800000U 
                                                           & (((IData)(0x0000004fU) 
                                                               + vlSelfRef.in1) 
                                                              << 0x00000017U))))));
    verification_top__DOT__c0__DOT__n7 = (vlSelfRef.in0 
                                          ^ vlSelfRef.in1);
    verification_top__DOT__c4__DOT__n0 = (vlSelfRef.in0 
                                          | vlSelfRef.in1);
    verification_top__DOT__c0__DOT__n0 = (vlSelfRef.in0 
                                          & vlSelfRef.in1);
    vlSelfRef.out_17 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((2U & vlSelfRef.in1)
                                             ? verification_top__DOT__c17__DOT__stage_n6_0
                                             : (((- (IData)(
                                                            (((IData)(0x0000004fU) 
                                                              + 
                                                              (0xff000000U 
                                                               & (0x11000000U 
                                                                  ^ 
                                                                  (vlSelfRef.in0 
                                                                   << 0x00000018U)))) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c17__DOT__stage_n6_0 
                                                   >> 2U)))));
    verification_top__DOT__c9__DOT__stage_n5_0 = ((0x80000000U 
                                                   & ((IData)(0x0000004fU) 
                                                      + verification_top__DOT__c0__DOT__n7)) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in0)
                                                         ? 
                                                        (0x00000011U 
                                                         ^ 
                                                         ((IData)(0x0000004fU) 
                                                          + verification_top__DOT__c0__DOT__n7))
                                                         : 
                                                        (8U 
                                                         ^ 
                                                         (((IData)(0x0000004fU) 
                                                           + verification_top__DOT__c0__DOT__n7) 
                                                          >> 1U)))));
    vlSelfRef.out_24 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x80000000U 
                                             & (((IData)(0x0000004fU) 
                                                 + verification_top__DOT__c4__DOT__n0) 
                                                << 0x00000010U)) 
                                            | ((1U 
                                                & vlSelfRef.in1)
                                                ? (0x00000011U 
                                                   ^ 
                                                   (0x7fff0000U 
                                                    & (((IData)(0x0000004fU) 
                                                        + verification_top__DOT__c4__DOT__n0) 
                                                       << 0x00000010U)))
                                                : (8U 
                                                   ^ 
                                                   (0x7fff8000U 
                                                    & (((IData)(0x0000004fU) 
                                                        + verification_top__DOT__c4__DOT__n0) 
                                                       << 0x0000000fU)))))));
    vlSelfRef.out_28 = (verification_top__DOT__c4__DOT__n0 
                        ^ (vlSelfRef.in1 + ((0x80000000U 
                                             & ((IData)(0x0000004fU) 
                                                + (0x00000011U 
                                                   ^ vlSelfRef.in0))) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & ((IData)(1U) 
                                                      + vlSelfRef.in1))
                                                   ? 
                                                  ((IData)(0x0000004fU) 
                                                   + 
                                                   (0x00000011U 
                                                    ^ vlSelfRef.in0))
                                                   : 
                                                  (((IData)(0x0000004fU) 
                                                    + 
                                                    (0x00000011U 
                                                     ^ vlSelfRef.in0)) 
                                                   >> 1U))))));
    vlSelfRef.out_4 = ((vlSelfRef.in0 + ((0x80000000U 
                                          & ((IData)(0x0000004fU) 
                                             + (0x00000011U 
                                                ^ verification_top__DOT__c4__DOT__n0))) 
                                         | (0x7fffffffU 
                                            & ((1U 
                                                & ((IData)(1U) 
                                                   + vlSelfRef.in1))
                                                ? ((IData)(0x0000004fU) 
                                                   + 
                                                   (0x00000011U 
                                                    ^ verification_top__DOT__c4__DOT__n0))
                                                : (
                                                   ((IData)(0x0000004fU) 
                                                    + 
                                                    (0x00000011U 
                                                     ^ verification_top__DOT__c4__DOT__n0)) 
                                                   >> 1U))))) 
                       ^ verification_top__DOT__c0__DOT__n7);
    verification_top__DOT__c25__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x0000004fU) 
                                                        + verification_top__DOT__c4__DOT__n0) 
                                                       << 0x00000010U)) 
                                                   | ((1U 
                                                       & vlSelfRef.in1)
                                                       ? 
                                                      (0x00000011U 
                                                       ^ 
                                                       (0x7fff0000U 
                                                        & (((IData)(0x0000004fU) 
                                                            + verification_top__DOT__c4__DOT__n0) 
                                                           << 0x00000010U)))
                                                       : 
                                                      (8U 
                                                       ^ 
                                                       (0x7fff8000U 
                                                        & (((IData)(0x0000004fU) 
                                                            + verification_top__DOT__c4__DOT__n0) 
                                                           << 0x0000000fU)))));
    if ((2U & vlSelfRef.in1)) {
        verification_top__DOT__c18__DOT__stage_n6_1 
            = verification_top__DOT__c17__DOT__stage_n6_0;
        verification_top__DOT__c26__DOT__stage_n7_1 
            = verification_top__DOT__c25__DOT__stage_n7_0;
    } else {
        verification_top__DOT__c18__DOT__stage_n6_1 
            = (((- (IData)((((IData)(0x0000004fU) + 
                             (0xff000000U & (0x11000000U 
                                             ^ (vlSelfRef.in0 
                                                << 0x00000018U)))) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c17__DOT__stage_n6_0 
                  >> 2U));
        verification_top__DOT__c26__DOT__stage_n7_1 
            = (((- (IData)((1U & (((IData)(0x0000004fU) 
                                   + verification_top__DOT__c4__DOT__n0) 
                                  >> 0x0000000fU)))) 
                << 0x0000001eU) | (verification_top__DOT__c25__DOT__stage_n7_0 
                                   >> 2U));
    }
    verification_top__DOT__c5__DOT__stage_n6_0 = ((0x80000000U 
                                                   & ((IData)(0x0000004fU) 
                                                      + 
                                                      (0x00000011U 
                                                       ^ verification_top__DOT__c4__DOT__n0))) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & ((IData)(1U) 
                                                            + vlSelfRef.in1))
                                                         ? 
                                                        ((IData)(0x0000004fU) 
                                                         + 
                                                         (0x00000011U 
                                                          ^ verification_top__DOT__c4__DOT__n0))
                                                         : 
                                                        (((IData)(0x0000004fU) 
                                                          + 
                                                          (0x00000011U 
                                                           ^ verification_top__DOT__c4__DOT__n0)) 
                                                         >> 1U))));
    if ((2U & ((IData)(5U) + vlSelfRef.in1))) {
        verification_top__DOT__c29__DOT__stage_n5_1 
            = verification_top__DOT__c29__DOT__stage_n5_0;
        verification_top__DOT__c6__DOT__stage_n6_1 
            = verification_top__DOT__c5__DOT__stage_n6_0;
    } else {
        verification_top__DOT__c29__DOT__stage_n5_1 
            = (((- (IData)((((IData)(0x0000004fU) + 
                             (0x00000011U ^ vlSelfRef.in0)) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c29__DOT__stage_n5_0 
                  >> 2U));
        verification_top__DOT__c6__DOT__stage_n6_1 
            = (((- (IData)((((IData)(0x0000004fU) + 
                             (0x00000011U ^ verification_top__DOT__c4__DOT__n0)) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c5__DOT__stage_n6_0 
                  >> 2U));
    }
    vlSelfRef.out_8 = (verification_top__DOT__c0__DOT__n0 
                       ^ (verification_top__DOT__c0__DOT__n7 
                          + ((0x80000000U & ((IData)(0x0000004fU) 
                                             + verification_top__DOT__c0__DOT__n7)) 
                             | (0x7fffffffU & ((1U 
                                                & vlSelfRef.in0)
                                                ? (0x00000011U 
                                                   ^ 
                                                   ((IData)(0x0000004fU) 
                                                    + verification_top__DOT__c0__DOT__n7))
                                                : (8U 
                                                   ^ 
                                                   (((IData)(0x0000004fU) 
                                                     + verification_top__DOT__c0__DOT__n7) 
                                                    >> 1U)))))));
    vlSelfRef.out_12 = (vlSelfRef.in1 ^ (verification_top__DOT__c0__DOT__n0 
                                         + ((0x80000000U 
                                             & (((IData)(0x0000004fU) 
                                                 + 
                                                 (0x00000011U 
                                                  ^ verification_top__DOT__c0__DOT__n0)) 
                                                << 0x00000010U)) 
                                            | ((1U 
                                                & ((IData)(1U) 
                                                   + vlSelfRef.in0))
                                                ? (0x7fff8000U 
                                                   & (((IData)(0x0000004fU) 
                                                       + 
                                                       (0x00000011U 
                                                        ^ verification_top__DOT__c0__DOT__n0)) 
                                                      << 0x0000000fU))
                                                : (0x7fff0000U 
                                                   & (((IData)(0x004fU) 
                                                       + 
                                                       (0x0011U 
                                                        ^ verification_top__DOT__c0__DOT__n0)) 
                                                      << 0x00000010U))))));
    vlSelfRef.out_20 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.in0 + ((0x80000000U 
                                             & (((IData)(0x0000004fU) 
                                                 + vlSelfRef.in1) 
                                                << 0x00000018U)) 
                                            | ((1U 
                                                & vlSelfRef.in0)
                                                ? (0x7f000000U 
                                                   & (0x11000000U 
                                                      ^ 
                                                      (((IData)(0x4fU) 
                                                        + vlSelfRef.in1) 
                                                       << 0x00000018U)))
                                                : (0x7f800000U 
                                                   & (0x08800000U 
                                                      ^ 
                                                      (0x7f800000U 
                                                       & (((IData)(0x0000004fU) 
                                                           + vlSelfRef.in1) 
                                                          << 0x00000017U))))))));
    vlSelfRef.out_0 = ((vlSelfRef.in1 + ((0x80000000U 
                                          & ((IData)(0x0000004fU) 
                                             + verification_top__DOT__c0__DOT__n0)) 
                                         | (0x7fffffffU 
                                            & ((1U 
                                                & vlSelfRef.in0)
                                                ? (0x00000011U 
                                                   ^ 
                                                   ((IData)(0x0000004fU) 
                                                    + verification_top__DOT__c0__DOT__n0))
                                                : (8U 
                                                   ^ 
                                                   (((IData)(0x0000004fU) 
                                                     + verification_top__DOT__c0__DOT__n0) 
                                                    >> 1U)))))) 
                       ^ verification_top__DOT__c0__DOT__n7);
    vlSelfRef.out_21 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.in0 + ((2U & vlSelfRef.in0)
                                             ? verification_top__DOT__c21__DOT__stage_n6_0
                                             : (((- (IData)(
                                                            (1U 
                                                             & (((IData)(0x0000004fU) 
                                                                 + vlSelfRef.in1) 
                                                                >> 7U)))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c21__DOT__stage_n6_0 
                                                   >> 2U)))));
    verification_top__DOT__c30__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000004fU) 
                                                       + 
                                                       (0x00000011U 
                                                        ^ vlSelfRef.in0))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c0__DOT__n0)
                                                          ? 
                                                         ((IData)(0x0000004fU) 
                                                          + 
                                                          (0x00000011U 
                                                           ^ vlSelfRef.in0))
                                                          : 
                                                         (((IData)(0x0000004fU) 
                                                           + 
                                                           (0x00000011U 
                                                            ^ vlSelfRef.in0)) 
                                                          >> 1U))));
    verification_top__DOT__c13__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x0000004fU) 
                                                        + 
                                                        (0x00000011U 
                                                         ^ verification_top__DOT__c0__DOT__n0)) 
                                                       << 0x00000010U)) 
                                                   | ((1U 
                                                       & ((IData)(1U) 
                                                          + vlSelfRef.in0))
                                                       ? 
                                                      (0x7fff8000U 
                                                       & (((IData)(0x0000004fU) 
                                                           + 
                                                           (0x00000011U 
                                                            ^ verification_top__DOT__c0__DOT__n0)) 
                                                          << 0x0000000fU))
                                                       : 
                                                      (0x7fff0000U 
                                                       & (((IData)(0x004fU) 
                                                           + 
                                                           (0x0011U 
                                                            ^ verification_top__DOT__c0__DOT__n0)) 
                                                          << 0x00000010U))));
    verification_top__DOT__c1__DOT__stage_n5_0 = ((0x80000000U 
                                                   & ((IData)(0x0000004fU) 
                                                      + verification_top__DOT__c0__DOT__n0)) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in0)
                                                         ? 
                                                        (0x00000011U 
                                                         ^ 
                                                         ((IData)(0x0000004fU) 
                                                          + verification_top__DOT__c0__DOT__n0))
                                                         : 
                                                        (8U 
                                                         ^ 
                                                         (((IData)(0x0000004fU) 
                                                           + verification_top__DOT__c0__DOT__n0) 
                                                          >> 1U)))));
    if ((2U & vlSelfRef.in0)) {
        verification_top__DOT__c22__DOT__stage_n6_1 
            = verification_top__DOT__c21__DOT__stage_n6_0;
        verification_top__DOT__c10__DOT__stage_n5_1 
            = verification_top__DOT__c9__DOT__stage_n5_0;
        verification_top__DOT__c2__DOT__stage_n5_1 
            = verification_top__DOT__c1__DOT__stage_n5_0;
    } else {
        verification_top__DOT__c22__DOT__stage_n6_1 
            = (((- (IData)((1U & (((IData)(0x0000004fU) 
                                   + vlSelfRef.in1) 
                                  >> 7U)))) << 0x0000001eU) 
               | (verification_top__DOT__c21__DOT__stage_n6_0 
                  >> 2U));
        verification_top__DOT__c10__DOT__stage_n5_1 
            = (((- (IData)((((IData)(0x0000004fU) + verification_top__DOT__c0__DOT__n7) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c9__DOT__stage_n5_0 
                  >> 2U));
        verification_top__DOT__c2__DOT__stage_n5_1 
            = (((- (IData)((((IData)(0x0000004fU) + verification_top__DOT__c0__DOT__n0) 
                            >> 0x0000001fU))) << 0x0000001eU) 
               | (verification_top__DOT__c1__DOT__stage_n5_0 
                  >> 2U));
    }
    if ((4U & ((IData)(5U) + vlSelfRef.in1))) {
        verification_top__DOT__c29__DOT__stage_n5_2 
            = verification_top__DOT__c29__DOT__stage_n5_1;
        verification_top__DOT__c7__DOT__stage_n6_2 
            = verification_top__DOT__c6__DOT__stage_n6_1;
    } else {
        verification_top__DOT__c29__DOT__stage_n5_2 
            = (((- (IData)((verification_top__DOT__c29__DOT__stage_n5_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c29__DOT__stage_n5_1 
                  >> 4U));
        verification_top__DOT__c7__DOT__stage_n6_2 
            = (((- (IData)((verification_top__DOT__c6__DOT__stage_n6_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c6__DOT__stage_n6_1 
                  >> 4U));
    }
    vlSelfRef.out_18 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((4U & vlSelfRef.in1)
                                             ? verification_top__DOT__c18__DOT__stage_n6_1
                                             : (((- (IData)(
                                                            (verification_top__DOT__c18__DOT__stage_n6_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c18__DOT__stage_n6_1 
                                                   >> 4U)))));
    if ((4U & vlSelfRef.in1)) {
        verification_top__DOT__c19__DOT__stage_n6_2 
            = verification_top__DOT__c18__DOT__stage_n6_1;
        verification_top__DOT__c27__DOT__stage_n7_2 
            = verification_top__DOT__c26__DOT__stage_n7_1;
    } else {
        verification_top__DOT__c19__DOT__stage_n6_2 
            = (((- (IData)((verification_top__DOT__c18__DOT__stage_n6_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c18__DOT__stage_n6_1 
                  >> 4U));
        verification_top__DOT__c27__DOT__stage_n7_2 
            = (((- (IData)((verification_top__DOT__c26__DOT__stage_n7_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c26__DOT__stage_n7_1 
                  >> 4U));
    }
    vlSelfRef.out_22 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.in0 + ((4U & vlSelfRef.in0)
                                             ? verification_top__DOT__c22__DOT__stage_n6_1
                                             : (((- (IData)(
                                                            (verification_top__DOT__c22__DOT__stage_n6_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c22__DOT__stage_n6_1 
                                                   >> 4U)))));
    if ((4U & vlSelfRef.in0)) {
        verification_top__DOT__c23__DOT__stage_n6_2 
            = verification_top__DOT__c22__DOT__stage_n6_1;
        verification_top__DOT__c11__DOT__stage_n5_2 
            = verification_top__DOT__c10__DOT__stage_n5_1;
        verification_top__DOT__c3__DOT__stage_n5_2 
            = verification_top__DOT__c2__DOT__stage_n5_1;
    } else {
        verification_top__DOT__c23__DOT__stage_n6_2 
            = (((- (IData)((verification_top__DOT__c22__DOT__stage_n6_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c22__DOT__stage_n6_1 
                  >> 4U));
        verification_top__DOT__c11__DOT__stage_n5_2 
            = (((- (IData)((verification_top__DOT__c10__DOT__stage_n5_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c10__DOT__stage_n5_1 
                  >> 4U));
        verification_top__DOT__c3__DOT__stage_n5_2 
            = (((- (IData)((verification_top__DOT__c2__DOT__stage_n5_1 
                            >> 0x0000001fU))) << 0x0000001cU) 
               | (verification_top__DOT__c2__DOT__stage_n5_1 
                  >> 4U));
    }
    vlSelfRef.out_9 = (verification_top__DOT__c0__DOT__n0 
                       ^ (verification_top__DOT__c0__DOT__n7 
                          + ((2U & vlSelfRef.in0) ? verification_top__DOT__c9__DOT__stage_n5_0
                              : (((- (IData)((((IData)(0x0000004fU) 
                                               + verification_top__DOT__c0__DOT__n7) 
                                              >> 0x0000001fU))) 
                                  << 0x0000001eU) | 
                                 (verification_top__DOT__c9__DOT__stage_n5_0 
                                  >> 2U)))));
    vlSelfRef.out_25 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & vlSelfRef.in1)
                                             ? verification_top__DOT__c25__DOT__stage_n7_0
                                             : (((- (IData)(
                                                            (1U 
                                                             & (((IData)(0x0000004fU) 
                                                                 + verification_top__DOT__c4__DOT__n0) 
                                                                >> 0x0000000fU)))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c25__DOT__stage_n7_0 
                                                   >> 2U)))));
    vlSelfRef.out_5 = ((vlSelfRef.in0 + ((2U & ((IData)(5U) 
                                                + vlSelfRef.in1))
                                          ? verification_top__DOT__c5__DOT__stage_n6_0
                                          : (((- (IData)(
                                                         (((IData)(0x0000004fU) 
                                                           + 
                                                           (0x00000011U 
                                                            ^ verification_top__DOT__c4__DOT__n0)) 
                                                          >> 0x0000001fU))) 
                                              << 0x0000001eU) 
                                             | (verification_top__DOT__c5__DOT__stage_n6_0 
                                                >> 2U)))) 
                       ^ verification_top__DOT__c0__DOT__n7);
    vlSelfRef.out_30 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((2U & verification_top__DOT__c0__DOT__n0)
                                             ? verification_top__DOT__c30__DOT__stage_n5_0
                                             : (((- (IData)(
                                                            (((IData)(0x0000004fU) 
                                                              + 
                                                              (0x00000011U 
                                                               ^ vlSelfRef.in0)) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c30__DOT__stage_n5_0 
                                                   >> 2U)))));
    verification_top__DOT__c31__DOT__stage_n5_1 = (
                                                   (2U 
                                                    & verification_top__DOT__c0__DOT__n0)
                                                    ? verification_top__DOT__c30__DOT__stage_n5_0
                                                    : 
                                                   (((- (IData)(
                                                                (((IData)(0x0000004fU) 
                                                                  + 
                                                                  (0x00000011U 
                                                                   ^ vlSelfRef.in0)) 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c30__DOT__stage_n5_0 
                                                       >> 2U)));
    vlSelfRef.out_13 = (vlSelfRef.in1 ^ (verification_top__DOT__c0__DOT__n0 
                                         + ((2U & ((IData)(9U) 
                                                   + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (1U 
                                                             & (((IData)(0x0000004fU) 
                                                                 + 
                                                                 (0x00000011U 
                                                                  ^ verification_top__DOT__c0__DOT__n0)) 
                                                                >> 0x0000000fU)))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c13__DOT__stage_n7_0 
                                                   >> 2U))
                                             : verification_top__DOT__c13__DOT__stage_n7_0)));
    verification_top__DOT__c14__DOT__stage_n7_1 = (
                                                   (2U 
                                                    & ((IData)(9U) 
                                                       + vlSelfRef.in0))
                                                    ? 
                                                   (((- (IData)(
                                                                (1U 
                                                                 & (((IData)(0x0000004fU) 
                                                                     + 
                                                                     (0x00000011U 
                                                                      ^ verification_top__DOT__c0__DOT__n0)) 
                                                                    >> 0x0000000fU)))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c13__DOT__stage_n7_0 
                                                       >> 2U))
                                                    : verification_top__DOT__c13__DOT__stage_n7_0);
    vlSelfRef.out_1 = ((vlSelfRef.in1 + ((2U & vlSelfRef.in0)
                                          ? verification_top__DOT__c1__DOT__stage_n5_0
                                          : (((- (IData)(
                                                         (((IData)(0x0000004fU) 
                                                           + verification_top__DOT__c0__DOT__n0) 
                                                          >> 0x0000001fU))) 
                                              << 0x0000001eU) 
                                             | (verification_top__DOT__c1__DOT__stage_n5_0 
                                                >> 2U)))) 
                       ^ verification_top__DOT__c0__DOT__n7);
    if ((8U & ((IData)(5U) + vlSelfRef.in1))) {
        verification_top__DOT__c29__DOT__stage_n5_3 
            = verification_top__DOT__c29__DOT__stage_n5_2;
        verification_top__DOT__c7__DOT__stage_n6_3 
            = verification_top__DOT__c7__DOT__stage_n6_2;
    } else {
        verification_top__DOT__c29__DOT__stage_n5_3 
            = (((- (IData)((verification_top__DOT__c29__DOT__stage_n5_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c29__DOT__stage_n5_2 
                  >> 8U));
        verification_top__DOT__c7__DOT__stage_n6_3 
            = (((- (IData)((verification_top__DOT__c7__DOT__stage_n6_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c7__DOT__stage_n6_2 
                  >> 8U));
    }
    if ((8U & vlSelfRef.in1)) {
        verification_top__DOT__c19__DOT__stage_n6_3 
            = verification_top__DOT__c19__DOT__stage_n6_2;
        verification_top__DOT__c27__DOT__stage_n7_3 
            = verification_top__DOT__c27__DOT__stage_n7_2;
    } else {
        verification_top__DOT__c19__DOT__stage_n6_3 
            = (((- (IData)((verification_top__DOT__c19__DOT__stage_n6_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c19__DOT__stage_n6_2 
                  >> 8U));
        verification_top__DOT__c27__DOT__stage_n7_3 
            = (((- (IData)((verification_top__DOT__c27__DOT__stage_n7_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c27__DOT__stage_n7_2 
                  >> 8U));
    }
    if ((8U & vlSelfRef.in0)) {
        verification_top__DOT__c23__DOT__stage_n6_3 
            = verification_top__DOT__c23__DOT__stage_n6_2;
        verification_top__DOT__c11__DOT__stage_n5_3 
            = verification_top__DOT__c11__DOT__stage_n5_2;
        verification_top__DOT__c3__DOT__stage_n5_3 
            = verification_top__DOT__c3__DOT__stage_n5_2;
    } else {
        verification_top__DOT__c23__DOT__stage_n6_3 
            = (((- (IData)((verification_top__DOT__c23__DOT__stage_n6_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c23__DOT__stage_n6_2 
                  >> 8U));
        verification_top__DOT__c11__DOT__stage_n5_3 
            = (((- (IData)((verification_top__DOT__c11__DOT__stage_n5_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c11__DOT__stage_n5_2 
                  >> 8U));
        verification_top__DOT__c3__DOT__stage_n5_3 
            = (((- (IData)((verification_top__DOT__c3__DOT__stage_n5_2 
                            >> 0x0000001fU))) << 0x00000018U) 
               | (verification_top__DOT__c3__DOT__stage_n5_2 
                  >> 8U));
    }
    vlSelfRef.out_10 = (verification_top__DOT__c0__DOT__n0 
                        ^ (verification_top__DOT__c0__DOT__n7 
                           + ((4U & vlSelfRef.in0) ? verification_top__DOT__c10__DOT__stage_n5_1
                               : (((- (IData)((verification_top__DOT__c10__DOT__stage_n5_1 
                                               >> 0x0000001fU))) 
                                   << 0x0000001cU) 
                                  | (verification_top__DOT__c10__DOT__stage_n5_1 
                                     >> 4U)))));
    vlSelfRef.out_26 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((4U & vlSelfRef.in1)
                                             ? verification_top__DOT__c26__DOT__stage_n7_1
                                             : (((- (IData)(
                                                            (verification_top__DOT__c26__DOT__stage_n7_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c26__DOT__stage_n7_1 
                                                   >> 4U)))));
    vlSelfRef.out_6 = ((vlSelfRef.in0 + ((4U & ((IData)(5U) 
                                                + vlSelfRef.in1))
                                          ? verification_top__DOT__c6__DOT__stage_n6_1
                                          : (((- (IData)(
                                                         (verification_top__DOT__c6__DOT__stage_n6_1 
                                                          >> 0x0000001fU))) 
                                              << 0x0000001cU) 
                                             | (verification_top__DOT__c6__DOT__stage_n6_1 
                                                >> 4U)))) 
                       ^ verification_top__DOT__c0__DOT__n7);
    verification_top__DOT__c31__DOT__stage_n5_2 = (
                                                   (4U 
                                                    & verification_top__DOT__c0__DOT__n0)
                                                    ? verification_top__DOT__c31__DOT__stage_n5_1
                                                    : 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c31__DOT__stage_n5_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c31__DOT__stage_n5_1 
                                                       >> 4U)));
    vlSelfRef.out_14 = (vlSelfRef.in1 ^ (verification_top__DOT__c0__DOT__n0 
                                         + ((4U & ((IData)(9U) 
                                                   + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c14__DOT__stage_n7_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c14__DOT__stage_n7_1 
                                                   >> 4U))
                                             : verification_top__DOT__c14__DOT__stage_n7_1)));
    verification_top__DOT__c15__DOT__stage_n7_2 = (
                                                   (4U 
                                                    & ((IData)(9U) 
                                                       + vlSelfRef.in0))
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c14__DOT__stage_n7_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c14__DOT__stage_n7_1 
                                                       >> 4U))
                                                    : verification_top__DOT__c14__DOT__stage_n7_1);
    vlSelfRef.out_2 = ((vlSelfRef.in1 + ((4U & vlSelfRef.in0)
                                          ? verification_top__DOT__c2__DOT__stage_n5_1
                                          : (((- (IData)(
                                                         (verification_top__DOT__c2__DOT__stage_n5_1 
                                                          >> 0x0000001fU))) 
                                              << 0x0000001cU) 
                                             | (verification_top__DOT__c2__DOT__stage_n5_1 
                                                >> 4U)))) 
                       ^ verification_top__DOT__c0__DOT__n7);
    vlSelfRef.out_29 = (verification_top__DOT__c4__DOT__n0 
                        ^ (vlSelfRef.in1 + ((0x00000010U 
                                             & ((IData)(5U) 
                                                + vlSelfRef.in1))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c29__DOT__stage_n5_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c29__DOT__stage_n5_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c29__DOT__stage_n5_3)));
    vlSelfRef.out_19 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((0x00000010U 
                                             & vlSelfRef.in1)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c19__DOT__stage_n6_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c19__DOT__stage_n6_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c19__DOT__stage_n6_3)));
    vlSelfRef.out_23 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.in0 + ((0x00000010U 
                                             & vlSelfRef.in0)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c23__DOT__stage_n6_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c23__DOT__stage_n6_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c23__DOT__stage_n6_3)));
    verification_top__DOT__c31__DOT__stage_n5_3 = (
                                                   (8U 
                                                    & verification_top__DOT__c0__DOT__n0)
                                                    ? verification_top__DOT__c31__DOT__stage_n5_2
                                                    : 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c31__DOT__stage_n5_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c31__DOT__stage_n5_2 
                                                       >> 8U)));
    verification_top__DOT__c15__DOT__stage_n7_3 = (
                                                   (8U 
                                                    & ((IData)(9U) 
                                                       + vlSelfRef.in0))
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c15__DOT__stage_n7_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c15__DOT__stage_n7_2 
                                                       >> 8U))
                                                    : verification_top__DOT__c15__DOT__stage_n7_2);
    vlSelfRef.out_11 = (verification_top__DOT__c0__DOT__n0 
                        ^ (verification_top__DOT__c0__DOT__n7 
                           + ((0x00000010U & vlSelfRef.in0)
                               ? (((- (IData)((verification_top__DOT__c11__DOT__stage_n5_3 
                                               >> 0x0000001fU))) 
                                   << 0x00000010U) 
                                  | (verification_top__DOT__c11__DOT__stage_n5_3 
                                     >> 0x00000010U))
                               : verification_top__DOT__c11__DOT__stage_n5_3)));
    vlSelfRef.out_27 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x00000010U 
                                             & vlSelfRef.in1)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c27__DOT__stage_n7_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c27__DOT__stage_n7_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c27__DOT__stage_n7_3)));
    vlSelfRef.out_7 = ((vlSelfRef.in0 + ((0x00000010U 
                                          & ((IData)(5U) 
                                             + vlSelfRef.in1))
                                          ? (((- (IData)(
                                                         (verification_top__DOT__c7__DOT__stage_n6_3 
                                                          >> 0x0000001fU))) 
                                              << 0x00000010U) 
                                             | (verification_top__DOT__c7__DOT__stage_n6_3 
                                                >> 0x00000010U))
                                          : verification_top__DOT__c7__DOT__stage_n6_3)) 
                       ^ verification_top__DOT__c0__DOT__n7);
    vlSelfRef.out_31 = (vlSelfRef.in0 ^ (vlSelfRef.in1 
                                         + ((0x00000010U 
                                             & verification_top__DOT__c0__DOT__n0)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c31__DOT__stage_n5_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c31__DOT__stage_n5_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c31__DOT__stage_n5_3)));
    vlSelfRef.out_15 = (vlSelfRef.in1 ^ (verification_top__DOT__c0__DOT__n0 
                                         + ((0x00000010U 
                                             & ((IData)(9U) 
                                                + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c15__DOT__stage_n7_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c15__DOT__stage_n7_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c15__DOT__stage_n7_3)));
    vlSelfRef.out_3 = ((vlSelfRef.in1 + ((0x00000010U 
                                          & vlSelfRef.in0)
                                          ? (((- (IData)(
                                                         (verification_top__DOT__c3__DOT__stage_n5_3 
                                                          >> 0x0000001fU))) 
                                              << 0x00000010U) 
                                             | (verification_top__DOT__c3__DOT__stage_n5_3 
                                                >> 0x00000010U))
                                          : verification_top__DOT__c3__DOT__stage_n5_3)) 
                       ^ verification_top__DOT__c0__DOT__n7);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vverification_top___024root___eval_phase__ico(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_phase__ico\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__ico
        vlSelfRef.__VicoTriggered[0U] = (QData)((IData)(
                                                        (((vlSelfRef.in1 
                                                           != vlSelfRef.__Vtrigprevexpr___TOP__in1__0) 
                                                          << 1U) 
                                                         | (vlSelfRef.in0 
                                                            != vlSelfRef.__Vtrigprevexpr___TOP__in0__0))));
        vlSelfRef.__Vtrigprevexpr___TOP__in0__0 = vlSelfRef.in0;
        vlSelfRef.__Vtrigprevexpr___TOP__in1__0 = vlSelfRef.in1;
        if (VL_UNLIKELY(((1U & (~ (IData)(vlSelfRef.__VicoDidInit)))))) {
            vlSelfRef.__VicoDidInit = 1U;
            vlSelfRef.__VicoTriggered[0U] = (1ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (2ULL | vlSelfRef.__VicoTriggered[0U]);
        }
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vverification_top___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_ico
            if ((3ULL & vlSelfRef.__VicoTriggered[0U])) {
                Vverification_top___024root___ico_comb__TOP__0(vlSelf);
            }
        }
    }
    return (__VicoExecute);
}

void Vverification_top___024root___eval(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    // Body
    __VicoIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-11/can-this-run-offline/work/agentic-riscv-codesign/results/boundary-corroboration-data/raw/verification/verification.v", 1, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 10000 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = Vverification_top___024root___eval_phase__ico(vlSelf);
    } while (vlSelfRef.__VicoPhaseResult);
}

#ifdef VL_DEBUG
void Vverification_top___024root___eval_debug_assertions(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_debug_assertions\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
