#include <stdint.h>
static int32_t word(float x) { union {float f; int32_t i;} u={.f=x};return u.i; }
static uint32_t digest(const void *p,unsigned n) {
 const unsigned char *s=p;uint32_t h=2166136261u;
 for(unsigned i=0;i<n;i++) h=(h^s[i])*16777619u;return h;
}
#define main tacle_original_main
#include "pm.c"
#undef main
unsigned external_snapshot(int32_t*v) {
 v[0]=pm_result;v[1]=pm_data.profile_size;v[2]=pm_data.num_templates;
 unsigned bad=0;int argmin=0;
 for(unsigned i=0;i<60;i++) {
  uint32_t b=(uint32_t)word(pm_init_array_7[i]);
  bad+=((b&0x7f800000u)==0x7f800000u || pm_init_array_7[i]<0);
  if(pm_init_array_7[i]<pm_init_array_7[argmin])argmin=i;
 }
 v[3]=argmin;v[4]=bad;v[5]=(int32_t)digest(pm_init_array_7,60*4);
 const unsigned ix[]={0,1,2,10,11,12,13,59};
 for(unsigned i=0;i<8;i++)v[6+i]=word(pm_init_array_7[ix[i]]);
 return 14;
}