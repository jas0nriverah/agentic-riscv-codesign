#include <stdint.h>
static int32_t word(float x) { union {float f; int32_t i;} u={.f=x};return u.i; }
static uint32_t digest(const void *p,unsigned n) {
 const unsigned char *s=p;uint32_t h=2166136261u;
 for(unsigned i=0;i<n;i++) h=(h^s[i])*16777619u;return h;
}
#define main tacle_original_main
#include "fmref.c"
#undef main
unsigned external_snapshot(int32_t*v) {
 FloatBuffer *bs[]={&fmref_fb1,&fmref_fb2,&fmref_fb3,&fmref_fb4};
 for(unsigned i=0;i<4;i++){v[2*i]=bs[i]->rpos;v[2*i+1]=bs[i]->rlen;
  v[9+i]=(int32_t)digest(bs[i]->buff,800);}
 v[8]=fmref_numiters;
 for(unsigned i=0;i<8;i++)v[13+i]=word(fmref_lpf_data.coeff[i]);
 for(unsigned i=0;i<2;i++) {v[21+i]=word(fmref_fb4.buff[i]);
  v[23+i]=word(fmref_fb2.buff[i]);v[25+i]=word(fmref_fb3.buff[i]);}
 return 27;
}