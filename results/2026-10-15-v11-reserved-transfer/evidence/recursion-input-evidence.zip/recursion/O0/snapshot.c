#include <stdint.h>
static int32_t word(float x) { union {float f; int32_t i;} u={.f=x};return u.i; }
static uint32_t digest(const void *p,unsigned n) {
 const unsigned char *s=p;uint32_t h=2166136261u;
 for(unsigned i=0;i<n;i++) h=(h^s[i])*16777619u;return h;
}
extern int recursion_result,recursion_input;
unsigned external_snapshot(int32_t*v){v[0]=recursion_result;v[1]=recursion_input;return 2;}