#include <stdint.h>
static int32_t word(float x) { union {float f; int32_t i;} u={.f=x};return u.i; }
static uint32_t digest(const void *p,unsigned n) {
 const unsigned char *s=p;uint32_t h=2166136261u;
 for(unsigned i=0;i<n;i++) h=(h^s[i])*16777619u;return h;
}
#include "arithm.h"
#include "bits.h"
extern int ammunition_result;
unsigned external_snapshot(int32_t*v) {
 v[0]=ammunition_result;v[1]=ammunition_overflow_bit;
 unsigned char a[4]={0x7f,0xff,0xff,0xff},b[4]={0,0,0,2},r[4],s[8]={0};
 ammunition_multiply_unsigned_integer(4,a,b,r);
 for(unsigned i=0;i<4;i++)v[2+i]=r[i];v[6]=ammunition_overflow_bit;
 ammunition_bit_string_set(s,13,1,35);
 for(unsigned i=0;i<8;i++)v[7+i]=s[i];return 15;
}