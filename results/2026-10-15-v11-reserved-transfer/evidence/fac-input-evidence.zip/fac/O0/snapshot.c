#include <stdint.h>
static int32_t word(float x) { union {float f; int32_t i;} u={.f=x};return u.i; }
static uint32_t digest(const void *p,unsigned n) {
 const unsigned char *s=p;uint32_t h=2166136261u;
 for(unsigned i=0;i<n;i++) h=(h^s[i])*16777619u;return h;
}
extern int fac_s;extern volatile int fac_n;
unsigned external_snapshot(int32_t*v){v[0]=fac_s;v[1]=fac_n;return 2;}