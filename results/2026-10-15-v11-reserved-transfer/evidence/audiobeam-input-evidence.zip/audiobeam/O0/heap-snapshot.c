#include <stdint.h>
static int32_t word(float x) { union {float f; int32_t i;} u={.f=x};return u.i; }
static uint32_t digest(const void *p,unsigned n) {
 const unsigned char *s=p;uint32_t h=2166136261u;
 for(unsigned i=0;i<n;i++) h=(h^s[i])*16777619u;return h;
}
#include "audiobeamlibmalloc.c"
unsigned v11_audio_heap_snapshot(int32_t*v) {
 /* Original ILP32 allocator: delays8->12, ptr4->8, values60->64,
    beam pointer4->8, then384 floats. Output starts at byte92. */
 float *out=(float*)(audiobeam_simulated_heap+92);
 v[0]=audiobeam_freeHeapPos;v[1]=(int32_t)digest(out,384*4);
 for(unsigned i=0;i<16;i++)v[2+i]=word(out[i]);
 unsigned finite=0;for(unsigned i=0;i<371;i++)
  finite+=(((uint32_t)word(out[i])&0x7f800000u)!=0x7f800000u);
 v[18]=finite;return 19;
}