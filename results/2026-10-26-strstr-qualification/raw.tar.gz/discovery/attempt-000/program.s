	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.strstr,"ax",@progbits
	.align	2
	.globl	strstr
	.type	strstr, @function
strstr:
	lbu	a2,0(a1)
	beq	a2,zero,.L2
	addi	a0,a0,-1
.L3:
	mv	a5,a0
	lbu	a4,1(a0)
	addi	a0,a0,1
	beq	a4,zero,.L16
	bne	a2,a4,.L3
	lbu	a7,1(a1)
	beq	a7,zero,.L2
	lbu	a4,1(a0)
	addi	a5,a5,2
.L32:
	bne	a7,a4,.L10
.L4:
	lbu	a4,2(a1)
	lbu	a3,1(a5)
	addi	a0,a5,-1
	bne	a3,a4,.L11
	addi	a6,a1,2
	addi	a3,a5,1
.L12:
	beq	a4,zero,.L2
	lbu	a4,1(a6)
	lbu	t1,1(a3)
	bne	t1,a4,.L11
	beq	a4,zero,.L2
	lbu	a4,2(a6)
	lbu	t1,2(a3)
	addi	a3,a3,2
	addi	a6,a6,2
	beq	t1,a4,.L12
.L11:
	bne	a4,zero,.L13
	ret
.L13:
	lbu	a4,0(a5)
.L10:
	mv	a3,a5
	beq	a4,a2,.L8
	beq	a4,zero,.L16
	lbu	a4,1(a5)
	bne	a2,a4,.L7
	addi	a3,a5,1
.L8:
	lbu	a4,1(a3)
	addi	a5,a3,1
	j	.L32
.L7:
	beq	a4,zero,.L16
	lbu	a4,2(a3)
	addi	a5,a5,2
	j	.L10
.L16:
	li	a0,0
.L2:
	ret
	.size	strstr, .-strstr
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a5,%hi(text)
	lw	a0,%lo(text)(a5)
	lui	a5,%hi(substr)
	lw	a1,%lo(substr)(a5)
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	ra,28(sp)
	li	s0,0
.L35:
	addi	a0,a0,1
	sw	a1,12(sp)
	call	strstr
	lw	a1,12(sp)
	addi	s0,s0,1
	bne	a0,zero,.L35
	lw	ra,28(sp)
	mv	a0,s0
	lw	s0,24(sp)
	addi	sp,sp,32
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	a0,a0,-8
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.globl	substr
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
.LC0:
	.string	"abba"
	.section	.data.substr,"aw"
	.align	2
	.type	substr, @object
	.size	substr, 4
substr:
	.word	.LC0
	.globl	text
	.section	.rodata.str1.4
	.align	2
.LC1:
	.string	"abbaabbaababadcsdabbacasdaabbbaabbadabbacbbbaabbadabbacasdaabbbaabba"
	.section	.data.text,"aw"
	.align	2
	.type	text, @object
	.size	text, 4
text:
	.word	.LC1
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
