module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hffffd000;
wire [31:0] n1 = n0 + 32'h00000200;
wire [31:0] n2 = {31'b0, ($signed(in0) < $signed(n1))};
assign result = n2;
endmodule
