	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.strlen,"ax",@progbits
	.align	2
	.globl	strlen
	.type	strlen, @function
strlen:
	mv	a5,a0
.L2:
	lbu	a4,0(a5)
	bne	a4,zero,.L3
	sub	a0,a5,a0
	ret
.L3:
	addi	a5,a5,1
	j	.L2
	.size	strlen, .-strlen
	.section	.text.strncmp,"ax",@progbits
	.align	2
	.globl	strncmp
	.type	strncmp, @function
strncmp:
	li	a4,0
.L5:
	beq	a2,a4,.L9
	add	a5,a0,a4
	add	a3,a1,a4
	lbu	a5,0(a5)
	lbu	a3,0(a3)
	beq	a5,a3,.L6
	sub	a0,a5,a3
	ret
.L6:
	addi	a4,a4,1
	bne	a5,zero,.L5
.L9:
	li	a0,0
	ret
	.size	strncmp, .-strncmp
	.section	.text.init_search,"ax",@progbits
	.align	2
	.globl	init_search
	.type	init_search, @function
init_search:
	addi	sp,sp,-16
	sw	s0,8(sp)
	sw	ra,12(sp)
	mv	s0,a0
	call	strlen
	lui	a5,%hi(len)
	sw	a0,%lo(len)(a5)
	lui	a5,%hi(table)
	addi	a5,a5,%lo(table)
	addi	a4,a5,1024
	mv	a2,a5
.L11:
	sw	a0,0(a5)
	addi	a5,a5,4
	bne	a5,a4,.L11
	mv	a4,s0
	addi	a0,a0,-1
	li	a3,-1
.L12:
	bne	a0,a3,.L13
	lui	a5,%hi(findme)
	lw	ra,12(sp)
	sw	s0,%lo(findme)(a5)
	lw	s0,8(sp)
	addi	sp,sp,16
	jr	ra
.L13:
	lbu	a5,0(a4)
	addi	a4,a4,1
	slli	a5,a5,2
	add	a5,a2,a5
	sw	a0,0(a5)
	addi	a0,a0,-1
	j	.L12
	.size	init_search, .-init_search
	.section	.text.strsearch,"ax",@progbits
	.align	2
	.globl	strsearch
	.type	strsearch, @function
strsearch:
	addi	sp,sp,-48
	lui	a5,%hi(len)
	sw	s1,36(sp)
	lw	s1,%lo(len)(a5)
	sw	s0,40(sp)
	sw	s2,32(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	ra,44(sp)
	mv	s4,a0
	lui	s2,%hi(table)
	call	strlen
	li	s3,1
	addi	s0,s1,-1
	mv	s5,a0
	addi	s2,s2,%lo(table)
	sub	s3,s3,s1
	lui	s6,%hi(findme)
.L18:
	bltu	s0,s5,.L21
	li	a1,0
.L16:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	mv	a0,a1
	addi	sp,sp,48
	jr	ra
.L19:
	add	s0,s0,a5
	bleu	s5,s0,.L18
.L21:
	add	a5,s4,s0
	lbu	a5,0(a5)
	slli	a5,a5,2
	add	a5,s2,a5
	lw	a5,0(a5)
	bne	a5,zero,.L19
	lw	a0,%lo(findme)(s6)
	add	a1,s3,s0
	add	a1,s4,a1
	mv	a2,s1
	sw	a1,12(sp)
	call	strncmp
	lw	a1,12(sp)
	beq	a0,zero,.L16
	addi	s0,s0,1
	j	.L18
	.size	strsearch, .-strsearch
	.section	.rodata.isaforge_mibench_stringsearch_main.str1.4,"aMS",@progbits,1
	.align	2
.LC106:
	.string	""
	.align	2
.LC107:
	.string	" not"
	.section	.text.isaforge_mibench_stringsearch_main,"ax",@progbits
	.align	2
	.globl	isaforge_mibench_stringsearch_main
	.type	isaforge_mibench_stringsearch_main, @function
isaforge_mibench_stringsearch_main:
	addi	sp,sp,-496
	sw	s0,488(sp)
	lui	s0,%hi(.LANCHOR0)
	addi	s0,s0,%lo(.LANCHOR0)
	li	a2,232
	mv	a1,s0
	add	a0,sp,a2
	sw	ra,492(sp)
	sw	s1,484(sp)
	sw	s2,480(sp)
	sw	s3,476(sp)
	sw	s5,468(sp)
	sw	s6,464(sp)
	sw	s4,472(sp)
	call	memcpy
	addi	a1,s0,232
	li	a2,228
	addi	a0,sp,4
	call	memcpy
	addi	s0,sp,232
	addi	s1,sp,4
	lui	s5,%hi(.LC107)
	lui	s6,%hi(.LC106)
	lui	s2,%hi(capture_error)
	li	s3,1
.L29:
	lw	a0,0(s0)
	bne	a0,zero,.L41
	lw	ra,492(sp)
	lw	s0,488(sp)
	lw	s1,484(sp)
	lw	s2,480(sp)
	lw	s3,476(sp)
	lw	s4,472(sp)
	lw	s5,468(sp)
	lw	s6,464(sp)
	li	a0,0
	addi	sp,sp,496
	jr	ra
.L41:
	call	init_search
	lw	s4,0(s1)
	mv	a0,s4
	call	strsearch
	addi	a4,s5,%lo(.LC107)
	beq	a0,zero,.L30
	addi	a4,s6,%lo(.LC106)
.L30:
	lui	a3,%hi(current_text)
	lw	a5,%lo(current_text)(a3)
	bne	a5,zero,.L31
	lui	a2,%hi(observed_cases)
	lw	a1,%lo(observed_cases)(a2)
	li	a2,56
	ble	a1,a2,.L32
.L31:
	sw	s3,%lo(capture_error)(s2)
.L33:
	beq	a0,zero,.L34
	beq	a5,zero,.L35
	lui	a4,%hi(current_found)
	lw	a4,%lo(current_found)(a4)
	bne	a4,zero,.L36
.L38:
	sw	s3,%lo(capture_error)(s2)
.L37:
	lui	a2,%hi(observed_cases)
	lw	a5,%lo(observed_cases)(a2)
	li	a4,56
	bgt	a5,a4,.L35
	lui	a0,%hi(current_found)
	lw	a6,%lo(current_found)(a0)
	lui	a4,%hi(observed_found)
	slli	a1,a5,2
	addi	a4,a4,%lo(observed_found)
	add	a4,a4,a1
	sw	a6,0(a4)
	lui	a4,%hi(observed_offsets)
	addi	a4,a4,%lo(observed_offsets)
	add	a4,a4,a1
	lui	a1,%hi(current_offset)
	lw	a6,%lo(current_offset)(a1)
	addi	a5,a5,1
	sw	a5,%lo(observed_cases)(a2)
	li	a5,-1
	sw	a6,0(a4)
	sw	zero,%lo(current_text)(a3)
	sw	zero,%lo(current_found)(a0)
	sw	a5,%lo(current_offset)(a1)
	j	.L40
.L32:
	lbu	a5,0(a4)
	lui	a4,%hi(current_found)
	sw	s4,%lo(current_text)(a3)
	seqz	a5,a5
	sw	a5,%lo(current_found)(a4)
	lui	a5,%hi(current_offset)
	li	a4,-1
	sw	a4,%lo(current_offset)(a5)
	mv	a5,s4
	j	.L33
.L36:
	bgtu	a5,a0,.L38
	sub	a0,a0,a5
	blt	a0,zero,.L38
	lui	a5,%hi(current_offset)
	sw	a0,%lo(current_offset)(a5)
	j	.L37
.L34:
	bne	a5,zero,.L37
.L35:
	sw	s3,%lo(capture_error)(s2)
.L40:
	addi	s0,s0,4
	addi	s1,s1,4
	j	.L29
	.size	isaforge_mibench_stringsearch_main, .-isaforge_mibench_stringsearch_main
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(observed_cases)
	sw	zero,%lo(observed_cases)(a5)
	lui	a5,%hi(capture_error)
	sw	zero,%lo(capture_error)(a5)
	lui	a5,%hi(current_found)
	sw	zero,%lo(current_found)(a5)
	li	a4,-1
	lui	a5,%hi(current_offset)
	sw	a4,%lo(current_offset)(a5)
	lui	a5,%hi(current_text)
	sw	zero,%lo(current_text)(a5)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	sw	ra,12(sp)
	call	isaforge_mibench_stringsearch_main
	lw	ra,12(sp)
	lui	a5,%hi(observed_cases)
	lw	a0,%lo(observed_cases)(a5)
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	li	a5,57
	bne	a0,a5,.L59
	lui	a5,%hi(observed_cases)
	lw	a4,%lo(observed_cases)(a5)
	li	a5,0
	bne	a4,a0,.L54
	lui	a5,%hi(capture_error)
	lw	a5,%lo(capture_error)(a5)
	bne	a5,zero,.L59
	lui	a4,%hi(current_text)
	lw	a4,%lo(current_text)(a4)
	bne	a4,zero,.L54
	lui	a3,%hi(expected_offsets)
	lui	a2,%hi(observed_found)
	lui	a1,%hi(observed_offsets)
	addi	a3,a3,%lo(expected_offsets)
	addi	a2,a2,%lo(observed_found)
	addi	a1,a1,%lo(observed_offsets)
	li	t1,228
.L56:
	add	a0,a4,a3
	lw	a7,0(a0)
	add	a6,a4,a2
	lw	a6,0(a6)
	not	a0,a7
	srli	a0,a0,31
	bne	a6,a0,.L54
	add	a0,a4,a1
	lw	a0,0(a0)
	bne	a7,a0,.L54
	addi	a4,a4,4
	bne	a4,t1,.L56
	li	a5,1
.L54:
	mv	a0,a5
	ret
.L59:
	li	a5,0
	j	.L54
	.size	verify_benchmark, .-verify_benchmark
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
.LC54:
	.string	"cabbie"
	.align	2
.LC55:
	.string	"your"
	.align	2
.LC56:
	.string	"It isn't here"
	.align	2
.LC57:
	.string	"But it is here"
	.align	2
.LC58:
	.string	"hodad"
	.align	2
.LC59:
	.string	"yoohoo"
	.align	2
.LC9:
	.string	"xx"
	.align	2
.LC10:
	.string	"x"
	.align	2
.LC60:
	.string	"."
	.align	2
.LC61:
	.string	"In recent years, the field of photonic "
	.align	2
.LC62:
	.string	"crystals has found new"
	.align	2
.LC63:
	.string	"applications in the RF and microwave"
	.align	2
.LC64:
	.string	"regime. A new type of metallic"
	.align	2
.LC65:
	.string	"electromagnetic crystal has been"
	.align	2
.LC66:
	.string	"developed that is having a"
	.align	2
.LC67:
	.string	"significant impact on the field of"
	.align	2
.LC68:
	.string	"antennas. It consists of a"
	.align	2
.LC69:
	.string	"conductive surface, covered with a"
	.align	2
.LC70:
	.string	"special texture which alters its"
	.align	2
.LC71:
	.string	"electromagnetic properties. Made of solid"
	.align	2
.LC72:
	.string	"metal, the structure"
	.align	2
.LC73:
	.string	"conducts DC currents, but over a"
	.align	2
.LC74:
	.string	"particular frequency range it does"
	.align	2
.LC75:
	.string	"not conduct AC currents. It does not"
	.align	2
.LC76:
	.string	"reverse the phase of reflected"
	.align	2
.LC77:
	.string	"waves, and the effective image currents"
	.align	2
.LC78:
	.string	"appear in-phase, rather than"
	.align	2
.LC79:
	.string	"out-of-phase as they are on normal"
	.align	2
.LC80:
	.string	"conductors. Furthermore, surface"
	.align	2
.LC81:
	.string	"waves do not propagate, and instead"
	.align	2
.LC82:
	.string	"radiate efficiently into free"
	.align	2
.LC83:
	.string	"space. This new material, termed a"
	.align	2
.LC84:
	.string	"high-impedance surface, provides"
	.align	2
.LC85:
	.string	"a useful new ground plane for novel"
	.align	2
.LC86:
	.string	"low-profile antennas and other"
	.align	2
.LC87:
	.string	"electromagnetic structures."
	.align	2
.LC88:
	.string	"The recent protests about the Michigamua"
	.align	2
.LC89:
	.string	"student organization have raised an"
	.align	2
.LC90:
	.string	"important question as to the proper nature"
	.align	2
.LC91:
	.string	"and scope of University involvement"
	.align	2
.LC92:
	.string	"with student organizations. Accordingly"
	.align	2
.LC93:
	.string	"the panel described in my Statement of"
	.align	2
.LC94:
	.string	"February 25, 2000 that is considering the"
	.align	2
.LC95:
	.string	"question of privileged space also will"
	.align	2
.LC96:
	.string	"consider under what circumstances and in"
	.align	2
.LC97:
	.string	"what ways the University, its"
	.align	2
.LC98:
	.string	"administrators and faculty members should"
	.align	2
.LC99:
	.string	"be associated with such organizations"
	.align	2
.LC100:
	.string	"and it will recommend guiding principles"
	.align	2
.LC101:
	.string	"in this regard. The University's"
	.align	2
.LC102:
	.string	"Executive Officers and I will then decide"
	.align	2
.LC103:
	.string	"whether and how to implement such"
	.align	2
.LC104:
	.string	"principles."
	.align	2
.LC0:
	.string	"abb"
	.align	2
.LC1:
	.string	"you"
	.align	2
.LC2:
	.string	"not"
	.align	2
.LC3:
	.string	"it"
	.align	2
.LC4:
	.string	"dad"
	.align	2
.LC5:
	.string	"yoo"
	.align	2
.LC6:
	.string	"hoo"
	.align	2
.LC7:
	.string	"oo"
	.align	2
.LC8:
	.string	"oh"
	.align	2
.LC11:
	.string	"field"
	.align	2
.LC12:
	.string	"new"
	.align	2
.LC13:
	.string	"row"
	.align	2
.LC14:
	.string	"regime"
	.align	2
.LC15:
	.string	"boom"
	.align	2
.LC16:
	.string	"that"
	.align	2
.LC17:
	.string	"impact"
	.align	2
.LC18:
	.string	"and"
	.align	2
.LC19:
	.string	"zoom"
	.align	2
.LC20:
	.string	"texture"
	.align	2
.LC21:
	.string	"magnet"
	.align	2
.LC22:
	.string	"doom"
	.align	2
.LC23:
	.string	"loom"
	.align	2
.LC24:
	.string	"freq"
	.align	2
.LC25:
	.string	"current"
	.align	2
.LC26:
	.string	"phase"
	.align	2
.LC27:
	.string	"images"
	.align	2
.LC28:
	.string	"appears"
	.align	2
.LC29:
	.string	"conductor"
	.align	2
.LC30:
	.string	"wavez"
	.align	2
.LC31:
	.string	"normal"
	.align	2
.LC32:
	.string	"free"
	.align	2
.LC33:
	.string	"termed"
	.align	2
.LC34:
	.string	"provide"
	.align	2
.LC35:
	.string	"for"
	.align	2
.LC36:
	.string	"struct"
	.align	2
.LC37:
	.string	"about"
	.align	2
.LC38:
	.string	"have"
	.align	2
.LC39:
	.string	"proper"
	.align	2
.LC40:
	.string	"involve"
	.align	2
.LC41:
	.string	"describedly"
	.align	2
.LC42:
	.string	"thats"
	.align	2
.LC43:
	.string	"spaces"
	.align	2
.LC44:
	.string	"circumstance"
	.align	2
.LC45:
	.string	"the"
	.align	2
.LC46:
	.string	"member"
	.align	2
.LC47:
	.string	"such"
	.align	2
.LC48:
	.string	"guide"
	.align	2
.LC49:
	.string	"regard"
	.align	2
.LC50:
	.string	"officers"
	.align	2
.LC51:
	.string	"implement"
	.align	2
.LC52:
	.string	"principalities"
	.section	.bss.findme,"aw",@nobits
	.align	2
	.type	findme, @object
	.size	findme, 4
findme:
	.zero	4
	.section	.bss.len,"aw",@nobits
	.align	2
	.type	len, @object
	.size	len, 4
len:
	.zero	4
	.section	.bss.table,"aw",@nobits
	.align	2
	.type	table, @object
	.size	table, 1024
table:
	.zero	1024
	.section	.bss.current_text,"aw",@nobits
	.align	2
	.type	current_text, @object
	.size	current_text, 4
current_text:
	.zero	4
	.section	.bss.current_offset,"aw",@nobits
	.align	2
	.type	current_offset, @object
	.size	current_offset, 4
current_offset:
	.zero	4
	.section	.bss.current_found,"aw",@nobits
	.align	2
	.type	current_found, @object
	.size	current_found, 4
current_found:
	.zero	4
	.section	.bss.capture_error,"aw",@nobits
	.align	2
	.type	capture_error, @object
	.size	capture_error, 4
capture_error:
	.zero	4
	.section	.bss.observed_cases,"aw",@nobits
	.align	2
	.type	observed_cases, @object
	.size	observed_cases, 4
observed_cases:
	.zero	4
	.section	.bss.observed_found,"aw",@nobits
	.align	2
	.type	observed_found, @object
	.size	observed_found, 228
observed_found:
	.zero	228
	.section	.bss.observed_offsets,"aw",@nobits
	.align	2
	.type	observed_offsets, @object
	.size	observed_offsets, 228
observed_offsets:
	.zero	228
	.section	.rodata.expected_offsets,"a"
	.align	2
	.type	expected_offsets, @object
	.size	expected_offsets, 228
expected_offsets:
	.word	1
	.word	0
	.word	-1
	.word	4
	.word	2
	.word	0
	.word	3
	.word	1
	.word	2
	.word	-1
	.word	0
	.word	0
	.word	-1
	.word	21
	.word	19
	.word	30
	.word	0
	.word	-1
	.word	10
	.word	12
	.word	-1
	.word	-1
	.word	8
	.word	7
	.word	-1
	.word	-1
	.word	11
	.word	15
	.word	12
	.word	-1
	.word	-1
	.word	7
	.word	0
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	-1
	.word	20
	.word	10
	.word	27
	.word	19
	.word	-1
	.word	8
	.word	-1
	.word	19
	.word	-1
	.section	.rodata
	.align	2
	.set	.LANCHOR0,. + 0
.LC108:
	.word	.LC0
	.word	.LC1
	.word	.LC2
	.word	.LC3
	.word	.LC4
	.word	.LC5
	.word	.LC6
	.word	.LC7
	.word	.LC8
	.word	.LC9
	.word	.LC9
	.word	.LC10
	.word	.LC10
	.word	.LC11
	.word	.LC12
	.word	.LC13
	.word	.LC14
	.word	.LC15
	.word	.LC16
	.word	.LC17
	.word	.LC18
	.word	.LC19
	.word	.LC20
	.word	.LC21
	.word	.LC22
	.word	.LC23
	.word	.LC24
	.word	.LC25
	.word	.LC26
	.word	.LC27
	.word	.LC28
	.word	.LC26
	.word	.LC29
	.word	.LC30
	.word	.LC31
	.word	.LC32
	.word	.LC33
	.word	.LC34
	.word	.LC35
	.word	.LC18
	.word	.LC36
	.word	.LC37
	.word	.LC38
	.word	.LC39
	.word	.LC40
	.word	.LC41
	.word	.LC42
	.word	.LC43
	.word	.LC44
	.word	.LC45
	.word	.LC46
	.word	.LC47
	.word	.LC48
	.word	.LC49
	.word	.LC50
	.word	.LC51
	.word	.LC52
	.word	0
.LC109:
	.word	.LC54
	.word	.LC55
	.word	.LC56
	.word	.LC57
	.word	.LC58
	.word	.LC59
	.word	.LC59
	.word	.LC59
	.word	.LC59
	.word	.LC59
	.word	.LC9
	.word	.LC10
	.word	.LC60
	.word	.LC61
	.word	.LC62
	.word	.LC63
	.word	.LC64
	.word	.LC65
	.word	.LC66
	.word	.LC67
	.word	.LC68
	.word	.LC69
	.word	.LC70
	.word	.LC71
	.word	.LC72
	.word	.LC73
	.word	.LC74
	.word	.LC75
	.word	.LC76
	.word	.LC77
	.word	.LC78
	.word	.LC79
	.word	.LC80
	.word	.LC81
	.word	.LC82
	.word	.LC83
	.word	.LC84
	.word	.LC85
	.word	.LC86
	.word	.LC87
	.word	.LC88
	.word	.LC89
	.word	.LC90
	.word	.LC91
	.word	.LC92
	.word	.LC93
	.word	.LC94
	.word	.LC95
	.word	.LC96
	.word	.LC97
	.word	.LC98
	.word	.LC99
	.word	.LC100
	.word	.LC101
	.word	.LC102
	.word	.LC103
	.word	.LC104
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
