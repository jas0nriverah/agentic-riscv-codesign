	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	sp,sp,-96
	sw	s0,88(sp)
	li	a2,80
	mv	s0,a0
	li	a1,0
	mv	a0,sp
	sw	ra,92(sp)
	call	memset
	li	a5,1
	lui	a0,%hi(x)
	sw	a5,8(sp)
	sw	a5,12(sp)
	sw	a5,16(sp)
	mv	a1,sp
	li	a5,2
	li	a2,80
	addi	a0,a0,%lo(x)
	sw	a5,20(sp)
	call	memcmp
	lw	ra,92(sp)
	or	a0,a0,s0
	lw	s0,88(sp)
	seqz	a0,a0
	addi	sp,sp,96
	jr	ra
	.size	verify_benchmark, .-verify_benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.ludcmp,"ax",@progbits
	.align	2
	.globl	ludcmp
	.type	ludcmp, @function
ludcmp:
	addi	sp,sp,-480
	sw	s1,468(sp)
	lui	s1,%hi(a)
	addi	s1,s1,%lo(a)
	sw	s5,452(sp)
	addi	s5,s1,80
	sw	s0,472(sp)
	sw	s2,464(sp)
	sw	s4,456(sp)
	sw	s6,448(sp)
	sw	s7,444(sp)
	sw	ra,476(sp)
	sw	s3,460(sp)
	sw	s8,440(sp)
	sw	s9,436(sp)
	sw	s10,432(sp)
	sw	s11,428(sp)
	mv	s2,a1
	mv	s6,s5
	mv	s4,s1
	li	s7,0
	li	s0,0
.L5:
	bgt	s2,s0,.L13
	lui	s6,%hi(b)
	addi	s6,s6,%lo(b)
	lw	a5,0(s6)
	li	s0,4
	li	s7,1
	sw	a5,16(sp)
	addi	s4,sp,16
.L14:
	ble	s7,s2,.L16
	lui	s3,%hi(x)
	slli	a5,s2,2
	addi	s3,s3,%lo(x)
	add	a4,s4,a5
	add	s0,s3,a5
	add	a5,a5,s2
	slli	a5,a5,2
	add	a5,a5,s2
	slli	a5,a5,2
	add	a5,s1,a5
	lw	a1,0(a5)
	lw	a0,0(a4)
	addi	s5,s2,-1
	call	__divsi3
	sw	a0,0(s0)
.L17:
	bge	s5,zero,.L20
	lw	ra,476(sp)
	lw	s0,472(sp)
	lw	s1,468(sp)
	lw	s2,464(sp)
	lw	s3,460(sp)
	lw	s4,456(sp)
	lw	s5,452(sp)
	lw	s6,448(sp)
	lw	s7,444(sp)
	lw	s8,440(sp)
	lw	s9,436(sp)
	lw	s10,432(sp)
	lw	s11,428(sp)
	li	a0,0
	addi	sp,sp,480
	jr	ra
.L13:
	addi	s10,s0,1
	mv	s8,s10
	mv	s3,s6
	mv	s9,s10
.L6:
	ble	s9,s2,.L9
	addi	s9,s4,80
.L10:
	ble	s8,s2,.L12
	addi	s4,s4,84
	addi	s6,s6,80
	addi	s7,s7,4
	mv	s0,s10
	j	.L5
.L9:
	add	s11,s3,s7
	lw	a5,0(s11)
	beq	s0,zero,.L7
	add	a3,s1,s7
	mv	a2,s3
	li	a4,0
.L8:
	lw	a1,0(a3)
	lw	a0,0(a2)
	sw	a4,12(sp)
	sw	a5,8(sp)
	sw	a3,4(sp)
	sw	a2,0(sp)
	call	__mulsi3
	lw	a4,12(sp)
	lw	a5,8(sp)
	lw	a2,0(sp)
	lw	a3,4(sp)
	addi	a4,a4,1
	sub	a5,a5,a0
	addi	a2,a2,4
	addi	a3,a3,80
	bne	a4,s0,.L8
.L7:
	lw	a1,0(s4)
	mv	a0,a5
	addi	s9,s9,1
	call	__divsi3
	sw	a0,0(s11)
	addi	s3,s3,80
	j	.L6
.L12:
	lw	s11,4(s9)
	slli	s3,s8,2
	add	s3,s3,s1
	mv	a4,s6
	li	a5,0
.L11:
	lw	a1,0(s3)
	lw	a0,0(a4)
	sw	a5,4(sp)
	sw	a4,0(sp)
	call	__mulsi3
	lw	a5,4(sp)
	lw	a4,0(sp)
	sub	s11,s11,a0
	addi	a5,a5,1
	addi	a4,a4,4
	addi	s3,s3,80
	ble	a5,s0,.L11
	sw	s11,4(s9)
	addi	s8,s8,1
	addi	s9,s9,4
	j	.L10
.L16:
	add	a5,s6,s0
	lw	s8,0(a5)
	li	s3,0
.L15:
	add	a5,s5,s3
	add	a4,s4,s3
	lw	a1,0(a4)
	lw	a0,0(a5)
	addi	s3,s3,4
	call	__mulsi3
	sub	s8,s8,a0
	bne	s3,s0,.L15
	add	a5,s4,s0
	sw	s8,0(a5)
	addi	s7,s7,1
	addi	s5,s5,80
	addi	s0,s0,4
	j	.L14
.L20:
	slli	s0,s5,2
	add	a5,s4,s0
	add	s6,s0,s5
	lw	s8,0(a5)
	slli	s6,s6,4
	addi	s7,s5,1
	add	s6,s6,s1
.L18:
	ble	s7,s2,.L19
	add	a5,s0,s5
	slli	a5,a5,2
	add	a5,a5,s5
	slli	a5,a5,2
	add	a5,s1,a5
	lw	a1,0(a5)
	mv	a0,s8
	add	s6,s3,s0
	call	__divsi3
	sw	a0,0(s6)
	addi	s5,s5,-1
	j	.L17
.L19:
	slli	a5,s7,2
	add	a4,s6,a5
	add	a5,s3,a5
	lw	a1,0(a5)
	lw	a0,0(a4)
	addi	s7,s7,1
	call	__mulsi3
	sub	s8,s8,a0
	j	.L18
	.size	ludcmp, .-ludcmp
	.section	.text.benchmark_body,"ax",@progbits
	.align	2
	.type	benchmark_body, @function
benchmark_body:
	addi	sp,sp,-80
	sw	s3,60(sp)
	sw	s4,56(sp)
	sw	s5,52(sp)
	sw	s6,48(sp)
	sw	s9,36(sp)
	sw	ra,76(sp)
	sw	s0,72(sp)
	sw	s1,68(sp)
	sw	s2,64(sp)
	sw	s7,44(sp)
	sw	s8,40(sp)
	sw	s10,32(sp)
	sw	s11,28(sp)
	sw	a0,12(sp)
	li	s9,0
	lui	s5,%hi(b)
	lui	s4,%hi(a)
	li	s3,6
	lui	s6,%hi(chkerr)
.L29:
	lw	a5,12(sp)
	bge	s9,a5,.L34
	addi	s8,s5,%lo(b)
	addi	s7,s4,%lo(a)
	li	s0,0
	j	.L35
.L32:
	add	a0,s11,s1
	beq	s0,s1,.L30
.L38:
	sw	a0,0(s2)
	addi	s1,s1,1
	add	s10,s10,a0
	addi	s2,s2,4
	bne	s1,s3,.L32
	sw	s10,0(s8)
	addi	s0,s0,1
	addi	s8,s8,4
	addi	s7,s7,80
	beq	s0,s3,.L33
.L35:
	mv	s2,s7
	li	s1,0
	li	s10,0
	addi	s11,s0,2
	j	.L32
.L30:
	call	__floatsidf
	mv	a2,a0
	mv	a3,a1
	call	__adddf3
	call	__fixdfsi
	j	.L38
.L33:
	li	a1,5
	li	a0,20
	call	ludcmp
	addi	s9,s9,1
	sw	zero,%lo(chkerr)(s6)
	j	.L29
.L34:
	lw	ra,76(sp)
	lw	s0,72(sp)
	lui	a5,%hi(chkerr)
	lw	a0,%lo(chkerr)(a5)
	lw	s1,68(sp)
	lw	s2,64(sp)
	lw	s3,60(sp)
	lw	s4,56(sp)
	lw	s5,52(sp)
	lw	s6,48(sp)
	lw	s7,44(sp)
	lw	s8,40(sp)
	lw	s9,36(sp)
	lw	s10,32(sp)
	lw	s11,28(sp)
	addi	sp,sp,80
	jr	ra
	.size	benchmark_body, .-benchmark_body
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	tail	benchmark_body
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	li	a0,1478
	tail	benchmark_body
	.size	benchmark, .-benchmark
	.globl	chkerr
	.section	.bss.chkerr,"aw",@nobits
	.align	2
	.type	chkerr, @object
	.size	chkerr, 4
chkerr:
	.zero	4
	.globl	x
	.section	.bss.x,"aw",@nobits
	.align	2
	.type	x, @object
	.size	x, 80
x:
	.zero	80
	.globl	b
	.section	.bss.b,"aw",@nobits
	.align	2
	.type	b, @object
	.size	b, 80
b:
	.zero	80
	.globl	a
	.section	.bss.a,"aw",@nobits
	.align	2
	.type	a, @object
	.size	a, 1600
a:
	.zero	1600
	.globl	__fixdfsi
	.globl	__adddf3
	.globl	__floatsidf
	.globl	__divsi3
	.globl	__mulsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
