	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.interface,"ax",@progbits
	.align	2
	.globl	interface
	.type	interface, @function
interface:
	lui	a5,%hi(Bitlist)
	addi	a5,a5,%lo(Bitlist)
	lbu	a4,4(a5)
	bne	a4,zero,.L2
	lbu	a4,6(a5)
	bne	a4,zero,.L3
.L4:
	lui	a4,%hi(sc_FH_TUERMODUL_CTRL_2375_2)
	lw	a3,%lo(sc_FH_TUERMODUL_CTRL_2375_2)(a4)
	beq	a3,zero,.L5
	lui	a2,%hi(time)
	lw	a2,%lo(time)(a2)
	beq	a3,a2,.L5
	lui	a3,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a3)
	sw	zero,%lo(sc_FH_TUERMODUL_CTRL_2375_2)(a4)
.L5:
	lui	a4,%hi(sc_FH_TUERMODUL_CTRL_2352_1)
	lw	a3,%lo(sc_FH_TUERMODUL_CTRL_2352_1)(a4)
	beq	a3,zero,.L6
	lui	a2,%hi(time)
	lw	a2,%lo(time)(a2)
	beq	a3,a2,.L6
	lui	a3,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a3)
	sw	zero,%lo(sc_FH_TUERMODUL_CTRL_2352_1)(a4)
.L6:
	lui	a4,%hi(sc_FH_TUERMODUL_CTRL_2329_1)
	lw	a3,%lo(sc_FH_TUERMODUL_CTRL_2329_1)(a4)
	beq	a3,zero,.L7
	lui	a2,%hi(time)
	lw	a2,%lo(time)(a2)
	beq	a3,a2,.L7
	lui	a3,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a3)
	sw	zero,%lo(sc_FH_TUERMODUL_CTRL_2329_1)(a4)
.L7:
	lui	a4,%hi(sc_FH_TUERMODUL_CTRL_1781_10)
	lw	a3,%lo(sc_FH_TUERMODUL_CTRL_1781_10)(a4)
	beq	a3,zero,.L8
	lui	a2,%hi(time)
	lw	a2,%lo(time)(a2)
	beq	a3,a2,.L8
	sw	zero,%lo(sc_FH_TUERMODUL_CTRL_1781_10)(a4)
.L8:
	lui	a4,%hi(sc_FH_TUERMODUL_CTRL_1739_10)
	lw	a3,%lo(sc_FH_TUERMODUL_CTRL_1739_10)(a4)
	beq	a3,zero,.L9
	lui	a2,%hi(time)
	lw	a2,%lo(time)(a2)
	beq	a3,a2,.L9
	sw	zero,%lo(sc_FH_TUERMODUL_CTRL_1739_10)(a4)
.L9:
	lbu	a5,0(a5)
	bne	a5,zero,.L10
	lui	a5,%hi(BLOCK_ERKENNUNG_CTRL__N)
	lw	a4,%lo(BLOCK_ERKENNUNG_CTRL__N)(a5)
	lui	a5,%hi(BLOCK_ERKENNUNG_CTRL__N_old)
	lw	a5,%lo(BLOCK_ERKENNUNG_CTRL__N_old)(a5)
	beq	a4,a5,.L1
.L10:
	lui	a5,%hi(time)
	lw	a4,%lo(time)(a5)
	lui	a5,%hi(tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy)
	sw	a4,%lo(tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy)(a5)
.L1:
	ret
.L2:
	lui	a4,%hi(time)
	lw	a3,%lo(time)(a4)
	lui	a4,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)
	sw	a3,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)(a4)
.L3:
	lui	a4,%hi(time)
	lw	a3,%lo(time)(a4)
	lui	a4,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)
	sw	a3,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)(a4)
	j	.L4
	.size	interface, .-interface
	.section	.text.init,"ax",@progbits
	.align	2
	.globl	init
	.type	init, @function
init:
	lui	a5,%hi(tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy)
	sw	zero,%lo(tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy)(a5)
	lui	a5,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)
	sw	zero,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)(a5)
	lui	a5,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)
	sw	zero,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)(a5)
	lui	a5,%hi(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)
	sb	zero,%lo(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)(a5)
	lui	a5,%hi(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)
	sb	zero,%lo(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)(a5)
	lui	a5,%hi(MEC_KINDERSICHERUNG_CTRL_next_state)
	sb	zero,%lo(MEC_KINDERSICHERUNG_CTRL_next_state)(a5)
	lui	a5,%hi(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)
	sb	zero,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	lui	a5,%hi(B_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(B_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(A_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(A_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(OEFFNEN_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a5)
	lui	a5,%hi(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)
	sb	zero,%lo(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)(a5)
	lui	a5,%hi(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)
	sb	zero,%lo(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)(a5)
	lui	a5,%hi(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)
	sb	zero,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a5)
	lui	a5,%hi(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)
	sb	zero,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a5)
	ret
	.size	init, .-init
	.section	.text.generic_KINDERSICHERUNG_CTRL,"ax",@progbits
	.align	2
	.globl	generic_KINDERSICHERUNG_CTRL
	.type	generic_KINDERSICHERUNG_CTRL, @function
generic_KINDERSICHERUNG_CTRL:
	lui	a5,%hi(Bitlist+10)
	lbu	a5,%lo(Bitlist+10)(a5)
	beq	a5,zero,.L28
	lui	a5,%hi(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)
	lbu	a2,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	li	a4,2
	beq	a2,a4,.L30
	li	a0,3
	beq	a2,a0,.L31
	li	a4,1
	bne	a2,a4,.L32
	lui	a4,%hi(FH_TUERMODUL__SFHA_ZENTRAL)
	lbu	a1,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(a4)
	lui	a4,%hi(FH_TUERMODUL__SFHZ_ZENTRAL)
	lbu	a3,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(a4)
	lui	a4,%hi(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)
	or	a6,a1,a3
	bne	a6,zero,.L33
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__SFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHZ_copy)(a3)
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHA_copy)(a3)
	sb	a0,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	sb	zero,%lo(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)(a4)
	ret
.L33:
	lbu	a5,%lo(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)(a4)
	bne	a5,a2,.L34
	beq	a1,zero,.L35
	lui	a2,%hi(FH_TUERMODUL__SFHA_ZENTRAL_old)
	lbu	a2,%lo(FH_TUERMODUL__SFHA_ZENTRAL_old)(a2)
	bne	a2,zero,.L36
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	sb	a5,%lo(FH_TUERMODUL__SFHA_copy)(a3)
.L85:
	sb	a5,%lo(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)(a4)
	ret
.L35:
	beq	a3,zero,.L37
.L51:
	lui	a5,%hi(FH_TUERMODUL__SFHZ_ZENTRAL_old)
	lbu	a5,%lo(FH_TUERMODUL__SFHZ_ZENTRAL_old)(a5)
	bne	a5,zero,.L38
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a3,%hi(FH_TUERMODUL__SFHZ_copy)
	li	a5,1
	sb	a5,%lo(FH_TUERMODUL__SFHZ_copy)(a3)
	j	.L85
.L37:
	lui	a5,%hi(FH_TUERMODUL__SFHA_ZENTRAL_old)
	lbu	a5,%lo(FH_TUERMODUL__SFHA_ZENTRAL_old)(a5)
	beq	a5,zero,.L39
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a5,%hi(FH_TUERMODUL__SFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHA_copy)(a5)
.L89:
	li	a5,1
	j	.L85
.L39:
	bne	a3,zero,.L28
.L52:
	lui	a5,%hi(FH_TUERMODUL__SFHZ_ZENTRAL_old)
	lbu	a5,%lo(FH_TUERMODUL__SFHZ_ZENTRAL_old)(a5)
	beq	a5,zero,.L28
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a5,%hi(FH_TUERMODUL__SFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHZ_copy)(a5)
	j	.L89
.L34:
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	ret
.L30:
	lui	a4,%hi(FH_TUERMODUL__SFHA_MEC)
	lbu	a2,%lo(FH_TUERMODUL__SFHA_MEC)(a4)
	lui	a4,%hi(FH_TUERMODUL__SFHZ_MEC)
	lbu	a3,%lo(FH_TUERMODUL__SFHZ_MEC)(a4)
	lui	a4,%hi(MEC_KINDERSICHERUNG_CTRL_next_state)
	or	a1,a2,a3
	bne	a1,zero,.L40
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__SFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHZ_copy)(a3)
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHA_copy)(a3)
	li	a3,3
	sb	a3,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	sb	zero,%lo(MEC_KINDERSICHERUNG_CTRL_next_state)(a4)
	ret
.L40:
	lbu	a5,%lo(MEC_KINDERSICHERUNG_CTRL_next_state)(a4)
	li	a1,1
	bne	a5,a1,.L34
	beq	a2,zero,.L41
	lui	a1,%hi(FH_TUERMODUL__SFHA_MEC_old)
	lbu	a1,%lo(FH_TUERMODUL__SFHA_MEC_old)(a1)
	bne	a1,zero,.L42
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	sb	a5,%lo(FH_TUERMODUL__SFHA_copy)(a3)
.L86:
	sb	a5,%lo(MEC_KINDERSICHERUNG_CTRL_next_state)(a4)
	ret
.L41:
	beq	a3,zero,.L43
.L53:
	lui	a5,%hi(FH_TUERMODUL__SFHZ_MEC_old)
	lbu	a5,%lo(FH_TUERMODUL__SFHZ_MEC_old)(a5)
	bne	a5,zero,.L44
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a3,%hi(FH_TUERMODUL__SFHZ_copy)
	li	a5,1
	sb	a5,%lo(FH_TUERMODUL__SFHZ_copy)(a3)
	j	.L86
.L43:
	lui	a5,%hi(FH_TUERMODUL__SFHA_MEC_old)
	lbu	a5,%lo(FH_TUERMODUL__SFHA_MEC_old)(a5)
	beq	a5,zero,.L45
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a5,%hi(FH_TUERMODUL__SFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHA_copy)(a5)
.L90:
	li	a5,1
	j	.L86
.L45:
	bne	a3,zero,.L28
.L54:
	lui	a5,%hi(FH_TUERMODUL__SFHZ_MEC_old)
	lbu	a5,%lo(FH_TUERMODUL__SFHZ_MEC_old)(a5)
	beq	a5,zero,.L28
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a5,%hi(FH_TUERMODUL__SFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__SFHZ_copy)(a5)
	j	.L90
.L31:
	lui	a3,%hi(FH_TUERMODUL__KL_50)
	lbu	a3,%lo(FH_TUERMODUL__KL_50)(a3)
	bne	a3,zero,.L46
	lui	a2,%hi(FH_TUERMODUL__SFHZ_MEC)
	lbu	a1,%lo(FH_TUERMODUL__SFHZ_MEC)(a2)
	lui	a2,%hi(FH_TUERMODUL__SFHA_MEC)
	beq	a1,zero,.L47
	lbu	a0,%lo(FH_TUERMODUL__SFHA_MEC)(a2)
	li	a3,1
	lui	a1,%hi(stable)
	lui	a2,%hi(FH_TUERMODUL__SFHZ_copy)
	sb	zero,%lo(stable)(a1)
	sb	a3,%lo(FH_TUERMODUL__SFHZ_copy)(a2)
	beq	a0,zero,.L88
	lui	a2,%hi(FH_TUERMODUL__SFHA_copy)
	sb	a3,%lo(FH_TUERMODUL__SFHA_copy)(a2)
.L88:
	sb	a4,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	ret
.L47:
	lbu	a2,%lo(FH_TUERMODUL__SFHA_MEC)(a2)
	beq	a2,zero,.L46
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	li	a2,1
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	sb	a2,%lo(FH_TUERMODUL__SFHA_copy)(a3)
	j	.L88
.L46:
	lui	a2,%hi(FH_TUERMODUL__SFHZ_ZENTRAL)
	lbu	a2,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(a2)
	lui	a4,%hi(FH_TUERMODUL__SFHA_ZENTRAL)
	lbu	a4,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(a4)
	bne	a2,zero,.L49
	beq	a4,zero,.L28
	bne	a3,zero,.L28
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	li	a4,1
	sb	a4,%lo(FH_TUERMODUL__SFHA_copy)(a3)
	j	.L88
.L49:
	beq	a4,zero,.L50
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a3,%hi(FH_TUERMODUL__SFHA_copy)
	li	a4,1
	sb	a4,%lo(FH_TUERMODUL__SFHA_copy)(a3)
.L87:
	lui	a3,%hi(FH_TUERMODUL__SFHZ_copy)
	sb	a4,%lo(FH_TUERMODUL__SFHZ_copy)(a3)
	j	.L88
.L50:
	bne	a3,zero,.L28
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	li	a4,1
	j	.L87
.L32:
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	sb	a0,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	ret
.L38:
	beq	a1,zero,.L37
	ret
.L44:
	beq	a2,zero,.L43
	ret
.L36:
	beq	a3,zero,.L52
	j	.L51
.L42:
	beq	a3,zero,.L54
	j	.L53
.L28:
	ret
	.size	generic_KINDERSICHERUNG_CTRL, .-generic_KINDERSICHERUNG_CTRL
	.section	.text.generic_FH_TUERMODUL_CTRL,"ax",@progbits
	.align	2
	.globl	generic_FH_TUERMODUL_CTRL
	.type	generic_FH_TUERMODUL_CTRL, @function
generic_FH_TUERMODUL_CTRL:
	lui	a5,%hi(Bitlist)
	addi	a5,a5,%lo(Bitlist)
	lbu	a4,13(a5)
	beq	a4,zero,.L92
	lbu	a4,10(a5)
	beq	a4,zero,.L93
.L94:
	lbu	a4,19(a5)
	bne	a4,zero,.L96
	lui	a4,%hi(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)
	li	a3,1
	sb	zero,0(a5)
	sb	a3,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
.L96:
	lui	a4,%hi(B_FH_TUERMODUL_CTRL_next_state)
	lbu	a1,%lo(B_FH_TUERMODUL_CTRL_next_state)(a4)
	li	a3,1
	sb	a3,11(a5)
	sb	a3,20(a5)
	li	a0,2
	beq	a1,a0,.L97
	li	a2,3
	beq	a1,a2,.L98
	bne	a1,a3,.L99
	lui	a3,%hi(FH_TUERMODUL_CTRL__N)
	lw	a3,%lo(FH_TUERMODUL_CTRL__N)(a3)
	li	a1,59
	bne	a3,a1,.L101
	lui	a1,%hi(FH_TUERMODUL_CTRL__N_old)
	lw	a1,%lo(FH_TUERMODUL_CTRL__N_old)(a1)
	beq	a1,a3,.L101
	lui	a3,%hi(stable)
	sb	a2,%lo(B_FH_TUERMODUL_CTRL_next_state)(a4)
	lui	a4,%hi(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)
	sb	zero,%lo(stable)(a3)
	sb	a2,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a4)
.L101:
	lui	a1,%hi(A_FH_TUERMODUL_CTRL_next_state)
	lbu	a0,%lo(A_FH_TUERMODUL_CTRL_next_state)(a1)
	li	a3,1
	lui	a4,%hi(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)
	bne	a0,a3,.L137
	lui	a3,%hi(step)
	lbu	a2,%lo(step)(a3)
	bne	a2,a0,.L138
	lui	a3,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)
	lw	a0,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)(a3)
	beq	a0,zero,.L138
	lui	a3,%hi(time)
	lw	a3,%lo(time)(a3)
	sub	a3,a3,a0
	bne	a3,a2,.L138
	lui	a0,%hi(FH_TUERMODUL__MFHZ)
	lui	a6,%hi(FH_TUERMODUL__MFHA)
	lbu	a0,%lo(FH_TUERMODUL__MFHZ)(a0)
	lbu	a6,%lo(FH_TUERMODUL__MFHA)(a6)
	or	a0,a0,a6
	beq	a0,zero,.L138
	lui	a2,%hi(stable)
	lui	a0,%hi(FH_TUERMODUL_CTRL__N)
	sb	zero,%lo(stable)(a2)
	lw	a2,%lo(FH_TUERMODUL_CTRL__N)(a0)
	add	a2,a2,a3
	sw	a2,%lo(FH_TUERMODUL_CTRL__N)(a0)
.L220:
	sb	a3,%lo(A_FH_TUERMODUL_CTRL_next_state)(a1)
	j	.L221
.L92:
	lbu	a4,15(a5)
	beq	a4,zero,.L91
	lbu	a4,14(a5)
	bne	a4,zero,.L91
	sb	zero,4(a5)
	sb	zero,6(a5)
	ret
.L93:
	lui	a4,%hi(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)
	li	a3,3
	sb	a3,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a4)
	j	.L94
.L97:
	lui	a3,%hi(FH_TUERMODUL__BLOCK)
	lbu	a3,%lo(FH_TUERMODUL__BLOCK)(a3)
	beq	a3,zero,.L103
	lui	a3,%hi(FH_TUERMODUL__BLOCK_old)
	lbu	a3,%lo(FH_TUERMODUL__BLOCK_old)(a3)
	bne	a3,zero,.L103
	lui	a3,%hi(FH_TUERMODUL__MFHZ)
	lbu	a3,%lo(FH_TUERMODUL__MFHZ)(a3)
	beq	a3,zero,.L103
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a3)
	lui	a3,%hi(time)
	lw	a2,%lo(time)(a3)
	lui	a3,%hi(sc_FH_TUERMODUL_CTRL_2329_1)
	sw	a2,%lo(sc_FH_TUERMODUL_CTRL_2329_1)(a3)
	li	a3,3
	sb	a3,%lo(B_FH_TUERMODUL_CTRL_next_state)(a4)
	lui	a4,%hi(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)
	sb	a3,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a4)
	j	.L101
.L103:
	lui	a4,%hi(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)
	lbu	a2,%lo(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)(a4)
	li	a1,2
	beq	a2,a1,.L104
	li	a3,3
	beq	a2,a3,.L105
	li	a1,1
	bne	a2,a1,.L106
	lui	a2,%hi(FH_TUERMODUL__SFHZ)
	lbu	a2,%lo(FH_TUERMODUL__SFHZ)(a2)
	bne	a2,zero,.L101
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	lui	a2,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a2)
.L216:
	sb	a3,%lo(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)(a4)
	j	.L101
.L104:
	lui	a3,%hi(FH_TUERMODUL__SFHA)
	lbu	a3,%lo(FH_TUERMODUL__SFHA)(a3)
	bne	a3,zero,.L101
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a3)
.L217:
	li	a3,3
	j	.L216
.L105:
	lui	a3,%hi(FH_TUERMODUL__SFHA)
	lbu	a3,%lo(FH_TUERMODUL__SFHA)(a3)
	beq	a3,zero,.L107
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	li	a2,1
	lui	a3,%hi(FH_TUERMODUL__MFHA_copy)
	sb	a2,%lo(FH_TUERMODUL__MFHA_copy)(a3)
	sb	a1,%lo(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)(a4)
	j	.L101
.L107:
	lui	a3,%hi(FH_TUERMODUL__SFHZ)
	lbu	a3,%lo(FH_TUERMODUL__SFHZ)(a3)
	beq	a3,zero,.L101
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a2,%hi(FH_TUERMODUL__MFHZ_copy)
	li	a3,1
	sb	a3,%lo(FH_TUERMODUL__MFHZ_copy)(a2)
	j	.L216
.L106:
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	j	.L216
.L98:
	lui	a2,%hi(FH_TUERMODUL_CTRL__N)
	lw	a1,%lo(FH_TUERMODUL_CTRL__N)(a2)
	li	a2,60
	ble	a1,a2,.L108
	lui	a1,%hi(FH_TUERMODUL_CTRL__N_old)
	lw	a1,%lo(FH_TUERMODUL_CTRL__N_old)(a1)
	bgt	a1,a2,.L108
	lui	a2,%hi(FH_TUERMODUL_CTRL__INREVERS1)
	lui	a1,%hi(FH_TUERMODUL_CTRL__INREVERS2)
	lbu	a2,%lo(FH_TUERMODUL_CTRL__INREVERS1)(a2)
	lbu	a1,%lo(FH_TUERMODUL_CTRL__INREVERS2)(a1)
	or	a2,a2,a1
	bne	a2,zero,.L108
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	lui	a2,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a2)
	lui	a2,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a2)
	sb	a3,%lo(B_FH_TUERMODUL_CTRL_next_state)(a4)
	j	.L101
.L108:
	lui	a3,%hi(FH_TUERMODUL__BLOCK)
	lbu	a3,%lo(FH_TUERMODUL__BLOCK)(a3)
	beq	a3,zero,.L109
	lui	a3,%hi(FH_TUERMODUL__BLOCK_old)
	lbu	a3,%lo(FH_TUERMODUL__BLOCK_old)(a3)
	bne	a3,zero,.L109
	lui	a3,%hi(FH_TUERMODUL__MFHA)
	lbu	a3,%lo(FH_TUERMODUL__MFHA)(a3)
	beq	a3,zero,.L110
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a3)
	lui	a3,%hi(time)
	lw	a2,%lo(time)(a3)
	lui	a3,%hi(sc_FH_TUERMODUL_CTRL_2375_2)
	sw	a2,%lo(sc_FH_TUERMODUL_CTRL_2375_2)(a3)
.L222:
	li	a3,2
	sb	a3,%lo(B_FH_TUERMODUL_CTRL_next_state)(a4)
	lui	a4,%hi(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)
	j	.L217
.L110:
	lui	a3,%hi(FH_TUERMODUL__MFHZ)
	lbu	a3,%lo(FH_TUERMODUL__MFHZ)(a3)
	beq	a3,zero,.L109
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a3)
	lui	a3,%hi(time)
	lw	a2,%lo(time)(a3)
	lui	a3,%hi(sc_FH_TUERMODUL_CTRL_2352_1)
	sw	a2,%lo(sc_FH_TUERMODUL_CTRL_2352_1)(a3)
	j	.L222
.L109:
	lui	a3,%hi(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a3)
	li	a2,2
	beq	a4,a2,.L111
	li	a1,3
	beq	a4,a1,.L112
	li	a0,1
	bne	a4,a0,.L113
	lui	a0,%hi(FH_TUERMODUL__POSITION)
	lw	a6,%lo(FH_TUERMODUL__POSITION)(a0)
	li	a0,404
	ble	a6,a0,.L114
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a4,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a4)
.L219:
	sb	a1,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a3)
	j	.L101
.L114:
	lui	a1,%hi(OEFFNEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a0,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a1)
	beq	a0,a4,.L115
	beq	a0,a2,.L116
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	sb	a2,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a1)
	j	.L101
.L115:
	lui	a4,%hi(FH_TUERMODUL__SFHZ)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ)(a4)
	beq	a4,zero,.L118
	lui	a4,%hi(FH_TUERMODUL__SFHZ_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ_old)(a4)
	beq	a4,zero,.L119
.L118:
	lui	a4,%hi(FH_TUERMODUL__SFHA)
	lbu	a4,%lo(FH_TUERMODUL__SFHA)(a4)
	beq	a4,zero,.L101
	lui	a4,%hi(FH_TUERMODUL__SFHA_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHA_old)(a4)
	bne	a4,zero,.L101
.L119:
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a4,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a4)
	li	a4,3
	sb	a4,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a3)
	sb	zero,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a1)
	j	.L101
.L116:
	lui	a2,%hi(FH_TUERMODUL__SFHZ)
	lbu	a2,%lo(FH_TUERMODUL__SFHZ)(a2)
	beq	a2,zero,.L120
	lui	a2,%hi(FH_TUERMODUL__SFHZ_old)
	lbu	a2,%lo(FH_TUERMODUL__SFHZ_old)(a2)
	bne	a2,zero,.L120
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	sb	a4,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a1)
	j	.L101
.L120:
	lui	a4,%hi(FH_TUERMODUL__SFHA)
	lbu	a4,%lo(FH_TUERMODUL__SFHA)(a4)
	bne	a4,zero,.L101
	lui	a4,%hi(FH_TUERMODUL__SFHA_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHA_old)(a4)
	bne	a4,zero,.L119
	j	.L101
.L111:
	lui	a2,%hi(FH_TUERMODUL__POSITION)
	lw	a2,%lo(FH_TUERMODUL__POSITION)(a2)
	bgt	a2,zero,.L121
.L126:
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a4,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a4)
	li	a4,3
	sb	a4,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a3)
	j	.L101
.L121:
	lui	a1,%hi(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a0,%lo(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a1)
	li	a2,1
	beq	a0,a2,.L122
	beq	a0,a4,.L123
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a3,%hi(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	sb	a4,%lo(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a1)
	sb	a4,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	j	.L214
.L122:
	lui	a4,%hi(FH_TUERMODUL__SFHA)
	lbu	a4,%lo(FH_TUERMODUL__SFHA)(a4)
	beq	a4,zero,.L125
	lui	a4,%hi(FH_TUERMODUL__SFHA_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHA_old)(a4)
	beq	a4,zero,.L126
.L125:
	lui	a4,%hi(FH_TUERMODUL__SFHZ)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ)(a4)
	beq	a4,zero,.L127
	lui	a4,%hi(FH_TUERMODUL__SFHZ_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ_old)(a4)
	beq	a4,zero,.L126
.L127:
	lui	a3,%hi(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a2,%lo(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	li	a4,1
	beq	a2,a4,.L128
	li	a1,2
	beq	a2,a1,.L129
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	sb	a1,%lo(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	sb	a4,17(a5)
	j	.L101
.L128:
	lbu	a4,22(a5)
	sb	zero,23(a5)
	beq	a4,zero,.L101
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a4,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	a2,%lo(FH_TUERMODUL__MFHZ_copy)(a4)
	lui	a4,%hi(FH_TUERMODUL_CTRL__INREVERS2_copy)
	sb	zero,%lo(FH_TUERMODUL_CTRL__INREVERS2_copy)(a4)
	li	a4,2
	sb	a4,%lo(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	lui	a4,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a4)
	sb	a2,17(a5)
	j	.L101
.L129:
	lbu	a2,24(a5)
	beq	a2,zero,.L101
	lui	a2,%hi(stable)
	sb	a4,%lo(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	lui	a3,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(stable)(a2)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a3)
	lui	a2,%hi(FH_TUERMODUL_CTRL__INREVERS2_copy)
	lui	a3,%hi(time)
	sb	a4,%lo(FH_TUERMODUL_CTRL__INREVERS2_copy)(a2)
	lw	a2,%lo(time)(a3)
	lui	a3,%hi(sc_FH_TUERMODUL_CTRL_1781_10)
	sb	a4,23(a5)
	sb	zero,17(a5)
	sw	a2,%lo(sc_FH_TUERMODUL_CTRL_1781_10)(a3)
.L215:
	lui	a3,%hi(FH_TUERMODUL__MFHA_copy)
	sb	a4,%lo(FH_TUERMODUL__MFHA_copy)(a3)
	j	.L101
.L123:
	lui	a4,%hi(FH_TUERMODUL__SFHZ)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ)(a4)
	bne	a4,zero,.L131
	lui	a4,%hi(FH_TUERMODUL__SFHZ_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ_old)(a4)
	bne	a4,zero,.L126
.L131:
	lui	a3,%hi(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a2,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	li	a4,1
	beq	a2,a4,.L132
	li	a0,2
	beq	a2,a0,.L133
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	sb	a0,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
.L218:
	lui	a3,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	a4,17(a5)
	sb	a4,%lo(FH_TUERMODUL__MFHZ_copy)(a3)
	j	.L101
.L132:
	lbu	a4,22(a5)
	sb	zero,23(a5)
	beq	a4,zero,.L101
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a4,%hi(FH_TUERMODUL_CTRL__INREVERS1_copy)
	sb	zero,%lo(FH_TUERMODUL_CTRL__INREVERS1_copy)(a4)
	li	a4,2
	sb	a4,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	lui	a4,%hi(FH_TUERMODUL__MFHA_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHA_copy)(a4)
.L214:
	lui	a4,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	a2,17(a5)
	sb	a2,%lo(FH_TUERMODUL__MFHZ_copy)(a4)
	j	.L101
.L133:
	lbu	a2,24(a5)
	beq	a2,zero,.L135
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	lui	a2,%hi(FH_TUERMODUL__MFHZ_copy)
	sb	zero,%lo(FH_TUERMODUL__MFHZ_copy)(a2)
	sb	a4,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	lui	a2,%hi(FH_TUERMODUL_CTRL__INREVERS1_copy)
	lui	a3,%hi(time)
	sb	a4,%lo(FH_TUERMODUL_CTRL__INREVERS1_copy)(a2)
	lw	a2,%lo(time)(a3)
	lui	a3,%hi(sc_FH_TUERMODUL_CTRL_1739_10)
	sb	a4,23(a5)
	sb	zero,17(a5)
	sw	a2,%lo(sc_FH_TUERMODUL_CTRL_1739_10)(a3)
	j	.L215
.L135:
	lui	a2,%hi(FH_TUERMODUL__SFHA)
	lbu	a2,%lo(FH_TUERMODUL__SFHA)(a2)
	beq	a2,zero,.L101
	lui	a2,%hi(FH_TUERMODUL__SFHA_old)
	lbu	a2,%lo(FH_TUERMODUL__SFHA_old)(a2)
	bne	a2,zero,.L101
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	sb	a4,%lo(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a1)
	sb	zero,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a3)
	j	.L101
.L112:
	lui	a4,%hi(FH_TUERMODUL__SFHZ)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ)(a4)
	beq	a4,zero,.L136
	lui	a4,%hi(FH_TUERMODUL__SFHZ_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHZ_old)(a4)
	bne	a4,zero,.L136
	lui	a4,%hi(FH_TUERMODUL__POSITION)
	lw	a4,%lo(FH_TUERMODUL__POSITION)(a4)
	ble	a4,zero,.L136
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a4,%hi(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	sb	a2,%lo(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a4)
	lui	a4,%hi(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	sb	a2,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a4)
	sb	a2,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a3)
	li	a4,1
	j	.L218
.L136:
	lui	a4,%hi(FH_TUERMODUL__SFHA)
	lbu	a4,%lo(FH_TUERMODUL__SFHA)(a4)
	beq	a4,zero,.L101
	lui	a4,%hi(FH_TUERMODUL__SFHA_old)
	lbu	a4,%lo(FH_TUERMODUL__SFHA_old)(a4)
	bne	a4,zero,.L101
	lui	a4,%hi(FH_TUERMODUL__POSITION)
	lw	a2,%lo(FH_TUERMODUL__POSITION)(a4)
	li	a4,404
	bgt	a2,a4,.L101
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	lui	a2,%hi(FH_TUERMODUL__MFHA_copy)
	li	a4,1
	sb	a4,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a3)
	sb	a4,%lo(FH_TUERMODUL__MFHA_copy)(a2)
	li	a3,2
	lui	a4,%hi(OEFFNEN_FH_TUERMODUL_CTRL_next_state)
	sb	a3,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a4)
	j	.L101
.L113:
	lui	a4,%hi(stable)
	sb	zero,%lo(stable)(a4)
	j	.L219
.L99:
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	sb	a0,%lo(B_FH_TUERMODUL_CTRL_next_state)(a4)
	j	.L101
.L138:
	lbu	a1,%lo(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)(a4)
	li	a3,1
	bne	a1,a3,.L140
	bne	a2,a1,.L139
	lui	a3,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)
	lw	a1,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)(a3)
	beq	a1,zero,.L139
	lui	a3,%hi(time)
	lw	a3,%lo(time)(a3)
	addi	a3,a3,-3
	bne	a3,a1,.L139
	lui	a3,%hi(FH_TUERMODUL__MFHZ)
	lui	a1,%hi(FH_TUERMODUL__MFHA)
	lbu	a3,%lo(FH_TUERMODUL__MFHZ)(a3)
	lbu	a1,%lo(FH_TUERMODUL__MFHA)(a1)
	or	a3,a3,a1
	bne	a3,zero,.L139
	lui	a1,%hi(FH_TUERMODUL_CTRL__N)
	lw	a3,%lo(FH_TUERMODUL_CTRL__N)(a1)
	ble	a3,zero,.L139
	lui	a0,%hi(stable)
	addi	a3,a3,-1
	sb	zero,%lo(stable)(a0)
	sw	a3,%lo(FH_TUERMODUL_CTRL__N)(a1)
	sb	a2,%lo(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)(a4)
.L139:
	lbu	a4,4(a5)
	sb	a4,5(a5)
	lbu	a4,6(a5)
	sb	a4,7(a5)
.L91:
	ret
.L140:
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
.L221:
	sb	a3,%lo(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)(a4)
	j	.L139
.L137:
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	lui	a2,%hi(FH_TUERMODUL_CTRL__N)
	sw	zero,%lo(FH_TUERMODUL_CTRL__N)(a2)
	j	.L220
	.size	generic_FH_TUERMODUL_CTRL, .-generic_FH_TUERMODUL_CTRL
	.section	.text.generic_EINKLEMMSCHUTZ_CTRL,"ax",@progbits
	.align	2
	.globl	generic_EINKLEMMSCHUTZ_CTRL
	.type	generic_EINKLEMMSCHUTZ_CTRL, @function
generic_EINKLEMMSCHUTZ_CTRL:
	lui	a5,%hi(Bitlist)
	addi	a5,a5,%lo(Bitlist)
	lbu	a4,16(a5)
	beq	a4,zero,.L223
	lui	a4,%hi(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)
	lbu	a2,%lo(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)(a4)
	li	a3,1
	beq	a2,a3,.L226
	li	a1,2
	beq	a2,a1,.L227
.L240:
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	sb	a3,%lo(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)(a4)
	ret
.L226:
	lui	a3,%hi(FH_TUERMODUL__EKS_LEISTE_AKTIV)
	lbu	a3,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV)(a3)
	beq	a3,zero,.L223
	lui	a3,%hi(FH_TUERMODUL__EKS_LEISTE_AKTIV_old)
	lbu	a3,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV_old)(a3)
	bne	a3,zero,.L223
	lui	a3,%hi(FH_TUERMODUL__SFHZ)
	lbu	a3,%lo(FH_TUERMODUL__SFHZ)(a3)
	beq	a3,zero,.L230
	lui	a3,%hi(FH_TUERMODUL__SFHA)
	lbu	a3,%lo(FH_TUERMODUL__SFHA)(a3)
	bne	a3,zero,.L223
.L230:
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	li	a3,1
	sb	a3,24(a5)
	li	a5,2
	sb	a5,%lo(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)(a4)
	ret
.L227:
	sb	zero,24(a5)
	lui	a5,%hi(FH_TUERMODUL__EKS_LEISTE_AKTIV)
	lbu	a5,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV)(a5)
	bne	a5,zero,.L223
	lui	a5,%hi(FH_TUERMODUL__EKS_LEISTE_AKTIV_old)
	lbu	a5,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV_old)(a5)
	bne	a5,zero,.L240
.L223:
	ret
	.size	generic_EINKLEMMSCHUTZ_CTRL, .-generic_EINKLEMMSCHUTZ_CTRL
	.section	.text.generic_BLOCK_ERKENNUNG_CTRL,"ax",@progbits
	.align	2
	.globl	generic_BLOCK_ERKENNUNG_CTRL
	.type	generic_BLOCK_ERKENNUNG_CTRL, @function
generic_BLOCK_ERKENNUNG_CTRL:
	lui	a5,%hi(Bitlist)
	addi	a5,a5,%lo(Bitlist)
	lbu	a4,19(a5)
	beq	a4,zero,.L242
	lui	a3,%hi(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)
	lbu	a4,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a3)
	li	a2,1
	beq	a4,a2,.L243
	li	a1,2
	beq	a4,a1,.L244
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	sb	a2,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a3)
.L241:
	ret
.L242:
	lbu	a4,21(a5)
	beq	a4,zero,.L241
	lbu	a4,20(a5)
	bne	a4,zero,.L241
	sb	zero,0(a5)
	ret
.L243:
	lui	a2,%hi(FH_TUERMODUL__I_EIN)
	lui	a1,%hi(FH_TUERMODUL__I_EIN_old)
	lw	a2,%lo(FH_TUERMODUL__I_EIN)(a2)
	lw	a1,%lo(FH_TUERMODUL__I_EIN_old)(a1)
	beq	a1,a2,.L241
	ble	a2,zero,.L241
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	lui	a2,%hi(FH_TUERMODUL__BLOCK_copy)
	sb	zero,%lo(FH_TUERMODUL__BLOCK_copy)(a2)
	li	a2,2
	sb	a2,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a3)
	lui	a3,%hi(BLOCK_ERKENNUNG_CTRL__N)
	sw	zero,%lo(BLOCK_ERKENNUNG_CTRL__N)(a3)
	lui	a3,%hi(BLOCK_ERKENNUNG_CTRL__I_EIN_MAX)
	sw	a2,%lo(BLOCK_ERKENNUNG_CTRL__I_EIN_MAX)(a3)
	lui	a3,%hi(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)
	li	a2,3
	sb	a2,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a3)
	sb	a4,0(a5)
	ret
.L244:
	lui	a4,%hi(FH_TUERMODUL__MFHA)
	lbu	a2,%lo(FH_TUERMODUL__MFHA)(a4)
	lui	a4,%hi(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)
	bne	a2,zero,.L249
	lui	a2,%hi(FH_TUERMODUL__MFHA_old)
	lbu	a2,%lo(FH_TUERMODUL__MFHA_old)(a2)
	bne	a2,zero,.L250
.L249:
	lui	a2,%hi(FH_TUERMODUL__MFHZ)
	lbu	a2,%lo(FH_TUERMODUL__MFHZ)(a2)
	bne	a2,zero,.L251
	lui	a2,%hi(FH_TUERMODUL__MFHZ_old)
	lbu	a2,%lo(FH_TUERMODUL__MFHZ_old)(a2)
	beq	a2,zero,.L251
.L250:
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	li	a5,1
	sb	a5,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a3)
	sb	zero,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
	ret
.L251:
	lbu	a2,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
	li	a3,2
	beq	a2,a3,.L252
	li	a0,3
	beq	a2,a0,.L253
	li	a1,1
	beq	a2,a1,.L241
	lui	a2,%hi(stable)
	sb	zero,%lo(stable)(a2)
	lui	a2,%hi(BLOCK_ERKENNUNG_CTRL__N)
	sw	zero,%lo(BLOCK_ERKENNUNG_CTRL__N)(a2)
	lui	a2,%hi(BLOCK_ERKENNUNG_CTRL__I_EIN_MAX)
	sw	a3,%lo(BLOCK_ERKENNUNG_CTRL__I_EIN_MAX)(a2)
	sb	a0,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
	sb	a1,0(a5)
	ret
.L252:
	lui	a5,%hi(BLOCK_ERKENNUNG_CTRL__I_EIN_MAX)
	lw	a5,%lo(BLOCK_ERKENNUNG_CTRL__I_EIN_MAX)(a5)
	lui	a3,%hi(FH_TUERMODUL__I_EIN)
	lw	a3,%lo(FH_TUERMODUL__I_EIN)(a3)
	addi	a5,a5,-1
	bgt	a5,a3,.L241
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	lui	a3,%hi(FH_TUERMODUL__BLOCK_copy)
	li	a5,1
	sb	a5,%lo(FH_TUERMODUL__BLOCK_copy)(a3)
	sb	a5,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
	ret
.L253:
	sb	zero,0(a5)
	lui	a5,%hi(BLOCK_ERKENNUNG_CTRL__N)
	lw	a5,%lo(BLOCK_ERKENNUNG_CTRL__N)(a5)
	li	a2,11
	bne	a5,a2,.L241
	lui	a2,%hi(BLOCK_ERKENNUNG_CTRL__N_old)
	lw	a2,%lo(BLOCK_ERKENNUNG_CTRL__N_old)(a2)
	beq	a2,a5,.L241
	lui	a5,%hi(stable)
	sb	zero,%lo(stable)(a5)
	sb	a3,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
	ret
	.size	generic_BLOCK_ERKENNUNG_CTRL, .-generic_BLOCK_ERKENNUNG_CTRL
	.section	.text.FH_DU,"ax",@progbits
	.align	2
	.globl	FH_DU
	.type	FH_DU, @function
FH_DU:
	lui	a3,%hi(stable)
	sb	zero,%lo(stable)(a3)
	lui	a5,%hi(time)
	li	a4,1
	lbu	a0,%lo(stable)(a3)
	sw	a4,%lo(time)(a5)
	lui	a5,%hi(step)
	sb	zero,%lo(step)(a5)
	lui	a5,%hi(Bitlist)
	lui	a2,%hi(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)
	li	a1,2
	addi	a5,a5,%lo(Bitlist)
	beq	a0,zero,.L300
	ret
.L268:
	lbu	a6,%lo(FH_DU__MFHZ)(t4)
	beq	a6,zero,.L272
	lbu	a6,%lo(FH_DU__MFHZ_old)(t3)
	bne	a6,zero,.L272
	li	a6,-100
	sb	zero,%lo(stable)(a3)
	sw	a6,%lo(FH_DU__MFH)(a0)
	sb	a4,%lo(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)(a2)
.L271:
	lbu	a0,10(a5)
	bne	a0,zero,.L274
	lui	a0,%hi(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)
	li	a6,3
	sb	a6,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a0)
.L274:
	lbu	a0,16(a5)
	bne	a0,zero,.L275
	lui	a0,%hi(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)
	sb	a4,%lo(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)(a0)
.L275:
	lbu	a0,19(a5)
	bne	a0,zero,.L276
	lui	a0,%hi(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)
	sb	zero,0(a5)
	sb	a4,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a0)
.L276:
	lbu	a0,13(a5)
	bne	a0,zero,.L277
	lui	a0,%hi(B_FH_TUERMODUL_CTRL_next_state)
	sb	a1,%lo(B_FH_TUERMODUL_CTRL_next_state)(a0)
	lui	a0,%hi(FH_TUERMODUL_CTRL__N)
	sw	zero,%lo(FH_TUERMODUL_CTRL__N)(a0)
	lui	a0,%hi(A_FH_TUERMODUL_CTRL_next_state)
	sb	a4,%lo(A_FH_TUERMODUL_CTRL_next_state)(a0)
	li	a0,256
	sh	a0,4(a5)
	lui	a0,%hi(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)
	sb	zero,6(a5)
	sb	a4,%lo(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)(a0)
.L277:
	lui	a0,%hi(FH_DU__S_FH_TMBFZUCAN)
	lui	a7,%hi(FH_DU__S_FH_TMBFZUCAN_old)
	lbu	a6,%lo(FH_DU__S_FH_TMBFZUCAN)(a0)
	lbu	a7,%lo(FH_DU__S_FH_TMBFZUCAN_old)(a7)
	sb	a4,11(a5)
	sb	a4,17(a5)
	sb	a4,20(a5)
	sb	a4,14(a5)
	beq	a7,a6,.L278
	lui	a7,%hi(FH_DU__DOOR_ID)
	lbu	a7,%lo(FH_DU__DOOR_ID)(a7)
	bne	a7,zero,.L278
	lui	a7,%hi(FH_DU__S_FH_FTZU)
	sb	a6,%lo(FH_DU__S_FH_FTZU)(a7)
.L278:
	lui	a6,%hi(FH_DU__S_FH_TMBFZUDISC)
	lui	a7,%hi(FH_DU__S_FH_TMBFZUDISC_old)
	lbu	a6,%lo(FH_DU__S_FH_TMBFZUDISC)(a6)
	lbu	a7,%lo(FH_DU__S_FH_TMBFZUDISC_old)(a7)
	beq	a7,a6,.L279
	lui	a7,%hi(FH_DU__DOOR_ID)
	lbu	a7,%lo(FH_DU__DOOR_ID)(a7)
	beq	a7,zero,.L279
	sb	a6,%lo(FH_DU__S_FH_TMBFZUCAN)(a0)
.L279:
	lui	a0,%hi(FH_DU__S_FH_TMBFAUFCAN)
	lui	a7,%hi(FH_DU__S_FH_TMBFAUFCAN_old)
	lbu	a6,%lo(FH_DU__S_FH_TMBFAUFCAN)(a0)
	lbu	a7,%lo(FH_DU__S_FH_TMBFAUFCAN_old)(a7)
	beq	a7,a6,.L280
	lui	a7,%hi(FH_DU__DOOR_ID)
	lbu	a7,%lo(FH_DU__DOOR_ID)(a7)
	bne	a7,zero,.L280
	lui	a7,%hi(FH_DU__S_FH_FTAUF)
	sb	a6,%lo(FH_DU__S_FH_FTAUF)(a7)
.L280:
	lui	a6,%hi(FH_DU__S_FH_TMBFAUFDISC)
	lui	a7,%hi(FH_DU__S_FH_TMBFAUFDISC_old)
	lbu	a6,%lo(FH_DU__S_FH_TMBFAUFDISC)(a6)
	lbu	a7,%lo(FH_DU__S_FH_TMBFAUFDISC_old)(a7)
	beq	a7,a6,.L281
	lui	a7,%hi(FH_DU__DOOR_ID)
	lbu	a7,%lo(FH_DU__DOOR_ID)(a7)
	beq	a7,zero,.L281
	sb	a6,%lo(FH_DU__S_FH_TMBFAUFCAN)(a0)
.L281:
	lbu	a0,12(a5)
	lui	s6,%hi(FH_DU__S_FH_AUFDISC)
	lui	s7,%hi(FH_TUERMODUL__SFHA_MEC)
	sb	a0,10(a5)
	lbu	a0,15(a5)
	lui	s4,%hi(FH_DU__S_FH_FTAUF)
	lui	s5,%hi(FH_TUERMODUL__SFHA_ZENTRAL)
	sb	a0,13(a5)
	lbu	a0,18(a5)
	lui	s2,%hi(FH_DU__S_FH_ZUDISC)
	lui	s3,%hi(FH_TUERMODUL__SFHZ_MEC)
	sb	a0,16(a5)
	lbu	a0,21(a5)
	lui	s0,%hi(FH_DU__S_FH_FTZU)
	lui	s1,%hi(FH_TUERMODUL__SFHZ_ZENTRAL)
	sb	a0,19(a5)
	lbu	a0,%lo(FH_DU__S_FH_AUFDISC)(s6)
	lui	s9,%hi(FH_TUERMODUL__I_EIN)
	lui	s11,%hi(FH_DU__I_EIN)
	sb	a0,%lo(FH_TUERMODUL__SFHA_MEC)(s7)
	lbu	a0,%lo(FH_DU__S_FH_FTAUF)(s4)
	lui	s10,%hi(FH_TUERMODUL__EKS_LEISTE_AKTIV)
	lui	s8,%hi(FH_TUERMODUL__POSITION)
	sb	a0,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(s5)
	lbu	a0,%lo(FH_DU__S_FH_ZUDISC)(s2)
	sb	a0,%lo(FH_TUERMODUL__SFHZ_MEC)(s3)
	lbu	a0,%lo(FH_DU__S_FH_FTZU)(s0)
	sb	a0,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(s1)
	call	generic_KINDERSICHERUNG_CTRL
	lui	a5,%hi(FH_TUERMODUL__MFHA)
	lbu	a0,%lo(FH_TUERMODUL__MFHA)(a5)
	lui	a3,%hi(FH_TUERMODUL__MFHZ)
	lui	a4,%hi(FH_DU__MFHA)
	sb	a0,%lo(FH_DU__MFHA)(a4)
	lbu	a0,%lo(FH_TUERMODUL__MFHZ)(a3)
	lui	a1,%hi(FH_DU__MFHZ)
	lw	a7,%lo(FH_TUERMODUL__POSITION)(s8)
	sb	a0,%lo(FH_DU__MFHZ)(a1)
	lw	a0,%lo(FH_TUERMODUL__I_EIN)(s9)
	lui	a6,%hi(FH_DU__EKS_LEISTE_AKTIV)
	lui	t1,%hi(FH_DU__FT)
	sw	a0,%lo(FH_DU__I_EIN)(s11)
	lbu	a0,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV)(s10)
	lui	t4,%hi(FH_TUERMODUL__KL_50)
	lui	t6,%hi(FH_TUERMODUL__BLOCK)
	sb	a0,%lo(FH_DU__EKS_LEISTE_AKTIV)(a6)
	lui	a0,%hi(FH_DU__POSITION)
	sw	a7,%lo(FH_DU__POSITION)(a0)
	lui	a7,%hi(FH_TUERMODUL__FT)
	lbu	a7,%lo(FH_TUERMODUL__FT)(a7)
	lui	t5,%hi(FH_DU__KL_50)
	lui	t2,%hi(FH_DU__BLOCK)
	sb	a7,%lo(FH_DU__FT)(t1)
	lbu	a7,%lo(FH_TUERMODUL__SFHA_MEC)(s7)
	sb	a7,%lo(FH_DU__S_FH_AUFDISC)(s6)
	lbu	a7,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(s5)
	sb	a7,%lo(FH_DU__S_FH_FTAUF)(s4)
	lbu	a7,%lo(FH_TUERMODUL__SFHZ_MEC)(s3)
	sb	a7,%lo(FH_DU__S_FH_ZUDISC)(s2)
	lbu	a7,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(s1)
	sb	a7,%lo(FH_DU__S_FH_FTZU)(s0)
	lbu	a7,%lo(FH_TUERMODUL__KL_50)(t4)
	sb	a7,%lo(FH_DU__KL_50)(t5)
	lbu	a7,%lo(FH_TUERMODUL__BLOCK)(t6)
	sb	a7,%lo(FH_DU__BLOCK)(t2)
	call	generic_FH_TUERMODUL_CTRL
	lui	a5,%hi(FH_TUERMODUL__MFHA)
	lbu	a7,%lo(FH_TUERMODUL__MFHA)(a5)
	lui	a4,%hi(FH_DU__MFHA)
	lui	a2,%hi(FH_TUERMODUL__MFHZ)
	sb	a7,%lo(FH_DU__MFHA)(a4)
	lbu	a7,%lo(FH_TUERMODUL__MFHZ)(a2)
	lui	a1,%hi(FH_DU__MFHZ)
	lui	a6,%hi(FH_DU__EKS_LEISTE_AKTIV)
	sb	a7,%lo(FH_DU__MFHZ)(a1)
	lw	a7,%lo(FH_TUERMODUL__I_EIN)(s9)
	lui	a0,%hi(FH_DU__POSITION)
	lui	t3,%hi(FH_DU__FT)
	sw	a7,%lo(FH_DU__I_EIN)(s11)
	lbu	a7,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV)(s10)
	lui	t4,%hi(FH_TUERMODUL__KL_50)
	lui	t5,%hi(FH_DU__KL_50)
	sb	a7,%lo(FH_DU__EKS_LEISTE_AKTIV)(a6)
	lw	a7,%lo(FH_TUERMODUL__POSITION)(s8)
	lui	t0,%hi(FH_TUERMODUL__BLOCK)
	lui	t2,%hi(FH_DU__BLOCK)
	sw	a7,%lo(FH_DU__POSITION)(a0)
	lui	a7,%hi(FH_TUERMODUL__FT)
	lbu	a7,%lo(FH_TUERMODUL__FT)(a7)
	sb	a7,%lo(FH_DU__FT)(t3)
	lbu	a7,%lo(FH_TUERMODUL__SFHA_MEC)(s7)
	sb	a7,%lo(FH_DU__S_FH_AUFDISC)(s6)
	lbu	a7,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(s5)
	sb	a7,%lo(FH_DU__S_FH_FTAUF)(s4)
	lbu	a7,%lo(FH_TUERMODUL__SFHZ_MEC)(s3)
	sb	a7,%lo(FH_DU__S_FH_ZUDISC)(s2)
	lbu	a7,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(s1)
	sb	a7,%lo(FH_DU__S_FH_FTZU)(s0)
	lbu	a7,%lo(FH_TUERMODUL__KL_50)(t4)
	sb	a7,%lo(FH_DU__KL_50)(t5)
	lbu	a7,%lo(FH_TUERMODUL__BLOCK)(t0)
	sb	a7,%lo(FH_DU__BLOCK)(t2)
	call	generic_EINKLEMMSCHUTZ_CTRL
	lui	a5,%hi(FH_TUERMODUL__MFHA)
	lbu	a7,%lo(FH_TUERMODUL__MFHA)(a5)
	lui	a3,%hi(FH_DU__MFHA)
	lui	a2,%hi(FH_TUERMODUL__MFHZ)
	sb	a7,%lo(FH_DU__MFHA)(a3)
	lbu	a7,%lo(FH_TUERMODUL__MFHZ)(a2)
	lui	a1,%hi(FH_DU__MFHZ)
	lui	a6,%hi(FH_DU__EKS_LEISTE_AKTIV)
	sb	a7,%lo(FH_DU__MFHZ)(a1)
	lw	a7,%lo(FH_TUERMODUL__I_EIN)(s9)
	lui	t1,%hi(FH_DU__POSITION)
	lui	t3,%hi(FH_DU__FT)
	sw	a7,%lo(FH_DU__I_EIN)(s11)
	lbu	a7,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV)(s10)
	lui	t4,%hi(FH_TUERMODUL__KL_50)
	lui	t6,%hi(FH_DU__KL_50)
	sb	a7,%lo(FH_DU__EKS_LEISTE_AKTIV)(a6)
	lw	a7,%lo(FH_TUERMODUL__POSITION)(s8)
	lui	t0,%hi(FH_TUERMODUL__BLOCK)
	lui	t2,%hi(FH_DU__BLOCK)
	sw	a7,%lo(FH_DU__POSITION)(t1)
	lui	a7,%hi(FH_TUERMODUL__FT)
	lbu	a7,%lo(FH_TUERMODUL__FT)(a7)
	sb	a7,%lo(FH_DU__FT)(t3)
	lbu	a7,%lo(FH_TUERMODUL__SFHA_MEC)(s7)
	sb	a7,%lo(FH_DU__S_FH_AUFDISC)(s6)
	lbu	a7,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(s5)
	sb	a7,%lo(FH_DU__S_FH_FTAUF)(s4)
	lbu	a7,%lo(FH_TUERMODUL__SFHZ_MEC)(s3)
	sb	a7,%lo(FH_DU__S_FH_ZUDISC)(s2)
	lbu	a7,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(s1)
	sb	a7,%lo(FH_DU__S_FH_FTZU)(s0)
	lbu	a7,%lo(FH_TUERMODUL__KL_50)(t4)
	sb	a7,%lo(FH_DU__KL_50)(t6)
	lbu	a7,%lo(FH_TUERMODUL__BLOCK)(t0)
	sb	a7,%lo(FH_DU__BLOCK)(t2)
	call	generic_BLOCK_ERKENNUNG_CTRL
	lui	t5,%hi(FH_TUERMODUL__KL_50)
	lbu	t5,%lo(FH_TUERMODUL__KL_50)(t5)
	lui	a5,%hi(Bitlist)
	addi	a5,a5,%lo(Bitlist)
	lui	t6,%hi(FH_DU__KL_50)
	sb	t5,%lo(FH_DU__KL_50)(t6)
	lbu	t5,10(a5)
	lbu	a6,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV)(s10)
	lui	a0,%hi(FH_DU__EKS_LEISTE_AKTIV)
	sb	t5,11(a5)
	lbu	t5,13(a5)
	sb	a6,%lo(FH_DU__EKS_LEISTE_AKTIV)(a0)
	lw	a0,%lo(FH_TUERMODUL__POSITION)(s8)
	sb	t5,14(a5)
	lbu	t5,16(a5)
	lw	a7,%lo(FH_TUERMODUL__I_EIN)(s9)
	lui	t1,%hi(FH_DU__POSITION)
	sb	t5,17(a5)
	lbu	t5,19(a5)
	sw	a0,%lo(FH_DU__POSITION)(t1)
	lui	a0,%hi(FH_TUERMODUL__FT)
	sb	t5,20(a5)
	lui	t5,%hi(FH_TUERMODUL_CTRL__N)
	lw	t6,%lo(FH_TUERMODUL_CTRL__N)(t5)
	lui	t5,%hi(FH_TUERMODUL_CTRL__N_old)
	lbu	a0,%lo(FH_TUERMODUL__FT)(a0)
	sw	t6,%lo(FH_TUERMODUL_CTRL__N_old)(t5)
	lui	t5,%hi(FH_TUERMODUL__I_EIN_old)
	sw	a7,%lo(FH_TUERMODUL__I_EIN_old)(t5)
	lui	t5,%hi(FH_DU__MFH_copy)
	lw	t6,%lo(FH_DU__MFH_copy)(t5)
	lui	t3,%hi(FH_DU__FT)
	lbu	t1,%lo(FH_TUERMODUL__SFHA_ZENTRAL)(s5)
	lbu	t4,%lo(FH_TUERMODUL__SFHZ_ZENTRAL)(s1)
	sb	a0,%lo(FH_DU__FT)(t3)
	lui	t5,%hi(FH_DU__MFH)
	lbu	a0,%lo(FH_TUERMODUL__SFHA_MEC)(s7)
	lbu	t3,%lo(FH_TUERMODUL__SFHZ_MEC)(s3)
	sw	t6,%lo(FH_DU__MFH)(t5)
	lui	t5,%hi(FH_DU__I_EIN_old)
	sw	a7,%lo(FH_DU__I_EIN)(s11)
	sw	a7,%lo(FH_DU__I_EIN_old)(t5)
	lui	a7,%hi(BLOCK_ERKENNUNG_CTRL__N)
	sb	a0,%lo(FH_DU__S_FH_AUFDISC)(s6)
	sb	t1,%lo(FH_DU__S_FH_FTAUF)(s4)
	sb	t3,%lo(FH_DU__S_FH_ZUDISC)(s2)
	sb	t4,%lo(FH_DU__S_FH_FTZU)(s0)
	lw	t5,%lo(BLOCK_ERKENNUNG_CTRL__N)(a7)
	lui	a7,%hi(BLOCK_ERKENNUNG_CTRL__N_old)
	lui	t0,%hi(FH_TUERMODUL__BLOCK)
	sw	t5,%lo(BLOCK_ERKENNUNG_CTRL__N_old)(a7)
	lui	a7,%hi(FH_TUERMODUL__SFHZ_ZENTRAL_old)
	sb	t4,%lo(FH_TUERMODUL__SFHZ_ZENTRAL_old)(a7)
	lui	a7,%hi(FH_TUERMODUL__SFHZ_MEC_old)
	sb	t3,%lo(FH_TUERMODUL__SFHZ_MEC_old)(a7)
	lui	a7,%hi(FH_TUERMODUL__SFHA_ZENTRAL_old)
	sb	t1,%lo(FH_TUERMODUL__SFHA_ZENTRAL_old)(a7)
	lui	a7,%hi(FH_TUERMODUL__SFHA_MEC_old)
	sb	a0,%lo(FH_TUERMODUL__SFHA_MEC_old)(a7)
	lui	a0,%hi(FH_TUERMODUL__BLOCK_copy)
	lbu	a0,%lo(FH_TUERMODUL__BLOCK_copy)(a0)
	lui	a7,%hi(FH_TUERMODUL__BLOCK_old)
	lui	a2,%hi(FH_TUERMODUL__MFHZ)
	sb	a0,%lo(FH_TUERMODUL__BLOCK_old)(a7)
	sb	a0,%lo(FH_TUERMODUL__BLOCK)(t0)
	lui	a0,%hi(FH_TUERMODUL__SFHZ_copy)
	lbu	a0,%lo(FH_TUERMODUL__SFHZ_copy)(a0)
	lui	a7,%hi(FH_TUERMODUL__SFHZ)
	lui	a4,%hi(FH_TUERMODUL__MFHA)
	sb	a0,%lo(FH_TUERMODUL__SFHZ)(a7)
	lui	a7,%hi(FH_TUERMODUL__SFHZ_old)
	sb	a0,%lo(FH_TUERMODUL__SFHZ_old)(a7)
	lui	a0,%hi(FH_TUERMODUL__SFHA_copy)
	lbu	a0,%lo(FH_TUERMODUL__SFHA_copy)(a0)
	lui	a7,%hi(FH_TUERMODUL__SFHA)
	lui	t2,%hi(FH_DU__BLOCK)
	sb	a0,%lo(FH_TUERMODUL__SFHA)(a7)
	lui	a7,%hi(FH_TUERMODUL__SFHA_old)
	sb	a0,%lo(FH_TUERMODUL__SFHA_old)(a7)
	lui	a0,%hi(FH_TUERMODUL__MFHZ_copy)
	lbu	a0,%lo(FH_TUERMODUL__MFHZ_copy)(a0)
	lui	a7,%hi(FH_TUERMODUL__MFHZ_old)
	lui	a1,%hi(FH_DU__MFHZ)
	sb	a0,%lo(FH_TUERMODUL__MFHZ)(a2)
	sb	a0,%lo(FH_TUERMODUL__MFHZ_old)(a7)
	lui	a0,%hi(FH_TUERMODUL__MFHA_copy)
	lbu	a0,%lo(FH_TUERMODUL__MFHA_copy)(a0)
	lui	a7,%hi(FH_TUERMODUL__MFHA_old)
	lui	a3,%hi(FH_DU__MFHA)
	sb	a0,%lo(FH_TUERMODUL__MFHA)(a4)
	sb	a0,%lo(FH_TUERMODUL__MFHA_old)(a7)
	lui	a0,%hi(FH_TUERMODUL__EKS_LEISTE_AKTIV_old)
	sb	a6,%lo(FH_TUERMODUL__EKS_LEISTE_AKTIV_old)(a0)
	lui	a0,%hi(FH_DU__EKS_LEISTE_AKTIV_old)
	sb	a6,%lo(FH_DU__EKS_LEISTE_AKTIV_old)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFAUFCAN)
	lbu	a6,%lo(FH_DU__S_FH_TMBFAUFCAN)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFAUFCAN_old)
	lui	a2,%hi(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)
	sb	a6,%lo(FH_DU__S_FH_TMBFAUFCAN_old)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFZUCAN)
	lbu	a6,%lo(FH_DU__S_FH_TMBFZUCAN)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFZUCAN_old)
	li	a4,1
	sb	a6,%lo(FH_DU__S_FH_TMBFZUCAN_old)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFZUDISC)
	lbu	a6,%lo(FH_DU__S_FH_TMBFZUDISC)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFZUDISC_old)
	sb	a6,%lo(FH_DU__S_FH_TMBFZUDISC_old)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFAUFDISC)
	lbu	a6,%lo(FH_DU__S_FH_TMBFAUFDISC)(a0)
	lui	a0,%hi(FH_DU__S_FH_TMBFAUFDISC_old)
	sb	a6,%lo(FH_DU__S_FH_TMBFAUFDISC_old)(a0)
	lui	a0,%hi(FH_DU__BLOCK_copy)
	lbu	a0,%lo(FH_DU__BLOCK_copy)(a0)
	lui	a6,%hi(FH_DU__BLOCK_old)
	sb	a0,%lo(FH_DU__BLOCK)(t2)
	sb	a0,%lo(FH_DU__BLOCK_old)(a6)
	lui	a0,%hi(FH_DU__MFHZ_copy)
	lbu	a0,%lo(FH_DU__MFHZ_copy)(a0)
	lui	a6,%hi(FH_DU__MFHZ_old)
	sb	a0,%lo(FH_DU__MFHZ)(a1)
	sb	a0,%lo(FH_DU__MFHZ_old)(a6)
	lui	a0,%hi(FH_DU__MFHA_copy)
	lbu	a0,%lo(FH_DU__MFHA_copy)(a0)
	lui	a6,%hi(FH_DU__MFHA_old)
	li	a1,2
	sb	a0,%lo(FH_DU__MFHA)(a3)
	lui	a3,%hi(stable)
	sb	a0,%lo(FH_DU__MFHA_old)(a6)
	lbu	a0,%lo(stable)(a3)
	beq	a0,zero,.L282
	lw	ra,60(sp)
	lw	s0,56(sp)
	lw	s1,52(sp)
	lw	s2,48(sp)
	lw	s3,44(sp)
	lw	s4,40(sp)
	lw	s5,36(sp)
	lw	s6,32(sp)
	lw	s7,28(sp)
	lw	s8,24(sp)
	lw	s9,20(sp)
	lw	s10,16(sp)
	lw	s11,12(sp)
	addi	sp,sp,64
	jr	ra
.L272:
	lbu	a6,%lo(FH_DU__MFHA)(t1)
	beq	a6,zero,.L271
	lbu	a6,%lo(FH_DU__MFHA_old)(a7)
	bne	a6,zero,.L271
	li	a6,100
	sw	a6,%lo(FH_DU__MFH)(a0)
	li	a0,3
	sb	zero,%lo(stable)(a3)
	sb	a0,%lo(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)(a2)
	j	.L271
.L269:
	lbu	a6,%lo(FH_DU__MFHA)(t1)
	bne	a6,zero,.L271
	lbu	a6,%lo(FH_DU__MFHA_old)(a7)
	j	.L301
.L300:
	addi	sp,sp,-64
	sw	ra,60(sp)
	sw	s0,56(sp)
	sw	s1,52(sp)
	sw	s2,48(sp)
	sw	s3,44(sp)
	sw	s4,40(sp)
	sw	s5,36(sp)
	sw	s6,32(sp)
	sw	s7,28(sp)
	sw	s8,24(sp)
	sw	s9,20(sp)
	sw	s10,16(sp)
	sw	s11,12(sp)
.L282:
	lui	a6,%hi(step)
	lbu	a0,%lo(step)(a6)
	sb	a4,%lo(stable)(a3)
	lui	t4,%hi(FH_DU__MFHZ)
	addi	a0,a0,1
	sb	a0,%lo(step)(a6)
	lbu	a6,%lo(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)(a2)
	lui	t3,%hi(FH_DU__MFHZ_old)
	lui	a0,%hi(FH_DU__MFH)
	lui	t1,%hi(FH_DU__MFHA)
	lui	a7,%hi(FH_DU__MFHA_old)
	beq	a6,a1,.L268
	li	t5,3
	beq	a6,t5,.L269
	bne	a6,a4,.L270
	lbu	a6,%lo(FH_DU__MFHZ)(t4)
	bne	a6,zero,.L271
	lbu	a6,%lo(FH_DU__MFHZ_old)(t3)
.L301:
	beq	a6,zero,.L271
.L270:
	sb	zero,%lo(stable)(a3)
	sw	zero,%lo(FH_DU__MFH)(a0)
	sb	a1,%lo(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)(a2)
	j	.L271
	.size	FH_DU, .-FH_DU
	.section	.text.benchmark_body.isra.0,"ax",@progbits
	.align	2
	.type	benchmark_body.isra.0, @function
benchmark_body.isra.0:
	addi	sp,sp,-16
	lui	a5,%hi(Bitlist)
	sw	s0,8(sp)
	sw	s1,4(sp)
	sw	s2,0(sp)
	sw	ra,12(sp)
	mv	s2,a0
	li	s0,0
	addi	s1,a5,%lo(Bitlist)
.L303:
	blt	s0,s2,.L304
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s1,4(sp)
	lw	s2,0(sp)
	addi	sp,sp,16
	jr	ra
.L304:
	li	a2,64
	li	a1,0
	mv	a0,s1
	call	memset
	call	init
	addi	s0,s0,1
	call	interface
	call	FH_DU
	j	.L303
	.size	benchmark_body.isra.0, .-benchmark_body.isra.0
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	tail	benchmark_body.isra.0
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	li	a0,1964
	sw	ra,12(sp)
	call	benchmark_body.isra.0
	lw	ra,12(sp)
	li	a0,0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	sp,sp,-80
	li	a5,256
	li	a1,0
	li	a2,56
	addi	a0,sp,8
	sw	a5,4(sp)
	sw	ra,76(sp)
	sw	zero,0(sp)
	call	memset
	lui	a4,%hi(Bitlist)
	li	a5,0
	addi	a4,a4,%lo(Bitlist)
	li	a1,64
.L312:
	add	a2,a5,a4
	add	a3,sp,a5
	lbu	a2,0(a2)
	lbu	a3,0(a3)
	bne	a2,a3,.L313
	addi	a5,a5,1
	bne	a5,a1,.L312
	lui	a5,%hi(tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy)
	lui	a4,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)
	lw	a4,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL)(a4)
	lw	a5,%lo(tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy)(a5)
	li	a0,0
	or	a5,a5,a4
	lui	a4,%hi(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)
	lw	a4,%lo(tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL)(a4)
	or	a5,a5,a4
	bne	a5,zero,.L310
	lui	a5,%hi(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)
	lbu	a4,%lo(KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state)(a5)
	li	a5,3
	bne	a4,a5,.L310
	lui	a5,%hi(B_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(B_FH_TUERMODUL_CTRL_next_state)(a5)
	li	a5,2
	bne	a4,a5,.L310
	lui	a5,%hi(A_FH_TUERMODUL_CTRL_next_state)
	lbu	a3,%lo(A_FH_TUERMODUL_CTRL_next_state)(a5)
	li	a5,1
	bne	a3,a5,.L310
	lui	a5,%hi(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)
	lbu	a5,%lo(WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state)(a5)
	bne	a5,a3,.L310
	lui	a3,%hi(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)
	lbu	a3,%lo(FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state)(a3)
	bne	a3,a4,.L310
	lui	a4,%hi(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)
	lbu	a4,%lo(EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state)(a4)
	bne	a4,a5,.L310
	lui	a5,%hi(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)
	lui	a4,%hi(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)
	lbu	a4,%lo(ZENTRAL_KINDERSICHERUNG_CTRL_next_state)(a4)
	lbu	a5,%lo(NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state)(a5)
	or	a5,a5,a4
	lui	a4,%hi(MEC_KINDERSICHERUNG_CTRL_next_state)
	lbu	a4,%lo(MEC_KINDERSICHERUNG_CTRL_next_state)(a4)
	or	a5,a5,a4
	lui	a4,%hi(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(INITIALISIERT_FH_TUERMODUL_CTRL_next_state)(a4)
	or	a5,a5,a4
	lui	a4,%hi(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a4)
	or	a5,a5,a4
	lui	a4,%hi(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a4)
	or	a5,a5,a4
	lui	a4,%hi(OEFFNEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(OEFFNEN_FH_TUERMODUL_CTRL_next_state)(a4)
	or	a5,a5,a4
	lui	a4,%hi(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)
	lbu	a4,%lo(SCHLIESSEN_FH_TUERMODUL_CTRL_next_state)(a4)
	or	a5,a5,a4
	lui	a4,%hi(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)
	lbu	a4,%lo(BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state)(a4)
	or	a5,a5,a4
	bne	a5,zero,.L310
	lui	a5,%hi(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)
	lbu	a0,%lo(BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state)(a5)
	addi	a0,a0,-1
	seqz	a0,a0
.L310:
	lw	ra,76(sp)
	addi	sp,sp,80
	jr	ra
.L313:
	li	a0,0
	j	.L310
	.size	verify_benchmark, .-verify_benchmark
	.globl	BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state
	.section	.bss.BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state,"aw",@nobits
	.type	BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state, @object
	.size	BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state, 1
BLOCK_ERKENNUNG_CTRL_BLOCK_ERKENNUNG_CTRL_next_state:
	.zero	1
	.globl	BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state
	.section	.bss.BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state,"aw",@nobits
	.type	BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state, @object
	.size	BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state, 1
BEWEGUNG_BLOCK_ERKENNUNG_CTRL_next_state:
	.zero	1
	.globl	EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state
	.section	.bss.EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state,"aw",@nobits
	.type	EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state, @object
	.size	EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state, 1
EINKLEMMSCHUTZ_CTRL_EINKLEMMSCHUTZ_CTRL_next_state:
	.zero	1
	.globl	FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state
	.section	.bss.FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state,"aw",@nobits
	.type	FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state, @object
	.size	FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state, 1
FH_STEUERUNG_DUMMY_FH_STEUERUNG_DUMMY_next_state:
	.zero	1
	.globl	SCHLIESSEN_FH_TUERMODUL_CTRL_next_state
	.section	.bss.SCHLIESSEN_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	SCHLIESSEN_FH_TUERMODUL_CTRL_next_state, @object
	.size	SCHLIESSEN_FH_TUERMODUL_CTRL_next_state, 1
SCHLIESSEN_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	OEFFNEN_FH_TUERMODUL_CTRL_next_state
	.section	.bss.OEFFNEN_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	OEFFNEN_FH_TUERMODUL_CTRL_next_state, @object
	.size	OEFFNEN_FH_TUERMODUL_CTRL_next_state, 1
OEFFNEN_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state
	.section	.bss.MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state, @object
	.size	MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state, 1
MANUELL_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state
	.section	.bss.TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state, @object
	.size	TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state, 1
TIPP_SCHLIESSEN_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	INITIALISIERT_FH_TUERMODUL_CTRL_next_state
	.section	.bss.INITIALISIERT_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	INITIALISIERT_FH_TUERMODUL_CTRL_next_state, @object
	.size	INITIALISIERT_FH_TUERMODUL_CTRL_next_state, 1
INITIALISIERT_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state
	.section	.bss.WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state, @object
	.size	WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state, 1
WIEDERHOLSPERRE_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	A_FH_TUERMODUL_CTRL_next_state
	.section	.bss.A_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	A_FH_TUERMODUL_CTRL_next_state, @object
	.size	A_FH_TUERMODUL_CTRL_next_state, 1
A_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	B_FH_TUERMODUL_CTRL_next_state
	.section	.bss.B_FH_TUERMODUL_CTRL_next_state,"aw",@nobits
	.type	B_FH_TUERMODUL_CTRL_next_state, @object
	.size	B_FH_TUERMODUL_CTRL_next_state, 1
B_FH_TUERMODUL_CTRL_next_state:
	.zero	1
	.globl	KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state
	.section	.bss.KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state,"aw",@nobits
	.type	KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state, @object
	.size	KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state, 1
KINDERSICHERUNG_CTRL_KINDERSICHERUNG_CTRL_next_state:
	.zero	1
	.globl	MEC_KINDERSICHERUNG_CTRL_next_state
	.section	.bss.MEC_KINDERSICHERUNG_CTRL_next_state,"aw",@nobits
	.type	MEC_KINDERSICHERUNG_CTRL_next_state, @object
	.size	MEC_KINDERSICHERUNG_CTRL_next_state, 1
MEC_KINDERSICHERUNG_CTRL_next_state:
	.zero	1
	.globl	ZENTRAL_KINDERSICHERUNG_CTRL_next_state
	.section	.bss.ZENTRAL_KINDERSICHERUNG_CTRL_next_state,"aw",@nobits
	.type	ZENTRAL_KINDERSICHERUNG_CTRL_next_state, @object
	.size	ZENTRAL_KINDERSICHERUNG_CTRL_next_state, 1
ZENTRAL_KINDERSICHERUNG_CTRL_next_state:
	.zero	1
	.globl	NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state
	.section	.bss.NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state,"aw",@nobits
	.type	NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state, @object
	.size	NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state, 1
NICHT_INITIALISIERT_NICHT_INITIALISIERT_next_state:
	.zero	1
	.globl	step
	.section	.bss.step,"aw",@nobits
	.type	step, @object
	.size	step, 1
step:
	.zero	1
	.globl	stable
	.section	.bss.stable,"aw",@nobits
	.type	stable, @object
	.size	stable, 1
stable:
	.zero	1
	.globl	time
	.section	.bss.time,"aw",@nobits
	.align	2
	.type	time, @object
	.size	time, 4
time:
	.zero	4
	.globl	FH_DU__MFHA_old
	.section	.bss.FH_DU__MFHA_old,"aw",@nobits
	.type	FH_DU__MFHA_old, @object
	.size	FH_DU__MFHA_old, 1
FH_DU__MFHA_old:
	.zero	1
	.globl	FH_DU__MFHA_copy
	.section	.bss.FH_DU__MFHA_copy,"aw",@nobits
	.type	FH_DU__MFHA_copy, @object
	.size	FH_DU__MFHA_copy, 1
FH_DU__MFHA_copy:
	.zero	1
	.globl	FH_DU__MFHA
	.section	.bss.FH_DU__MFHA,"aw",@nobits
	.type	FH_DU__MFHA, @object
	.size	FH_DU__MFHA, 1
FH_DU__MFHA:
	.zero	1
	.globl	FH_DU__MFHZ_old
	.section	.bss.FH_DU__MFHZ_old,"aw",@nobits
	.type	FH_DU__MFHZ_old, @object
	.size	FH_DU__MFHZ_old, 1
FH_DU__MFHZ_old:
	.zero	1
	.globl	FH_DU__MFHZ_copy
	.section	.bss.FH_DU__MFHZ_copy,"aw",@nobits
	.type	FH_DU__MFHZ_copy, @object
	.size	FH_DU__MFHZ_copy, 1
FH_DU__MFHZ_copy:
	.zero	1
	.globl	FH_DU__MFHZ
	.section	.bss.FH_DU__MFHZ,"aw",@nobits
	.type	FH_DU__MFHZ, @object
	.size	FH_DU__MFHZ, 1
FH_DU__MFHZ:
	.zero	1
	.globl	FH_DU__BLOCK_old
	.section	.bss.FH_DU__BLOCK_old,"aw",@nobits
	.type	FH_DU__BLOCK_old, @object
	.size	FH_DU__BLOCK_old, 1
FH_DU__BLOCK_old:
	.zero	1
	.globl	FH_DU__BLOCK_copy
	.section	.bss.FH_DU__BLOCK_copy,"aw",@nobits
	.type	FH_DU__BLOCK_copy, @object
	.size	FH_DU__BLOCK_copy, 1
FH_DU__BLOCK_copy:
	.zero	1
	.globl	FH_DU__BLOCK
	.section	.bss.FH_DU__BLOCK,"aw",@nobits
	.type	FH_DU__BLOCK, @object
	.size	FH_DU__BLOCK, 1
FH_DU__BLOCK:
	.zero	1
	.globl	FH_DU__DOOR_ID
	.section	.bss.FH_DU__DOOR_ID,"aw",@nobits
	.type	FH_DU__DOOR_ID, @object
	.size	FH_DU__DOOR_ID, 1
FH_DU__DOOR_ID:
	.zero	1
	.globl	FH_DU__S_FH_AUFDISC
	.section	.bss.FH_DU__S_FH_AUFDISC,"aw",@nobits
	.type	FH_DU__S_FH_AUFDISC, @object
	.size	FH_DU__S_FH_AUFDISC, 1
FH_DU__S_FH_AUFDISC:
	.zero	1
	.globl	FH_DU__S_FH_ZUDISC
	.section	.bss.FH_DU__S_FH_ZUDISC,"aw",@nobits
	.type	FH_DU__S_FH_ZUDISC, @object
	.size	FH_DU__S_FH_ZUDISC, 1
FH_DU__S_FH_ZUDISC:
	.zero	1
	.globl	FH_DU__S_FH_TMBFAUFDISC_old
	.section	.bss.FH_DU__S_FH_TMBFAUFDISC_old,"aw",@nobits
	.type	FH_DU__S_FH_TMBFAUFDISC_old, @object
	.size	FH_DU__S_FH_TMBFAUFDISC_old, 1
FH_DU__S_FH_TMBFAUFDISC_old:
	.zero	1
	.globl	FH_DU__S_FH_TMBFAUFDISC
	.section	.bss.FH_DU__S_FH_TMBFAUFDISC,"aw",@nobits
	.type	FH_DU__S_FH_TMBFAUFDISC, @object
	.size	FH_DU__S_FH_TMBFAUFDISC, 1
FH_DU__S_FH_TMBFAUFDISC:
	.zero	1
	.globl	FH_DU__S_FH_TMBFZUDISC_old
	.section	.bss.FH_DU__S_FH_TMBFZUDISC_old,"aw",@nobits
	.type	FH_DU__S_FH_TMBFZUDISC_old, @object
	.size	FH_DU__S_FH_TMBFZUDISC_old, 1
FH_DU__S_FH_TMBFZUDISC_old:
	.zero	1
	.globl	FH_DU__S_FH_TMBFZUDISC
	.section	.bss.FH_DU__S_FH_TMBFZUDISC,"aw",@nobits
	.type	FH_DU__S_FH_TMBFZUDISC, @object
	.size	FH_DU__S_FH_TMBFZUDISC, 1
FH_DU__S_FH_TMBFZUDISC:
	.zero	1
	.globl	FH_DU__S_FH_TMBFZUCAN_old
	.section	.bss.FH_DU__S_FH_TMBFZUCAN_old,"aw",@nobits
	.type	FH_DU__S_FH_TMBFZUCAN_old, @object
	.size	FH_DU__S_FH_TMBFZUCAN_old, 1
FH_DU__S_FH_TMBFZUCAN_old:
	.zero	1
	.globl	FH_DU__S_FH_TMBFZUCAN_copy
	.section	.bss.FH_DU__S_FH_TMBFZUCAN_copy,"aw",@nobits
	.type	FH_DU__S_FH_TMBFZUCAN_copy, @object
	.size	FH_DU__S_FH_TMBFZUCAN_copy, 1
FH_DU__S_FH_TMBFZUCAN_copy:
	.zero	1
	.globl	FH_DU__S_FH_TMBFZUCAN
	.section	.bss.FH_DU__S_FH_TMBFZUCAN,"aw",@nobits
	.type	FH_DU__S_FH_TMBFZUCAN, @object
	.size	FH_DU__S_FH_TMBFZUCAN, 1
FH_DU__S_FH_TMBFZUCAN:
	.zero	1
	.globl	FH_DU__S_FH_TMBFAUFCAN_old
	.section	.bss.FH_DU__S_FH_TMBFAUFCAN_old,"aw",@nobits
	.type	FH_DU__S_FH_TMBFAUFCAN_old, @object
	.size	FH_DU__S_FH_TMBFAUFCAN_old, 1
FH_DU__S_FH_TMBFAUFCAN_old:
	.zero	1
	.globl	FH_DU__S_FH_TMBFAUFCAN_copy
	.section	.bss.FH_DU__S_FH_TMBFAUFCAN_copy,"aw",@nobits
	.type	FH_DU__S_FH_TMBFAUFCAN_copy, @object
	.size	FH_DU__S_FH_TMBFAUFCAN_copy, 1
FH_DU__S_FH_TMBFAUFCAN_copy:
	.zero	1
	.globl	FH_DU__S_FH_TMBFAUFCAN
	.section	.bss.FH_DU__S_FH_TMBFAUFCAN,"aw",@nobits
	.type	FH_DU__S_FH_TMBFAUFCAN, @object
	.size	FH_DU__S_FH_TMBFAUFCAN, 1
FH_DU__S_FH_TMBFAUFCAN:
	.zero	1
	.globl	FH_DU__EKS_LEISTE_AKTIV_old
	.section	.bss.FH_DU__EKS_LEISTE_AKTIV_old,"aw",@nobits
	.type	FH_DU__EKS_LEISTE_AKTIV_old, @object
	.size	FH_DU__EKS_LEISTE_AKTIV_old, 1
FH_DU__EKS_LEISTE_AKTIV_old:
	.zero	1
	.globl	FH_DU__EKS_LEISTE_AKTIV
	.section	.bss.FH_DU__EKS_LEISTE_AKTIV,"aw",@nobits
	.type	FH_DU__EKS_LEISTE_AKTIV, @object
	.size	FH_DU__EKS_LEISTE_AKTIV, 1
FH_DU__EKS_LEISTE_AKTIV:
	.zero	1
	.globl	FH_DU__FT
	.section	.bss.FH_DU__FT,"aw",@nobits
	.type	FH_DU__FT, @object
	.size	FH_DU__FT, 1
FH_DU__FT:
	.zero	1
	.globl	FH_DU__S_FH_FTAUF
	.section	.bss.FH_DU__S_FH_FTAUF,"aw",@nobits
	.type	FH_DU__S_FH_FTAUF, @object
	.size	FH_DU__S_FH_FTAUF, 1
FH_DU__S_FH_FTAUF:
	.zero	1
	.globl	FH_DU__S_FH_FTZU
	.section	.bss.FH_DU__S_FH_FTZU,"aw",@nobits
	.type	FH_DU__S_FH_FTZU, @object
	.size	FH_DU__S_FH_FTZU, 1
FH_DU__S_FH_FTZU:
	.zero	1
	.globl	FH_DU__KL_50
	.section	.bss.FH_DU__KL_50,"aw",@nobits
	.type	FH_DU__KL_50, @object
	.size	FH_DU__KL_50, 1
FH_DU__KL_50:
	.zero	1
	.globl	FH_TUERMODUL__COM_CLOSE
	.section	.bss.FH_TUERMODUL__COM_CLOSE,"aw",@nobits
	.type	FH_TUERMODUL__COM_CLOSE, @object
	.size	FH_TUERMODUL__COM_CLOSE, 1
FH_TUERMODUL__COM_CLOSE:
	.zero	1
	.globl	FH_TUERMODUL__COM_OPEN
	.section	.bss.FH_TUERMODUL__COM_OPEN,"aw",@nobits
	.type	FH_TUERMODUL__COM_OPEN, @object
	.size	FH_TUERMODUL__COM_OPEN, 1
FH_TUERMODUL__COM_OPEN:
	.zero	1
	.globl	FH_TUERMODUL__EKS_LEISTE_AKTIV_old
	.section	.bss.FH_TUERMODUL__EKS_LEISTE_AKTIV_old,"aw",@nobits
	.type	FH_TUERMODUL__EKS_LEISTE_AKTIV_old, @object
	.size	FH_TUERMODUL__EKS_LEISTE_AKTIV_old, 1
FH_TUERMODUL__EKS_LEISTE_AKTIV_old:
	.zero	1
	.globl	FH_TUERMODUL__EKS_LEISTE_AKTIV
	.section	.bss.FH_TUERMODUL__EKS_LEISTE_AKTIV,"aw",@nobits
	.type	FH_TUERMODUL__EKS_LEISTE_AKTIV, @object
	.size	FH_TUERMODUL__EKS_LEISTE_AKTIV, 1
FH_TUERMODUL__EKS_LEISTE_AKTIV:
	.zero	1
	.globl	FH_TUERMODUL__MFHA_old
	.section	.bss.FH_TUERMODUL__MFHA_old,"aw",@nobits
	.type	FH_TUERMODUL__MFHA_old, @object
	.size	FH_TUERMODUL__MFHA_old, 1
FH_TUERMODUL__MFHA_old:
	.zero	1
	.globl	FH_TUERMODUL__MFHA_copy
	.section	.bss.FH_TUERMODUL__MFHA_copy,"aw",@nobits
	.type	FH_TUERMODUL__MFHA_copy, @object
	.size	FH_TUERMODUL__MFHA_copy, 1
FH_TUERMODUL__MFHA_copy:
	.zero	1
	.globl	FH_TUERMODUL__MFHA
	.section	.bss.FH_TUERMODUL__MFHA,"aw",@nobits
	.type	FH_TUERMODUL__MFHA, @object
	.size	FH_TUERMODUL__MFHA, 1
FH_TUERMODUL__MFHA:
	.zero	1
	.globl	FH_TUERMODUL__MFHZ_old
	.section	.bss.FH_TUERMODUL__MFHZ_old,"aw",@nobits
	.type	FH_TUERMODUL__MFHZ_old, @object
	.size	FH_TUERMODUL__MFHZ_old, 1
FH_TUERMODUL__MFHZ_old:
	.zero	1
	.globl	FH_TUERMODUL__MFHZ_copy
	.section	.bss.FH_TUERMODUL__MFHZ_copy,"aw",@nobits
	.type	FH_TUERMODUL__MFHZ_copy, @object
	.size	FH_TUERMODUL__MFHZ_copy, 1
FH_TUERMODUL__MFHZ_copy:
	.zero	1
	.globl	FH_TUERMODUL__MFHZ
	.section	.bss.FH_TUERMODUL__MFHZ,"aw",@nobits
	.type	FH_TUERMODUL__MFHZ, @object
	.size	FH_TUERMODUL__MFHZ, 1
FH_TUERMODUL__MFHZ:
	.zero	1
	.globl	FH_TUERMODUL__SFHA_old
	.section	.bss.FH_TUERMODUL__SFHA_old,"aw",@nobits
	.type	FH_TUERMODUL__SFHA_old, @object
	.size	FH_TUERMODUL__SFHA_old, 1
FH_TUERMODUL__SFHA_old:
	.zero	1
	.globl	FH_TUERMODUL__SFHA_copy
	.section	.bss.FH_TUERMODUL__SFHA_copy,"aw",@nobits
	.type	FH_TUERMODUL__SFHA_copy, @object
	.size	FH_TUERMODUL__SFHA_copy, 1
FH_TUERMODUL__SFHA_copy:
	.zero	1
	.globl	FH_TUERMODUL__SFHA
	.section	.bss.FH_TUERMODUL__SFHA,"aw",@nobits
	.type	FH_TUERMODUL__SFHA, @object
	.size	FH_TUERMODUL__SFHA, 1
FH_TUERMODUL__SFHA:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ_old
	.section	.bss.FH_TUERMODUL__SFHZ_old,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ_old, @object
	.size	FH_TUERMODUL__SFHZ_old, 1
FH_TUERMODUL__SFHZ_old:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ_copy
	.section	.bss.FH_TUERMODUL__SFHZ_copy,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ_copy, @object
	.size	FH_TUERMODUL__SFHZ_copy, 1
FH_TUERMODUL__SFHZ_copy:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ
	.section	.bss.FH_TUERMODUL__SFHZ,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ, @object
	.size	FH_TUERMODUL__SFHZ, 1
FH_TUERMODUL__SFHZ:
	.zero	1
	.globl	FH_TUERMODUL__FT
	.section	.bss.FH_TUERMODUL__FT,"aw",@nobits
	.type	FH_TUERMODUL__FT, @object
	.size	FH_TUERMODUL__FT, 1
FH_TUERMODUL__FT:
	.zero	1
	.globl	FH_TUERMODUL__BLOCK_old
	.section	.bss.FH_TUERMODUL__BLOCK_old,"aw",@nobits
	.type	FH_TUERMODUL__BLOCK_old, @object
	.size	FH_TUERMODUL__BLOCK_old, 1
FH_TUERMODUL__BLOCK_old:
	.zero	1
	.globl	FH_TUERMODUL__BLOCK_copy
	.section	.bss.FH_TUERMODUL__BLOCK_copy,"aw",@nobits
	.type	FH_TUERMODUL__BLOCK_copy, @object
	.size	FH_TUERMODUL__BLOCK_copy, 1
FH_TUERMODUL__BLOCK_copy:
	.zero	1
	.globl	FH_TUERMODUL__BLOCK
	.section	.bss.FH_TUERMODUL__BLOCK,"aw",@nobits
	.type	FH_TUERMODUL__BLOCK, @object
	.size	FH_TUERMODUL__BLOCK, 1
FH_TUERMODUL__BLOCK:
	.zero	1
	.globl	FH_TUERMODUL__KL_50
	.section	.bss.FH_TUERMODUL__KL_50,"aw",@nobits
	.type	FH_TUERMODUL__KL_50, @object
	.size	FH_TUERMODUL__KL_50, 1
FH_TUERMODUL__KL_50:
	.zero	1
	.globl	FH_TUERMODUL__SFHA_MEC_old
	.section	.bss.FH_TUERMODUL__SFHA_MEC_old,"aw",@nobits
	.type	FH_TUERMODUL__SFHA_MEC_old, @object
	.size	FH_TUERMODUL__SFHA_MEC_old, 1
FH_TUERMODUL__SFHA_MEC_old:
	.zero	1
	.globl	FH_TUERMODUL__SFHA_MEC
	.section	.bss.FH_TUERMODUL__SFHA_MEC,"aw",@nobits
	.type	FH_TUERMODUL__SFHA_MEC, @object
	.size	FH_TUERMODUL__SFHA_MEC, 1
FH_TUERMODUL__SFHA_MEC:
	.zero	1
	.globl	FH_TUERMODUL__SFHA_ZENTRAL_old
	.section	.bss.FH_TUERMODUL__SFHA_ZENTRAL_old,"aw",@nobits
	.type	FH_TUERMODUL__SFHA_ZENTRAL_old, @object
	.size	FH_TUERMODUL__SFHA_ZENTRAL_old, 1
FH_TUERMODUL__SFHA_ZENTRAL_old:
	.zero	1
	.globl	FH_TUERMODUL__SFHA_ZENTRAL
	.section	.bss.FH_TUERMODUL__SFHA_ZENTRAL,"aw",@nobits
	.type	FH_TUERMODUL__SFHA_ZENTRAL, @object
	.size	FH_TUERMODUL__SFHA_ZENTRAL, 1
FH_TUERMODUL__SFHA_ZENTRAL:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ_MEC_old
	.section	.bss.FH_TUERMODUL__SFHZ_MEC_old,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ_MEC_old, @object
	.size	FH_TUERMODUL__SFHZ_MEC_old, 1
FH_TUERMODUL__SFHZ_MEC_old:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ_MEC
	.section	.bss.FH_TUERMODUL__SFHZ_MEC,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ_MEC, @object
	.size	FH_TUERMODUL__SFHZ_MEC, 1
FH_TUERMODUL__SFHZ_MEC:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ_ZENTRAL_old
	.section	.bss.FH_TUERMODUL__SFHZ_ZENTRAL_old,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ_ZENTRAL_old, @object
	.size	FH_TUERMODUL__SFHZ_ZENTRAL_old, 1
FH_TUERMODUL__SFHZ_ZENTRAL_old:
	.zero	1
	.globl	FH_TUERMODUL__SFHZ_ZENTRAL
	.section	.bss.FH_TUERMODUL__SFHZ_ZENTRAL,"aw",@nobits
	.type	FH_TUERMODUL__SFHZ_ZENTRAL, @object
	.size	FH_TUERMODUL__SFHZ_ZENTRAL, 1
FH_TUERMODUL__SFHZ_ZENTRAL:
	.zero	1
	.globl	FH_TUERMODUL_CTRL__FT
	.section	.bss.FH_TUERMODUL_CTRL__FT,"aw",@nobits
	.type	FH_TUERMODUL_CTRL__FT, @object
	.size	FH_TUERMODUL_CTRL__FT, 1
FH_TUERMODUL_CTRL__FT:
	.zero	1
	.globl	FH_TUERMODUL_CTRL__INREVERS1_copy
	.section	.bss.FH_TUERMODUL_CTRL__INREVERS1_copy,"aw",@nobits
	.type	FH_TUERMODUL_CTRL__INREVERS1_copy, @object
	.size	FH_TUERMODUL_CTRL__INREVERS1_copy, 1
FH_TUERMODUL_CTRL__INREVERS1_copy:
	.zero	1
	.globl	FH_TUERMODUL_CTRL__INREVERS1
	.section	.bss.FH_TUERMODUL_CTRL__INREVERS1,"aw",@nobits
	.type	FH_TUERMODUL_CTRL__INREVERS1, @object
	.size	FH_TUERMODUL_CTRL__INREVERS1, 1
FH_TUERMODUL_CTRL__INREVERS1:
	.zero	1
	.globl	FH_TUERMODUL_CTRL__INREVERS2_copy
	.section	.bss.FH_TUERMODUL_CTRL__INREVERS2_copy,"aw",@nobits
	.type	FH_TUERMODUL_CTRL__INREVERS2_copy, @object
	.size	FH_TUERMODUL_CTRL__INREVERS2_copy, 1
FH_TUERMODUL_CTRL__INREVERS2_copy:
	.zero	1
	.globl	FH_TUERMODUL_CTRL__INREVERS2
	.section	.bss.FH_TUERMODUL_CTRL__INREVERS2,"aw",@nobits
	.type	FH_TUERMODUL_CTRL__INREVERS2, @object
	.size	FH_TUERMODUL_CTRL__INREVERS2, 1
FH_TUERMODUL_CTRL__INREVERS2:
	.zero	1
	.globl	BLOCK_ERKENNUNG_CTRL__N_old
	.section	.bss.BLOCK_ERKENNUNG_CTRL__N_old,"aw",@nobits
	.align	2
	.type	BLOCK_ERKENNUNG_CTRL__N_old, @object
	.size	BLOCK_ERKENNUNG_CTRL__N_old, 4
BLOCK_ERKENNUNG_CTRL__N_old:
	.zero	4
	.globl	BLOCK_ERKENNUNG_CTRL__N_copy
	.section	.bss.BLOCK_ERKENNUNG_CTRL__N_copy,"aw",@nobits
	.align	2
	.type	BLOCK_ERKENNUNG_CTRL__N_copy, @object
	.size	BLOCK_ERKENNUNG_CTRL__N_copy, 4
BLOCK_ERKENNUNG_CTRL__N_copy:
	.zero	4
	.globl	BLOCK_ERKENNUNG_CTRL__N
	.section	.bss.BLOCK_ERKENNUNG_CTRL__N,"aw",@nobits
	.align	2
	.type	BLOCK_ERKENNUNG_CTRL__N, @object
	.size	BLOCK_ERKENNUNG_CTRL__N, 4
BLOCK_ERKENNUNG_CTRL__N:
	.zero	4
	.globl	BLOCK_ERKENNUNG_CTRL__I_EIN_MAX_copy
	.section	.bss.BLOCK_ERKENNUNG_CTRL__I_EIN_MAX_copy,"aw",@nobits
	.align	2
	.type	BLOCK_ERKENNUNG_CTRL__I_EIN_MAX_copy, @object
	.size	BLOCK_ERKENNUNG_CTRL__I_EIN_MAX_copy, 4
BLOCK_ERKENNUNG_CTRL__I_EIN_MAX_copy:
	.zero	4
	.globl	BLOCK_ERKENNUNG_CTRL__I_EIN_MAX
	.section	.bss.BLOCK_ERKENNUNG_CTRL__I_EIN_MAX,"aw",@nobits
	.align	2
	.type	BLOCK_ERKENNUNG_CTRL__I_EIN_MAX, @object
	.size	BLOCK_ERKENNUNG_CTRL__I_EIN_MAX, 4
BLOCK_ERKENNUNG_CTRL__I_EIN_MAX:
	.zero	4
	.globl	FH_DU__I_EIN_old
	.section	.bss.FH_DU__I_EIN_old,"aw",@nobits
	.align	2
	.type	FH_DU__I_EIN_old, @object
	.size	FH_DU__I_EIN_old, 4
FH_DU__I_EIN_old:
	.zero	4
	.globl	FH_DU__I_EIN
	.section	.bss.FH_DU__I_EIN,"aw",@nobits
	.align	2
	.type	FH_DU__I_EIN, @object
	.size	FH_DU__I_EIN, 4
FH_DU__I_EIN:
	.zero	4
	.globl	FH_DU__POSITION
	.section	.bss.FH_DU__POSITION,"aw",@nobits
	.align	2
	.type	FH_DU__POSITION, @object
	.size	FH_DU__POSITION, 4
FH_DU__POSITION:
	.zero	4
	.globl	FH_DU__MFH_copy
	.section	.bss.FH_DU__MFH_copy,"aw",@nobits
	.align	2
	.type	FH_DU__MFH_copy, @object
	.size	FH_DU__MFH_copy, 4
FH_DU__MFH_copy:
	.zero	4
	.globl	FH_DU__MFH
	.section	.bss.FH_DU__MFH,"aw",@nobits
	.align	2
	.type	FH_DU__MFH, @object
	.size	FH_DU__MFH, 4
FH_DU__MFH:
	.zero	4
	.globl	FH_TUERMODUL__I_EIN_old
	.section	.bss.FH_TUERMODUL__I_EIN_old,"aw",@nobits
	.align	2
	.type	FH_TUERMODUL__I_EIN_old, @object
	.size	FH_TUERMODUL__I_EIN_old, 4
FH_TUERMODUL__I_EIN_old:
	.zero	4
	.globl	FH_TUERMODUL__I_EIN
	.section	.bss.FH_TUERMODUL__I_EIN,"aw",@nobits
	.align	2
	.type	FH_TUERMODUL__I_EIN, @object
	.size	FH_TUERMODUL__I_EIN, 4
FH_TUERMODUL__I_EIN:
	.zero	4
	.globl	FH_TUERMODUL__POSITION
	.section	.bss.FH_TUERMODUL__POSITION,"aw",@nobits
	.align	2
	.type	FH_TUERMODUL__POSITION, @object
	.size	FH_TUERMODUL__POSITION, 4
FH_TUERMODUL__POSITION:
	.zero	4
	.globl	sc_FH_TUERMODUL_CTRL_1739_10
	.section	.bss.sc_FH_TUERMODUL_CTRL_1739_10,"aw",@nobits
	.align	2
	.type	sc_FH_TUERMODUL_CTRL_1739_10, @object
	.size	sc_FH_TUERMODUL_CTRL_1739_10, 4
sc_FH_TUERMODUL_CTRL_1739_10:
	.zero	4
	.globl	sc_FH_TUERMODUL_CTRL_1781_10
	.section	.bss.sc_FH_TUERMODUL_CTRL_1781_10,"aw",@nobits
	.align	2
	.type	sc_FH_TUERMODUL_CTRL_1781_10, @object
	.size	sc_FH_TUERMODUL_CTRL_1781_10, 4
sc_FH_TUERMODUL_CTRL_1781_10:
	.zero	4
	.globl	FH_TUERMODUL_CTRL__N_old
	.section	.bss.FH_TUERMODUL_CTRL__N_old,"aw",@nobits
	.align	2
	.type	FH_TUERMODUL_CTRL__N_old, @object
	.size	FH_TUERMODUL_CTRL__N_old, 4
FH_TUERMODUL_CTRL__N_old:
	.zero	4
	.globl	FH_TUERMODUL_CTRL__N_copy
	.section	.bss.FH_TUERMODUL_CTRL__N_copy,"aw",@nobits
	.align	2
	.type	FH_TUERMODUL_CTRL__N_copy, @object
	.size	FH_TUERMODUL_CTRL__N_copy, 4
FH_TUERMODUL_CTRL__N_copy:
	.zero	4
	.globl	FH_TUERMODUL_CTRL__N
	.section	.bss.FH_TUERMODUL_CTRL__N,"aw",@nobits
	.align	2
	.type	FH_TUERMODUL_CTRL__N, @object
	.size	FH_TUERMODUL_CTRL__N, 4
FH_TUERMODUL_CTRL__N:
	.zero	4
	.globl	sc_FH_TUERMODUL_CTRL_2329_1
	.section	.bss.sc_FH_TUERMODUL_CTRL_2329_1,"aw",@nobits
	.align	2
	.type	sc_FH_TUERMODUL_CTRL_2329_1, @object
	.size	sc_FH_TUERMODUL_CTRL_2329_1, 4
sc_FH_TUERMODUL_CTRL_2329_1:
	.zero	4
	.globl	sc_FH_TUERMODUL_CTRL_2352_1
	.section	.bss.sc_FH_TUERMODUL_CTRL_2352_1,"aw",@nobits
	.align	2
	.type	sc_FH_TUERMODUL_CTRL_2352_1, @object
	.size	sc_FH_TUERMODUL_CTRL_2352_1, 4
sc_FH_TUERMODUL_CTRL_2352_1:
	.zero	4
	.globl	sc_FH_TUERMODUL_CTRL_2375_2
	.section	.bss.sc_FH_TUERMODUL_CTRL_2375_2,"aw",@nobits
	.align	2
	.type	sc_FH_TUERMODUL_CTRL_2375_2, @object
	.size	sc_FH_TUERMODUL_CTRL_2375_2, 4
sc_FH_TUERMODUL_CTRL_2375_2:
	.zero	4
	.globl	tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL
	.section	.bss.tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL,"aw",@nobits
	.align	2
	.type	tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL, @object
	.size	tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL, 4
tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRL:
	.zero	4
	.globl	tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL
	.section	.bss.tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL,"aw",@nobits
	.align	2
	.type	tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL, @object
	.size	tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL, 4
tm_entered_WIEDERHOLSPERRE_FH_TUERMODUL_CTRLexited_BEREIT_FH_TUERMODUL_CTRL:
	.zero	4
	.globl	tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy
	.section	.bss.tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy,"aw",@nobits
	.align	2
	.type	tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy, @object
	.size	tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy, 4
tm_entered_EINSCHALTSTROM_MESSEN_BLOCK_ERKENNUNG_CTRLch_BLOCK_ERKENNUNG_CTRL__N_copy:
	.zero	4
	.section	.bss.Bitlist,"aw",@nobits
	.align	2
	.type	Bitlist, @object
	.size	Bitlist, 64
Bitlist:
	.zero	64
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
