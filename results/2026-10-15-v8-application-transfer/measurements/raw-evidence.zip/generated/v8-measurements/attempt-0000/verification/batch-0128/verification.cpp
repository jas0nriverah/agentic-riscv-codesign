#include "Vverification_top.h"
#include "verilated.h"
#include <fstream>
#include <iostream>
#include <cstdint>
int main(int argc, char **argv) { Verilated::commandArgs(argc, argv);
Vverification_top top; std::ifstream vectors(argv[1]); uint32_t a,b,want; unsigned count=0;
while(vectors >> std::hex >> a >> b) { top.in0=a; top.in1=b; top.eval();
if (!(vectors >> std::hex >> want) || top.out_0 != want) { std::cerr << "Mismatch formula 0 vector " << std::dec << count << " got " << std::hex << top.out_0 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_1 != want) { std::cerr << "Mismatch formula 1 vector " << std::dec << count << " got " << std::hex << top.out_1 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_2 != want) { std::cerr << "Mismatch formula 2 vector " << std::dec << count << " got " << std::hex << top.out_2 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_3 != want) { std::cerr << "Mismatch formula 3 vector " << std::dec << count << " got " << std::hex << top.out_3 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_4 != want) { std::cerr << "Mismatch formula 4 vector " << std::dec << count << " got " << std::hex << top.out_4 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_5 != want) { std::cerr << "Mismatch formula 5 vector " << std::dec << count << " got " << std::hex << top.out_5 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_6 != want) { std::cerr << "Mismatch formula 6 vector " << std::dec << count << " got " << std::hex << top.out_6 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_7 != want) { std::cerr << "Mismatch formula 7 vector " << std::dec << count << " got " << std::hex << top.out_7 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_8 != want) { std::cerr << "Mismatch formula 8 vector " << std::dec << count << " got " << std::hex << top.out_8 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_9 != want) { std::cerr << "Mismatch formula 9 vector " << std::dec << count << " got " << std::hex << top.out_9 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_10 != want) { std::cerr << "Mismatch formula 10 vector " << std::dec << count << " got " << std::hex << top.out_10 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_11 != want) { std::cerr << "Mismatch formula 11 vector " << std::dec << count << " got " << std::hex << top.out_11 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_12 != want) { std::cerr << "Mismatch formula 12 vector " << std::dec << count << " got " << std::hex << top.out_12 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_13 != want) { std::cerr << "Mismatch formula 13 vector " << std::dec << count << " got " << std::hex << top.out_13 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_14 != want) { std::cerr << "Mismatch formula 14 vector " << std::dec << count << " got " << std::hex << top.out_14 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_15 != want) { std::cerr << "Mismatch formula 15 vector " << std::dec << count << " got " << std::hex << top.out_15 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_16 != want) { std::cerr << "Mismatch formula 16 vector " << std::dec << count << " got " << std::hex << top.out_16 << " expected " << want << "\n"; return 1; }
if (!(vectors >> std::hex >> want) || top.out_17 != want) { std::cerr << "Mismatch formula 17 vector " << std::dec << count << " got " << std::hex << top.out_17 << " expected " << want << "\n"; return 1; }
++count; }
std::cout << count << " vectors passed\n"; top.final(); return 0; }