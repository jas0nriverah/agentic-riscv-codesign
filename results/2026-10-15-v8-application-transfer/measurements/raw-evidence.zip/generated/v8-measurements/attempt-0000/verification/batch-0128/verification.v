module verification_top(input wire [31:0] in0, in1, output wire [31:0] out_0, output wire [31:0] out_1, output wire [31:0] out_2, output wire [31:0] out_3, output wire [31:0] out_4, output wire [31:0] out_5, output wire [31:0] out_6, output wire [31:0] out_7, output wire [31:0] out_8, output wire [31:0] out_9, output wire [31:0] out_10, output wire [31:0] out_11, output wire [31:0] out_12, output wire [31:0] out_13, output wire [31:0] out_14, output wire [31:0] out_15, output wire [31:0] out_16, output wire [31:0] out_17);
candidate_0 c0(.in0(in0), .in1(in1), .result(out_0));
candidate_1 c1(.in0(in0), .in1(in1), .result(out_1));
candidate_2 c2(.in0(in0), .in1(in1), .result(out_2));
candidate_3 c3(.in0(in0), .in1(in1), .result(out_3));
candidate_4 c4(.in0(in0), .in1(in1), .result(out_4));
candidate_5 c5(.in0(in0), .in1(in1), .result(out_5));
candidate_6 c6(.in0(in0), .in1(in1), .result(out_6));
candidate_7 c7(.in0(in0), .in1(in1), .result(out_7));
candidate_8 c8(.in0(in0), .in1(in1), .result(out_8));
candidate_9 c9(.in0(in0), .in1(in1), .result(out_9));
candidate_10 c10(.in0(in0), .in1(in1), .result(out_10));
candidate_11 c11(.in0(in0), .in1(in1), .result(out_11));
candidate_12 c12(.in0(in0), .in1(in1), .result(out_12));
candidate_13 c13(.in0(in0), .in1(in1), .result(out_13));
candidate_14 c14(.in0(in0), .in1(in1), .result(out_14));
candidate_15 c15(.in0(in0), .in1(in1), .result(out_15));
candidate_16 c16(.in0(in0), .in1(in1), .result(out_16));
candidate_17 c17(.in0(in0), .in1(in1), .result(out_17));
endmodule
module candidate_0(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001f;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h0000001a;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {1'b0, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {2'b0, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {4'b0, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {8'b0, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {16'b0, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
assign result = n1;
endmodule

module candidate_1(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] n1 = n0 & 32'h0000003f;
wire [31:0] n2 = n1 - in1;
assign result = n2;
endmodule

module candidate_2(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001a;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {1'b0, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {2'b0, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {4'b0, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {8'b0, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {16'b0, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 + n0;
wire [31:0] n2 = n1 & 32'h0000003f;
wire [31:0] n3 = n2 - n0;
assign result = n3;
endmodule

module candidate_3(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
assign result = n1;
endmodule

module candidate_4(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h0000001f;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = in0 - n0;
assign result = n1;
endmodule

module candidate_5(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000004;
wire [31:0] value_n0 = in1;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = in0 - n1;
assign result = n2;
endmodule

module candidate_6(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000004;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {value_n1[30:0], 1'b0} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {stage_n1_0[29:0], 2'b0} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {stage_n1_1[27:0], 4'b0} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {stage_n1_2[23:0], 8'b0} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {stage_n1_3[15:0], 16'b0} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n1 - n0;
assign result = n2;
endmodule

module candidate_7(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000001;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 + in0;
wire [31:0] shift_n2 = 32'h00000004;
wire [31:0] value_n2 = n1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {value_n2[30:0], 1'b0} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {stage_n2_0[29:0], 2'b0} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {stage_n2_1[27:0], 4'b0} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {stage_n2_2[23:0], 8'b0} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {stage_n2_3[15:0], 16'b0} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n2 - n1;
assign result = n3;
endmodule

module candidate_8(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000004;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {value_n0[30:0], 1'b0} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {stage_n0_0[29:0], 2'b0} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {stage_n0_1[27:0], 4'b0} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {stage_n0_2[23:0], 8'b0} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {stage_n0_3[15:0], 16'b0} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 - in0;
assign result = n1;
endmodule

module candidate_9(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000010;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_10(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000005;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_11(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 - in1;
assign result = n1;
endmodule

module candidate_12(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000010;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h0000001f;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 - n1;
assign result = n2;
endmodule

module candidate_13(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000004;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 - in1;
assign result = n1;
endmodule

module candidate_14(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000004;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h0000001f;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 - n1;
assign result = n2;
endmodule

module candidate_15(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000005;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] n1 = n0 - in1;
assign result = n1;
endmodule

module candidate_16(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] shift_n0 = 32'h00000005;
wire [31:0] value_n0 = in0;
wire [31:0] stage_n0_0 = shift_n0[0] ? {{1{value_n0[31]}}, value_n0[31:1]} : value_n0;
wire [31:0] stage_n0_1 = shift_n0[1] ? {{2{stage_n0_0[31]}}, stage_n0_0[31:2]} : stage_n0_0;
wire [31:0] stage_n0_2 = shift_n0[2] ? {{4{stage_n0_1[31]}}, stage_n0_1[31:4]} : stage_n0_1;
wire [31:0] stage_n0_3 = shift_n0[3] ? {{8{stage_n0_2[31]}}, stage_n0_2[31:8]} : stage_n0_2;
wire [31:0] stage_n0_4 = shift_n0[4] ? {{16{stage_n0_3[31]}}, stage_n0_3[31:16]} : stage_n0_3;
wire [31:0] n0 = stage_n0_4;
wire [31:0] shift_n1 = 32'h0000001f;
wire [31:0] value_n1 = in1;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] n2 = n0 - n1;
assign result = n2;
endmodule

module candidate_17(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] a_n0 = in0;
wire [31:0] b_n0 = in1;
wire signed [63:0] p_n0 = $signed({{32{a_n0[31]}}, a_n0}) * $signed({{32{b_n0[31]}}, b_n0});
wire [31:0] n0 = p_n0[63:32];
wire [31:0] shift_n1 = 32'h00000004;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in0;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule
