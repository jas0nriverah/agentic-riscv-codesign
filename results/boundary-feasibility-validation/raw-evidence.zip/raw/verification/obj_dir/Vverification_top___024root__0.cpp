// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vverification_top.h for the primary calling header

#include "Vverification_top__pch.h"

bool Vverification_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((2U > n));
    return (0U);
}

void Vverification_top___024root___ico_comb__TOP__0(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___ico_comb__TOP__0\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ verification_top__DOT__c55__DOT__stage_n5_0;
    verification_top__DOT__c55__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c54__DOT__stage_n5_0;
    verification_top__DOT__c54__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c53__DOT__stage_n5_0;
    verification_top__DOT__c53__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c52__DOT__stage_n5_0;
    verification_top__DOT__c52__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c51__DOT__stage_n5_0;
    verification_top__DOT__c51__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c50__DOT__stage_n5_0;
    verification_top__DOT__c50__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c49__DOT__stage_n5_0;
    verification_top__DOT__c49__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c48__DOT__stage_n5_0;
    verification_top__DOT__c48__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c47__DOT__stage_n7_0;
    verification_top__DOT__c47__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c45__DOT__stage_n9_0;
    verification_top__DOT__c45__DOT__stage_n9_0 = 0;
    IData/*31:0*/ verification_top__DOT__c41__DOT__stage_n9_0;
    verification_top__DOT__c41__DOT__stage_n9_0 = 0;
    IData/*31:0*/ verification_top__DOT__c39__DOT__stage_n8_0;
    verification_top__DOT__c39__DOT__stage_n8_0 = 0;
    IData/*31:0*/ verification_top__DOT__c37__DOT__stage_n6_0;
    verification_top__DOT__c37__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c35__DOT__stage_n7_0;
    verification_top__DOT__c35__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c33__DOT__stage_n6_0;
    verification_top__DOT__c33__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c29__DOT__stage_n6_0;
    verification_top__DOT__c29__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c27__DOT__stage_n8_0;
    verification_top__DOT__c27__DOT__stage_n8_0 = 0;
    IData/*31:0*/ verification_top__DOT__c26__DOT__n6;
    verification_top__DOT__c26__DOT__n6 = 0;
    IData/*31:0*/ verification_top__DOT__c26__DOT__n9;
    verification_top__DOT__c26__DOT__n9 = 0;
    IData/*31:0*/ verification_top__DOT__c25__DOT__stage_n6_0;
    verification_top__DOT__c25__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c24__DOT__n2;
    verification_top__DOT__c24__DOT__n2 = 0;
    IData/*31:0*/ verification_top__DOT__c24__DOT__n4;
    verification_top__DOT__c24__DOT__n4 = 0;
    IData/*31:0*/ verification_top__DOT__c19__DOT__stage_n5_2;
    verification_top__DOT__c19__DOT__stage_n5_2 = 0;
    IData/*31:0*/ verification_top__DOT__c19__DOT__stage_n5_3;
    verification_top__DOT__c19__DOT__stage_n5_3 = 0;
    IData/*31:0*/ verification_top__DOT__c18__DOT__stage_n5_1;
    verification_top__DOT__c18__DOT__stage_n5_1 = 0;
    IData/*31:0*/ verification_top__DOT__c17__DOT__stage_n5_0;
    verification_top__DOT__c17__DOT__stage_n5_0 = 0;
    IData/*31:0*/ verification_top__DOT__c16__DOT__n3;
    verification_top__DOT__c16__DOT__n3 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_2;
    verification_top__DOT__c15__DOT__stage_n7_2 = 0;
    IData/*31:0*/ verification_top__DOT__c15__DOT__stage_n7_3;
    verification_top__DOT__c15__DOT__stage_n7_3 = 0;
    IData/*31:0*/ verification_top__DOT__c14__DOT__stage_n7_1;
    verification_top__DOT__c14__DOT__stage_n7_1 = 0;
    IData/*31:0*/ verification_top__DOT__c13__DOT__stage_n7_0;
    verification_top__DOT__c13__DOT__stage_n7_0 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n9_2;
    verification_top__DOT__c11__DOT__stage_n9_2 = 0;
    IData/*31:0*/ verification_top__DOT__c11__DOT__stage_n9_3;
    verification_top__DOT__c11__DOT__stage_n9_3 = 0;
    IData/*31:0*/ verification_top__DOT__c10__DOT__stage_n9_1;
    verification_top__DOT__c10__DOT__stage_n9_1 = 0;
    IData/*31:0*/ verification_top__DOT__c9__DOT__stage_n9_0;
    verification_top__DOT__c9__DOT__stage_n9_0 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n6_2;
    verification_top__DOT__c7__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c7__DOT__stage_n6_3;
    verification_top__DOT__c7__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c6__DOT__stage_n6_1;
    verification_top__DOT__c6__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c5__DOT__stage_n6_0;
    verification_top__DOT__c5__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n6_2;
    verification_top__DOT__c3__DOT__stage_n6_2 = 0;
    IData/*31:0*/ verification_top__DOT__c3__DOT__stage_n6_3;
    verification_top__DOT__c3__DOT__stage_n6_3 = 0;
    IData/*31:0*/ verification_top__DOT__c2__DOT__stage_n6_1;
    verification_top__DOT__c2__DOT__stage_n6_1 = 0;
    IData/*31:0*/ verification_top__DOT__c1__DOT__stage_n6_0;
    verification_top__DOT__c1__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c0__DOT__n0;
    verification_top__DOT__c0__DOT__n0 = 0;
    // Body
    verification_top__DOT__c54__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000161U) 
                                                       + vlSelfRef.in0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         (0x00000051U 
                                                          ^ 
                                                          (((IData)(0x00000161U) 
                                                            + vlSelfRef.in0) 
                                                           >> 1U))
                                                          : 
                                                         (0x000000a3U 
                                                          ^ 
                                                          ((IData)(0x00000161U) 
                                                           + vlSelfRef.in0)))));
    verification_top__DOT__c52__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + vlSelfRef.in0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         (0x00000017U 
                                                          ^ 
                                                          (((IData)(0x0000009dU) 
                                                            + vlSelfRef.in0) 
                                                           >> 1U))
                                                          : 
                                                         (0x0000002fU 
                                                          ^ 
                                                          ((IData)(0x0000009dU) 
                                                           + vlSelfRef.in0)))));
    verification_top__DOT__c50__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000061U) 
                                                       + vlSelfRef.in0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         (0x0000000bU 
                                                          ^ 
                                                          (((IData)(0x00000061U) 
                                                            + vlSelfRef.in0) 
                                                           >> 1U))
                                                          : 
                                                         (0x00000017U 
                                                          ^ 
                                                          ((IData)(0x00000061U) 
                                                           + vlSelfRef.in0)))));
    verification_top__DOT__c48__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000002fU) 
                                                       + vlSelfRef.in0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         (5U 
                                                          ^ 
                                                          (((IData)(0x0000002fU) 
                                                            + vlSelfRef.in0) 
                                                           >> 1U))
                                                          : 
                                                         (0x0000000bU 
                                                          ^ 
                                                          ((IData)(0x0000002fU) 
                                                           + vlSelfRef.in0)))));
    verification_top__DOT__c47__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x0000009dU) 
                                                        + vlSelfRef.in1) 
                                                       << 0x00000018U)) 
                                                   | ((1U 
                                                       & ((IData)(1U) 
                                                          + vlSelfRef.in0))
                                                       ? 
                                                      (0x7f800000U 
                                                       & (0x17800000U 
                                                          ^ 
                                                          (0x7f800000U 
                                                           & (((IData)(0x0000009dU) 
                                                               + vlSelfRef.in1) 
                                                              << 0x00000017U))))
                                                       : 
                                                      (0x7f000000U 
                                                       & (0x2f000000U 
                                                          ^ 
                                                          (((IData)(0x1dU) 
                                                            + vlSelfRef.in1) 
                                                           << 0x00000018U)))));
    verification_top__DOT__c26__DOT__n9 = (vlSelfRef.in0 
                                           + vlSelfRef.in1);
    verification_top__DOT__c26__DOT__n6 = ((0x0000000fU 
                                            ^ vlSelfRef.in1) 
                                           & (vlSelfRef.in0 
                                              >> 1U));
    verification_top__DOT__c24__DOT__n2 = (0x0000001dU 
                                           ^ (vlSelfRef.in0 
                                              ^ ((IData)(0x00000071U) 
                                                 + vlSelfRef.in1)));
    verification_top__DOT__c24__DOT__n4 = (vlSelfRef.in0 
                                           ^ (vlSelfRef.in1 
                                              >> 1U));
    verification_top__DOT__c13__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x00000071U) 
                                                        + 
                                                        (0x0000001dU 
                                                         ^ vlSelfRef.in1)) 
                                                       << 0x00000018U)) 
                                                   | ((1U 
                                                       & ((IData)(1U) 
                                                          + vlSelfRef.in0))
                                                       ? 
                                                      (0x7f800000U 
                                                       & (((IData)(0x00000071U) 
                                                           + 
                                                           (0x0000001dU 
                                                            ^ vlSelfRef.in1)) 
                                                          << 0x00000017U))
                                                       : 
                                                      (0x7f000000U 
                                                       & (((IData)(0x71U) 
                                                           + 
                                                           (0x1dU 
                                                            ^ vlSelfRef.in1)) 
                                                          << 0x00000018U))));
    vlSelfRef.verification_top__DOT__c4__DOT__n8 = 
        (vlSelfRef.in0 ^ vlSelfRef.in1);
    verification_top__DOT__c16__DOT__n3 = (vlSelfRef.in1 
                                           & (0x0000000fU 
                                              ^ vlSelfRef.in0));
    vlSelfRef.verification_top__DOT__c0__DOT__n8 = 
        (vlSelfRef.in0 | vlSelfRef.in1);
    verification_top__DOT__c0__DOT__n0 = (vlSelfRef.in0 
                                          & vlSelfRef.in1);
    verification_top__DOT__c25__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & verification_top__DOT__c24__DOT__n2) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c24__DOT__n4)
                                                          ? 
                                                         (verification_top__DOT__c24__DOT__n2 
                                                          >> 1U)
                                                          : verification_top__DOT__c24__DOT__n2)));
    verification_top__DOT__c14__DOT__stage_n7_1 = (
                                                   (2U 
                                                    & ((IData)(0x0000000bU) 
                                                       + vlSelfRef.in0))
                                                    ? 
                                                   (((- (IData)(
                                                                (1U 
                                                                 & (((IData)(0x00000071U) 
                                                                     + 
                                                                     (0x0000001dU 
                                                                      ^ vlSelfRef.in1)) 
                                                                    >> 7U)))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c13__DOT__stage_n7_0 
                                                       >> 2U))
                                                    : verification_top__DOT__c13__DOT__stage_n7_0);
    vlSelfRef.out_32 = ((vlSelfRef.verification_top__DOT__c4__DOT__n8 
                         + ((0x80000000U & ((IData)(0x0000002fU) 
                                            + (0x0000000bU 
                                               ^ vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                            | (0x7fffffffU & ((1U & vlSelfRef.in1)
                                               ? ((IData)(0x0000002fU) 
                                                  + 
                                                  (0x0000000bU 
                                                   ^ vlSelfRef.verification_top__DOT__c4__DOT__n8))
                                               : (((IData)(0x0000002fU) 
                                                   + 
                                                   (0x0000000bU 
                                                    ^ vlSelfRef.verification_top__DOT__c4__DOT__n8)) 
                                                  >> 1U))))) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_26 = (verification_top__DOT__c26__DOT__n9 
                        ^ ((0x80000000U & ((IData)(0x00000071U) 
                                           + (0x0000ffffU 
                                              & vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                           | (0x7fffffffU & ((1U & verification_top__DOT__c26__DOT__n6)
                                              ? (0x0000000eU 
                                                 ^ 
                                                 (((IData)(0x00000071U) 
                                                   + 
                                                   (0x0000ffffU 
                                                    & vlSelfRef.verification_top__DOT__c4__DOT__n8)) 
                                                  >> 1U))
                                              : (0x0000001dU 
                                                 ^ 
                                                 ((IData)(0x00000071U) 
                                                  + 
                                                  (0x0000ffffU 
                                                   & vlSelfRef.verification_top__DOT__c4__DOT__n8)))))));
    vlSelfRef.out_48 = ((vlSelfRef.in1 + ((2U & ((IData)(0x0000000bU) 
                                                 + vlSelfRef.in1))
                                           ? (((- (IData)(
                                                          (((IData)(0x0000002fU) 
                                                            + vlSelfRef.in0) 
                                                           >> 0x0000001fU))) 
                                               << 0x0000001eU) 
                                              | (verification_top__DOT__c48__DOT__stage_n5_0 
                                                 >> 2U))
                                           : verification_top__DOT__c48__DOT__stage_n5_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_50 = ((vlSelfRef.in1 + ((2U & ((IData)(0x0000000bU) 
                                                 + vlSelfRef.in1))
                                           ? (((- (IData)(
                                                          (((IData)(0x00000061U) 
                                                            + vlSelfRef.in0) 
                                                           >> 0x0000001fU))) 
                                               << 0x0000001eU) 
                                              | (verification_top__DOT__c50__DOT__stage_n5_0 
                                                 >> 2U))
                                           : verification_top__DOT__c50__DOT__stage_n5_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_52 = ((vlSelfRef.in1 + ((2U & ((IData)(0x0000000bU) 
                                                 + vlSelfRef.in1))
                                           ? (((- (IData)(
                                                          (((IData)(0x0000009dU) 
                                                            + vlSelfRef.in0) 
                                                           >> 0x0000001fU))) 
                                               << 0x0000001eU) 
                                              | (verification_top__DOT__c52__DOT__stage_n5_0 
                                                 >> 2U))
                                           : verification_top__DOT__c52__DOT__stage_n5_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_54 = ((vlSelfRef.in1 + ((2U & ((IData)(0x0000000bU) 
                                                 + vlSelfRef.in1))
                                           ? (((- (IData)(
                                                          (((IData)(0x00000161U) 
                                                            + vlSelfRef.in0) 
                                                           >> 0x0000001fU))) 
                                               << 0x0000001eU) 
                                              | (verification_top__DOT__c54__DOT__stage_n5_0 
                                                 >> 2U))
                                           : verification_top__DOT__c54__DOT__stage_n5_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    verification_top__DOT__c33__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + 
                                                       (0x0000002fU 
                                                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in1)
                                                          ? 
                                                         ((IData)(0x0000009dU) 
                                                          + 
                                                          (0x0000002fU 
                                                           ^ vlSelfRef.verification_top__DOT__c4__DOT__n8))
                                                          : 
                                                         (((IData)(0x0000009dU) 
                                                           + 
                                                           (0x0000002fU 
                                                            ^ vlSelfRef.verification_top__DOT__c4__DOT__n8)) 
                                                          >> 1U))));
    verification_top__DOT__c45__DOT__stage_n9_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + 
                                                       (0xff000000U 
                                                        & (0x2f000000U 
                                                           ^ 
                                                           (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                            << 0x00000018U))))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         ((IData)(0x0000009dU) 
                                                          + 
                                                          (0x7f000000U 
                                                           & (0x2f000000U 
                                                              ^ 
                                                              (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                               << 0x00000018U))))
                                                          : 
                                                         (((IData)(0x0000009dU) 
                                                           + 
                                                           (0xff000000U 
                                                            & (0x2f000000U 
                                                               ^ 
                                                               (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                                << 0x00000018U)))) 
                                                          >> 1U))));
    verification_top__DOT__c35__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + 
                                                       (0x0000002fU 
                                                        ^ 
                                                        (0x0000ffffU 
                                                         & vlSelfRef.verification_top__DOT__c4__DOT__n8)))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in0)
                                                          ? 
                                                         ((IData)(0x0000009dU) 
                                                          + 
                                                          (0x0000002fU 
                                                           ^ 
                                                           (0x0000ffffU 
                                                            & vlSelfRef.verification_top__DOT__c4__DOT__n8)))
                                                          : 
                                                         (((IData)(0x0000009dU) 
                                                           + 
                                                           (0x0000002fU 
                                                            ^ 
                                                            (0x0000ffffU 
                                                             & vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                                                          >> 1U))));
    verification_top__DOT__c27__DOT__stage_n8_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000071U) 
                                                       + 
                                                       (0x0000ffffU 
                                                        & vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c26__DOT__n6)
                                                          ? 
                                                         (0x0000000eU 
                                                          ^ 
                                                          (((IData)(0x00000071U) 
                                                            + 
                                                            (0x0000ffffU 
                                                             & vlSelfRef.verification_top__DOT__c4__DOT__n8)) 
                                                           >> 1U))
                                                          : 
                                                         (0x0000001dU 
                                                          ^ 
                                                          ((IData)(0x00000071U) 
                                                           + 
                                                           (0x0000ffffU 
                                                            & vlSelfRef.verification_top__DOT__c4__DOT__n8))))));
    vlSelfRef.out_16 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x80000000U 
                                             & ((IData)(0x00000071U) 
                                                + vlSelfRef.in1)) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & verification_top__DOT__c16__DOT__n3)
                                                   ? 
                                                  (0x0000000eU 
                                                   ^ 
                                                   (((IData)(0x00000071U) 
                                                     + vlSelfRef.in1) 
                                                    >> 1U))
                                                   : 
                                                  (0x0000001dU 
                                                   ^ 
                                                   ((IData)(0x00000071U) 
                                                    + vlSelfRef.in1)))))));
    verification_top__DOT__c55__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000161U) 
                                                       + 
                                                       (0x000000a3U 
                                                        ^ vlSelfRef.in1))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c16__DOT__n3)
                                                          ? 
                                                         (((IData)(0x00000161U) 
                                                           + 
                                                           (0x000000a3U 
                                                            ^ vlSelfRef.in1)) 
                                                          >> 1U)
                                                          : 
                                                         ((IData)(0x00000161U) 
                                                          + 
                                                          (0x000000a3U 
                                                           ^ vlSelfRef.in1)))));
    verification_top__DOT__c53__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + 
                                                       (0x0000002fU 
                                                        ^ vlSelfRef.in1))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c16__DOT__n3)
                                                          ? 
                                                         (((IData)(0x0000009dU) 
                                                           + 
                                                           (0x0000002fU 
                                                            ^ vlSelfRef.in1)) 
                                                          >> 1U)
                                                          : 
                                                         ((IData)(0x0000009dU) 
                                                          + 
                                                          (0x0000002fU 
                                                           ^ vlSelfRef.in1)))));
    verification_top__DOT__c51__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000061U) 
                                                       + 
                                                       (0x00000017U 
                                                        ^ vlSelfRef.in1))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c16__DOT__n3)
                                                          ? 
                                                         (((IData)(0x00000061U) 
                                                           + 
                                                           (0x00000017U 
                                                            ^ vlSelfRef.in1)) 
                                                          >> 1U)
                                                          : 
                                                         ((IData)(0x00000061U) 
                                                          + 
                                                          (0x00000017U 
                                                           ^ vlSelfRef.in1)))));
    verification_top__DOT__c49__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000002fU) 
                                                       + 
                                                       (0x0000000bU 
                                                        ^ vlSelfRef.in1))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c16__DOT__n3)
                                                          ? 
                                                         (((IData)(0x0000002fU) 
                                                           + 
                                                           (0x0000000bU 
                                                            ^ vlSelfRef.in1)) 
                                                          >> 1U)
                                                          : 
                                                         ((IData)(0x0000002fU) 
                                                          + 
                                                          (0x0000000bU 
                                                           ^ vlSelfRef.in1)))));
    verification_top__DOT__c17__DOT__stage_n5_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000071U) 
                                                       + vlSelfRef.in1)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & verification_top__DOT__c16__DOT__n3)
                                                          ? 
                                                         (0x0000000eU 
                                                          ^ 
                                                          (((IData)(0x00000071U) 
                                                            + vlSelfRef.in1) 
                                                           >> 1U))
                                                          : 
                                                         (0x0000001dU 
                                                          ^ 
                                                          ((IData)(0x00000071U) 
                                                           + vlSelfRef.in1)))));
    vlSelfRef.out_4 = ((vlSelfRef.in0 + ((0x80000000U 
                                          & ((IData)(0x00000071U) 
                                             + vlSelfRef.verification_top__DOT__c0__DOT__n8)) 
                                         | (0x7fffffffU 
                                            & ((1U 
                                                & vlSelfRef.in0)
                                                ? (0x0000001dU 
                                                   ^ 
                                                   ((IData)(0x00000071U) 
                                                    + vlSelfRef.verification_top__DOT__c0__DOT__n8))
                                                : (0x0000000eU 
                                                   ^ 
                                                   (((IData)(0x00000071U) 
                                                     + vlSelfRef.verification_top__DOT__c0__DOT__n8) 
                                                    >> 1U)))))) 
                       ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_12 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (vlSelfRef.in1 + ((0x80000000U 
                                             & (((IData)(0x00000071U) 
                                                 + 
                                                 (0x0000001dU 
                                                  ^ vlSelfRef.in1)) 
                                                << 0x00000018U)) 
                                            | ((1U 
                                                & ((IData)(1U) 
                                                   + vlSelfRef.in0))
                                                ? (0x7f800000U 
                                                   & (((IData)(0x00000071U) 
                                                       + 
                                                       (0x0000001dU 
                                                        ^ vlSelfRef.in1)) 
                                                      << 0x00000017U))
                                                : (0x7f000000U 
                                                   & (((IData)(0x71U) 
                                                       + 
                                                       (0x1dU 
                                                        ^ vlSelfRef.in1)) 
                                                      << 0x00000018U))))));
    vlSelfRef.out_28 = ((vlSelfRef.in1 + ((1U & ((IData)(1U) 
                                                 + vlSelfRef.in1))
                                           ? (0x0000000eU 
                                              ^ (((IData)(0x00000071U) 
                                                  + vlSelfRef.verification_top__DOT__c0__DOT__n8) 
                                                 >> 1U))
                                           : (0x0000001dU 
                                              ^ ((IData)(0x00000071U) 
                                                 + vlSelfRef.verification_top__DOT__c0__DOT__n8)))) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_38 = ((vlSelfRef.verification_top__DOT__c0__DOT__n8 
                         + ((0x80000000U & ((IData)(0x0000002fU) 
                                            + (0xff000000U 
                                               & (0x0b000000U 
                                                  ^ 
                                                  (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                   << 0x00000018U))))) 
                            | (0x7fffffffU & ((1U & vlSelfRef.in0)
                                               ? ((IData)(0x0000002fU) 
                                                  + 
                                                  (0x7f000000U 
                                                   & (0x0b000000U 
                                                      ^ 
                                                      (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                       << 0x00000018U))))
                                               : (((IData)(0x0000002fU) 
                                                   + 
                                                   (0xff000000U 
                                                    & (0x0b000000U 
                                                       ^ 
                                                       (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                        << 0x00000018U)))) 
                                                  >> 1U))))) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_46 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (vlSelfRef.in0 + ((0x80000000U 
                                             & (((IData)(0x0000002fU) 
                                                 + vlSelfRef.in1) 
                                                << 0x00000018U)) 
                                            | ((1U 
                                                & ((IData)(1U) 
                                                   + vlSelfRef.in0))
                                                ? (0x7f800000U 
                                                   & (0x05800000U 
                                                      ^ 
                                                      (0x7f800000U 
                                                       & (((IData)(0x0000002fU) 
                                                           + vlSelfRef.in1) 
                                                          << 0x00000017U))))
                                                : (0x7f000000U 
                                                   & (0x0b000000U 
                                                      ^ 
                                                      (((IData)(0x2fU) 
                                                        + vlSelfRef.in1) 
                                                       << 0x00000018U)))))));
    vlSelfRef.out_13 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (vlSelfRef.in1 + ((2U & ((IData)(0x0000000bU) 
                                                   + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (1U 
                                                             & (((IData)(0x00000071U) 
                                                                 + 
                                                                 (0x0000001dU 
                                                                  ^ vlSelfRef.in1)) 
                                                                >> 7U)))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c13__DOT__stage_n7_0 
                                                   >> 2U))
                                             : verification_top__DOT__c13__DOT__stage_n7_0)));
    vlSelfRef.out_47 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (vlSelfRef.in0 + ((2U & ((IData)(0x0000000bU) 
                                                   + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (1U 
                                                             & (((IData)(0x0000009dU) 
                                                                 + vlSelfRef.in1) 
                                                                >> 7U)))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c47__DOT__stage_n7_0 
                                                   >> 2U))
                                             : verification_top__DOT__c47__DOT__stage_n7_0)));
    verification_top__DOT__c29__DOT__stage_n6_0 = (
                                                   (1U 
                                                    & ((IData)(1U) 
                                                       + vlSelfRef.in1))
                                                    ? 
                                                   (0x0000000eU 
                                                    ^ 
                                                    (((IData)(0x00000071U) 
                                                      + vlSelfRef.verification_top__DOT__c0__DOT__n8) 
                                                     >> 1U))
                                                    : 
                                                   (0x0000001dU 
                                                    ^ 
                                                    ((IData)(0x00000071U) 
                                                     + vlSelfRef.verification_top__DOT__c0__DOT__n8)));
    verification_top__DOT__c39__DOT__stage_n8_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + 
                                                       (0xff000000U 
                                                        & (0x2f000000U 
                                                           ^ 
                                                           (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                            << 0x00000018U))))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.in0)
                                                          ? 
                                                         ((IData)(0x0000009dU) 
                                                          + 
                                                          (0x7f000000U 
                                                           & (0x2f000000U 
                                                              ^ 
                                                              (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                               << 0x00000018U))))
                                                          : 
                                                         (((IData)(0x0000009dU) 
                                                           + 
                                                           (0xff000000U 
                                                            & (0x2f000000U 
                                                               ^ 
                                                               (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                                << 0x00000018U)))) 
                                                          >> 1U))));
    verification_top__DOT__c5__DOT__stage_n6_0 = ((0x80000000U 
                                                   & ((IData)(0x00000071U) 
                                                      + vlSelfRef.verification_top__DOT__c0__DOT__n8)) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in0)
                                                         ? 
                                                        (0x0000001dU 
                                                         ^ 
                                                         ((IData)(0x00000071U) 
                                                          + vlSelfRef.verification_top__DOT__c0__DOT__n8))
                                                         : 
                                                        (0x0000000eU 
                                                         ^ 
                                                         (((IData)(0x00000071U) 
                                                           + vlSelfRef.verification_top__DOT__c0__DOT__n8) 
                                                          >> 1U)))));
    vlSelfRef.out_36 = (verification_top__DOT__c0__DOT__n0 
                        ^ (verification_top__DOT__c0__DOT__n0 
                           + ((0x80000000U & ((IData)(0x0000002fU) 
                                              + verification_top__DOT__c0__DOT__n0)) 
                              | (0x7fffffffU & ((1U 
                                                 & ((IData)(1U) 
                                                    + vlSelfRef.in1))
                                                 ? 
                                                (5U 
                                                 ^ 
                                                 (((IData)(0x0000002fU) 
                                                   + verification_top__DOT__c0__DOT__n0) 
                                                  >> 1U))
                                                 : 
                                                (0x0000000bU 
                                                 ^ 
                                                 ((IData)(0x0000002fU) 
                                                  + verification_top__DOT__c0__DOT__n0)))))));
    vlSelfRef.out_0 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                       ^ (vlSelfRef.in1 + ((0x80000000U 
                                            & ((IData)(0x00000071U) 
                                               + (0x0000001dU 
                                                  ^ verification_top__DOT__c0__DOT__n0))) 
                                           | (0x7fffffffU 
                                              & ((1U 
                                                  & vlSelfRef.in1)
                                                  ? 
                                                 ((IData)(0x00000071U) 
                                                  + 
                                                  (0x0000001dU 
                                                   ^ verification_top__DOT__c0__DOT__n0))
                                                  : 
                                                 (((IData)(0x00000071U) 
                                                   + 
                                                   (0x0000001dU 
                                                    ^ verification_top__DOT__c0__DOT__n0)) 
                                                  >> 1U))))));
    vlSelfRef.out_8 = (verification_top__DOT__c0__DOT__n0 
                       ^ (vlSelfRef.in1 + ((0x80000000U 
                                            & ((IData)(0x00000071U) 
                                               + (0xff000000U 
                                                  & (0x1d000000U 
                                                     ^ 
                                                     (verification_top__DOT__c0__DOT__n0 
                                                      << 0x00000018U))))) 
                                           | (0x7fffffffU 
                                              & ((1U 
                                                  & ((IData)(1U) 
                                                     + vlSelfRef.in0))
                                                  ? 
                                                 ((IData)(0x00000071U) 
                                                  + 
                                                  (0x7f000000U 
                                                   & (0x1d000000U 
                                                      ^ 
                                                      (verification_top__DOT__c0__DOT__n0 
                                                       << 0x00000018U))))
                                                  : 
                                                 (((IData)(0x00000071U) 
                                                   + 
                                                   (0xff000000U 
                                                    & (0x1d000000U 
                                                       ^ 
                                                       (verification_top__DOT__c0__DOT__n0 
                                                        << 0x00000018U)))) 
                                                  >> 1U))))));
    vlSelfRef.out_24 = (verification_top__DOT__c0__DOT__n0 
                        + ((0x80000000U & verification_top__DOT__c24__DOT__n2) 
                           | (0x7fffffffU & ((1U & verification_top__DOT__c24__DOT__n4)
                                              ? (verification_top__DOT__c24__DOT__n2 
                                                 >> 1U)
                                              : verification_top__DOT__c24__DOT__n2))));
    vlSelfRef.out_34 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                           + ((0x80000000U & ((IData)(0x0000002fU) 
                                              + (0x0000000bU 
                                                 ^ 
                                                 (0x0000ffffU 
                                                  & vlSelfRef.verification_top__DOT__c4__DOT__n8)))) 
                              | (0x7fffffffU & ((1U 
                                                 & vlSelfRef.in0)
                                                 ? 
                                                ((IData)(0x0000002fU) 
                                                 + 
                                                 (0x0000000bU 
                                                  ^ 
                                                  (0x0000ffffU 
                                                   & vlSelfRef.verification_top__DOT__c4__DOT__n8)))
                                                 : 
                                                (((IData)(0x0000002fU) 
                                                  + 
                                                  (0x0000000bU 
                                                   ^ 
                                                   (0x0000ffffU 
                                                    & vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                                                 >> 1U))))));
    vlSelfRef.out_40 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (verification_top__DOT__c0__DOT__n0 
                           + ((0x80000000U & (((IData)(0x0000002fU) 
                                               + verification_top__DOT__c0__DOT__n0) 
                                              << 0x00000010U)) 
                              | ((1U & ((IData)(1U) 
                                        + vlSelfRef.in0))
                                  ? (0x7fff0000U & 
                                     (0x000b0000U ^ 
                                      (((IData)(0x002fU) 
                                        + verification_top__DOT__c0__DOT__n0) 
                                       << 0x00000010U)))
                                  : (0x7fff8000U & 
                                     (0x00058000U ^ 
                                      (0x7fff8000U 
                                       & (((IData)(0x0000002fU) 
                                           + verification_top__DOT__c0__DOT__n0) 
                                          << 0x0000000fU))))))));
    vlSelfRef.out_44 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                           + ((0x80000000U & ((IData)(0x0000002fU) 
                                              + (0xff000000U 
                                                 & (0x0b000000U 
                                                    ^ 
                                                    (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                     << 0x00000018U))))) 
                              | (0x7fffffffU & ((1U 
                                                 & ((IData)(1U) 
                                                    + vlSelfRef.in1))
                                                 ? 
                                                ((IData)(0x0000002fU) 
                                                 + 
                                                 (0x7f000000U 
                                                  & (0x0b000000U 
                                                     ^ 
                                                     (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                      << 0x00000018U))))
                                                 : 
                                                (((IData)(0x0000002fU) 
                                                  + 
                                                  (0xff000000U 
                                                   & (0x0b000000U 
                                                      ^ 
                                                      (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                       << 0x00000018U)))) 
                                                 >> 1U))))));
    verification_top__DOT__c37__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + verification_top__DOT__c0__DOT__n0)) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & ((IData)(1U) 
                                                             + vlSelfRef.in1))
                                                          ? 
                                                         (0x00000017U 
                                                          ^ 
                                                          (((IData)(0x0000009dU) 
                                                            + verification_top__DOT__c0__DOT__n0) 
                                                           >> 1U))
                                                          : 
                                                         (0x0000002fU 
                                                          ^ 
                                                          ((IData)(0x0000009dU) 
                                                           + verification_top__DOT__c0__DOT__n0)))));
    verification_top__DOT__c41__DOT__stage_n9_0 = (
                                                   (0x80000000U 
                                                    & (((IData)(0x0000009dU) 
                                                        + verification_top__DOT__c0__DOT__n0) 
                                                       << 0x00000010U)) 
                                                   | ((1U 
                                                       & ((IData)(1U) 
                                                          + vlSelfRef.in0))
                                                       ? 
                                                      (0x7fff0000U 
                                                       & (0x002f0000U 
                                                          ^ 
                                                          (((IData)(0x009dU) 
                                                            + verification_top__DOT__c0__DOT__n0) 
                                                           << 0x00000010U)))
                                                       : 
                                                      (0x7fff8000U 
                                                       & (0x00178000U 
                                                          ^ 
                                                          (0x7fff8000U 
                                                           & (((IData)(0x0000009dU) 
                                                               + verification_top__DOT__c0__DOT__n0) 
                                                              << 0x0000000fU))))));
    verification_top__DOT__c1__DOT__stage_n6_0 = ((0x80000000U 
                                                   & ((IData)(0x00000071U) 
                                                      + 
                                                      (0x0000001dU 
                                                       ^ verification_top__DOT__c0__DOT__n0))) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & vlSelfRef.in1)
                                                         ? 
                                                        ((IData)(0x00000071U) 
                                                         + 
                                                         (0x0000001dU 
                                                          ^ verification_top__DOT__c0__DOT__n0))
                                                         : 
                                                        (((IData)(0x00000071U) 
                                                          + 
                                                          (0x0000001dU 
                                                           ^ verification_top__DOT__c0__DOT__n0)) 
                                                         >> 1U))));
    verification_top__DOT__c9__DOT__stage_n9_0 = ((0x80000000U 
                                                   & ((IData)(0x00000071U) 
                                                      + 
                                                      (0xff000000U 
                                                       & (0x1d000000U 
                                                          ^ 
                                                          (verification_top__DOT__c0__DOT__n0 
                                                           << 0x00000018U))))) 
                                                  | (0x7fffffffU 
                                                     & ((1U 
                                                         & ((IData)(1U) 
                                                            + vlSelfRef.in0))
                                                         ? 
                                                        ((IData)(0x00000071U) 
                                                         + 
                                                         (0x7f000000U 
                                                          & (0x1d000000U 
                                                             ^ 
                                                             (verification_top__DOT__c0__DOT__n0 
                                                              << 0x00000018U))))
                                                         : 
                                                        (((IData)(0x00000071U) 
                                                          + 
                                                          (0xff000000U 
                                                           & (0x1d000000U 
                                                              ^ 
                                                              (verification_top__DOT__c0__DOT__n0 
                                                               << 0x00000018U)))) 
                                                         >> 1U))));
    vlSelfRef.out_25 = (verification_top__DOT__c0__DOT__n0 
                        + ((2U & verification_top__DOT__c24__DOT__n4)
                            ? (((- (IData)((verification_top__DOT__c24__DOT__n2 
                                            >> 0x0000001fU))) 
                                << 0x0000001eU) | (verification_top__DOT__c25__DOT__stage_n6_0 
                                                   >> 2U))
                            : verification_top__DOT__c25__DOT__stage_n6_0));
    vlSelfRef.out_14 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (vlSelfRef.in1 + ((4U & ((IData)(0x0000000bU) 
                                                   + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c14__DOT__stage_n7_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c14__DOT__stage_n7_1 
                                                   >> 4U))
                                             : verification_top__DOT__c14__DOT__stage_n7_1)));
    verification_top__DOT__c15__DOT__stage_n7_2 = (
                                                   (4U 
                                                    & ((IData)(0x0000000bU) 
                                                       + vlSelfRef.in0))
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c14__DOT__stage_n7_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c14__DOT__stage_n7_1 
                                                       >> 4U))
                                                    : verification_top__DOT__c14__DOT__stage_n7_1);
    vlSelfRef.out_33 = ((vlSelfRef.verification_top__DOT__c4__DOT__n8 
                         + ((2U & ((IData)(2U) + (0x0000000fU 
                                                  ^ vlSelfRef.in1)))
                             ? (((- (IData)((((IData)(0x0000009dU) 
                                              + (0x0000002fU 
                                                 ^ vlSelfRef.verification_top__DOT__c4__DOT__n8)) 
                                             >> 0x0000001fU))) 
                                 << 0x0000001eU) | 
                                (verification_top__DOT__c33__DOT__stage_n6_0 
                                 >> 2U)) : verification_top__DOT__c33__DOT__stage_n6_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_45 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                           + ((2U & ((IData)(2U) + 
                                     (0x0000000fU ^ 
                                      ((IData)(5U) 
                                       + vlSelfRef.in1))))
                               ? (((- (IData)((((IData)(0x0000009dU) 
                                                + (0xff000000U 
                                                   & (0x2f000000U 
                                                      ^ 
                                                      (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                                                       << 0x00000018U)))) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c45__DOT__stage_n9_0 
                                     >> 2U)) : verification_top__DOT__c45__DOT__stage_n9_0)));
    vlSelfRef.out_35 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.verification_top__DOT__c4__DOT__n8 
                           + ((2U & ((IData)(2U) + 
                                     (0x0000000fU ^ vlSelfRef.in0)))
                               ? (((- (IData)((((IData)(0x0000009dU) 
                                                + (0x0000002fU 
                                                   ^ 
                                                   (0x0000ffffU 
                                                    & vlSelfRef.verification_top__DOT__c4__DOT__n8))) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c35__DOT__stage_n7_0 
                                     >> 2U)) : verification_top__DOT__c35__DOT__stage_n7_0)));
    vlSelfRef.out_27 = (((2U & verification_top__DOT__c26__DOT__n6)
                          ? (((- (IData)((((IData)(0x00000071U) 
                                           + (0x0000ffffU 
                                              & vlSelfRef.verification_top__DOT__c4__DOT__n8)) 
                                          >> 0x0000001fU))) 
                              << 0x0000001eU) | (verification_top__DOT__c27__DOT__stage_n8_0 
                                                 >> 2U))
                          : verification_top__DOT__c27__DOT__stage_n8_0) 
                        ^ verification_top__DOT__c26__DOT__n9);
    vlSelfRef.out_55 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (((IData)(0x00000161U) 
                                                              + 
                                                              (0x000000a3U 
                                                               ^ vlSelfRef.in1)) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c55__DOT__stage_n5_0 
                                                   >> 2U))
                                             : verification_top__DOT__c55__DOT__stage_n5_0)));
    vlSelfRef.out_53 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (((IData)(0x0000009dU) 
                                                              + 
                                                              (0x0000002fU 
                                                               ^ vlSelfRef.in1)) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c53__DOT__stage_n5_0 
                                                   >> 2U))
                                             : verification_top__DOT__c53__DOT__stage_n5_0)));
    vlSelfRef.out_51 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (((IData)(0x00000061U) 
                                                              + 
                                                              (0x00000017U 
                                                               ^ vlSelfRef.in1)) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c51__DOT__stage_n5_0 
                                                   >> 2U))
                                             : verification_top__DOT__c51__DOT__stage_n5_0)));
    vlSelfRef.out_49 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (((IData)(0x0000002fU) 
                                                              + 
                                                              (0x0000000bU 
                                                               ^ vlSelfRef.in1)) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c49__DOT__stage_n5_0 
                                                   >> 2U))
                                             : verification_top__DOT__c49__DOT__stage_n5_0)));
    vlSelfRef.out_17 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (((IData)(0x00000071U) 
                                                              + vlSelfRef.in1) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c17__DOT__stage_n5_0 
                                                   >> 2U))
                                             : verification_top__DOT__c17__DOT__stage_n5_0)));
    verification_top__DOT__c18__DOT__stage_n5_1 = (
                                                   (2U 
                                                    & verification_top__DOT__c16__DOT__n3)
                                                    ? 
                                                   (((- (IData)(
                                                                (((IData)(0x00000071U) 
                                                                  + vlSelfRef.in1) 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c17__DOT__stage_n5_0 
                                                       >> 2U))
                                                    : verification_top__DOT__c17__DOT__stage_n5_0);
    vlSelfRef.out_29 = ((vlSelfRef.in1 + ((2U & ((IData)(0x0000000bU) 
                                                 + vlSelfRef.in1))
                                           ? (verification_top__DOT__c29__DOT__stage_n6_0 
                                              >> 2U)
                                           : verification_top__DOT__c29__DOT__stage_n6_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_39 = ((vlSelfRef.verification_top__DOT__c0__DOT__n8 
                         + ((2U & ((IData)(2U) + (0x0000000fU 
                                                  ^ vlSelfRef.in0)))
                             ? (((- (IData)((((IData)(0x0000009dU) 
                                              + (0xff000000U 
                                                 & (0x2f000000U 
                                                    ^ 
                                                    (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                                                     << 0x00000018U)))) 
                                             >> 0x0000001fU))) 
                                 << 0x0000001eU) | 
                                (verification_top__DOT__c39__DOT__stage_n8_0 
                                 >> 2U)) : verification_top__DOT__c39__DOT__stage_n8_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_5 = ((vlSelfRef.in0 + ((2U & ((IData)(2U) 
                                                + (0x0000000fU 
                                                   ^ vlSelfRef.in0)))
                                          ? (((- (IData)(
                                                         (((IData)(0x00000071U) 
                                                           + vlSelfRef.verification_top__DOT__c0__DOT__n8) 
                                                          >> 0x0000001fU))) 
                                              << 0x0000001eU) 
                                             | (verification_top__DOT__c5__DOT__stage_n6_0 
                                                >> 2U))
                                          : verification_top__DOT__c5__DOT__stage_n6_0)) 
                       ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    verification_top__DOT__c6__DOT__stage_n6_1 = ((2U 
                                                   & ((IData)(2U) 
                                                      + 
                                                      (0x0000000fU 
                                                       ^ vlSelfRef.in0)))
                                                   ? 
                                                  (((- (IData)(
                                                               (((IData)(0x00000071U) 
                                                                 + vlSelfRef.verification_top__DOT__c0__DOT__n8) 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001eU) 
                                                   | (verification_top__DOT__c5__DOT__stage_n6_0 
                                                      >> 2U))
                                                   : verification_top__DOT__c5__DOT__stage_n6_0);
    vlSelfRef.out_37 = (verification_top__DOT__c0__DOT__n0 
                        ^ (verification_top__DOT__c0__DOT__n0 
                           + ((2U & ((IData)(0x0000000bU) 
                                     + vlSelfRef.in1))
                               ? (((- (IData)((((IData)(0x0000009dU) 
                                                + verification_top__DOT__c0__DOT__n0) 
                                               >> 0x0000001fU))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c37__DOT__stage_n6_0 
                                     >> 2U)) : verification_top__DOT__c37__DOT__stage_n6_0)));
    vlSelfRef.out_41 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (verification_top__DOT__c0__DOT__n0 
                           + ((2U & ((IData)(2U) + 
                                     (0x0000000fU ^ 
                                      ((IData)(5U) 
                                       + vlSelfRef.in0))))
                               ? (((- (IData)((1U & 
                                               (((IData)(0x0000009dU) 
                                                 + verification_top__DOT__c0__DOT__n0) 
                                                >> 0x0000000fU)))) 
                                   << 0x0000001eU) 
                                  | (verification_top__DOT__c41__DOT__stage_n9_0 
                                     >> 2U)) : verification_top__DOT__c41__DOT__stage_n9_0)));
    vlSelfRef.out_1 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                       ^ (vlSelfRef.in1 + ((2U & ((IData)(2U) 
                                                  + 
                                                  (0x0000000fU 
                                                   ^ vlSelfRef.in1)))
                                            ? (((- (IData)(
                                                           (((IData)(0x00000071U) 
                                                             + 
                                                             (0x0000001dU 
                                                              ^ verification_top__DOT__c0__DOT__n0)) 
                                                            >> 0x0000001fU))) 
                                                << 0x0000001eU) 
                                               | (verification_top__DOT__c1__DOT__stage_n6_0 
                                                  >> 2U))
                                            : verification_top__DOT__c1__DOT__stage_n6_0)));
    verification_top__DOT__c2__DOT__stage_n6_1 = ((2U 
                                                   & ((IData)(2U) 
                                                      + 
                                                      (0x0000000fU 
                                                       ^ vlSelfRef.in1)))
                                                   ? 
                                                  (((- (IData)(
                                                               (((IData)(0x00000071U) 
                                                                 + 
                                                                 (0x0000001dU 
                                                                  ^ verification_top__DOT__c0__DOT__n0)) 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001eU) 
                                                   | (verification_top__DOT__c1__DOT__stage_n6_0 
                                                      >> 2U))
                                                   : verification_top__DOT__c1__DOT__stage_n6_0);
    vlSelfRef.out_9 = (verification_top__DOT__c0__DOT__n0 
                       ^ (vlSelfRef.in1 + ((2U & ((IData)(2U) 
                                                  + 
                                                  (0x0000000fU 
                                                   ^ 
                                                   ((IData)(5U) 
                                                    + vlSelfRef.in0))))
                                            ? (((- (IData)(
                                                           (((IData)(0x00000071U) 
                                                             + 
                                                             (0xff000000U 
                                                              & (0x1d000000U 
                                                                 ^ 
                                                                 (verification_top__DOT__c0__DOT__n0 
                                                                  << 0x00000018U)))) 
                                                            >> 0x0000001fU))) 
                                                << 0x0000001eU) 
                                               | (verification_top__DOT__c9__DOT__stage_n9_0 
                                                  >> 2U))
                                            : verification_top__DOT__c9__DOT__stage_n9_0)));
    verification_top__DOT__c10__DOT__stage_n9_1 = (
                                                   (2U 
                                                    & ((IData)(2U) 
                                                       + 
                                                       (0x0000000fU 
                                                        ^ 
                                                        ((IData)(5U) 
                                                         + vlSelfRef.in0))))
                                                    ? 
                                                   (((- (IData)(
                                                                (((IData)(0x00000071U) 
                                                                  + 
                                                                  (0xff000000U 
                                                                   & (0x1d000000U 
                                                                      ^ 
                                                                      (verification_top__DOT__c0__DOT__n0 
                                                                       << 0x00000018U)))) 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c9__DOT__stage_n9_0 
                                                       >> 2U))
                                                    : verification_top__DOT__c9__DOT__stage_n9_0);
    verification_top__DOT__c15__DOT__stage_n7_3 = (
                                                   (8U 
                                                    & ((IData)(0x0000000bU) 
                                                       + vlSelfRef.in0))
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c15__DOT__stage_n7_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c15__DOT__stage_n7_2 
                                                       >> 8U))
                                                    : verification_top__DOT__c15__DOT__stage_n7_2);
    vlSelfRef.out_18 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((4U & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c18__DOT__stage_n5_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c18__DOT__stage_n5_1 
                                                   >> 4U))
                                             : verification_top__DOT__c18__DOT__stage_n5_1)));
    verification_top__DOT__c19__DOT__stage_n5_2 = (
                                                   (4U 
                                                    & verification_top__DOT__c16__DOT__n3)
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c18__DOT__stage_n5_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c18__DOT__stage_n5_1 
                                                       >> 4U))
                                                    : verification_top__DOT__c18__DOT__stage_n5_1);
    vlSelfRef.out_6 = ((vlSelfRef.in0 + ((4U & ((IData)(2U) 
                                                + (0x0000000fU 
                                                   ^ vlSelfRef.in0)))
                                          ? (((- (IData)(
                                                         (verification_top__DOT__c6__DOT__stage_n6_1 
                                                          >> 0x0000001fU))) 
                                              << 0x0000001cU) 
                                             | (verification_top__DOT__c6__DOT__stage_n6_1 
                                                >> 4U))
                                          : verification_top__DOT__c6__DOT__stage_n6_1)) 
                       ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    verification_top__DOT__c7__DOT__stage_n6_2 = ((4U 
                                                   & ((IData)(2U) 
                                                      + 
                                                      (0x0000000fU 
                                                       ^ vlSelfRef.in0)))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c6__DOT__stage_n6_1 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c6__DOT__stage_n6_1 
                                                      >> 4U))
                                                   : verification_top__DOT__c6__DOT__stage_n6_1);
    vlSelfRef.out_2 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                       ^ (vlSelfRef.in1 + ((4U & ((IData)(2U) 
                                                  + 
                                                  (0x0000000fU 
                                                   ^ vlSelfRef.in1)))
                                            ? (((- (IData)(
                                                           (verification_top__DOT__c2__DOT__stage_n6_1 
                                                            >> 0x0000001fU))) 
                                                << 0x0000001cU) 
                                               | (verification_top__DOT__c2__DOT__stage_n6_1 
                                                  >> 4U))
                                            : verification_top__DOT__c2__DOT__stage_n6_1)));
    verification_top__DOT__c3__DOT__stage_n6_2 = ((4U 
                                                   & ((IData)(2U) 
                                                      + 
                                                      (0x0000000fU 
                                                       ^ vlSelfRef.in1)))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c2__DOT__stage_n6_1 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c2__DOT__stage_n6_1 
                                                      >> 4U))
                                                   : verification_top__DOT__c2__DOT__stage_n6_1);
    vlSelfRef.out_10 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.in1 + ((4U & ((IData)(2U) 
                                                   + 
                                                   (0x0000000fU 
                                                    ^ 
                                                    ((IData)(5U) 
                                                     + vlSelfRef.in0))))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c10__DOT__stage_n9_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c10__DOT__stage_n9_1 
                                                   >> 4U))
                                             : verification_top__DOT__c10__DOT__stage_n9_1)));
    verification_top__DOT__c11__DOT__stage_n9_2 = (
                                                   (4U 
                                                    & ((IData)(2U) 
                                                       + 
                                                       (0x0000000fU 
                                                        ^ 
                                                        ((IData)(5U) 
                                                         + vlSelfRef.in0))))
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c10__DOT__stage_n9_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c10__DOT__stage_n9_1 
                                                       >> 4U))
                                                    : verification_top__DOT__c10__DOT__stage_n9_1);
    vlSelfRef.out_15 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                        ^ (vlSelfRef.in1 + ((0x00000010U 
                                             & ((IData)(0x0000000bU) 
                                                + vlSelfRef.in0))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c15__DOT__stage_n7_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c15__DOT__stage_n7_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c15__DOT__stage_n7_3)));
    verification_top__DOT__c19__DOT__stage_n5_3 = (
                                                   (8U 
                                                    & verification_top__DOT__c16__DOT__n3)
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c19__DOT__stage_n5_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c19__DOT__stage_n5_2 
                                                       >> 8U))
                                                    : verification_top__DOT__c19__DOT__stage_n5_2);
    verification_top__DOT__c7__DOT__stage_n6_3 = ((8U 
                                                   & ((IData)(2U) 
                                                      + 
                                                      (0x0000000fU 
                                                       ^ vlSelfRef.in0)))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c7__DOT__stage_n6_2 
                                                                >> 0x0000001fU))) 
                                                    << 0x00000018U) 
                                                   | (verification_top__DOT__c7__DOT__stage_n6_2 
                                                      >> 8U))
                                                   : verification_top__DOT__c7__DOT__stage_n6_2);
    verification_top__DOT__c3__DOT__stage_n6_3 = ((8U 
                                                   & ((IData)(2U) 
                                                      + 
                                                      (0x0000000fU 
                                                       ^ vlSelfRef.in1)))
                                                   ? 
                                                  (((- (IData)(
                                                               (verification_top__DOT__c3__DOT__stage_n6_2 
                                                                >> 0x0000001fU))) 
                                                    << 0x00000018U) 
                                                   | (verification_top__DOT__c3__DOT__stage_n6_2 
                                                      >> 8U))
                                                   : verification_top__DOT__c3__DOT__stage_n6_2);
    verification_top__DOT__c11__DOT__stage_n9_3 = (
                                                   (8U 
                                                    & ((IData)(2U) 
                                                       + 
                                                       (0x0000000fU 
                                                        ^ 
                                                        ((IData)(5U) 
                                                         + vlSelfRef.in0))))
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c11__DOT__stage_n9_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c11__DOT__stage_n9_2 
                                                       >> 8U))
                                                    : verification_top__DOT__c11__DOT__stage_n9_2);
    vlSelfRef.out_19 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x00000010U 
                                             & verification_top__DOT__c16__DOT__n3)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c19__DOT__stage_n5_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c19__DOT__stage_n5_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c19__DOT__stage_n5_3)));
    vlSelfRef.out_7 = ((vlSelfRef.in0 + ((0x00000010U 
                                          & ((IData)(2U) 
                                             + (0x0000000fU 
                                                ^ vlSelfRef.in0)))
                                          ? (((- (IData)(
                                                         (verification_top__DOT__c7__DOT__stage_n6_3 
                                                          >> 0x0000001fU))) 
                                              << 0x00000010U) 
                                             | (verification_top__DOT__c7__DOT__stage_n6_3 
                                                >> 0x00000010U))
                                          : verification_top__DOT__c7__DOT__stage_n6_3)) 
                       ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_3 = (vlSelfRef.verification_top__DOT__c0__DOT__n8 
                       ^ (vlSelfRef.in1 + ((0x00000010U 
                                            & ((IData)(2U) 
                                               + (0x0000000fU 
                                                  ^ vlSelfRef.in1)))
                                            ? (((- (IData)(
                                                           (verification_top__DOT__c3__DOT__stage_n6_3 
                                                            >> 0x0000001fU))) 
                                                << 0x00000010U) 
                                               | (verification_top__DOT__c3__DOT__stage_n6_3 
                                                  >> 0x00000010U))
                                            : verification_top__DOT__c3__DOT__stage_n6_3)));
    vlSelfRef.out_11 = (verification_top__DOT__c0__DOT__n0 
                        ^ (vlSelfRef.in1 + ((0x00000010U 
                                             & ((IData)(2U) 
                                                + (0x0000000fU 
                                                   ^ 
                                                   ((IData)(5U) 
                                                    + vlSelfRef.in0))))
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c11__DOT__stage_n9_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c11__DOT__stage_n9_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c11__DOT__stage_n9_3)));
}

void Vverification_top___024root___ico_comb__TOP__1(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___ico_comb__TOP__1\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ verification_top__DOT__c43__DOT__stage_n6_0;
    verification_top__DOT__c43__DOT__stage_n6_0 = 0;
    IData/*31:0*/ verification_top__DOT__c23__DOT__stage_n7_2;
    verification_top__DOT__c23__DOT__stage_n7_2 = 0;
    IData/*31:0*/ verification_top__DOT__c23__DOT__stage_n7_3;
    verification_top__DOT__c23__DOT__stage_n7_3 = 0;
    IData/*31:0*/ verification_top__DOT__c22__DOT__stage_n7_1;
    verification_top__DOT__c22__DOT__stage_n7_1 = 0;
    IData/*31:0*/ verification_top__DOT__c21__DOT__stage_n7_0;
    verification_top__DOT__c21__DOT__stage_n7_0 = 0;
    // Body
    vlSelfRef.out_30 = ((vlSelfRef.in0 + vlSelfRef.verification_top__DOT__c30__DOT__stage_n4_0) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_31 = ((vlSelfRef.in0 + (((- (IData)(
                                                      (1U 
                                                       & (((IData)(0x00000071U) 
                                                           + vlSelfRef.in0) 
                                                          >> 7U)))) 
                                           << 0x0000001eU) 
                                          | (vlSelfRef.verification_top__DOT__c30__DOT__stage_n4_0 
                                             >> 2U))) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_20 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x80000000U 
                                             & ((IData)(0x00000071U) 
                                                + (0xffff0000U 
                                                   & (0x001d0000U 
                                                      ^ 
                                                      (vlSelfRef.in1 
                                                       << 0x00000010U))))) 
                                            | (0x7fffffffU 
                                               & ((1U 
                                                   & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                                   ? 
                                                  (((IData)(0x00000071U) 
                                                    + 
                                                    (0xffff0000U 
                                                     & (0x001d0000U 
                                                        ^ 
                                                        (vlSelfRef.in1 
                                                         << 0x00000010U)))) 
                                                   >> 1U)
                                                   : 
                                                  ((IData)(0x00000071U) 
                                                   + 
                                                   (0x7fff0000U 
                                                    & (0x001d0000U 
                                                       ^ 
                                                       (vlSelfRef.in1 
                                                        << 0x00000010U)))))))));
    verification_top__DOT__c21__DOT__stage_n7_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x00000071U) 
                                                       + 
                                                       (0xffff0000U 
                                                        & (0x001d0000U 
                                                           ^ 
                                                           (vlSelfRef.in1 
                                                            << 0x00000010U))))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                                          ? 
                                                         (((IData)(0x00000071U) 
                                                           + 
                                                           (0xffff0000U 
                                                            & (0x001d0000U 
                                                               ^ 
                                                               (vlSelfRef.in1 
                                                                << 0x00000010U)))) 
                                                          >> 1U)
                                                          : 
                                                         ((IData)(0x00000071U) 
                                                          + 
                                                          (0x7fff0000U 
                                                           & (0x001d0000U 
                                                              ^ 
                                                              (vlSelfRef.in1 
                                                               << 0x00000010U)))))));
    vlSelfRef.out_42 = ((vlSelfRef.in0 + ((0x80000000U 
                                           & ((IData)(0x0000002fU) 
                                              + (0x0000000bU 
                                                 ^ vlSelfRef.verification_top__DOT__c0__DOT__n8))) 
                                          | (0x7fffffffU 
                                             & ((1U 
                                                 & vlSelfRef.verification_top__DOT__c42__DOT__n4)
                                                 ? 
                                                (((IData)(0x0000002fU) 
                                                  + 
                                                  (0x0000000bU 
                                                   ^ vlSelfRef.verification_top__DOT__c0__DOT__n8)) 
                                                 >> 1U)
                                                 : 
                                                ((IData)(0x0000002fU) 
                                                 + 
                                                 (0x0000000bU 
                                                  ^ vlSelfRef.verification_top__DOT__c0__DOT__n8)))))) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    verification_top__DOT__c43__DOT__stage_n6_0 = (
                                                   (0x80000000U 
                                                    & ((IData)(0x0000009dU) 
                                                       + 
                                                       (0x0000002fU 
                                                        ^ vlSelfRef.verification_top__DOT__c0__DOT__n8))) 
                                                   | (0x7fffffffU 
                                                      & ((1U 
                                                          & vlSelfRef.verification_top__DOT__c42__DOT__n4)
                                                          ? 
                                                         (((IData)(0x0000009dU) 
                                                           + 
                                                           (0x0000002fU 
                                                            ^ vlSelfRef.verification_top__DOT__c0__DOT__n8)) 
                                                          >> 1U)
                                                          : 
                                                         ((IData)(0x0000009dU) 
                                                          + 
                                                          (0x0000002fU 
                                                           ^ vlSelfRef.verification_top__DOT__c0__DOT__n8)))));
    vlSelfRef.out_21 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((2U & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                             ? (((- (IData)(
                                                            (((IData)(0x00000071U) 
                                                              + 
                                                              (0xffff0000U 
                                                               & (0x001d0000U 
                                                                  ^ 
                                                                  (vlSelfRef.in1 
                                                                   << 0x00000010U)))) 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001eU) 
                                                | (verification_top__DOT__c21__DOT__stage_n7_0 
                                                   >> 2U))
                                             : verification_top__DOT__c21__DOT__stage_n7_0)));
    verification_top__DOT__c22__DOT__stage_n7_1 = (
                                                   (2U 
                                                    & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                                    ? 
                                                   (((- (IData)(
                                                                (((IData)(0x00000071U) 
                                                                  + 
                                                                  (0xffff0000U 
                                                                   & (0x001d0000U 
                                                                      ^ 
                                                                      (vlSelfRef.in1 
                                                                       << 0x00000010U)))) 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001eU) 
                                                    | (verification_top__DOT__c21__DOT__stage_n7_0 
                                                       >> 2U))
                                                    : verification_top__DOT__c21__DOT__stage_n7_0);
    vlSelfRef.out_43 = ((vlSelfRef.in0 + ((2U & vlSelfRef.verification_top__DOT__c42__DOT__n4)
                                           ? (((- (IData)(
                                                          (((IData)(0x0000009dU) 
                                                            + 
                                                            (0x0000002fU 
                                                             ^ vlSelfRef.verification_top__DOT__c0__DOT__n8)) 
                                                           >> 0x0000001fU))) 
                                               << 0x0000001eU) 
                                              | (verification_top__DOT__c43__DOT__stage_n6_0 
                                                 >> 2U))
                                           : verification_top__DOT__c43__DOT__stage_n6_0)) 
                        ^ vlSelfRef.verification_top__DOT__c4__DOT__n8);
    vlSelfRef.out_22 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((4U & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c22__DOT__stage_n7_1 
                                                             >> 0x0000001fU))) 
                                                 << 0x0000001cU) 
                                                | (verification_top__DOT__c22__DOT__stage_n7_1 
                                                   >> 4U))
                                             : verification_top__DOT__c22__DOT__stage_n7_1)));
    verification_top__DOT__c23__DOT__stage_n7_2 = (
                                                   (4U 
                                                    & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c22__DOT__stage_n7_1 
                                                                 >> 0x0000001fU))) 
                                                     << 0x0000001cU) 
                                                    | (verification_top__DOT__c22__DOT__stage_n7_1 
                                                       >> 4U))
                                                    : verification_top__DOT__c22__DOT__stage_n7_1);
    verification_top__DOT__c23__DOT__stage_n7_3 = (
                                                   (8U 
                                                    & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                                    ? 
                                                   (((- (IData)(
                                                                (verification_top__DOT__c23__DOT__stage_n7_2 
                                                                 >> 0x0000001fU))) 
                                                     << 0x00000018U) 
                                                    | (verification_top__DOT__c23__DOT__stage_n7_2 
                                                       >> 8U))
                                                    : verification_top__DOT__c23__DOT__stage_n7_2);
    vlSelfRef.out_23 = (vlSelfRef.in1 ^ (vlSelfRef.in0 
                                         + ((0x00000010U 
                                             & vlSelfRef.verification_top__DOT__c20__DOT__n5)
                                             ? (((- (IData)(
                                                            (verification_top__DOT__c23__DOT__stage_n7_3 
                                                             >> 0x0000001fU))) 
                                                 << 0x00000010U) 
                                                | (verification_top__DOT__c23__DOT__stage_n7_3 
                                                   >> 0x00000010U))
                                             : verification_top__DOT__c23__DOT__stage_n7_3)));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vverification_top___024root___eval_phase__ico(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_phase__ico\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__ico
        vlSelfRef.__VicoTriggered[0U] = (QData)((IData)(
                                                        (((vlSelfRef.in1 
                                                           != vlSelfRef.__Vtrigprevexpr___TOP__in1__0) 
                                                          << 1U) 
                                                         | (vlSelfRef.in0 
                                                            != vlSelfRef.__Vtrigprevexpr___TOP__in0__0))));
        vlSelfRef.__Vtrigprevexpr___TOP__in0__0 = vlSelfRef.in0;
        vlSelfRef.__Vtrigprevexpr___TOP__in1__0 = vlSelfRef.in1;
        if (VL_UNLIKELY(((1U & (~ (IData)(vlSelfRef.__VicoDidInit)))))) {
            vlSelfRef.__VicoDidInit = 1U;
            vlSelfRef.__VicoTriggered[0U] = (1ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (2ULL | vlSelfRef.__VicoTriggered[0U]);
        }
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vverification_top___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_ico
            if ((3ULL & vlSelfRef.__VicoTriggered[0U])) {
                Vverification_top___024root___ico_comb__TOP__0(vlSelf);
            }
            if ((1ULL & vlSelfRef.__VicoTriggered[0U])) {
                {
                    // Inlined CFunc: _ico_sequent__TOP__0
                    vlSelfRef.verification_top__DOT__c30__DOT__stage_n4_0 
                        = ((0x80000000U & (((IData)(0x00000071U) 
                                            + vlSelfRef.in0) 
                                           << 0x00000018U)) 
                           | (0x7f800000U & (0x0e800000U 
                                             ^ (0x7f800000U 
                                                & (((IData)(0x00000071U) 
                                                    + vlSelfRef.in0) 
                                                   << 0x00000017U)))));
                    vlSelfRef.verification_top__DOT__c20__DOT__n5 
                        = (0x0000000fU ^ ((0x80000000U 
                                           & vlSelfRef.in0) 
                                          | (vlSelfRef.in0 
                                             >> 1U)));
                }
            }
            if ((2ULL & vlSelfRef.__VicoTriggered[0U])) {
                {
                    // Inlined CFunc: _ico_sequent__TOP__1
                    vlSelfRef.verification_top__DOT__c42__DOT__n4 
                        = (0x0000000fU ^ ((0x80000000U 
                                           & vlSelfRef.in1) 
                                          | (vlSelfRef.in1 
                                             >> 1U)));
                }
            }
            if ((3ULL & vlSelfRef.__VicoTriggered[0U])) {
                Vverification_top___024root___ico_comb__TOP__1(vlSelf);
            }
        }
    }
    return (__VicoExecute);
}

void Vverification_top___024root___eval(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    // Body
    __VicoIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-11/can-this-run-offline/work/agentic-riscv-codesign/results/boundary-feasibility-validation/raw/verification/verification.v", 1, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 10000 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = Vverification_top___024root___eval_phase__ico(vlSelf);
    } while (vlSelfRef.__VicoPhaseResult);
}

#ifdef VL_DEBUG
void Vverification_top___024root___eval_debug_assertions(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_debug_assertions\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
