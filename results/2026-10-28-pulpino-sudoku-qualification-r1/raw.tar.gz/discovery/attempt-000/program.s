	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.safe,"ax",@progbits
	.align	2
	.globl	safe
	.type	safe, @function
safe:
	slli	a5,a1,3
	add	a5,a5,a1
	add	a4,a5,a2
	slli	a4,a4,2
	add	a4,a0,a4
	lw	a4,0(a4)
	beq	a4,a3,.L11
	bne	a4,zero,.L12
	slli	a5,a5,2
	add	a5,a0,a5
	li	a6,0
	li	a7,9
.L3:
	lw	t1,0(a5)
	beq	t1,a3,.L1
	addi	a6,a6,1
	addi	a5,a5,4
	bne	a6,a7,.L3
	slli	a5,a2,2
	add	a5,a0,a5
	li	a6,0
	li	a7,9
.L4:
	lw	t1,0(a5)
	beq	t1,a3,.L1
	addi	a6,a6,1
	addi	a5,a5,36
	bne	a6,a7,.L4
	li	a7,5
	li	a6,2
	bgt	a1,a7,.L5
	slti	a1,a1,3
	seqz	a6,a1
.L5:
	li	a5,2
	bgt	a2,a7,.L6
	slti	a2,a2,3
	seqz	a5,a2
.L6:
	slli	a2,a5,1
	add	a2,a2,a5
	slli	a5,a6,3
	sub	a5,a5,a6
	slli	a5,a5,2
	sub	a5,a5,a6
	addi	t3,a2,3
	li	a6,4
.L7:
	addi	a6,a6,-1
	bne	a6,zero,.L10
.L11:
	li	a4,1
.L1:
	mv	a0,a4
	ret
.L10:
	slli	a7,a5,2
	add	a7,a0,a7
	mv	a1,a2
.L8:
	bgt	t3,a1,.L9
	addi	a5,a5,9
	j	.L7
.L9:
	slli	t1,a1,2
	add	t1,a7,t1
	lw	t1,0(t1)
	beq	t1,a3,.L1
	addi	a1,a1,1
	j	.L8
.L12:
	li	a4,0
	j	.L1
	.size	safe, .-safe
	.section	.text.solve,"ax",@progbits
	.align	2
	.globl	solve
	.type	solve, @function
solve:
	li	a5,9
	bne	a1,a5,.L18
	li	a5,1
	sw	a5,0(a3)
	ret
.L18:
	tail	solve.part.0
	.size	solve, .-solve
	.section	.text.solve.part.0,"ax",@progbits
	.align	2
	.type	solve.part.0, @function
solve.part.0:
	addi	sp,sp,-48
	sw	s0,40(sp)
	slli	s0,a1,3
	add	s0,s0,a1
	add	s0,s0,a2
	sw	s1,36(sp)
	slli	s0,s0,2
	li	s1,1
	sw	s2,32(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	s8,8(sp)
	sw	s9,4(sp)
	sw	s10,0(sp)
	sw	ra,44(sp)
	sw	s7,12(sp)
	mv	s8,a0
	mv	s2,a1
	mv	s3,a2
	mv	s4,a3
	add	s0,a0,s0
	li	s6,8
	add	s9,a2,s1
	add	s10,a1,s1
	li	s5,10
.L26:
	mv	a3,s1
	mv	a2,s3
	mv	a1,s2
	mv	a0,s8
	call	safe
	beq	a0,zero,.L22
	lw	s7,0(s0)
	sw	s1,0(s0)
	mv	a3,s4
	bne	s3,s6,.L23
	li	a2,0
	mv	a1,s10
.L33:
	mv	a0,s8
	call	solve
	lw	a5,0(s4)
	bne	a5,zero,.L21
	sw	s7,0(s0)
.L22:
	addi	s1,s1,1
	bne	s1,s5,.L26
.L21:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	lw	s7,12(sp)
	lw	s8,8(sp)
	lw	s9,4(sp)
	lw	s10,0(sp)
	addi	sp,sp,48
	jr	ra
.L23:
	mv	a2,s9
	mv	a1,s2
	j	.L33
	.size	solve.part.0, .-solve.part.0
	.section	.text.sudokusolver,"ax",@progbits
	.align	2
	.globl	sudokusolver
	.type	sudokusolver, @function
sudokusolver:
	mv	a3,a1
	li	a2,0
	li	a1,0
	tail	solve.part.0
	.size	sudokusolver, .-sudokusolver
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-48
	sw	s0,40(sp)
	lui	s0,%hi(grid_init)
	addi	s0,s0,%lo(grid_init)
	sw	ra,44(sp)
	sw	s1,36(sp)
	sw	s2,32(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	mv	a3,s0
	li	a2,0
	li	a1,9
	li	a0,81
.L38:
	mv	a5,a3
	li	a4,0
.L39:
	sw	zero,0(a5)
	addi	a4,a4,1
	addi	a5,a5,4
	bne	a4,a1,.L39
	addi	a2,a2,9
	addi	a3,a3,36
	bne	a2,a0,.L38
	li	a3,3
	li	a2,5
	li	a0,4
	li	a1,7
	li	a5,2
	li	s1,1
	li	a6,6
	li	a7,8
	sw	a0,28(s0)
	sw	a1,36(s0)
	sw	a1,104(s0)
	sw	a1,164(s0)
	sw	a0,228(s0)
	sw	a0,284(s0)
	sw	a4,4(s0)
	sw	a3,8(s0)
	sw	s1,12(s0)
	sw	a2,20(s0)
	sw	a6,24(s0)
	sw	a2,68(s0)
	sw	a2,72(s0)
	sw	s1,80(s0)
	sw	a5,84(s0)
	sw	a4,92(s0)
	sw	a3,96(s0)
	sw	a5,108(s0)
	sw	a3,140(s0)
	sw	a3,148(s0)
	sw	a6,152(s0)
	sw	a4,156(s0)
	sw	a2,168(s0)
	sw	a5,172(s0)
	sw	a4,180(s0)
	sw	s1,212(s0)
	sw	a3,216(s0)
	sw	a5,224(s0)
	sw	a7,236(s0)
	sw	s1,240(s0)
	sw	a4,248(s0)
	sw	a6,252(s0)
	lui	s3,%hi(grid_solved)
	lui	s2,%hi(solved)
	sw	a0,292(s0)
	li	s4,36
	sw	a1,296(s0)
	sw	a3,300(s0)
	sw	a5,308(s0)
	sw	a7,312(s0)
	sw	a2,316(s0)
	li	s5,81
	addi	a1,s2,%lo(solved)
	addi	a0,s3,%lo(grid_solved)
.L41:
	addi	a6,s3,%lo(grid_solved)
	mv	a2,s0
	li	a3,0
	j	.L45
.L42:
	add	t1,a2,a4
	lw	t1,0(t1)
	add	a7,a6,a4
	addi	a4,a4,4
	sw	t1,0(a7)
	bne	a4,s4,.L42
	addi	a3,a3,9
	addi	a2,a2,36
	addi	a6,a6,36
	beq	a3,s5,.L43
.L45:
	li	a4,0
	j	.L42
.L43:
	sw	a5,12(sp)
	sw	zero,%lo(solved)(s2)
	call	sudokusolver
	lw	a5,12(sp)
	beq	a5,s1,.L44
	lui	a4,%hi(solved)
	addi	a1,a4,%lo(solved)
	lui	a4,%hi(grid_solved)
	li	a5,1
	addi	a0,a4,%lo(grid_solved)
	j	.L41
.L44:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	a0,%lo(solved)(s2)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	addi	sp,sp,48
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	li	a5,1
	bne	a0,a5,.L54
	lui	a5,%hi(solved)
	lw	a5,%lo(solved)(a5)
	bne	a5,a0,.L54
	lui	a3,%hi(grid_solved)
	lui	a2,%hi(SUDOKUSOLVED)
	li	a4,0
	addi	a3,a3,%lo(grid_solved)
	addi	a2,a2,%lo(SUDOKUSOLVED)
	li	a6,324
.L51:
	add	a0,a4,a3
	add	a1,a4,a2
	lw	a0,0(a0)
	lw	a1,0(a1)
	bne	a0,a1,.L54
	addi	a4,a4,4
	bne	a4,a6,.L51
.L49:
	mv	a0,a5
	ret
.L54:
	li	a5,0
	j	.L49
	.size	verify_benchmark, .-verify_benchmark
	.globl	solved
	.section	.bss.solved,"aw",@nobits
	.align	2
	.type	solved, @object
	.size	solved, 4
solved:
	.zero	4
	.globl	grid_solved
	.section	.bss.grid_solved,"aw",@nobits
	.align	2
	.type	grid_solved, @object
	.size	grid_solved, 324
grid_solved:
	.zero	324
	.globl	grid_init
	.section	.bss.grid_init,"aw",@nobits
	.align	2
	.type	grid_init, @object
	.size	grid_init, 324
grid_init:
	.zero	324
	.globl	SUDOKUSOLVED
	.section	.rodata.SUDOKUSOLVED,"a"
	.align	2
	.type	SUDOKUSOLVED, @object
	.size	SUDOKUSOLVED, 324
SUDOKUSOLVED:
	.word	8
	.word	9
	.word	3
	.word	1
	.word	7
	.word	5
	.word	6
	.word	4
	.word	2
	.word	7
	.word	2
	.word	4
	.word	8
	.word	3
	.word	6
	.word	9
	.word	1
	.word	5
	.word	5
	.word	6
	.word	1
	.word	2
	.word	4
	.word	9
	.word	3
	.word	8
	.word	7
	.word	2
	.word	1
	.word	5
	.word	6
	.word	8
	.word	4
	.word	7
	.word	9
	.word	3
	.word	4
	.word	3
	.word	6
	.word	9
	.word	1
	.word	7
	.word	5
	.word	2
	.word	8
	.word	9
	.word	7
	.word	8
	.word	5
	.word	2
	.word	3
	.word	4
	.word	6
	.word	1
	.word	3
	.word	5
	.word	2
	.word	4
	.word	6
	.word	8
	.word	1
	.word	7
	.word	9
	.word	6
	.word	8
	.word	9
	.word	7
	.word	5
	.word	1
	.word	2
	.word	3
	.word	4
	.word	1
	.word	4
	.word	7
	.word	3
	.word	9
	.word	2
	.word	8
	.word	5
	.word	6
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
