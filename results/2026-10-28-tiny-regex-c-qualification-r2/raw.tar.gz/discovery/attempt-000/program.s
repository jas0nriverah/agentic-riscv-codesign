	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.re_compile,"ax",@progbits
	.align	2
	.globl	re_compile
	.type	re_compile, @function
re_compile:
	lui	a5,%hi(re_compiled.1)
	addi	sp,sp,-32
	addi	a5,a5,%lo(re_compiled.1)
	sw	s0,28(sp)
	sw	s1,24(sp)
	sw	s2,20(sp)
	sw	s3,16(sp)
	sw	s4,12(sp)
	sw	s5,8(sp)
	sw	s6,4(sp)
	sw	s7,0(sp)
	li	a2,0
	li	a4,0
	li	a7,1
	mv	a6,a5
	li	t2,29
	li	t4,63
	li	s0,92
	li	t5,94
	li	s1,91
	li	t6,43
	li	s2,46
	li	s3,36
	li	s4,42
.L2:
	add	a1,a0,a4
	lbu	a3,0(a1)
	beq	a3,zero,.L39
	bne	a2,t2,.L40
.L39:
	slli	a2,a2,3
	add	a2,a6,a2
	sb	zero,0(a2)
	mv	a0,a6
	j	.L1
.L40:
	beq	a3,t4,.L3
	bgtu	a3,t4,.L4
	beq	a3,t6,.L5
	bgtu	a3,t6,.L6
	beq	a3,s3,.L7
	beq	a3,s4,.L8
.L9:
	li	a1,7
	sb	a1,0(a5)
	j	.L59
.L6:
	bne	a3,s2,.L9
	li	a3,1
	j	.L58
.L4:
	beq	a3,s0,.L11
	beq	a3,t5,.L12
	bne	a3,s1,.L9
	lbu	a3,1(a1)
	bne	a3,t5,.L28
	li	a3,9
	sb	a3,0(a5)
	lbu	a3,2(a1)
	beq	a3,zero,.L29
	addi	a4,a4,1
.L30:
	lui	a1,%hi(ccl_buf.0)
	mv	t3,a4
	mv	a3,a7
	li	t0,92
	li	s5,39
	li	s6,38
	addi	a1,a1,%lo(ccl_buf.0)
.L32:
	addi	a4,a4,1
	add	t1,a0,a4
	lbu	t1,0(t1)
	addi	s7,t1,-93
	beq	s7,zero,.L41
	bne	t1,zero,.L35
.L41:
	li	a1,39
	bgt	a3,a1,.L29
	lui	a1,%hi(ccl_buf.0)
	addi	a1,a1,%lo(ccl_buf.0)
	add	t1,a1,a3
	add	a1,a7,a1
	sb	zero,0(t1)
	sw	a1,4(a5)
	addi	a7,a3,1
	j	.L15
.L12:
	li	a3,2
.L58:
	sb	a3,0(a5)
.L15:
	add	a3,a0,a4
	lbu	a3,0(a3)
	beq	a3,zero,.L29
	addi	a5,a5,8
	addi	a4,a4,1
	addi	a2,a2,1
	j	.L2
.L7:
	li	a3,3
	j	.L58
.L8:
	li	a3,5
	j	.L58
.L5:
	li	a3,6
	j	.L58
.L3:
	li	a3,4
	j	.L58
.L11:
	addi	t1,a4,1
	add	a1,a0,t1
	lbu	a3,0(a1)
	beq	a3,zero,.L15
	mv	a4,t1
	li	t1,100
	beq	a3,t1,.L18
	bgtu	a3,t1,.L19
	li	t1,83
	beq	a3,t1,.L20
	li	t1,87
	beq	a3,t1,.L21
	li	t1,68
	beq	a3,t1,.L22
.L23:
	li	a3,7
	sb	a3,0(a5)
	lbu	a3,0(a1)
.L59:
	sb	a3,4(a5)
	j	.L15
.L19:
	li	t1,115
	beq	a3,t1,.L24
	li	t1,119
	bne	a3,t1,.L23
	li	a3,12
	j	.L58
.L18:
	li	a3,10
	j	.L58
.L22:
	li	a3,11
	j	.L58
.L21:
	li	a3,13
	j	.L58
.L24:
	li	a3,14
	j	.L58
.L20:
	li	a3,15
	j	.L58
.L28:
	li	a3,8
	sb	a3,0(a5)
	j	.L30
.L35:
	bne	t1,t0,.L33
	bgt	a3,s6,.L29
	add	a4,a0,t3
	lbu	a4,2(a4)
	beq	a4,zero,.L29
	add	t1,a1,a3
	addi	a4,t3,2
	sb	t0,0(t1)
	addi	a3,a3,1
.L34:
	add	t1,a0,a4
	lbu	t3,0(t1)
	add	t1,a1,a3
	addi	a3,a3,1
	sb	t3,0(t1)
	mv	t3,a4
	j	.L32
.L33:
	ble	a3,s5,.L34
.L29:
	li	a0,0
.L1:
	lw	s0,28(sp)
	lw	s1,24(sp)
	lw	s2,20(sp)
	lw	s3,16(sp)
	lw	s4,12(sp)
	lw	s5,8(sp)
	lw	s6,4(sp)
	lw	s7,0(sp)
	addi	sp,sp,32
	jr	ra
	.size	re_compile, .-re_compile
	.section	.text.isaforge_tiny_regex_diagnostic_print,"ax",@progbits
	.align	2
	.globl	isaforge_tiny_regex_diagnostic_print
	.type	isaforge_tiny_regex_diagnostic_print, @function
isaforge_tiny_regex_diagnostic_print:
	ret
	.size	isaforge_tiny_regex_diagnostic_print, .-isaforge_tiny_regex_diagnostic_print
	.section	.text.isdigit,"ax",@progbits
	.align	2
	.globl	isdigit
	.type	isdigit, @function
isdigit:
	addi	a0,a0,-48
	sltiu	a0,a0,10
	ret
	.size	isdigit, .-isdigit
	.section	.text.isalpha,"ax",@progbits
	.align	2
	.globl	isalpha
	.type	isalpha, @function
isalpha:
	andi	a0,a0,-33
	addi	a0,a0,-65
	sltiu	a0,a0,26
	ret
	.size	isalpha, .-isalpha
	.section	.text.matchalphanum,"ax",@progbits
	.align	2
	.type	matchalphanum, @function
matchalphanum:
	li	a4,95
	beq	a0,a4,.L65
	addi	sp,sp,-32
	sw	ra,28(sp)
	sw	a0,12(sp)
	call	isalpha
	bne	a0,zero,.L63
	lw	a5,12(sp)
	addi	a5,a5,-48
	sltiu	a0,a5,10
.L63:
	lw	ra,28(sp)
	addi	sp,sp,32
	jr	ra
.L65:
	li	a0,1
	ret
	.size	matchalphanum, .-matchalphanum
	.section	.text.isspace,"ax",@progbits
	.align	2
	.globl	isspace
	.type	isspace, @function
isspace:
	addi	a5,a0,-9
	addi	a0,a0,-32
	sltiu	a5,a5,5
	seqz	a0,a0
	or	a0,a5,a0
	ret
	.size	isspace, .-isspace
	.section	.text.matchcharclass,"ax",@progbits
	.align	2
	.type	matchcharclass, @function
matchcharclass:
	addi	sp,sp,-64
	sw	s1,52(sp)
	sw	s2,48(sp)
	sw	s3,44(sp)
	sw	s4,40(sp)
	sw	s5,36(sp)
	sw	s6,32(sp)
	sw	s7,28(sp)
	sw	s8,24(sp)
	sw	s9,20(sp)
	sw	s11,12(sp)
	sw	ra,60(sp)
	sw	s0,56(sp)
	sw	s10,16(sp)
	mv	s9,a0
	mv	s11,a1
	li	s1,45
	li	s4,92
	li	s2,100
	li	s3,87
	li	s5,115
	li	s6,119
	li	s7,83
	li	s8,68
.L93:
	lbu	s10,0(s11)
	beq	s9,s1,.L72
	addi	a5,s10,-45
	beq	a5,zero,.L99
	beq	s10,zero,.L99
	lbu	a5,1(s11)
	bne	a5,s1,.L72
	lbu	a3,2(s11)
	sltu	a4,s9,s10
	seqz	a4,a4
	snez	a5,a3
	and	a5,a5,a4
	beq	a5,zero,.L72
	bleu	s9,a3,.L98
.L72:
	bne	s10,s4,.L76
	lbu	s10,1(s11)
	addi	s0,s11,1
	beq	s10,s2,.L77
	bgtu	s10,s2,.L78
	beq	s10,s7,.L79
	beq	s10,s3,.L80
	beq	s10,s8,.L81
.L82:
	bne	s9,s10,.L73
.L98:
	li	a0,1
	j	.L71
.L78:
	beq	s10,s5,.L83
	bne	s10,s6,.L82
	mv	a0,s9
	call	matchalphanum
	j	.L86
.L77:
	addi	a0,s9,-48
	sltiu	a0,a0,10
.L86:
	bne	a0,zero,.L71
	bne	s9,s10,.L73
	bgtu	s9,s3,.L87
	li	a5,67
	bleu	s9,a5,.L98
	addi	a4,s9,-68
.L117:
	li	a5,557056
	addi	a5,a5,1
	srl	a5,a5,a4
	andi	a5,a5,1
	beq	a5,zero,.L98
	addi	s11,s11,2
	j	.L93
.L81:
	addi	a0,s9,-48
	sltiu	a0,a0,10
	seqz	a0,a0
	j	.L86
.L80:
	mv	a0,s9
	call	matchalphanum
.L115:
	xori	a0,a0,1
	j	.L86
.L83:
	mv	a0,s9
	call	isspace
	j	.L86
.L79:
	mv	a0,s9
	call	isspace
	j	.L115
.L87:
	addi	a4,s9,-100
	andi	a4,a4,0xff
	li	a5,19
	bleu	a4,a5,.L117
	j	.L98
.L76:
	bne	s9,s10,.L99
	li	a5,45
	li	a0,1
	bne	s9,a5,.L71
	lbu	a5,-1(s11)
	beq	a5,zero,.L71
	lbu	a0,1(s11)
	seqz	a0,a0
.L71:
	lw	ra,60(sp)
	lw	s0,56(sp)
	lw	s1,52(sp)
	lw	s2,48(sp)
	lw	s3,44(sp)
	lw	s4,40(sp)
	lw	s5,36(sp)
	lw	s6,32(sp)
	lw	s7,28(sp)
	lw	s8,24(sp)
	lw	s9,20(sp)
	lw	s10,16(sp)
	lw	s11,12(sp)
	addi	sp,sp,64
	jr	ra
.L99:
	mv	s0,s11
.L73:
	beq	s10,zero,.L102
	addi	s11,s0,1
	j	.L93
.L102:
	li	a0,0
	j	.L71
	.size	matchcharclass, .-matchcharclass
	.section	.text.matchone,"ax",@progbits
	.align	2
	.type	matchone, @function
matchone:
	addi	sp,sp,-32
	addi	a0,a0,-1
	sw	ra,28(sp)
	sw	a1,12(sp)
	andi	a5,a0,0xff
	li	a4,14
	bgtu	a5,a4,.L119
	lui	a4,%hi(.L121)
	slli	a5,a5,2
	addi	a4,a4,%lo(.L121)
	add	a5,a5,a4
	lw	a5,0(a5)
	mv	a0,a2
	jr	a5
	.section	.rodata.matchone,"a",@progbits
	.align	2
	.align	2
.L121:
	.word	.L130
	.word	.L119
	.word	.L119
	.word	.L119
	.word	.L119
	.word	.L119
	.word	.L119
	.word	.L128
	.word	.L127
	.word	.L126
	.word	.L125
	.word	.L124
	.word	.L123
	.word	.L122
	.word	.L120
	.section	.text.matchone
.L128:
	lw	a1,12(sp)
	lw	ra,28(sp)
	addi	sp,sp,32
	tail	matchcharclass
.L127:
	lw	a1,12(sp)
	call	matchcharclass
.L132:
	xori	a0,a0,1
	j	.L118
.L126:
	addi	a0,a2,-48
	sltiu	a0,a0,10
.L118:
	lw	ra,28(sp)
	addi	sp,sp,32
	jr	ra
.L125:
	addi	a0,a2,-48
	sltiu	a0,a0,10
.L133:
	seqz	a0,a0
	j	.L118
.L124:
	lw	ra,28(sp)
	addi	sp,sp,32
	tail	matchalphanum
.L123:
	call	matchalphanum
	j	.L132
.L122:
	lw	ra,28(sp)
	addi	sp,sp,32
	tail	isspace
.L120:
	call	isspace
	j	.L132
.L119:
	lbu	a0,12(sp)
	sub	a0,a0,a2
	j	.L133
.L130:
	li	a0,1
	j	.L118
	.size	matchone, .-matchone
	.section	.text.matchpattern,"ax",@progbits
	.align	2
	.type	matchpattern, @function
matchpattern:
	addi	sp,sp,-48
	sw	s2,32(sp)
	lw	s2,0(a2)
	sw	s0,40(sp)
	sw	s1,36(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	sw	ra,44(sp)
	mv	s1,a0
	mv	s3,a1
	mv	s0,a2
	li	s4,4
	li	s5,5
	li	s6,6
.L160:
	lbu	a5,0(s1)
	beq	a5,zero,.L135
	lbu	a4,8(s1)
	bne	a4,s4,.L136
.L135:
	lw	a4,0(s1)
	sw	a4,8(sp)
	lw	a4,4(s1)
	sw	a4,12(sp)
	beq	a5,zero,.L138
	mv	a2,s0
	mv	a1,s3
	addi	a0,s1,16
	call	matchpattern
	mv	s2,a0
	bne	a0,zero,.L138
	lbu	a2,0(s3)
	beq	a2,zero,.L134
	lw	a0,8(sp)
	lw	a1,12(sp)
	call	matchone
	beq	a0,zero,.L134
	mv	a2,s0
	addi	a1,s3,1
	addi	a0,s1,16
	call	matchpattern
	beq	a0,zero,.L134
	lw	a5,0(s0)
	addi	a5,a5,1
	sw	a5,0(s0)
.L138:
	li	s2,1
.L134:
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	mv	a0,s2
	lw	s2,32(sp)
	addi	sp,sp,48
	jr	ra
.L161:
	addi	s1,s1,8
	j	.L160
.L136:
	bne	a4,s5,.L144
	lw	a5,0(s1)
	lw	s5,0(s0)
	addi	s4,s1,16
	sw	a5,8(sp)
	lw	a5,4(s1)
	mv	s1,s3
	sw	a5,12(sp)
.L145:
	lbu	a2,0(s1)
	beq	a2,zero,.L149
	lw	a0,8(sp)
	lw	a1,12(sp)
	call	matchone
	bne	a0,zero,.L147
.L149:
	bleu	s3,s1,.L150
	sw	s5,0(s0)
.L187:
	li	s2,0
	j	.L134
.L147:
	lw	a5,0(s0)
	addi	s1,s1,1
	addi	a5,a5,1
	sw	a5,0(s0)
	j	.L145
.L150:
	mv	a2,s0
	mv	a1,s1
	mv	a0,s4
	call	matchpattern
	mv	s2,a0
	bne	a0,zero,.L134
	lw	a5,0(s0)
	addi	s1,s1,-1
	addi	a5,a5,-1
	sw	a5,0(s0)
	j	.L149
.L144:
	bne	a4,s6,.L151
	lw	a5,0(s1)
	addi	s4,s1,16
	sw	a5,8(sp)
	lw	a5,4(s1)
	mv	s1,s3
	sw	a5,12(sp)
.L152:
	lbu	a2,0(s1)
	beq	a2,zero,.L156
	lw	a0,8(sp)
	lw	a1,12(sp)
	call	matchone
	bne	a0,zero,.L154
.L156:
	bgeu	s3,s1,.L187
	mv	a2,s0
	mv	a1,s1
	mv	a0,s4
	call	matchpattern
	mv	s2,a0
	bne	a0,zero,.L134
	lw	a5,0(s0)
	addi	s1,s1,-1
	addi	a5,a5,-1
	sw	a5,0(s0)
	j	.L156
.L154:
	lw	a5,0(s0)
	addi	s1,s1,1
	addi	a5,a5,1
	sw	a5,0(s0)
	j	.L152
.L151:
	addi	a5,a5,-3
	bne	a5,zero,.L158
	bne	a4,zero,.L158
	lbu	s2,0(s3)
	seqz	s2,s2
	j	.L134
.L158:
	lw	a5,0(s0)
	addi	a5,a5,1
	sw	a5,0(s0)
	lbu	a2,0(s3)
	beq	a2,zero,.L159
	lw	a0,0(s1)
	lw	a1,4(s1)
	addi	s3,s3,1
	call	matchone
	bne	a0,zero,.L161
.L159:
	sw	s2,0(s0)
	j	.L187
	.size	matchpattern, .-matchpattern
	.section	.text.re_matchp,"ax",@progbits
	.align	2
	.globl	re_matchp
	.type	re_matchp, @function
re_matchp:
	sw	zero,0(a2)
	bne	a0,zero,.L189
	li	a0,-1
	ret
.L189:
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	s1,20(sp)
	sw	s2,16(sp)
	sw	s3,12(sp)
	sw	ra,28(sp)
	lbu	a4,0(a0)
	li	a5,2
	mv	s2,a1
	mv	s3,a2
	mv	s1,a0
	mv	s0,a1
	bne	a4,a5,.L191
	addi	a0,a0,8
	call	matchpattern
	xori	a0,a0,1
	neg	a0,a0
	j	.L188
.L192:
	addi	s0,s0,1
	beq	a5,zero,.L193
.L191:
	mv	a2,s3
	mv	a1,s0
	mv	a0,s1
	call	matchpattern
	lbu	a5,0(s0)
	beq	a0,zero,.L192
	sub	a0,s0,s2
	bne	a5,zero,.L188
.L193:
	li	a0,-1
.L188:
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	addi	sp,sp,32
	jr	ra
	.size	re_matchp, .-re_matchp
	.section	.text.re_match,"ax",@progbits
	.align	2
	.globl	re_match
	.type	re_match, @function
re_match:
	addi	sp,sp,-32
	sw	ra,28(sp)
	sw	a1,12(sp)
	sw	a2,8(sp)
	call	re_compile
	lw	a2,8(sp)
	lw	a1,12(sp)
	lw	ra,28(sp)
	addi	sp,sp,32
	tail	re_matchp
	.size	re_match, .-re_match
	.section	.text.isaforge_tiny_regex_upstream_test_main,"ax",@progbits
	.align	2
	.globl	isaforge_tiny_regex_upstream_test_main
	.type	isaforge_tiny_regex_upstream_test_main, @function
isaforge_tiny_regex_upstream_test_main:
	addi	sp,sp,-48
	sw	s0,40(sp)
	lui	s0,%hi(test_vector)
	addi	s0,s0,%lo(test_vector)
	sw	s1,36(sp)
	sw	s3,28(sp)
	sw	s4,24(sp)
	sw	ra,44(sp)
	sw	s2,32(sp)
	sw	s5,20(sp)
	sw	s6,16(sp)
	addi	s4,s0,1216
	li	s1,0
	li	s3,-1
.L211:
	lw	a5,4(s0)
	lw	s5,0(s0)
	lw	a1,8(s0)
	addi	a2,sp,12
	mv	a0,a5
	lw	s2,12(s0)
	mv	s6,a5
	call	re_match
	bne	s5,zero,.L208
	beq	a0,s3,.L209
.L214:
	mv	a0,s6
	call	re_compile
	addi	s1,s1,1
.L209:
	addi	s0,s0,16
	bne	s0,s4,.L211
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	lw	s4,24(sp)
	lw	s5,20(sp)
	lw	s6,16(sp)
	mv	a0,s1
	lw	s1,36(sp)
	addi	sp,sp,48
	jr	ra
.L208:
	beq	a0,s3,.L214
	lw	a5,12(sp)
	sub	s2,s2,a5
	snez	s2,s2
	add	s1,s1,s2
	j	.L209
	.size	isaforge_tiny_regex_upstream_test_main, .-isaforge_tiny_regex_upstream_test_main
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	tail	isaforge_tiny_regex_upstream_test_main
	.size	benchmark, .-benchmark
	.section	.text.isaforge_tiny_regex_case_count,"ax",@progbits
	.align	2
	.globl	isaforge_tiny_regex_case_count
	.type	isaforge_tiny_regex_case_count, @function
isaforge_tiny_regex_case_count:
	li	a0,76
	ret
	.size	isaforge_tiny_regex_case_count, .-isaforge_tiny_regex_case_count
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	seqz	a0,a0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.bss.ccl_buf.0,"aw",@nobits
	.align	2
	.type	ccl_buf.0, @object
	.size	ccl_buf.0, 40
ccl_buf.0:
	.zero	40
	.section	.bss.re_compiled.1,"aw",@nobits
	.align	2
	.type	re_compiled.1, @object
	.size	re_compiled.1, 240
re_compiled.1:
	.zero	240
	.globl	test_vector
	.section	.rodata.str1.4,"aMS",@progbits,1
	.align	2
.LC18:
	.string	"\\d"
	.align	2
.LC19:
	.string	"5"
	.align	2
.LC20:
	.string	"\\w+"
	.align	2
.LC21:
	.string	"hej"
	.align	2
.LC22:
	.string	"\\s"
	.align	2
.LC23:
	.string	"\t \n"
	.align	2
.LC24:
	.string	"\\S"
	.align	2
.LC25:
	.string	"[\\s]"
	.align	2
.LC26:
	.string	"[\\S]"
	.align	2
.LC27:
	.string	"\\D"
	.align	2
.LC28:
	.string	"\\W+"
	.align	2
.LC29:
	.string	"[0-9]+"
	.align	2
.LC30:
	.string	"12345"
	.align	2
.LC31:
	.string	"[^\\w]"
	.align	2
.LC32:
	.string	"\\"
	.align	2
.LC33:
	.string	"[\\W]"
	.align	2
.LC34:
	.string	"[\\w]"
	.align	2
.LC35:
	.string	"[^\\d]"
	.align	2
.LC36:
	.string	"d"
	.align	2
.LC37:
	.string	"[\\d]"
	.align	2
.LC38:
	.string	"[^\\D]"
	.align	2
.LC39:
	.string	"[\\D]"
	.align	2
.LC40:
	.string	"^.*\\\\.*$"
	.align	2
.LC41:
	.string	"c:\\Tools"
	.align	2
.LC42:
	.string	".?\\w+jsj$"
	.align	2
.LC43:
	.string	"%JxLLcVx8wxrjsj"
	.align	2
.LC44:
	.string	"=KbvUQjsj"
	.align	2
.LC45:
	.string	"^uDnoZjsj"
	.align	2
.LC46:
	.string	"UzZbjsj"
	.align	2
.LC47:
	.string	"\"wjsj"
	.align	2
.LC48:
	.string	"zLa_FTEjsj"
	.align	2
.LC49:
	.string	"\"mw3p8_Ojsj"
	.align	2
.LC50:
	.string	"^[\\+-]*[\\d]+$"
	.align	2
.LC51:
	.string	"+27"
	.align	2
.LC52:
	.string	"[abc]"
	.align	2
.LC53:
	.string	"1c2"
	.align	2
.LC54:
	.string	"1C2"
	.align	2
.LC55:
	.string	"[1-5]+"
	.align	2
.LC56:
	.string	"0123456789"
	.align	2
.LC57:
	.string	"[.2]"
	.align	2
.LC58:
	.string	"a*$"
	.align	2
.LC59:
	.string	"Xaa"
	.align	2
.LC60:
	.string	"[a-h]+"
	.align	2
.LC61:
	.string	"abcdefghxxx"
	.align	2
.LC62:
	.string	"ABCDEFGH"
	.align	2
.LC63:
	.string	"[A-H]+"
	.align	2
.LC64:
	.string	"abcdefgh"
	.align	2
.LC65:
	.string	"[^\\s]+"
	.align	2
.LC66:
	.string	"abc def"
	.align	2
.LC67:
	.string	"[^fc]+"
	.align	2
.LC68:
	.string	"[^d\\sf]+"
	.align	2
.LC69:
	.string	"\n"
	.align	2
.LC70:
	.string	"abc\ndef"
	.align	2
.LC71:
	.string	"b.\\s*\n"
	.align	2
.LC72:
	.base64	"YWENCmJiDQpjYw0KDQoA"
	.align	2
.LC73:
	.string	".*c"
	.align	2
.LC74:
	.string	"abcabc"
	.align	2
.LC75:
	.string	".+c"
	.align	2
.LC76:
	.string	"[b-z].*"
	.align	2
.LC77:
	.string	"ab"
	.align	2
.LC78:
	.string	"b[k-z]*"
	.align	2
.LC79:
	.string	"[0-9]"
	.align	2
.LC80:
	.string	"  - "
	.align	2
.LC81:
	.string	"[^0-9]"
	.align	2
.LC82:
	.string	"0|"
	.align	2
.LC83:
	.string	"\\d\\d:\\d\\d:\\d\\d"
	.align	2
.LC84:
	.string	"0s:00:00"
	.align	2
.LC85:
	.string	"000:00"
	.align	2
.LC86:
	.string	"00:0000"
	.align	2
.LC87:
	.string	"100:0:00"
	.align	2
.LC88:
	.string	"00:100:00"
	.align	2
.LC89:
	.string	"0:00:100"
	.align	2
.LC90:
	.string	"\\d\\d?:\\d\\d?:\\d\\d?"
	.align	2
.LC91:
	.string	"0:0:0"
	.align	2
.LC92:
	.string	"0:00:0"
	.align	2
.LC93:
	.string	"0:0:00"
	.align	2
.LC94:
	.string	"00:0:0"
	.align	2
.LC95:
	.string	"00:00:0"
	.align	2
.LC96:
	.string	"00:0:00"
	.align	2
.LC97:
	.string	"0:00:00"
	.align	2
.LC98:
	.string	"00:00:00"
	.align	2
.LC99:
	.string	"[Hh]ello [Ww]orld\\s*[!]?"
	.align	2
.LC100:
	.string	"Hello world !"
	.align	2
.LC101:
	.string	"hello world !"
	.align	2
.LC102:
	.string	"Hello World !"
	.align	2
.LC103:
	.string	"Hello world!   "
	.align	2
.LC104:
	.string	"Hello world  !"
	.align	2
.LC105:
	.string	"hello World    !"
	.align	2
.LC106:
	.string	"a:0"
	.align	2
.LC107:
	.string	".?bar"
	.align	2
.LC108:
	.string	"real_bar"
	.align	2
.LC109:
	.string	"real_foo"
	.align	2
.LC110:
	.string	"X?Y"
	.align	2
.LC111:
	.string	"Z"
	.align	2
.LC112:
	.string	"[a-z]+\nbreak"
	.align	2
.LC113:
	.string	"blahblah\nbreak"
	.align	2
.LC114:
	.string	"[a-z\\s]+\nbreak"
	.align	2
.LC115:
	.string	"bla bla \nbreak"
	.section	.data.test_vector,"aw"
	.align	2
	.type	test_vector, @object
	.size	test_vector, 1216
test_vector:
	.word	1
	.word	.LC18
	.word	.LC19
	.word	1
	.word	1
	.word	.LC20
	.word	.LC21
	.word	3
	.word	1
	.word	.LC22
	.word	.LC23
	.word	1
	.word	0
	.word	.LC24
	.word	.LC23
	.word	0
	.word	1
	.word	.LC25
	.word	.LC23
	.word	1
	.word	0
	.word	.LC26
	.word	.LC23
	.word	0
	.word	0
	.word	.LC27
	.word	.LC19
	.word	0
	.word	0
	.word	.LC28
	.word	.LC21
	.word	0
	.word	1
	.word	.LC29
	.word	.LC30
	.word	5
	.word	1
	.word	.LC27
	.word	.LC21
	.word	1
	.word	0
	.word	.LC18
	.word	.LC21
	.word	0
	.word	1
	.word	.LC31
	.word	.LC32
	.word	1
	.word	1
	.word	.LC33
	.word	.LC32
	.word	1
	.word	0
	.word	.LC34
	.word	.LC32
	.word	0
	.word	1
	.word	.LC35
	.word	.LC36
	.word	1
	.word	0
	.word	.LC37
	.word	.LC36
	.word	0
	.word	0
	.word	.LC38
	.word	.LC36
	.word	0
	.word	1
	.word	.LC39
	.word	.LC36
	.word	1
	.word	1
	.word	.LC40
	.word	.LC41
	.word	8
	.word	1
	.word	.LC40
	.word	.LC41
	.word	8
	.word	1
	.word	.LC42
	.word	.LC43
	.word	15
	.word	1
	.word	.LC42
	.word	.LC44
	.word	9
	.word	1
	.word	.LC42
	.word	.LC45
	.word	9
	.word	1
	.word	.LC42
	.word	.LC46
	.word	7
	.word	1
	.word	.LC42
	.word	.LC47
	.word	5
	.word	1
	.word	.LC42
	.word	.LC48
	.word	10
	.word	1
	.word	.LC42
	.word	.LC49
	.word	11
	.word	1
	.word	.LC50
	.word	.LC51
	.word	3
	.word	1
	.word	.LC52
	.word	.LC53
	.word	1
	.word	0
	.word	.LC52
	.word	.LC54
	.word	0
	.word	1
	.word	.LC55
	.word	.LC56
	.word	5
	.word	1
	.word	.LC57
	.word	.LC54
	.word	1
	.word	1
	.word	.LC58
	.word	.LC59
	.word	2
	.word	1
	.word	.LC58
	.word	.LC59
	.word	2
	.word	1
	.word	.LC60
	.word	.LC61
	.word	8
	.word	0
	.word	.LC60
	.word	.LC62
	.word	0
	.word	1
	.word	.LC63
	.word	.LC62
	.word	8
	.word	0
	.word	.LC63
	.word	.LC64
	.word	0
	.word	1
	.word	.LC65
	.word	.LC66
	.word	3
	.word	1
	.word	.LC67
	.word	.LC66
	.word	2
	.word	1
	.word	.LC68
	.word	.LC66
	.word	3
	.word	1
	.word	.LC69
	.word	.LC70
	.word	1
	.word	1
	.word	.LC71
	.word	.LC72
	.word	4
	.word	1
	.word	.LC73
	.word	.LC74
	.word	6
	.word	1
	.word	.LC75
	.word	.LC74
	.word	6
	.word	1
	.word	.LC76
	.word	.LC77
	.word	1
	.word	1
	.word	.LC78
	.word	.LC77
	.word	1
	.word	0
	.word	.LC79
	.word	.LC80
	.word	0
	.word	1
	.word	.LC81
	.word	.LC80
	.word	1
	.word	1
	.word	.LC82
	.word	.LC82
	.word	2
	.word	0
	.word	.LC83
	.word	.LC84
	.word	0
	.word	0
	.word	.LC83
	.word	.LC85
	.word	0
	.word	0
	.word	.LC83
	.word	.LC86
	.word	0
	.word	0
	.word	.LC83
	.word	.LC87
	.word	0
	.word	0
	.word	.LC83
	.word	.LC88
	.word	0
	.word	0
	.word	.LC83
	.word	.LC89
	.word	0
	.word	1
	.word	.LC90
	.word	.LC91
	.word	5
	.word	1
	.word	.LC90
	.word	.LC92
	.word	6
	.word	1
	.word	.LC90
	.word	.LC93
	.word	5
	.word	1
	.word	.LC90
	.word	.LC94
	.word	6
	.word	1
	.word	.LC90
	.word	.LC95
	.word	7
	.word	1
	.word	.LC90
	.word	.LC96
	.word	6
	.word	1
	.word	.LC90
	.word	.LC97
	.word	6
	.word	1
	.word	.LC90
	.word	.LC98
	.word	7
	.word	1
	.word	.LC99
	.word	.LC100
	.word	12
	.word	1
	.word	.LC99
	.word	.LC101
	.word	12
	.word	1
	.word	.LC99
	.word	.LC102
	.word	12
	.word	1
	.word	.LC99
	.word	.LC103
	.word	11
	.word	1
	.word	.LC99
	.word	.LC104
	.word	13
	.word	1
	.word	.LC99
	.word	.LC105
	.word	15
	.word	0
	.word	.LC90
	.word	.LC106
	.word	0
	.word	1
	.word	.LC107
	.word	.LC108
	.word	4
	.word	0
	.word	.LC107
	.word	.LC109
	.word	0
	.word	0
	.word	.LC110
	.word	.LC111
	.word	0
	.word	1
	.word	.LC112
	.word	.LC113
	.word	14
	.word	1
	.word	.LC114
	.word	.LC115
	.word	14
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
