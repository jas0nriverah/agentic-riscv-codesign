// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vverification_top__pch.h"

//============================================================
// Constructors

Vverification_top::Vverification_top(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vverification_top__Syms(contextp(), _vcname__, this)}
    , in0{vlSymsp->TOP.in0}
    , in1{vlSymsp->TOP.in1}
    , out_0{vlSymsp->TOP.out_0}
    , out_1{vlSymsp->TOP.out_1}
    , out_2{vlSymsp->TOP.out_2}
    , out_3{vlSymsp->TOP.out_3}
    , out_4{vlSymsp->TOP.out_4}
    , out_5{vlSymsp->TOP.out_5}
    , out_6{vlSymsp->TOP.out_6}
    , out_7{vlSymsp->TOP.out_7}
    , out_8{vlSymsp->TOP.out_8}
    , out_9{vlSymsp->TOP.out_9}
    , out_10{vlSymsp->TOP.out_10}
    , out_11{vlSymsp->TOP.out_11}
    , out_12{vlSymsp->TOP.out_12}
    , out_13{vlSymsp->TOP.out_13}
    , out_14{vlSymsp->TOP.out_14}
    , out_15{vlSymsp->TOP.out_15}
    , out_16{vlSymsp->TOP.out_16}
    , out_17{vlSymsp->TOP.out_17}
    , out_18{vlSymsp->TOP.out_18}
    , out_19{vlSymsp->TOP.out_19}
    , out_20{vlSymsp->TOP.out_20}
    , out_21{vlSymsp->TOP.out_21}
    , out_22{vlSymsp->TOP.out_22}
    , out_23{vlSymsp->TOP.out_23}
    , out_24{vlSymsp->TOP.out_24}
    , out_25{vlSymsp->TOP.out_25}
    , out_26{vlSymsp->TOP.out_26}
    , out_27{vlSymsp->TOP.out_27}
    , out_28{vlSymsp->TOP.out_28}
    , out_29{vlSymsp->TOP.out_29}
    , out_30{vlSymsp->TOP.out_30}
    , out_31{vlSymsp->TOP.out_31}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vverification_top::Vverification_top(const char* _vcname__)
    : Vverification_top(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vverification_top::~Vverification_top() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vverification_top___024root___eval_debug_assertions(Vverification_top___024root* vlSelf);
#endif  // VL_DEBUG
void Vverification_top___024root___eval_static(Vverification_top___024root* vlSelf);
void Vverification_top___024root___eval_initial(Vverification_top___024root* vlSelf);
void Vverification_top___024root___eval_settle(Vverification_top___024root* vlSelf);
void Vverification_top___024root___eval(Vverification_top___024root* vlSelf);

void Vverification_top::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vverification_top::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vverification_top___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vverification_top___024root___eval_static(&(vlSymsp->TOP));
        Vverification_top___024root___eval_initial(&(vlSymsp->TOP));
        Vverification_top___024root___eval_settle(&(vlSymsp->TOP));
        vlSymsp->__Vm_didInit = true;
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vverification_top___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vverification_top::eventsPending() { return false; }

uint64_t Vverification_top::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vverification_top::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vverification_top___024root___eval_final(Vverification_top___024root* vlSelf);

VL_ATTR_COLD void Vverification_top::final() {
    contextp()->executingFinal(true);
    Vverification_top___024root___eval_final(&(vlSymsp->TOP));
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vverification_top::hierName() const { return vlSymsp->name(); }
const char* Vverification_top::modelName() const { return "Vverification_top"; }
unsigned Vverification_top::threads() const { return 1; }
void Vverification_top::prepareClone() const { contextp()->prepareClone(); }
void Vverification_top::atClone() const {
    contextp()->threadPoolpOnClone();
}
