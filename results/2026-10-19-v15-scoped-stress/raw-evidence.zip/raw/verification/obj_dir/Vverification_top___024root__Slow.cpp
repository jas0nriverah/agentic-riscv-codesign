// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vverification_top.h for the primary calling header

#include "Vverification_top__pch.h"

void Vverification_top___024root___ctor_var_reset(Vverification_top___024root* vlSelf);

Vverification_top___024root::Vverification_top___024root(Vverification_top__Syms* symsp, const char* namep)
 {
    vlSymsp = symsp;
    vlNamep = strdup(namep);
    // Reset structure values
    Vverification_top___024root___ctor_var_reset(this);
}

void Vverification_top___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

Vverification_top___024root::~Vverification_top___024root() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}
