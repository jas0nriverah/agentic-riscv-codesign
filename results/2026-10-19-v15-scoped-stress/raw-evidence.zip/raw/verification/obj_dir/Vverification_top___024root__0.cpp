// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vverification_top.h for the primary calling header

#include "Vverification_top__pch.h"

bool Vverification_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 2> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((2U > n));
    return (0U);
}

void Vverification_top___024root___ico_comb__TOP__0(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___ico_comb__TOP__0\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ verification_top__DOT__c26__DOT__stage_n1_2;
    verification_top__DOT__c26__DOT__stage_n1_2 = 0;
    IData/*31:0*/ verification_top__DOT__c25__DOT__stage_n1_2;
    verification_top__DOT__c25__DOT__stage_n1_2 = 0;
    IData/*31:0*/ verification_top__DOT__c24__DOT__n0;
    verification_top__DOT__c24__DOT__n0 = 0;
    IData/*31:0*/ verification_top__DOT__c24__DOT__stage_n1_1;
    verification_top__DOT__c24__DOT__stage_n1_1 = 0;
    IData/*31:0*/ verification_top__DOT__c18__DOT__stage_n1_2;
    verification_top__DOT__c18__DOT__stage_n1_2 = 0;
    IData/*31:0*/ verification_top__DOT__c17__DOT__stage_n1_2;
    verification_top__DOT__c17__DOT__stage_n1_2 = 0;
    IData/*31:0*/ verification_top__DOT__c16__DOT__stage_n1_1;
    verification_top__DOT__c16__DOT__stage_n1_1 = 0;
    IData/*31:0*/ verification_top__DOT__c0__DOT__n0;
    verification_top__DOT__c0__DOT__n0 = 0;
    // Body
    vlSelfRef.out_8 = (vlSelfRef.in1 ^ ((IData)(0x0000001fU) 
                                        * vlSelfRef.in0));
    vlSelfRef.out_9 = (vlSelfRef.in1 ^ ((IData)(0x0000002fU) 
                                        * vlSelfRef.in0));
    vlSelfRef.out_10 = (vlSelfRef.in1 ^ ((IData)(0x0000004fU) 
                                         * vlSelfRef.in0));
    vlSelfRef.out_11 = (vlSelfRef.in1 ^ ((IData)(0x0000005fU) 
                                         * vlSelfRef.in0));
    vlSelfRef.out_12 = (vlSelfRef.in1 ^ ((IData)(0x0000006fU) 
                                         * vlSelfRef.in0));
    vlSelfRef.out_13 = (vlSelfRef.in1 ^ ((IData)(0x0000007fU) 
                                         * vlSelfRef.in0));
    vlSelfRef.out_14 = (vlSelfRef.in1 ^ ((IData)(0x0000008fU) 
                                         * vlSelfRef.in0));
    vlSelfRef.out_15 = (vlSelfRef.in1 ^ ((IData)(0x0000009fU) 
                                         * vlSelfRef.in0));
    verification_top__DOT__c24__DOT__n0 = (vlSelfRef.in0 
                                           & vlSelfRef.in1);
    verification_top__DOT__c0__DOT__n0 = (vlSelfRef.in0 
                                          ^ vlSelfRef.in1);
    vlSelfRef.out_27 = ((((- (IData)((verification_top__DOT__c24__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c24__DOT__n0 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_31 = ((((- (IData)((verification_top__DOT__c24__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000010U) | (verification_top__DOT__c24__DOT__n0 
                                             >> 0x00000010U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    verification_top__DOT__c25__DOT__stage_n1_2 = (
                                                   ((- (IData)(
                                                               (verification_top__DOT__c24__DOT__n0 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c24__DOT__n0 
                                                      >> 4U));
    verification_top__DOT__c24__DOT__stage_n1_1 = (
                                                   ((- (IData)(
                                                               (verification_top__DOT__c24__DOT__n0 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001eU) 
                                                   | (verification_top__DOT__c24__DOT__n0 
                                                      >> 2U));
    vlSelfRef.out_0 = ((IData)(0x0000001fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_1 = ((IData)(0x0000002fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_2 = ((IData)(0x0000004fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_3 = ((IData)(0x0000005fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_4 = ((IData)(0x0000006fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_5 = ((IData)(0x0000007fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_6 = ((IData)(0x0000008fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_7 = ((IData)(0x0000009fU) * verification_top__DOT__c0__DOT__n0);
    vlSelfRef.out_19 = ((((- (IData)((verification_top__DOT__c0__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c0__DOT__n0 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_23 = ((((- (IData)((verification_top__DOT__c0__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000010U) | (verification_top__DOT__c0__DOT__n0 
                                             >> 0x00000010U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    verification_top__DOT__c17__DOT__stage_n1_2 = (
                                                   ((- (IData)(
                                                               (verification_top__DOT__c0__DOT__n0 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c0__DOT__n0 
                                                      >> 4U));
    verification_top__DOT__c16__DOT__stage_n1_1 = (
                                                   ((- (IData)(
                                                               (verification_top__DOT__c0__DOT__n0 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001eU) 
                                                   | (verification_top__DOT__c0__DOT__n0 
                                                      >> 2U));
    vlSelfRef.out_25 = (verification_top__DOT__c25__DOT__stage_n1_2 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_29 = ((((- (IData)((verification_top__DOT__c24__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c25__DOT__stage_n1_2 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_24 = (verification_top__DOT__c24__DOT__stage_n1_1 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_28 = ((((- (IData)((verification_top__DOT__c24__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c24__DOT__stage_n1_1 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    verification_top__DOT__c26__DOT__stage_n1_2 = (
                                                   ((- (IData)(
                                                               (verification_top__DOT__c24__DOT__n0 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c24__DOT__stage_n1_1 
                                                      >> 4U));
    vlSelfRef.out_17 = (verification_top__DOT__c17__DOT__stage_n1_2 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_21 = ((((- (IData)((verification_top__DOT__c0__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c17__DOT__stage_n1_2 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_16 = (verification_top__DOT__c16__DOT__stage_n1_1 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_20 = ((((- (IData)((verification_top__DOT__c0__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c16__DOT__stage_n1_1 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    verification_top__DOT__c18__DOT__stage_n1_2 = (
                                                   ((- (IData)(
                                                               (verification_top__DOT__c0__DOT__n0 
                                                                >> 0x0000001fU))) 
                                                    << 0x0000001cU) 
                                                   | (verification_top__DOT__c16__DOT__stage_n1_1 
                                                      >> 4U));
    vlSelfRef.out_26 = (verification_top__DOT__c26__DOT__stage_n1_2 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_30 = ((((- (IData)((verification_top__DOT__c24__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c26__DOT__stage_n1_2 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_18 = (verification_top__DOT__c18__DOT__stage_n1_2 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
    vlSelfRef.out_22 = ((((- (IData)((verification_top__DOT__c0__DOT__n0 
                                      >> 0x0000001fU))) 
                          << 0x00000018U) | (verification_top__DOT__c18__DOT__stage_n1_2 
                                             >> 8U)) 
                        - (- (IData)((vlSelfRef.in1 
                                      >> 0x0000001fU))));
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vverification_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 2> &triggers, const std::string &tag);
#endif  // VL_DEBUG

bool Vverification_top___024root___eval_phase__ico(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_phase__ico\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__ico
        vlSelfRef.__VicoTriggered[0U] = (QData)((IData)(
                                                        (((vlSelfRef.in1 
                                                           != vlSelfRef.__Vtrigprevexpr___TOP__in1__0) 
                                                          << 1U) 
                                                         | (vlSelfRef.in0 
                                                            != vlSelfRef.__Vtrigprevexpr___TOP__in0__0))));
        vlSelfRef.__Vtrigprevexpr___TOP__in0__0 = vlSelfRef.in0;
        vlSelfRef.__Vtrigprevexpr___TOP__in1__0 = vlSelfRef.in1;
        if (VL_UNLIKELY(((1U & (~ (IData)(vlSelfRef.__VicoDidInit)))))) {
            vlSelfRef.__VicoDidInit = 1U;
            vlSelfRef.__VicoTriggered[0U] = (1ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (2ULL | vlSelfRef.__VicoTriggered[0U]);
        }
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vverification_top___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_ico
            if ((3ULL & vlSelfRef.__VicoTriggered[0U])) {
                Vverification_top___024root___ico_comb__TOP__0(vlSelf);
            }
        }
    }
    return (__VicoExecute);
}

void Vverification_top___024root___eval(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __VicoIterCount;
    // Body
    __VicoIterCount = 0U;
    do {
        if (VL_UNLIKELY(((0x00002710U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vverification_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
            VL_FATAL_MT("/Users/jasonrivera/Documents/Codex/2026-10-11/can-this-run-offline/work/agentic-riscv-codesign/results/2026-10-19-v15-scoped-stress/raw/verification/verification.v", 1, "", "DIDNOTCONVERGE: Input combinational region did not converge after '--converge-limit' of 10000 tries");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        vlSelfRef.__VicoPhaseResult = Vverification_top___024root___eval_phase__ico(vlSelf);
    } while (vlSelfRef.__VicoPhaseResult);
}

#ifdef VL_DEBUG
void Vverification_top___024root___eval_debug_assertions(Vverification_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vverification_top___024root___eval_debug_assertions\n"); );
    Vverification_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
