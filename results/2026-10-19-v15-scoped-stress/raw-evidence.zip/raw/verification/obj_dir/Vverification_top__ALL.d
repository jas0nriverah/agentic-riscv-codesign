Vverification_top__ALL.o: Vverification_top__ALL.cpp \
  Vverification_top.cpp Vverification_top__pch.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_config.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilatedos.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_types.h \
  /opt/homebrew/Cellar/verilator/5.050/share/verilator/include/verilated_funcs.h \
  Vverification_top__Syms.h Vverification_top.h \
  Vverification_top___024root.h Vverification_top___024root__0.cpp \
  Vverification_top___024root__Slow.cpp \
  Vverification_top___024root__0__Slow.cpp \
  Vverification_top__Syms__Slow.cpp
