module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h80008000;
wire [31:0] n1 = n0 + 32'hfffffe3c;
wire [31:0] n2 = in0 + n1;
assign result = n2;
endmodule
