module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h8000d000;
wire [31:0] n1 = n0 + 32'h0000053c;
assign result = n1;
endmodule
