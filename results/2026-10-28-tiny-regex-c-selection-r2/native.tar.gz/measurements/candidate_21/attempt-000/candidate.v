module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + 32'hffffff9c;
wire [31:0] n1 = n0 & 32'h000000ff;
assign result = n1;
endmodule
