module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'hffffffdf;
wire [31:0] n1 = n0 + 32'hffffffbf;
assign result = n1;
endmodule
