	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.warm_caches,"ax",@progbits
	.align	2
	.globl	warm_caches
	.type	warm_caches, @function
warm_caches:
	ret
	.size	warm_caches, .-warm_caches
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-32
	sw	s0,24(sp)
	sw	s1,20(sp)
	sw	ra,28(sp)
	sw	s2,16(sp)
	sw	s3,12(sp)
	addi	s0,sp,32
	mv	t0,sp
	addi	sp,sp,-32
	mv	a6,sp
	addi	sp,sp,-32
	mv	a4,sp
	li	a5,2
	addi	sp,sp,-32
	sw	a5,8(a4)
	li	a5,3
	sw	a5,12(a4)
	li	a5,4
	sw	a5,16(a4)
	li	a5,5
	li	t6,1
	sw	a5,20(a4)
	li	a1,7
	li	a5,6
	sw	a5,24(a4)
	mv	t5,sp
	sw	zero,0(a4)
	sw	t6,4(a4)
	li	a5,0
	li	t1,0
	li	a0,0
	li	t2,28
	mv	s1,a1
.L4:
	bne	a1,t6,.L5
	li	a3,0
.L6:
	add	a7,a4,a3
	lw	a7,0(a7)
	add	a2,a6,a3
	addi	a3,a3,4
	sw	a7,0(a2)
	bne	a3,t2,.L6
	li	a2,0
.L7:
	lw	a3,0(a6)
	bne	a3,zero,.L10
	bge	a0,a2,.L11
	mv	a0,a2
.L11:
	andi	a3,t1,1
	beq	a3,zero,.L12
	neg	a2,a2
.L12:
	add	a5,a5,a2
	addi	t3,a4,4
	addi	a7,t5,4
	mv	a2,a1
.L13:
	lw	a1,0(a4)
	mv	a3,a4
.L16:
	lw	t4,4(a3)
	addi	a3,a3,4
	sw	t4,-4(a3)
	bne	a3,t3,.L16
	sw	a1,0(a3)
	lw	a1,0(a7)
	addi	a1,a1,-1
	sw	a1,0(a7)
	bgt	a1,zero,.L17
	addi	a2,a2,1
	addi	t3,a3,4
	addi	a7,a7,4
	bne	a2,s1,.L13
	li	a4,32768
	add	a5,a5,a4
	li	a3,65536
	mv	sp,t0
	bgeu	a5,a3,.L20
	blt	a0,a4,.L26
.L20:
	li	a0,-1
	j	.L3
.L5:
	addi	a2,a1,-1
	slli	a3,a2,2
	add	a3,t5,a3
	sw	a1,0(a3)
.L19:
	mv	a1,a2
	j	.L4
.L10:
	addi	t4,a3,1
	slli	a3,a3,2
	srai	t4,t4,1
	mv	a7,a6
	add	a3,a3,a6
	li	t3,0
.L8:
	bgt	t4,t3,.L9
	addi	a2,a2,1
	j	.L7
.L9:
	lw	s3,0(a3)
	lw	s2,0(a7)
	addi	t3,t3,1
	sw	s3,0(a7)
	sw	s2,0(a3)
	addi	a7,a7,4
	addi	a3,a3,-4
	j	.L8
.L17:
	addi	t1,t1,1
	j	.L19
.L26:
	slli	a5,a5,15
	or	a0,a5,a0
.L3:
	addi	sp,s0,-32
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	addi	sp,sp,32
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	blt	a0,zero,.L30
	li	a5,-32768
	srli	a4,a0,15
	addi	a5,a5,-228
	add	a4,a4,a5
	slli	a5,a0,17
	srli	a5,a5,17
	addi	a5,a5,-16
	seqz	a4,a4
	seqz	a5,a5
	and	a0,a4,a5
	ret
.L30:
	li	a0,0
	ret
	.size	verify_benchmark, .-verify_benchmark
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
