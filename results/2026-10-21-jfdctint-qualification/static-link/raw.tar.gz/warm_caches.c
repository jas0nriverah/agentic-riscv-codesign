/* Harness compatibility only: upstream BEEBS has no warmup function. */
void warm_caches(int heat) { (void)heat; }
