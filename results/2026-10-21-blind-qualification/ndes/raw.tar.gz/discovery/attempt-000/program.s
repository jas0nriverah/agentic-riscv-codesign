	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.getbit,"ax",@progbits
	.align	2
	.globl	getbit
	.type	getbit, @function
getbit:
	addi	sp,sp,-16
	lui	a5,%hi(bit)
	sw	a0,8(sp)
	sw	a1,12(sp)
	addi	a5,a5,%lo(bit)
	bgt	a2,a3,.L2
	slli	a2,a2,2
	add	a5,a5,a2
	lw	a0,0(a5)
	and	a0,a0,a1
.L5:
	snez	a0,a0
	addi	sp,sp,16
	jr	ra
.L2:
	sub	a2,a2,a3
	slli	a2,a2,2
	add	a5,a5,a2
	lw	a5,0(a5)
	and	a0,a5,a0
	j	.L5
	.size	getbit, .-getbit
	.section	.text.ks,"ax",@progbits
	.align	2
	.globl	ks
	.type	ks, @function
ks:
	addi	sp,sp,-32
	sw	s0,24(sp)
	lui	s0,%hi(icd)
	addi	s0,s0,%lo(icd)
	lw	a6,4(s0)
	sw	s1,20(sp)
	mv	s1,a1
	lw	a1,0(s0)
	slli	a4,a6,28
	li	a2,268435456
	and	a4,a4,a2
	sw	ra,28(sp)
	sw	s2,16(sp)
	sw	s3,12(sp)
	sw	s4,8(sp)
	sw	s5,4(sp)
	sw	s6,0(sp)
	li	a3,16
	slli	a5,a1,28
	or	a4,a4,a6
	bgtu	a0,a3,.L7
	li	a3,65536
	addi	a3,a3,518
	srl	a3,a3,a0
	andi	a3,a3,1
	beq	a3,zero,.L7
	and	a5,a5,a2
	srli	a3,a4,1
	or	a5,a5,a1
.L15:
	lui	s6,%hi(ipc2)
	srli	a5,a5,1
	addi	s6,s6,%lo(ipc2)
	sw	a3,4(s0)
	sw	a5,0(s0)
	sw	zero,0(s1)
	sw	zero,4(s1)
	sw	zero,8(s1)
	addi	s2,s6,16
	li	s3,0
	li	s4,0
	li	s5,0
.L9:
	lbu	a2,0(s2)
	lw	a1,4(s0)
	lw	a0,0(s0)
	li	a3,28
	slli	s5,s5,1
	call	getbit
	or	s5,s5,a0
	sw	s5,8(s1)
	lbu	a2,16(s2)
	lw	a1,4(s0)
	lw	a0,0(s0)
	li	a3,28
	slli	s4,s4,1
	call	getbit
	or	s4,s4,a0
	sw	s4,4(s1)
	lbu	a2,32(s2)
	lw	a0,0(s0)
	lw	a1,4(s0)
	li	a3,28
	slli	s3,s3,1
	call	getbit
	or	s3,s3,a0
	sw	s3,0(s1)
	addi	s2,s2,-1
	bne	s2,s6,.L9
	lw	ra,28(sp)
	lw	s0,24(sp)
	lw	s1,20(sp)
	lw	s2,16(sp)
	lw	s3,12(sp)
	lw	s4,8(sp)
	lw	s5,4(sp)
	lw	s6,0(sp)
	addi	sp,sp,32
	jr	ra
.L7:
	srli	a4,a4,1
	and	a5,a5,a2
	slli	a3,a4,28
	or	a5,a5,a1
	srli	a5,a5,1
	and	a3,a3,a2
	or	a3,a3,a4
	slli	a4,a5,28
	and	a4,a4,a2
	srli	a3,a3,1
	or	a5,a4,a5
	j	.L15
	.size	ks, .-ks
	.section	.text.cyfun,"ax",@progbits
	.align	2
	.globl	cyfun
	.type	cyfun, @function
cyfun:
	lui	t3,%hi(iet.3)
	addi	t3,t3,%lo(iet.3)
	lui	a6,%hi(bit)
	addi	sp,sp,-16
	addi	a7,t3,64
	li	a5,0
	li	a3,0
	li	a4,0
	addi	a6,a6,%lo(bit)
.L17:
	lw	t1,0(a7)
	slli	a4,a4,1
	slli	a3,a3,1
	slli	t1,t1,2
	add	t1,t1,a6
	lw	t1,0(t1)
	slli	a5,a5,1
	addi	a7,a7,-4
	and	t1,a0,t1
	snez	t1,t1
	or	a4,t1,a4
	lw	t1,68(a7)
	slli	t1,t1,2
	add	t1,t1,a6
	lw	t1,0(t1)
	and	t1,a0,t1
	snez	t1,t1
	or	a3,t1,a3
	lw	t1,132(a7)
	slli	t1,t1,2
	add	t1,t1,a6
	lw	t1,0(t1)
	and	t1,a0,t1
	snez	t1,t1
	or	a5,t1,a5
	bne	t3,a7,.L17
	lw	a0,4(a1)
	xor	a3,a3,a0
	lw	a0,8(a1)
	lw	a1,0(a1)
	xor	a4,a4,a0
	xor	a5,a5,a1
	slli	a0,a3,16
	slli	a5,a5,8
	srli	a3,a3,8
	add	a5,a5,a3
	addi	a3,sp,4
	add	a4,a4,a0
	addi	a1,sp,8
	mv	a7,a3
.L18:
	andi	a0,a4,63
	sb	a0,1(a3)
	andi	a0,a5,63
	sb	a0,5(a3)
	addi	a3,a3,1
	srli	a4,a4,6
	srli	a5,a5,6
	bne	a1,a3,.L18
	lui	t1,%hi(ibin.1)
	lui	t3,%hi(is.2)
	li	a0,8
	li	a3,0
	addi	t1,t1,%lo(ibin.1)
	addi	t3,t3,%lo(is.2)
.L19:
	add	a5,a7,a0
	lbu	a4,0(a5)
	slli	a1,a3,4
	srai	a5,a4,5
	slli	a3,a4,1
	andi	a5,a5,1
	andi	a3,a3,2
	or	a3,a3,a5
	slli	a5,a4,2
	andi	t4,a4,4
	andi	a5,a5,8
	or	a5,a5,t4
	srai	t4,a4,2
	andi	t4,t4,2
	srai	a4,a4,4
	andi	a4,a4,1
	add	a5,a5,t4
	add	a5,a5,a4
	slli	a4,a3,3
	add	a4,a4,a3
	slli	a3,a5,3
	add	a5,a3,a5
	slli	a5,a5,2
	add	a5,a4,a5
	add	a5,t3,a5
	add	a5,a5,a0
	lbu	a5,0(a5)
	addi	a0,a0,-1
	add	a5,t1,a5
	lbu	a5,0(a5)
	or	a3,a5,a1
	bne	a0,zero,.L19
	lui	a0,%hi(ipp.0)
	addi	a0,a0,%lo(ipp.0)
	sw	zero,0(a2)
	addi	a1,a0,128
	li	a5,0
.L20:
	lw	a4,0(a1)
	slli	a5,a5,1
	addi	a1,a1,-4
	slli	a4,a4,2
	add	a4,a6,a4
	lw	a4,0(a4)
	and	a4,a3,a4
	snez	a4,a4
	or	a5,a4,a5
	sw	a5,0(a2)
	bne	a0,a1,.L20
	addi	sp,sp,16
	jr	ra
	.size	cyfun, .-cyfun
	.section	.text.des,"ax",@progbits
	.align	2
	.globl	des
	.type	des, @function
des:
	addi	sp,sp,-112
	sw	s8,72(sp)
	mv	s8,a5
	lui	a5,%hi(initflag.7)
	sw	a3,20(sp)
	lw	a3,%lo(initflag.7)(a5)
	sw	s3,92(sp)
	sw	ra,108(sp)
	sw	s0,104(sp)
	sw	s1,100(sp)
	sw	s2,96(sp)
	sw	s4,88(sp)
	sw	s5,84(sp)
	sw	s6,80(sp)
	sw	s7,76(sp)
	sw	a0,24(sp)
	sw	a1,28(sp)
	sw	a2,16(sp)
	mv	s3,a6
	bne	a3,zero,.L27
.L31:
	lw	a5,0(a4)
	bne	a5,zero,.L28
.L29:
	lui	s4,%hi(ip.5)
	addi	s4,s4,%lo(ip.5)
	addi	s1,s4,32
	li	s0,0
	li	s2,0
.L32:
	lbu	a2,0(s1)
	lw	a1,28(sp)
	lw	a0,24(sp)
	li	a3,32
	slli	s2,s2,1
	call	getbit
	lbu	a2,32(s1)
	lw	a1,28(sp)
	or	s2,s2,a0
	lw	a0,24(sp)
	li	a3,32
	slli	s0,s0,1
	call	getbit
	addi	s1,s1,-1
	or	s0,s0,a0
	bne	s1,s4,.L32
	li	s1,1
	lui	s5,%hi(kns.6)
	mv	s7,s1
	li	s6,17
	addi	s5,s5,%lo(kns.6)
.L36:
	mv	a5,s1
	bne	s8,s7,.L35
	sub	a5,s6,s1
.L35:
	slli	a1,a5,1
	add	a1,a1,a5
	slli	a1,a1,2
	li	a2,12
	add	a1,s5,a1
	mv	a0,sp
	call	memcpy
	addi	a2,sp,40
	mv	a1,sp
	mv	a0,s0
	call	cyfun
	lw	s4,40(sp)
	addi	s1,s1,1
	xor	s4,s2,s4
	mv	s2,s0
	bne	s1,s6,.L39
	lui	s6,%hi(ipm.4)
	addi	s6,s6,%lo(ipm.4)
	sw	zero,0(s3)
	sw	zero,4(s3)
	addi	s1,s6,32
	li	s2,0
	li	s5,0
.L37:
	lbu	a2,0(s1)
	li	a3,32
	mv	a1,s4
	mv	a0,s0
	call	getbit
	slli	s5,s5,1
	or	s5,s5,a0
	sw	s5,4(s3)
	lbu	a2,32(s1)
	li	a3,32
	mv	a0,s0
	mv	a1,s4
	call	getbit
	slli	s2,s2,1
	or	s2,s2,a0
	sw	s2,0(s3)
	addi	s1,s1,-1
	bne	s6,s1,.L37
	lw	ra,108(sp)
	lw	s0,104(sp)
	lw	s1,100(sp)
	lw	s2,96(sp)
	lw	s3,92(sp)
	lw	s4,88(sp)
	lw	s5,84(sp)
	lw	s6,80(sp)
	lw	s7,76(sp)
	lw	s8,72(sp)
	addi	sp,sp,112
	jr	ra
.L27:
	sw	zero,%lo(initflag.7)(a5)
	lui	a5,%hi(bit)
	addi	a5,a5,%lo(bit)
	li	a3,1
	sw	a3,4(a5)
	addi	a2,a5,124
.L30:
	slli	a3,a3,1
	sw	a3,8(a5)
	addi	a5,a5,4
	bne	a5,a2,.L30
	j	.L31
.L28:
	lui	s4,%hi(ipc1)
	addi	s4,s4,%lo(ipc1)
	lui	s5,%hi(icd)
	sw	zero,0(a4)
	addi	s0,s4,28
	li	s1,0
	li	s2,0
	addi	s5,s5,%lo(icd)
.L33:
	lbu	a2,0(s0)
	lw	a1,20(sp)
	lw	a0,16(sp)
	li	a3,32
	slli	s2,s2,1
	call	getbit
	lbu	a2,28(s0)
	or	s2,s2,a0
	lw	a1,20(sp)
	lw	a0,16(sp)
	li	a3,32
	sw	s2,4(s5)
	slli	s1,s1,1
	call	getbit
	or	s1,s1,a0
	sw	s1,0(s5)
	addi	s0,s0,-1
	bne	s0,s4,.L33
	lui	a5,%hi(kns.6)
	addi	s0,a5,%lo(kns.6)
	li	s1,1
	li	s2,17
.L34:
	mv	a0,s1
	addi	a1,sp,52
	call	ks
	addi	s0,s0,12
	li	a2,12
	addi	a1,sp,52
	mv	a0,s0
	addi	s1,s1,1
	call	memcpy
	bne	s1,s2,.L34
	j	.L29
.L39:
	mv	s0,s4
	j	.L36
	.size	des, .-des
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	lui	a3,%hi(key)
	lui	a1,%hi(inp)
	addi	a3,a3,%lo(key)
	addi	a1,a1,%lo(inp)
	lui	a5,%hi(isw)
	lw	a0,0(a1)
	lw	a2,0(a3)
	lw	a5,%lo(isw)(a5)
	lw	a3,4(a3)
	lw	a1,4(a1)
	lui	a6,%hi(out)
	lui	a4,%hi(newkey)
	addi	sp,sp,-16
	addi	a6,a6,%lo(out)
	addi	a4,a4,%lo(newkey)
	sw	ra,12(sp)
	call	des
	lw	ra,12(sp)
	li	a0,0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	lui	a5,%hi(inp)
	addi	a5,a5,%lo(inp)
	li	a4,35
	sw	a4,0(a5)
	li	a4,26
	sw	a4,4(a5)
	lui	a5,%hi(key)
	addi	a5,a5,%lo(key)
	li	a4,2
	sw	a4,0(a5)
	li	a4,16
	sw	a4,4(a5)
	lui	a5,%hi(value)
	lw	a5,%lo(value)(a5)
	lui	a4,%hi(newkey)
	sw	a5,%lo(newkey)(a4)
	lui	a4,%hi(isw)
	sw	a5,%lo(isw)(a4)
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	lui	a5,%hi(out)
	addi	a5,a5,%lo(out)
	lw	a3,0(a5)
	li	a4,-1805377536
	addi	a4,a4,-1867
	li	a0,0
	bne	a3,a4,.L49
	lw	a0,4(a5)
	li	a5,-1806503936
	addi	a5,a5,188
	add	a0,a0,a5
	seqz	a0,a0
.L49:
	ret
	.size	verify_benchmark, .-verify_benchmark
	.section	.rodata.ipp.0,"a"
	.align	2
	.type	ipp.0, @object
	.size	ipp.0, 132
ipp.0:
	.word	0
	.word	16
	.word	7
	.word	20
	.word	21
	.word	29
	.word	12
	.word	28
	.word	17
	.word	1
	.word	15
	.word	23
	.word	26
	.word	5
	.word	18
	.word	31
	.word	10
	.word	2
	.word	8
	.word	24
	.word	14
	.word	32
	.word	27
	.word	3
	.word	9
	.word	19
	.word	13
	.word	30
	.word	6
	.word	22
	.word	11
	.word	4
	.word	25
	.section	.rodata.ibin.1,"a"
	.align	2
	.type	ibin.1, @object
	.size	ibin.1, 16
ibin.1:
	.base64	"AAgEDAIKBg4BCQUNAwsHDw=="
	.section	.rodata.is.2,"a"
	.align	2
	.type	is.2, @object
	.size	is.2, 576
is.2:
	.base64	"AA4PCgcCDAQN"
	.base64	"AAADDQ0OCg0B"
	.base64	"AAQADQoECQEH"
	.base64	"AA8NAQMLBAYC"
	.base64	"AAQBAA0MAQsC"
	.base64	"AA8NBwgLDwAP"
	.base64	"AAEOBgYCDgQL"
	.base64	"AAwICg8IAwsB"
	.base64	"AA0ICQ4ECgII"
	.base64	"AAcEAAsCBAsN"
	.base64	"AA4HBAkBDwsE"
	.base64	"AAgKDQAMAg0O"
	.base64	"AAEODgMBDw4E"
	.base64	"AAQHCQUMAgcI"
	.base64	"AAgLCQALBQ0B"
	.base64	"AAIBAAYHDAgH"
	.base64	"AAIGBgAHCQ8G"
	.base64	"AA4PAwYEBwQK"
	.base64	"AA0KCAwKAgwJ"
	.base64	"AAQDBgoBCQEE"
	.base64	"AA8LAwYKAgAP"
	.base64	"AAICBA8HDAkD"
	.base64	"AAYEDwsNCAMM"
	.base64	"AAkPCQEOBQQK"
	.base64	"AAsDDwkLBggL"
	.base64	"AA0IBgANCQEH"
	.base64	"AAINAwcHDAcO"
	.base64	"AAEECA0CDwoI"
	.base64	"AAgEBQoGCA0B"
	.base64	"AAEOCgMBBQoE"
	.base64	"AAsBAA0IAw4C"
	.base64	"AAcCBwgNCgcN"
	.base64	"AAMJAQEIAAMK"
	.base64	"AAoMAgQFBg4M"
	.base64	"AA8FCw8PBwoA"
	.base64	"AAULBAkGCwkP"
	.base64	"AAoHDQIFDQwJ"
	.base64	"AAYACAcAAQMF"
	.base64	"AAwIAQEJAA8G"
	.base64	"AAsGDwQPDgUM"
	.base64	"AAYCDAgDAwkD"
	.base64	"AAwBBQIPDQUG"
	.base64	"AAkMAgMMBAYK"
	.base64	"AAMHDgUAAQAJ"
	.base64	"AAwNBwUPBAcO"
	.base64	"AAsKDgwKDgwL"
	.base64	"AAcGDA4FCggN"
	.base64	"AA4MAwsJBw8A"
	.base64	"AAUMCwsNDgUF"
	.base64	"AAkGDAEDAAIA"
	.base64	"AAMJBQUGAQAP"
	.base64	"AAoACwwKBg4D"
	.base64	"AAkABAwABwoA"
	.base64	"AAUJCwoJCw8O"
	.base64	"AAoDCgIDDQUD"
	.base64	"AAAFBQcEAAIF"
	.base64	"AAAFAgQOBQYM"
	.base64	"AAMLDw4IAwgJ"
	.base64	"AAUCDggACwkF"
	.base64	"AAYOAgIFCAMG"
	.base64	"AAcKCA8JCwEH"
	.base64	"AAgFAQkGCAYC"
	.base64	"AAAPBwQOBgII"
	.base64	"AA0JDA4DDQwL"
	.section	.rodata.iet.3,"a"
	.align	2
	.type	iet.3, @object
	.size	iet.3, 196
iet.3:
	.word	0
	.word	32
	.word	1
	.word	2
	.word	3
	.word	4
	.word	5
	.word	4
	.word	5
	.word	6
	.word	7
	.word	8
	.word	9
	.word	8
	.word	9
	.word	10
	.word	11
	.word	12
	.word	13
	.word	12
	.word	13
	.word	14
	.word	15
	.word	16
	.word	17
	.word	16
	.word	17
	.word	18
	.word	19
	.word	20
	.word	21
	.word	20
	.word	21
	.word	22
	.word	23
	.word	24
	.word	25
	.word	24
	.word	25
	.word	26
	.word	27
	.word	28
	.word	29
	.word	28
	.word	29
	.word	30
	.word	31
	.word	32
	.word	1
	.section	.rodata.ipm.4,"a"
	.align	2
	.type	ipm.4, @object
	.size	ipm.4, 65
ipm.4:
	.base64	"ACgIMBA4GEAgJwcvDzcXPx8mBi4ONhY+HiUFLQ01FT0dJAQsDDQUPBwjAysLMxM7GyICKgoyEjoaIQEpCTERORk="
	.section	.rodata.ip.5,"a"
	.align	2
	.type	ip.5, @object
	.size	ip.5, 65
ip.5:
	.base64	"ADoyKiIaEgoCPDQsJBwUDAQ+Ni4mHhYOBkA4MCggGBAIOTEpIRkRCQE7MysjGxMLAz01LSUdFQ0FPzcvJx8XDwc="
	.section	.bss.kns.6,"aw",@nobits
	.align	2
	.type	kns.6, @object
	.size	kns.6, 204
kns.6:
	.zero	204
	.section	.data.initflag.7,"aw"
	.align	2
	.type	initflag.7, @object
	.size	initflag.7, 4
initflag.7:
	.word	1
	.section	.bss.isw,"aw",@nobits
	.align	2
	.type	isw, @object
	.size	isw, 4
isw:
	.zero	4
	.section	.bss.newkey,"aw",@nobits
	.align	2
	.type	newkey, @object
	.size	newkey, 4
newkey:
	.zero	4
	.section	.bss.key,"aw",@nobits
	.align	2
	.type	key, @object
	.size	key, 8
key:
	.zero	8
	.section	.bss.inp,"aw",@nobits
	.align	2
	.type	inp, @object
	.size	inp, 8
inp:
	.zero	8
	.globl	out
	.section	.bss.out,"aw",@nobits
	.align	2
	.type	out, @object
	.size	out, 8
out:
	.zero	8
	.globl	value
	.section	.data.value,"aw"
	.align	2
	.type	value, @object
	.size	value, 4
value:
	.word	1
	.section	.rodata.ipc2,"a"
	.align	2
	.type	ipc2, @object
	.size	ipc2, 49
ipc2:
	.base64	"AA4RCxgBBQMcDwYVChcTDAQaCBAHGxQNAik0HyUvNx4oMy0hMCwxJzgiNS4qMiQdIA=="
	.section	.rodata.ipc1,"a"
	.align	2
	.type	ipc1, @object
	.size	ipc1, 57
ipc1:
	.base64	"ADkxKSEZEQkBOjIqIhoSCgI7MysjGxMLAzw0LCQ/Ny8nHxcPBz42LiYeFg4GPTUtJR0VDQUcFAwE"
	.section	.bss.icd,"aw",@nobits
	.align	2
	.type	icd, @object
	.size	icd, 8
icd:
	.zero	8
	.globl	bit
	.section	.bss.bit,"aw",@nobits
	.align	2
	.type	bit, @object
	.size	bit, 132
bit:
	.zero	132
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
