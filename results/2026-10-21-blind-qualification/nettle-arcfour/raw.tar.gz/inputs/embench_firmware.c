// Workload-independent Embench harness on the existing serial-report SoC.
#include <stdint.h>
extern void initialise_benchmark(void), warm_caches(int);
extern int benchmark(void), verify_benchmark(int);
static inline uint32_t cycles(void) {
    uint32_t v; __asm__ volatile("rdcycle %0" : "=r"(v) :: "memory"); return v;
}
static inline uint32_t instructions(void) {
    uint32_t v; __asm__ volatile("rdinstret %0" : "=r"(v) :: "memory"); return v;
}

/* Independent fixed ciphertext check, outside the benchmark counters.
 * Same upstream key/plaintext; expected bytes come from the separately
 * recorded byte-oriented Python RC4 reference, not this C implementation.
 */
struct arcfour_ctx { unsigned char S[256], i, j; };
extern void arcfour_set_key(struct arcfour_ctx *, int, const unsigned char *);
extern void arcfour_crypt(struct arcfour_ctx *, int, unsigned char *, const unsigned char *);
static int isaforge_arcfour_check(void) {
    struct arcfour_ctx ctx;
    const unsigned char key[16] = {15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0};
    const unsigned char plain[16] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
    const unsigned char expected[16] = {0x08,0x47,0x73,0xcb,0x87,0x5b,0xee,0xfe,0x01,0xa1,0xbe,0x84,0x71,0xdf,0x1b,0xbc};
    unsigned char output[16];
    arcfour_set_key(&ctx, 16, key);
    arcfour_crypt(&ctx, 16, output, plain);
    for (unsigned i = 0; i < 16; ++i) if (output[i] != expected[i]) return 0;
    return 1;
}

int main(void) {
    initialise_benchmark();
    warm_caches(1);
    uint32_t i0=instructions(), c0=cycles();
    int result=benchmark();
    uint32_t c1=cycles(), i1=instructions();
    int correct=verify_benchmark(result);
    if (!isaforge_arcfour_check()) correct=0;
    volatile uint32_t *out=(volatile uint32_t *)0x10000000;
    *out=0x49534146; *out=(uint32_t)result; *out=c1-c0; *out=i1-i0; *out=correct;
    *(volatile uint32_t *)0x10000004=correct ? 0x600d600d : 0xdead0003;
    return 0;
}

/* BEEBS ABI adapter only: upstream has no warmup entrypoint. */
void warm_caches(int heat) { (void)heat; }
