	.file	"program.c"
	.option nopic
	.option norelax
	.attribute arch, "rv32i2p1_zicsr2p0"
	.attribute unaligned_access, 0
	.attribute stack_align, 16
	.text
	.section	.text.arcfour_set_key,"ax",@progbits
	.align	2
	.globl	arcfour_set_key
	.type	arcfour_set_key, @function
arcfour_set_key:
	addi	sp,sp,-48
	sw	s0,40(sp)
	sw	ra,44(sp)
	sw	s1,36(sp)
	sw	s2,32(sp)
	sw	s3,28(sp)
	mv	s0,a0
	li	a5,0
	li	a4,256
.L2:
	add	a3,s0,a5
	sb	a5,0(a3)
	addi	a5,a5,1
	bne	a5,a4,.L2
	mv	s1,s0
	addi	s3,s0,256
	li	a0,0
	li	s2,0
.L3:
	add	a5,a2,a0
	lbu	a4,0(s1)
	lbu	a5,0(a5)
	addi	a0,a0,1
	sw	a2,12(sp)
	add	a5,a5,a4
	add	s2,a5,s2
	andi	s2,s2,255
	add	a5,s0,s2
	lbu	a3,0(a5)
	sw	a1,8(sp)
	addi	s1,s1,1
	sb	a3,-1(s1)
	sb	a4,0(a5)
	call	__umodsi3
	lw	a1,8(sp)
	lw	a2,12(sp)
	bne	s3,s1,.L3
	sb	zero,257(s0)
	sb	zero,256(s0)
	lw	ra,44(sp)
	lw	s0,40(sp)
	lw	s1,36(sp)
	lw	s2,32(sp)
	lw	s3,28(sp)
	addi	sp,sp,48
	jr	ra
	.size	arcfour_set_key, .-arcfour_set_key
	.section	.text.arcfour_crypt,"ax",@progbits
	.align	2
	.globl	arcfour_crypt
	.type	arcfour_crypt, @function
arcfour_crypt:
	lbu	t1,256(a0)
	lbu	a6,257(a0)
	li	a4,0
	addi	t5,t1,1
.L8:
	bne	a4,a1,.L9
	add	t1,t1,a4
	sb	t1,256(a0)
	sb	a6,257(a0)
	ret
.L9:
	add	a7,t5,a4
	andi	a7,a7,0xff
	add	a7,a0,a7
	lbu	a5,0(a7)
	add	a6,a5,a6
	andi	a6,a6,0xff
	add	t4,a0,a6
	lbu	t3,0(t4)
	sb	t3,0(a7)
	sb	a5,0(t4)
	add	a5,a5,t3
	andi	a5,a5,0xff
	add	a7,a3,a4
	add	a5,a0,a5
	lbu	a7,0(a7)
	lbu	a5,0(a5)
	add	t4,a2,a4
	addi	a4,a4,1
	xor	a5,a7,a5
	sb	a5,0(t4)
	j	.L8
	.size	arcfour_crypt, .-arcfour_crypt
	.section	.text.initialise_benchmark,"ax",@progbits
	.align	2
	.globl	initialise_benchmark
	.type	initialise_benchmark, @function
initialise_benchmark:
	ret
	.size	initialise_benchmark, .-initialise_benchmark
	.section	.text.benchmark,"ax",@progbits
	.align	2
	.globl	benchmark
	.type	benchmark, @function
benchmark:
	addi	sp,sp,-16
	sw	s0,8(sp)
	sw	s2,0(sp)
	lui	s0,%hi(arcfour_ctx)
	lui	s2,%hi(key)
	addi	a2,s2,%lo(key)
	addi	a0,s0,%lo(arcfour_ctx)
	li	a1,16
	sw	ra,12(sp)
	sw	s1,4(sp)
	call	arcfour_set_key
	lui	s1,%hi(result)
	lui	a3,%hi(data)
	addi	a3,a3,%lo(data)
	addi	a2,s1,%lo(result)
	addi	a0,s0,%lo(arcfour_ctx)
	li	a1,16
	call	arcfour_crypt
	addi	a2,s2,%lo(key)
	addi	a0,s0,%lo(arcfour_ctx)
	li	a1,16
	call	arcfour_set_key
	addi	a3,s1,%lo(result)
	addi	a0,s0,%lo(arcfour_ctx)
	mv	a2,a3
	li	a1,16
	call	arcfour_crypt
	lw	ra,12(sp)
	lw	s0,8(sp)
	lw	s1,4(sp)
	lw	s2,0(sp)
	li	a0,0
	addi	sp,sp,16
	jr	ra
	.size	benchmark, .-benchmark
	.section	.text.verify_benchmark,"ax",@progbits
	.align	2
	.globl	verify_benchmark
	.type	verify_benchmark, @function
verify_benchmark:
	addi	sp,sp,-80
	lui	a1,%hi(.LANCHOR0)
	li	a2,64
	addi	a1,a1,%lo(.LANCHOR0)
	mv	a0,sp
	sw	ra,76(sp)
	call	memcpy
	lui	a3,%hi(result)
	mv	a5,sp
	li	a4,0
	addi	a3,a3,%lo(result)
	li	a2,16
.L15:
	add	a1,a4,a3
	lbu	a0,0(a1)
	lw	a1,0(a5)
	bne	a0,a1,.L16
	addi	a4,a4,1
	addi	a5,a5,4
	bne	a4,a2,.L15
	li	a0,1
.L13:
	lw	ra,76(sp)
	addi	sp,sp,80
	jr	ra
.L16:
	li	a0,0
	j	.L13
	.size	verify_benchmark, .-verify_benchmark
	.globl	arcfour_ctx
	.section	.bss.arcfour_ctx,"aw",@nobits
	.align	2
	.type	arcfour_ctx, @object
	.size	arcfour_ctx, 258
arcfour_ctx:
	.zero	258
	.section	.bss.result,"aw",@nobits
	.align	2
	.type	result, @object
	.size	result, 16
result:
	.zero	16
	.section	.rodata.data,"a"
	.align	2
	.type	data, @object
	.size	data, 16
data:
	.base64	"AAECAwQFBgcICQoLDA0ODw=="
	.section	.rodata.key,"a"
	.align	2
	.type	key, @object
	.size	key, 16
key:
	.base64	"Dw4NDAsKCQgHBgUEAwIBAA=="
	.section	.rodata
	.align	2
	.set	.LANCHOR0,. + 0
.LC0:
	.word	0
	.word	1
	.word	2
	.word	3
	.word	4
	.word	5
	.word	6
	.word	7
	.word	8
	.word	9
	.word	10
	.word	11
	.word	12
	.word	13
	.word	14
	.word	15
	.globl	__umodsi3
	.ident	"GCC: (xPack GNU RISC-V Embedded GCC arm64) 15.2.0"
	.section	.note.GNU-stack,"",@progbits
