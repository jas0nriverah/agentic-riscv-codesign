module verification_top(input wire [31:0] in0, in1, output wire [31:0] out_0, output wire [31:0] out_1, output wire [31:0] out_2, output wire [31:0] out_3, output wire [31:0] out_4, output wire [31:0] out_5, output wire [31:0] out_6, output wire [31:0] out_7, output wire [31:0] out_8, output wire [31:0] out_9, output wire [31:0] out_10, output wire [31:0] out_11, output wire [31:0] out_12, output wire [31:0] out_13, output wire [31:0] out_14, output wire [31:0] out_15, output wire [31:0] out_16, output wire [31:0] out_17, output wire [31:0] out_18, output wire [31:0] out_19, output wire [31:0] out_20, output wire [31:0] out_21, output wire [31:0] out_22, output wire [31:0] out_23, output wire [31:0] out_24, output wire [31:0] out_25, output wire [31:0] out_26, output wire [31:0] out_27, output wire [31:0] out_28, output wire [31:0] out_29, output wire [31:0] out_30, output wire [31:0] out_31, output wire [31:0] out_32, output wire [31:0] out_33, output wire [31:0] out_34, output wire [31:0] out_35, output wire [31:0] out_36, output wire [31:0] out_37, output wire [31:0] out_38, output wire [31:0] out_39, output wire [31:0] out_40, output wire [31:0] out_41, output wire [31:0] out_42, output wire [31:0] out_43, output wire [31:0] out_44, output wire [31:0] out_45, output wire [31:0] out_46, output wire [31:0] out_47);
candidate_0 c0(.in0(in0), .in1(in1), .result(out_0));
candidate_1 c1(.in0(in0), .in1(in1), .result(out_1));
candidate_2 c2(.in0(in0), .in1(in1), .result(out_2));
candidate_3 c3(.in0(in0), .in1(in1), .result(out_3));
candidate_4 c4(.in0(in0), .in1(in1), .result(out_4));
candidate_5 c5(.in0(in0), .in1(in1), .result(out_5));
candidate_6 c6(.in0(in0), .in1(in1), .result(out_6));
candidate_7 c7(.in0(in0), .in1(in1), .result(out_7));
candidate_8 c8(.in0(in0), .in1(in1), .result(out_8));
candidate_9 c9(.in0(in0), .in1(in1), .result(out_9));
candidate_10 c10(.in0(in0), .in1(in1), .result(out_10));
candidate_11 c11(.in0(in0), .in1(in1), .result(out_11));
candidate_12 c12(.in0(in0), .in1(in1), .result(out_12));
candidate_13 c13(.in0(in0), .in1(in1), .result(out_13));
candidate_14 c14(.in0(in0), .in1(in1), .result(out_14));
candidate_15 c15(.in0(in0), .in1(in1), .result(out_15));
candidate_16 c16(.in0(in0), .in1(in1), .result(out_16));
candidate_17 c17(.in0(in0), .in1(in1), .result(out_17));
candidate_18 c18(.in0(in0), .in1(in1), .result(out_18));
candidate_19 c19(.in0(in0), .in1(in1), .result(out_19));
candidate_20 c20(.in0(in0), .in1(in1), .result(out_20));
candidate_21 c21(.in0(in0), .in1(in1), .result(out_21));
candidate_22 c22(.in0(in0), .in1(in1), .result(out_22));
candidate_23 c23(.in0(in0), .in1(in1), .result(out_23));
candidate_24 c24(.in0(in0), .in1(in1), .result(out_24));
candidate_25 c25(.in0(in0), .in1(in1), .result(out_25));
candidate_26 c26(.in0(in0), .in1(in1), .result(out_26));
candidate_27 c27(.in0(in0), .in1(in1), .result(out_27));
candidate_28 c28(.in0(in0), .in1(in1), .result(out_28));
candidate_29 c29(.in0(in0), .in1(in1), .result(out_29));
candidate_30 c30(.in0(in0), .in1(in1), .result(out_30));
candidate_31 c31(.in0(in0), .in1(in1), .result(out_31));
candidate_32 c32(.in0(in0), .in1(in1), .result(out_32));
candidate_33 c33(.in0(in0), .in1(in1), .result(out_33));
candidate_34 c34(.in0(in0), .in1(in1), .result(out_34));
candidate_35 c35(.in0(in0), .in1(in1), .result(out_35));
candidate_36 c36(.in0(in0), .in1(in1), .result(out_36));
candidate_37 c37(.in0(in0), .in1(in1), .result(out_37));
candidate_38 c38(.in0(in0), .in1(in1), .result(out_38));
candidate_39 c39(.in0(in0), .in1(in1), .result(out_39));
candidate_40 c40(.in0(in0), .in1(in1), .result(out_40));
candidate_41 c41(.in0(in0), .in1(in1), .result(out_41));
candidate_42 c42(.in0(in0), .in1(in1), .result(out_42));
candidate_43 c43(.in0(in0), .in1(in1), .result(out_43));
candidate_44 c44(.in0(in0), .in1(in1), .result(out_44));
candidate_45 c45(.in0(in0), .in1(in1), .result(out_45));
candidate_46 c46(.in0(in0), .in1(in1), .result(out_46));
candidate_47 c47(.in0(in0), .in1(in1), .result(out_47));
endmodule
module candidate_0(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h0000000b;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_1(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000554;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_2(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h000007fc;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_3(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000154;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_4(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000155;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_5(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h0000002c;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_6(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h000001ff;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_7(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000055;
wire [31:0] n1 = in0 * n0;
wire [31:0] n2 = n1 + in1;
assign result = n2;
endmodule

module candidate_8(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h0000000b;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_9(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000554;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_10(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h000007fc;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_11(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000154;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_12(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000155;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_13(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h0000002c;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_14(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h000001ff;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_15(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'h00000000 + 32'h00000055;
wire [31:0] n1 = in0 * n0;
assign result = n1;
endmodule

module candidate_16(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h0000000b;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_17(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h00000554;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_18(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h000007fc;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_19(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h00000154;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_20(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h00000155;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_21(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h0000002c;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_22(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h000001ff;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_23(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = 32'h00000000 + 32'h00000055;
wire [31:0] n3 = n1 * n2;
assign result = n3;
endmodule

module candidate_24(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h0000000b;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_25(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h00000554;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_26(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h000007fc;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_27(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h00000154;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_28(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h00000155;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_29(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h0000002c;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_30(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h000001ff;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_31(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] n1 = 32'h00000000 + 32'h00000055;
wire [31:0] n2 = n0 * n1;
assign result = n2;
endmodule

module candidate_32(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000001;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_33(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h0000000c;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_34(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_35(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000018;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_36(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000003;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_37(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h0000001e;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_38(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000004;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_39(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 + in1;
wire [31:0] shift_n1 = 32'h00000008;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_40(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h00000001;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_41(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h0000000c;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_42(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h00000002;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_43(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h00000018;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_44(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h00000003;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_45(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h0000001e;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_46(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h00000004;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule

module candidate_47(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 - in1;
wire [31:0] shift_n1 = 32'h00000008;
wire [31:0] value_n1 = n0;
wire [31:0] stage_n1_0 = shift_n1[0] ? {{1{value_n1[31]}}, value_n1[31:1]} : value_n1;
wire [31:0] stage_n1_1 = shift_n1[1] ? {{2{stage_n1_0[31]}}, stage_n1_0[31:2]} : stage_n1_0;
wire [31:0] stage_n1_2 = shift_n1[2] ? {{4{stage_n1_1[31]}}, stage_n1_1[31:4]} : stage_n1_1;
wire [31:0] stage_n1_3 = shift_n1[3] ? {{8{stage_n1_2[31]}}, stage_n1_2[31:8]} : stage_n1_2;
wire [31:0] stage_n1_4 = shift_n1[4] ? {{16{stage_n1_3[31]}}, stage_n1_3[31:16]} : stage_n1_3;
wire [31:0] n1 = stage_n1_4;
wire [31:0] shift_n2 = 32'h0000001f;
wire [31:0] value_n2 = in1;
wire [31:0] stage_n2_0 = shift_n2[0] ? {{1{value_n2[31]}}, value_n2[31:1]} : value_n2;
wire [31:0] stage_n2_1 = shift_n2[1] ? {{2{stage_n2_0[31]}}, stage_n2_0[31:2]} : stage_n2_0;
wire [31:0] stage_n2_2 = shift_n2[2] ? {{4{stage_n2_1[31]}}, stage_n2_1[31:4]} : stage_n2_1;
wire [31:0] stage_n2_3 = shift_n2[3] ? {{8{stage_n2_2[31]}}, stage_n2_2[31:8]} : stage_n2_2;
wire [31:0] stage_n2_4 = shift_n2[4] ? {{16{stage_n2_3[31]}}, stage_n2_3[31:16]} : stage_n2_3;
wire [31:0] n2 = stage_n2_4;
wire [31:0] n3 = n1 - n2;
assign result = n3;
endmodule
