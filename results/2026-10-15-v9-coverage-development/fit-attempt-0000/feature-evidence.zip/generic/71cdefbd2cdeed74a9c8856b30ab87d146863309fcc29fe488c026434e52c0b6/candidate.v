module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = in0 & 32'h0000003f;
wire [31:0] n1 = n0 - in1;
wire [31:0] n2 = n1 * 32'h00000155;
wire [31:0] shift_n3 = 32'h00000002;
wire [31:0] value_n3 = n2;
wire [31:0] stage_n3_0 = shift_n3[0] ? {value_n3[30:0], 1'b0} : value_n3;
wire [31:0] stage_n3_1 = shift_n3[1] ? {stage_n3_0[29:0], 2'b0} : stage_n3_0;
wire [31:0] stage_n3_2 = shift_n3[2] ? {stage_n3_1[27:0], 4'b0} : stage_n3_1;
wire [31:0] stage_n3_3 = shift_n3[3] ? {stage_n3_2[23:0], 8'b0} : stage_n3_2;
wire [31:0] stage_n3_4 = shift_n3[4] ? {stage_n3_3[15:0], 16'b0} : stage_n3_3;
wire [31:0] n3 = stage_n3_4;
assign result = n3;
endmodule
