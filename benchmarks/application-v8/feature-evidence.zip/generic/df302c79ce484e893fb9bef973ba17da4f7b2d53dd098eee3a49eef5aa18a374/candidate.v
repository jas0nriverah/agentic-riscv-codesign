module candidate(input wire [31:0] in0, in1, output wire [31:0] result);
wire [31:0] n0 = 32'hb60b6000;
wire [31:0] n1 = n0 + 32'h000000b7;
assign result = n1;
endmodule
